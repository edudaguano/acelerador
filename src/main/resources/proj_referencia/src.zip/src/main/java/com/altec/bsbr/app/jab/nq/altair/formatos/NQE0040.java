package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0040")
public class NQE0040 {
@PsFieldString(name="COENTID", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COENTID;
@PsFieldString(name="COALERT", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALERT;
@PsFieldString(name="CDCENAR", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCENAR;
@PsFieldString(name="CDDETIN", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDDETIN;
@PsFieldString(name="CDOCOPE", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDOCOPE;
@PsFieldString(name="NUCNTR", length=32, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUCNTR;

public String getCOENTID() {
 return COENTID;
}
public void setCOENTID(String COENTID) {
 this.COENTID = COENTID;
}

public String getCOALERT() {
 return COALERT;
}
public void setCOALERT(String COALERT) {
 this.COALERT = COALERT;
}

public String getCDCENAR() {
 return CDCENAR;
}
public void setCDCENAR(String CDCENAR) {
 this.CDCENAR = CDCENAR;
}

public String getCDDETIN() {
 return CDDETIN;
}
public void setCDDETIN(String CDDETIN) {
 this.CDDETIN = CDDETIN;
}

public String getCDOCOPE() {
 return CDOCOPE;
}
public void setCDOCOPE(String CDOCOPE) {
 this.CDOCOPE = CDOCOPE;
}

public String getNUCNTR() {
 return NUCNTR;
}
public void setNUCNTR(String NUCNTR) {
 this.NUCNTR = NUCNTR;
}


}
