package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.AlertaCliCCPoupService;
import com.altec.bsbr.app.jab.nq.service.AlertaCliCCPoupWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class AlertaCliCCPoupEndPoint extends SpringBeanAutowiringSupport implements AlertaCliCCPoupWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(AlertaCliCCPoupEndPoint.class);

	@Autowired
	private AlertaCliCCPoupService alertacliccpoup;

	@WebMethod
	public String versao() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = alertacliccpoup.versao();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarCenario(String strCODENTI, String strCODALER, String strCODCENA) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = alertacliccpoup.consultarCenario(strCODENTI, strCODALER, strCODCENA);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarDadoProduto(String strCDENTI, String strCDALER, String strCDCENA, String strCDDTINT,
			String strCDPROD, String strNUCNTR) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = alertacliccpoup.consultarDadoProduto(strCDENTI, strCDALER, strCDCENA, strCDDTINT, strCDPROD,
					strNUCNTR);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarClientePJ(String strCOENTID, String strCOALER) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = alertacliccpoup.consultarClientePJ(strCOENTID, strCOALER);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarClientePF(String strCOENTID, String strCOALER) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = alertacliccpoup.consultarClientePF(strCOENTID, strCOALER);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarOperacao(String strCDENTID, String strCDALERT, String strCDCENAR, String strCDDETIN,
			String strCDDOCOP, String strNUCNTR) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = alertacliccpoup.consultarOperacao(strCDENTID, strCDALERT, strCDCENAR, strCDDETIN, strCDDOCOP,
					strNUCNTR);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
}
