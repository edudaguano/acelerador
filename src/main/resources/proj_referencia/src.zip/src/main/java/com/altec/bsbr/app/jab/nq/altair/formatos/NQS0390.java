package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0390")
public class NQS0390 {
@PsFieldNumber(name="CORGENP", length=2, defaultValue = "0" )
private Integer CORGENP;
@PsFieldString(name="COENSIP", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COENSIP;
@PsFieldNumber(name="CORGENQ", length=2, defaultValue = "0" )
private Integer CORGENQ;
@PsFieldString(name="COENQSI", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COENQSI;
@PsFieldNumber(name="DSENLEN", length=4, defaultValue = "0" )
private Integer DSENLEN;
@PsFieldString(name="DSENTE1", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENTE1;
@PsFieldString(name="DSENTE2", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENTE2;
@PsFieldString(name="DSENTE3", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENTE3;
@PsFieldString(name="DSENTE4", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENTE4;
@PsFieldString(name="DSENTE5", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENTE5;
@PsFieldString(name="DSENTE6", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENTE6;
@PsFieldString(name="DSENTE7", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENTE7;
@PsFieldString(name="DSENTE8", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENTE8;
public Integer getCORGENP() {
 return CORGENP;
}
public void setCORGENP(Integer cORGENP) {
CORGENP = cORGENP;
}
public String getCOENSIP() {
 return COENSIP;
}
public void setCOENSIP(String COENSIP) {
 this.COENSIP = COENSIP;
}
public Integer getCORGENQ() {
 return CORGENQ;
}
public void setCORGENQ(Integer cORGENQ) {
CORGENQ = cORGENQ;
}
public String getCOENQSI() {
 return COENQSI;
}
public void setCOENQSI(String COENQSI) {
 this.COENQSI = COENQSI;
}
public Integer getDSENLEN() {
 return DSENLEN;
}
public void setDSENLEN(Integer dSENLEN) {
DSENLEN = dSENLEN;
}
public String getDSENTE1() {
 return DSENTE1;
}
public void setDSENTE1(String DSENTE1) {
 this.DSENTE1 = DSENTE1;
}

public String getDSENTE2() {
 return DSENTE2;
}
public void setDSENTE2(String DSENTE2) {
 this.DSENTE2 = DSENTE2;
}

public String getDSENTE3() {
 return DSENTE3;
}
public void setDSENTE3(String DSENTE3) {
 this.DSENTE3 = DSENTE3;
}

public String getDSENTE4() {
 return DSENTE4;
}
public void setDSENTE4(String DSENTE4) {
 this.DSENTE4 = DSENTE4;
}

public String getDSENTE5() {
 return DSENTE5;
}
public void setDSENTE5(String DSENTE5) {
 this.DSENTE5 = DSENTE5;
}

public String getDSENTE6() {
 return DSENTE6;
}
public void setDSENTE6(String DSENTE6) {
 this.DSENTE6 = DSENTE6;
}

public String getDSENTE7() {
 return DSENTE7;
}
public void setDSENTE7(String DSENTE7) {
 this.DSENTE7 = DSENTE7;
}

public String getDSENTE8() {
 return DSENTE8;
}
public void setDSENTE8(String DSENTE8) {
 this.DSENTE8 = DSENTE8;
}


}
