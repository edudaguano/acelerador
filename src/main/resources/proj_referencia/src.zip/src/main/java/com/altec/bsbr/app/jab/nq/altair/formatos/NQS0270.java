package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0270")
public class NQS0270 {
@PsFieldString(name="COPROD", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COPROD;
@PsFieldString(name="CODEINP", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODEINP;
@PsFieldString(name="CODEINT", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODEINT;
@PsFieldNumber(name="COPRSPR", length=6, defaultValue = "0" )
private Integer COPRSPR;
@PsFieldString(name="NOPRSPR", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOPRSPR;
@PsFieldString(name="COAGENC", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COAGENC;
@PsFieldString(name="NOAGENC", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOAGENC;
@PsFieldString(name="NUCONTA", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUCONTA;
@PsFieldString(name="TPCONTA", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPCONTA;
@PsFieldString(name="NUCNTR", length=32, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUCNTR;
@PsFieldString(name="DTINCNT", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTINCNT;
@PsFieldString(name="DTFICNT", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTFICNT;
@PsFieldNumber(name="VLSLDDE", length=15, decimal=2, defaultValue = "0" )
private double VLSLDDE;
@PsFieldNumber(name="VLLIPRO", length=15, decimal=2, defaultValue = "0" )
private double VLLIPRO;
@PsFieldNumber(name="VLCONTR", length=15, decimal=2, defaultValue = "0" )
private double VLCONTR;
@PsFieldString(name="NOGEREN", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOGEREN;

public String getCOPROD() {
 return COPROD;
}
public void setCOPROD(String COPROD) {
 this.COPROD = COPROD;
}

public String getCODEINP() {
 return CODEINP;
}
public void setCODEINP(String CODEINP) {
 this.CODEINP = CODEINP;
}

public String getCODEINT() {
 return CODEINT;
}
public void setCODEINT(String CODEINT) {
 this.CODEINT = CODEINT;
}
public Integer getCOPRSPR() {
 return COPRSPR;
}
public void setCOPRSPR(Integer cOPRSPR) {
COPRSPR = cOPRSPR;
}
public String getNOPRSPR() {
 return NOPRSPR;
}
public void setNOPRSPR(String NOPRSPR) {
 this.NOPRSPR = NOPRSPR;
}

public String getCOAGENC() {
 return COAGENC;
}
public void setCOAGENC(String COAGENC) {
 this.COAGENC = COAGENC;
}

public String getNOAGENC() {
 return NOAGENC;
}
public void setNOAGENC(String NOAGENC) {
 this.NOAGENC = NOAGENC;
}

public String getNUCONTA() {
 return NUCONTA;
}
public void setNUCONTA(String NUCONTA) {
 this.NUCONTA = NUCONTA;
}

public String getTPCONTA() {
 return TPCONTA;
}
public void setTPCONTA(String TPCONTA) {
 this.TPCONTA = TPCONTA;
}

public String getNUCNTR() {
 return NUCNTR;
}
public void setNUCNTR(String NUCNTR) {
 this.NUCNTR = NUCNTR;
}

public String getDTINCNT() {
 return DTINCNT;
}
public void setDTINCNT(String DTINCNT) {
 this.DTINCNT = DTINCNT;
}

public String getDTFICNT() {
 return DTFICNT;
}
public void setDTFICNT(String DTFICNT) {
 this.DTFICNT = DTFICNT;
}
public double getVLSLDDE() {
 return VLSLDDE;
}
public void setVLSLDDE(double vLSLDDE) {
VLSLDDE = vLSLDDE;
}public double getVLLIPRO() {
 return VLLIPRO;
}
public void setVLLIPRO(double vLLIPRO) {
VLLIPRO = vLLIPRO;
}public double getVLCONTR() {
 return VLCONTR;
}
public void setVLCONTR(double vLCONTR) {
VLCONTR = vLCONTR;
}
public String getNOGEREN() {
 return NOGEREN;
}
public void setNOGEREN(String NOGEREN) {
 this.NOGEREN = NOGEREN;
}


}
