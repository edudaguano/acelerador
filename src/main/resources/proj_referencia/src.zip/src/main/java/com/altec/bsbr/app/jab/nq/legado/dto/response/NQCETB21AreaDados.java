package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name= "NQCETB21AreaDados")
public class NQCETB21AreaDados {
	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*
	//
	//01     NQCETB21-SAIDA.                                           
	
	//03    NQCETB21-S-DATA.                                          
	//
	@PsFieldString(name= "NQCETB21_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_CD_BANC_CLIE;//          05   NQCETB21-S-CD-BANC-CLIE       PIC  X(004).                
	
	//*       CODIGO DO BANCO                                           
	//
	@PsFieldString(name= "NQCETB21_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_CD_CLIE;//          05   NQCETB21-S-CD-CLIE            PIC  X(008).                
	
	//*       CODIGO DO CLIENTE                                         
	//
	@PsFieldString(name= "NQCETB21_S_DT_MOVI", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_DT_MOVI;//          05   NQCETB21-S-DT-MOVI            PIC  X(010).                
	
	//*       DATA DO MOVIMENTO                                         
	//
	@PsFieldString(name= "NQCETB21_S_NR_CNTR", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_NR_CNTR;//          05   NQCETB21-S-NR-CNTR            PIC  X(020).                
	
	//*       NUMERO DO CONTRATO                                        
	//
	@PsFieldString(name= "NQCETB21_S_NR_CNTA_OPER", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_NR_CNTA_OPER;//          05   NQCETB21-S-NR-CNTA-OPER       PIC  X(020).                
	
	//*       NUMERO DA CONTA DE OPERACAO                               
	//
	@PsFieldString(name= "NQCETB21_S_DT_FORZ", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_DT_FORZ;//          05   NQCETB21-S-DT-FORZ            PIC  X(010).                
	
	//*       DATA DA FORMALIZACAO                                      
	//
	@PsFieldString(name= "NQCETB21_S_DT_LIQU", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_DT_LIQU;//          05   NQCETB21-S-DT-LIQU            PIC  X(010).                
	
	//*       DATA DE LIQUIDACAO                                        
	//
	@PsFieldString(name= "NQCETB21_S_DT_INIC_VIGE", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_DT_INIC_VIGE;//          05   NQCETB21-S-DT-INIC-VIGE       PIC  X(010).                
	
	//*       DATA DE INICIO DA VIGENCIA                                
	//
	@PsFieldString(name= "NQCETB21_S_DT_FIM_VIGE", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_DT_FIM_VIGE;//          05   NQCETB21-S-DT-FIM-VIGE        PIC  X(010).                
	
	//*       DATA DE FIM DA VIGENCIA                                   
	//
	@PsFieldNumber(name= "NQCETB21_S_VL_LIQU", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB21_S_VL_LIQU;//          05   NQCETB21-S-VL-LIQU            PIC S9(015)V99.             
	
	//*       VALOR DA LIQUIDACAO                                       
	//
	@PsFieldNumber(name= "NQCETB21_S_VL_FINC", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB21_S_VL_FINC;//          05   NQCETB21-S-VL-FINC            PIC S9(015)V99.             
	
	//*       VALOR DO FINANCIAMENTO                                    
	//
	@PsFieldNumber(name= "NQCETB21_S_VL_ENTR_OFER", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB21_S_VL_ENTR_OFER;//          05   NQCETB21-S-VL-ENTR-OFER       PIC S9(015)V99.             
	
	//*       VALOR DA ENTRADA OFERECIDA                                
	//
	@PsFieldString(name= "NQCETB21_S_TP_TRAN", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_TP_TRAN;//          05   NQCETB21-S-TP-TRAN            PIC  X(001).                
	
	//*       TIPO DE TRANSACAO                                         
	//
	@PsFieldString(name= "NQCETB21_S_CD_BANC_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_CD_BANC_CNTR;//          05   NQCETB21-S-CD-BANC-CNTR       PIC  X(004).                
	
	//*       CODIGO DO BANCO DO CONTRATO                               
	//
	@PsFieldString(name= "NQCETB21_S_CD_AGEN_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_CD_AGEN_CNTR;//          05   NQCETB21-S-CD-AGEN-CNTR       PIC  X(004).                
	
	//*       CODIGO DA AGENCIA DO CONTRATO                             
	//
	@PsFieldString(name= "NQCETB21_S_NR_CNTR_A", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_NR_CNTR_A;//          05   NQCETB21-S-NR-CNTR-A          PIC  X(020).                
	
	//*       NUMERO DO CONTRATO ALTAIR                                 
	//
	@PsFieldString(name= "NQCETB21_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_CD_PROD_ALTAIR;//          05   NQCETB21-S-CD-PROD-ALTAIR     PIC  X(002).                
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name= "NQCETB21_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_CD_SUBP_ALTAIR;//          05   NQCETB21-S-CD-SUBP-ALTAIR     PIC  X(004).                
	
	//*       CODIGO DO SUBPRODUTO                                      
	//
	@PsFieldString(name= "NQCETB21_S_CD_MOED", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_CD_MOED;//          05   NQCETB21-S-CD-MOED            PIC  X(003).                
	
	//*       CODIGO DA MOEDA                                           
	//
	@PsFieldNumber(name= "NQCETB21_S_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB21_S_NR_SEQU_OPER;//          05   NQCETB21-S-NR-SEQU-OPER       PIC  9(003).                
	
	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	@PsFieldString(name= "NQCETB21_S_CD_IDEF_OPER", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_CD_IDEF_OPER;//          05   NQCETB21-S-CD-IDEF-OPER       PIC  X(020).                
	
	//*       CODIGO DA IDENTIFICACAO DA OPERACAO                       
	//
	@PsFieldString(name= "NQCETB21_S_NM_CLIE", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB21_S_NM_CLIE;//         05   NQCETB21-S-NM-CLIE            PIC  X(040).                
	
	public String getNQCETB21_S_CD_BANC_CLIE() {
		return NQCETB21_S_CD_BANC_CLIE;
	}

	public void setNQCETB21_S_CD_BANC_CLIE(String nQCETB21_S_CD_BANC_CLIE) {
		NQCETB21_S_CD_BANC_CLIE = nQCETB21_S_CD_BANC_CLIE;
	}

	public String getNQCETB21_S_CD_CLIE() {
		return NQCETB21_S_CD_CLIE;
	}

	public void setNQCETB21_S_CD_CLIE(String nQCETB21_S_CD_CLIE) {
		NQCETB21_S_CD_CLIE = nQCETB21_S_CD_CLIE;
	}

	public String getNQCETB21_S_DT_MOVI() {
		return NQCETB21_S_DT_MOVI;
	}

	public void setNQCETB21_S_DT_MOVI(String nQCETB21_S_DT_MOVI) {
		NQCETB21_S_DT_MOVI = nQCETB21_S_DT_MOVI;
	}

	public String getNQCETB21_S_NR_CNTR() {
		return NQCETB21_S_NR_CNTR;
	}

	public void setNQCETB21_S_NR_CNTR(String nQCETB21_S_NR_CNTR) {
		NQCETB21_S_NR_CNTR = nQCETB21_S_NR_CNTR;
	}

	public String getNQCETB21_S_NR_CNTA_OPER() {
		return NQCETB21_S_NR_CNTA_OPER;
	}

	public void setNQCETB21_S_NR_CNTA_OPER(String nQCETB21_S_NR_CNTA_OPER) {
		NQCETB21_S_NR_CNTA_OPER = nQCETB21_S_NR_CNTA_OPER;
	}

	public String getNQCETB21_S_DT_FORZ() {
		return NQCETB21_S_DT_FORZ;
	}

	public void setNQCETB21_S_DT_FORZ(String nQCETB21_S_DT_FORZ) {
		NQCETB21_S_DT_FORZ = nQCETB21_S_DT_FORZ;
	}

	public String getNQCETB21_S_DT_LIQU() {
		return NQCETB21_S_DT_LIQU;
	}

	public void setNQCETB21_S_DT_LIQU(String nQCETB21_S_DT_LIQU) {
		NQCETB21_S_DT_LIQU = nQCETB21_S_DT_LIQU;
	}

	public String getNQCETB21_S_DT_INIC_VIGE() {
		return NQCETB21_S_DT_INIC_VIGE;
	}

	public void setNQCETB21_S_DT_INIC_VIGE(String nQCETB21_S_DT_INIC_VIGE) {
		NQCETB21_S_DT_INIC_VIGE = nQCETB21_S_DT_INIC_VIGE;
	}

	public String getNQCETB21_S_DT_FIM_VIGE() {
		return NQCETB21_S_DT_FIM_VIGE;
	}

	public void setNQCETB21_S_DT_FIM_VIGE(String nQCETB21_S_DT_FIM_VIGE) {
		NQCETB21_S_DT_FIM_VIGE = nQCETB21_S_DT_FIM_VIGE;
	}

	public Double getNQCETB21_S_VL_LIQU() {
		return NQCETB21_S_VL_LIQU;
	}

	public void setNQCETB21_S_VL_LIQU(Double nQCETB21_S_VL_LIQU) {
		NQCETB21_S_VL_LIQU = nQCETB21_S_VL_LIQU;
	}

	public Double getNQCETB21_S_VL_FINC() {
		return NQCETB21_S_VL_FINC;
	}

	public void setNQCETB21_S_VL_FINC(Double nQCETB21_S_VL_FINC) {
		NQCETB21_S_VL_FINC = nQCETB21_S_VL_FINC;
	}

	public Double getNQCETB21_S_VL_ENTR_OFER() {
		return NQCETB21_S_VL_ENTR_OFER;
	}

	public void setNQCETB21_S_VL_ENTR_OFER(Double nQCETB21_S_VL_ENTR_OFER) {
		NQCETB21_S_VL_ENTR_OFER = nQCETB21_S_VL_ENTR_OFER;
	}

	public String getNQCETB21_S_TP_TRAN() {
		return NQCETB21_S_TP_TRAN;
	}

	public void setNQCETB21_S_TP_TRAN(String nQCETB21_S_TP_TRAN) {
		NQCETB21_S_TP_TRAN = nQCETB21_S_TP_TRAN;
	}

	public String getNQCETB21_S_CD_BANC_CNTR() {
		return NQCETB21_S_CD_BANC_CNTR;
	}

	public void setNQCETB21_S_CD_BANC_CNTR(String nQCETB21_S_CD_BANC_CNTR) {
		NQCETB21_S_CD_BANC_CNTR = nQCETB21_S_CD_BANC_CNTR;
	}

	public String getNQCETB21_S_CD_AGEN_CNTR() {
		return NQCETB21_S_CD_AGEN_CNTR;
	}

	public void setNQCETB21_S_CD_AGEN_CNTR(String nQCETB21_S_CD_AGEN_CNTR) {
		NQCETB21_S_CD_AGEN_CNTR = nQCETB21_S_CD_AGEN_CNTR;
	}

	public String getNQCETB21_S_NR_CNTR_A() {
		return NQCETB21_S_NR_CNTR_A;
	}

	public void setNQCETB21_S_NR_CNTR_A(String nQCETB21_S_NR_CNTR_A) {
		NQCETB21_S_NR_CNTR_A = nQCETB21_S_NR_CNTR_A;
	}

	public String getNQCETB21_S_CD_PROD_ALTAIR() {
		return NQCETB21_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB21_S_CD_PROD_ALTAIR(String nQCETB21_S_CD_PROD_ALTAIR) {
		NQCETB21_S_CD_PROD_ALTAIR = nQCETB21_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB21_S_CD_SUBP_ALTAIR() {
		return NQCETB21_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB21_S_CD_SUBP_ALTAIR(String nQCETB21_S_CD_SUBP_ALTAIR) {
		NQCETB21_S_CD_SUBP_ALTAIR = nQCETB21_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB21_S_CD_MOED() {
		return NQCETB21_S_CD_MOED;
	}

	public void setNQCETB21_S_CD_MOED(String nQCETB21_S_CD_MOED) {
		NQCETB21_S_CD_MOED = nQCETB21_S_CD_MOED;
	}

	public Long getNQCETB21_S_NR_SEQU_OPER() {
		return NQCETB21_S_NR_SEQU_OPER;
	}

	public void setNQCETB21_S_NR_SEQU_OPER(Long nQCETB21_S_NR_SEQU_OPER) {
		NQCETB21_S_NR_SEQU_OPER = nQCETB21_S_NR_SEQU_OPER;
	}

	public String getNQCETB21_S_CD_IDEF_OPER() {
		return NQCETB21_S_CD_IDEF_OPER;
	}

	public void setNQCETB21_S_CD_IDEF_OPER(String nQCETB21_S_CD_IDEF_OPER) {
		NQCETB21_S_CD_IDEF_OPER = nQCETB21_S_CD_IDEF_OPER;
	}

	public String getNQCETB21_S_NM_CLIE() {
		return NQCETB21_S_NM_CLIE;
	}

	public void setNQCETB21_S_NM_CLIE(String nQCETB21_S_NM_CLIE) {
		NQCETB21_S_NM_CLIE = nQCETB21_S_NM_CLIE;
	}	
}