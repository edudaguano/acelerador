package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0010")
public class NQE0010 {
@PsFieldString(name="COENTID", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COENTID;
@PsFieldNumber(name="TPUNIOR", length=4, defaultValue = "0" )
private Integer TPUNIOR;
@PsFieldNumber(name="CDUNIOR", length=4, defaultValue = "0" )
private Integer CDUNIOR;
@PsFieldString(name="COALERP", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALERP;
@PsFieldString(name="DTQUEST", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTQUEST;
@PsFieldString(name="DTGERPA", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTGERPA;
@PsFieldString(name="IDORDPA", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String IDORDPA;

public String getCOENTID() {
 return COENTID;
}
public void setCOENTID(String COENTID) {
 this.COENTID = COENTID;
}
public Integer getTPUNIOR() {
 return TPUNIOR;
}
public void setTPUNIOR(Integer tPUNIOR) {
TPUNIOR = tPUNIOR;
}public Integer getCDUNIOR() {
 return CDUNIOR;
}
public void setCDUNIOR(Integer cDUNIOR) {
CDUNIOR = cDUNIOR;
}
public String getCOALERP() {
 return COALERP;
}
public void setCOALERP(String COALERP) {
 this.COALERP = COALERP;
}

public String getDTQUEST() {
 return DTQUEST;
}
public void setDTQUEST(String DTQUEST) {
 this.DTQUEST = DTQUEST;
}

public String getDTGERPA() {
 return DTGERPA;
}
public void setDTGERPA(String DTGERPA) {
 this.DTGERPA = DTGERPA;
}

public String getIDORDPA() {
 return IDORDPA;
}
public void setIDORDPA(String IDORDPA) {
 this.IDORDPA = IDORDPA;
}


}
