package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface ClientesACService {
	public String consultarClientes(String strBanco, String strCliente, String StrUsuario) throws BusinessException;

	public String listarClientes(String strBanco, String strCliente, String StrUsuario) throws BusinessException;

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws BusinessException;
}
