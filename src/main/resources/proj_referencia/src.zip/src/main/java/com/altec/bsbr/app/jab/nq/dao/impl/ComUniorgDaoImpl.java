package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0500;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0240;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0500;
import com.altec.bsbr.app.jab.nq.dao.ComUniorgDao;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.altec.bsbr.fw.ps.parser.object.PsScreen;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ComUniorgDaoImpl implements ComUniorgDao {

	private final Logger LOGGER = LoggerFactory.getLogger(ComUniorgDaoImpl.class);

	@Autowired
	private AltairService altairService;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String versao() {
		// TODO: retornar versão do projeto
		return "";
	}

	public String consultaUniorg(String strCDUNIOR) {
		NQE0500 request = new NQE0500();
		request.setCDCHPSQ(strCDUNIOR.isEmpty() ? null : Integer.valueOf(strCDUNIOR));

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQD3", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0500.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

}
