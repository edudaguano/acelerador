package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;


@PsFormat(name= "NQCETB03LegadoRequest")
public class NQCETB03LegadoRequest {
// -*-NQCETB03
//   *----------------------------------------------------------------*
//   *    NOME    : TABELA NQ20003 - LISTA                            *
//   *    TIPO    : COMUNICACAO                                       *
//   *    BOOK    : NQCETB03                                          *
//   *    TAMANHO : 086 BYTES (ENTRADA)                               *
//   *----------------------------------------------------------------*
//                                                                     
//   *----------------------------------------------------------------*
//   *       AREA DE ENTRADA                                           
//   *----------------------------------------------------------------*
//                                                                     
//    01     NQCETB03-ENTRADA.                                         
//                                                                     
	@PsFieldString(name= "NQCETB3E_NM_PROG", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB3E_NM_PROG;//      05   NQCETB3E-NM-PROG              PIC  X(008).                

//   *       NOME DO PROGRAMA CHAMADO                                  
//                                                                     
	@PsFieldString(name= "NQCETB3E_NM_AREA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB3E_NM_AREA;//      05   NQCETB3E-NM-AREA              PIC  X(008).                

//   *       NOME DA AREA DE TS                                        
//                                                                     
	@PsFieldString(name= "NQCETB3E_SG_FCAO", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB3E_SG_FCAO;//      05   NQCETB3E-SG-FCAO              PIC  X(002).                

//   *       FUNCAO A SER EXECUTADA                                    
//   *       C = CONSULTAR                                             
//   *       L = LISTAR                                                
//   *       I = INCLUIR                                               
//   *       A = ALTERAR                                               
//   *       E = EXCLUIR                                               
//                                                                     
	@PsFieldNumber(name= "NQCETB3E_QT_TAMA_AREA", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long NQCETB3E_QT_TAMA_AREA;//      05   NQCETB3E-QT-TAMA-AREA         PIC  9(007).                

//   *       TAMANHO DA AREA DE TS                                     
//                                                                     
	@PsFieldString(name= "NQCETB3E_CD_USUA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB3E_CD_USUA;//      05   NQCETB3E-CD-USUA              PIC  X(008).                

//   *       CODIGO DO USUARIO                                         
//                                                                     
	@PsFieldNumber(name= "NQCETB3E_NR_SEQU_SIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB3E_NR_SEQU_SIST;//      05   NQCETB3E-NR-SEQU-SIST         PIC  9(004).                

//   *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                     
	@PsFieldNumber(name= "NQCETB3E_NR_SEQU_LIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB3E_NR_SEQU_LIST;//      05   NQCETB3E-NR-SEQU-LIST         PIC  9(004).                

//   *       NUMERO DE SEQUENCIA DA LISTA                              
//                                                                     
	@PsFieldString(name= "NQCETB3E_DS_LIST", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB3E_DS_LIST;//      05   NQCETB3E-DS-LIST              PIC  X(040).                

//   *       DESCRICAO DA LISTA                                        
//                                                                     
	@PsFieldNumber(name= "NQCETB3E_NR_SEQU_CAPO_SIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB3E_NR_SEQU_CAPO_SIST;//      05   NQCETB3E-NR-SEQU-CAPO-SIST    PIC  9(004).                

//   *       NUMERO DE SEQUENCIA DO CAMPO DO SISTEMA ASSOCIADO         
//                                                                     
	@PsFieldString(name= "NQCETB3E_IN_LIST_ATIV", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB3E_IN_LIST_ATIV;//      05   NQCETB3E-IN-LIST-ATIV         PIC  X(001).                

	public NQCETB03LegadoRequest() { }

	public String getNQCETB3E_NM_PROG() {
		return NQCETB3E_NM_PROG;
	}

	public void setNQCETB3E_NM_PROG(String nQCETB3E_NM_PROG) {
		NQCETB3E_NM_PROG = nQCETB3E_NM_PROG;
	}

	public String getNQCETB3E_NM_AREA() {
		return NQCETB3E_NM_AREA;
	}

	public void setNQCETB3E_NM_AREA(String nQCETB3E_NM_AREA) {
		NQCETB3E_NM_AREA = nQCETB3E_NM_AREA;
	}

	public String getNQCETB3E_SG_FCAO() {
		return NQCETB3E_SG_FCAO;
	}

	public void setNQCETB3E_SG_FCAO(String nQCETB3E_SG_FCAO) {
		NQCETB3E_SG_FCAO = nQCETB3E_SG_FCAO;
	}

	public Long getNQCETB3E_QT_TAMA_AREA() {
		return NQCETB3E_QT_TAMA_AREA;
	}

	public void setNQCETB3E_QT_TAMA_AREA(Long nQCETB3E_QT_TAMA_AREA) {
		NQCETB3E_QT_TAMA_AREA = nQCETB3E_QT_TAMA_AREA;
	}

	public String getNQCETB3E_CD_USUA() {
		return NQCETB3E_CD_USUA;
	}

	public void setNQCETB3E_CD_USUA(String nQCETB3E_CD_USUA) {
		NQCETB3E_CD_USUA = nQCETB3E_CD_USUA;
	}

	public Long getNQCETB3E_NR_SEQU_SIST() {
		return NQCETB3E_NR_SEQU_SIST;
	}

	public void setNQCETB3E_NR_SEQU_SIST(Long nQCETB3E_NR_SEQU_SIST) {
		NQCETB3E_NR_SEQU_SIST = nQCETB3E_NR_SEQU_SIST;
	}

	public Long getNQCETB3E_NR_SEQU_LIST() {
		return NQCETB3E_NR_SEQU_LIST;
	}

	public void setNQCETB3E_NR_SEQU_LIST(Long nQCETB3E_NR_SEQU_LIST) {
		NQCETB3E_NR_SEQU_LIST = nQCETB3E_NR_SEQU_LIST;
	}

	public String getNQCETB3E_DS_LIST() {
		return NQCETB3E_DS_LIST;
	}

	public void setNQCETB3E_DS_LIST(String nQCETB3E_DS_LIST) {
		NQCETB3E_DS_LIST = nQCETB3E_DS_LIST;
	}

	public Long getNQCETB3E_NR_SEQU_CAPO_SIST() {
		return NQCETB3E_NR_SEQU_CAPO_SIST;
	}

	public void setNQCETB3E_NR_SEQU_CAPO_SIST(Long nQCETB3E_NR_SEQU_CAPO_SIST) {
		NQCETB3E_NR_SEQU_CAPO_SIST = nQCETB3E_NR_SEQU_CAPO_SIST;
	}

	public String getNQCETB3E_IN_LIST_ATIV() {
		return NQCETB3E_IN_LIST_ATIV;
	}

	public void setNQCETB3E_IN_LIST_ATIV(String nQCETB3E_IN_LIST_ATIV) {
		NQCETB3E_IN_LIST_ATIV = nQCETB3E_IN_LIST_ATIV;
	}

	
}