package com.altec.bsbr.app.jab.nq.service.impl;

import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.EnqSuspeitaDao;
import com.altec.bsbr.app.jab.nq.service.EnqSuspeitaService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class EnqSuspeitaServiceImpl implements EnqSuspeitaService {
	private final Logger LOGGER = LoggerFactory.getLogger(EnqSuspeitaServiceImpl.class);
	@Autowired
	private EnqSuspeitaDao enqsuspeita;

	public String versao() throws BusinessException {
		return enqsuspeita.versao();
	}

	public String inserirEnquadramento(String strCDENTID, String strCDALERT, String strCDOREN1, String strCDENQ01,
			String strCDUSRES) throws BusinessException {
		return enqsuspeita.inserirEnquadramento(strCDENTID, strCDALERT, strCDOREN1, strCDENQ01, strCDUSRES);
	}

	public String listarOrgaoEnquadramento(String strCORGPAG) throws BusinessException {
		return enqsuspeita.listarOrgaoEnquadramento(strCORGPAG);
	}

	public String consultarEnquadramento(String strCORGENQ, String strCOENPAG) throws BusinessException {
		return enqsuspeita.consultarEnquadramento(strCORGENQ, strCOENPAG);
	}
}
