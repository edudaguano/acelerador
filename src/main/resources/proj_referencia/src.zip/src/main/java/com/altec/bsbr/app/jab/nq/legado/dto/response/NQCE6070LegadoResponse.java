package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE6070LegadoResponse {
	/*
// -*-NQCE6070
//         01      RECEIVE-COMMAREA.                                        
	@FixedLenghtField(position = 419, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_PGM_CHAMADA;//                 03  COMM-PGM-CHAMADA    PIC  X(008).                     

	@FixedLenghtField(position = 420, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOMEDATS;//                 03  COMM-NOMEDATS       PIC  X(010).                     

	@FixedLenghtField(position = 421, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_TAM_COMM;//                 03  COMM-TAM-COMM       PIC  9(007).                     

	@FixedLenghtField(position = 422, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOME_TS;//                 03  COMM-NOME-TS        PIC  X(008).                     

	@FixedLenghtField(position = 423, lenght = 9, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_MATRICULA;//                 03  COMM-MATRICULA      PIC  9(009).                     

	@FixedLenghtField(position = 424, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CINSTIT;//                 03  COMM-CINSTIT        PIC  9(003).                     

	@FixedLenghtField(position = 425, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CODAGENC;//                 03  COMM-CODAGENC       PIC  9(004).                     

	@FixedLenghtField(position = 426, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_STATUS;//                 03  COMM-STATUS         PIC  X(001).                     

	@FixedLenghtField(position = 427, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_TP_PES;//                 03  COMM-TP-PES         PIC  X(001).                     

	@FixedLenghtField(position = 428, lenght = 14, paddingAlign = Align.LEFT, paddingChar = '0')
	private String COMM_CPFCNPJ;//                 03  COMM-CPFCNPJ        PIC  9(014).                     

//         01      SEND-AREA.                                               
	@FixedLenghtField(position = 429, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN;//                 03  TS01-MENS-LEN       PIC S9(004) COMP VALUE +83.      

//                 03  TS01-AREA-MENSAGEM.                                  
	@FixedLenghtField(position = 430, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO;//                     05  TS01-RETORNO    PIC  9(003) VALUE ZEROS.         

	@FixedLenghtField(position = 431, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM;//                     05  TS01-MENSAGEM   PIC  X(080) VALUE SPACES.                                                                      

	@FixedLenghtField(position = 432, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_MENS_LEN;//                 03  TS02-MENS-LEN       PIC S9(004) COMP VALUE +103.     

//                 03  TS02-AREA-DETALHE.                                   
	@FixedLenghtField(position = 433, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NUMCONTA;//                     05 TS02-NUMCONTA    PIC  X(010).                     

	@FixedLenghtField(position = 434, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NOM_CLI;//                     05 TS02-NOM-CLI     PIC  X(050).                     

	@FixedLenghtField(position = 435, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_TP_PES;//                     05 TS02-TP-PES      PIC  X(001).                     

	@FixedLenghtField(position = 436, lenght = 18, paddingAlign = Align.LEFT, paddingChar = '0')
	private String TS02_CPFCNPJ;//                     05 TS02-CPFCNPJ     PIC  X(018).                     

	@FixedLenghtField(position = 437, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_DATA_CAD;//                     05 TS02-DATA-CAD    PIC  X(008).                     

	@FixedLenghtField(position = 438, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_DATA_FIN;//                     05 TS02-DATA-FIN    PIC  X(008).                     

	@FixedLenghtField(position = 439, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_STATUS;//                     05 TS02-STATUS      PIC  X(008).                     

	public NQCE6070LegadoResponse() { }
	public NQCE6070LegadoResponse(String comm_pgm_chamada, String comm_nomedats, Long comm_tam_comm, String comm_nome_ts, Long comm_matricula, Long comm_cinstit, Long comm_codagenc, String comm_status, String comm_tp_pes, String comm_cpfcnpj, String ts02_numconta, String ts02_nom_cli, String ts02_tp_pes, String ts02_cpfcnpj, String ts02_data_cad, String ts02_data_fin, String ts02_status) { 		this.COMM_PGM_CHAMADA = comm_pgm_chamada;
		this.COMM_NOMEDATS = comm_nomedats;
		this.COMM_TAM_COMM = comm_tam_comm;
		this.COMM_NOME_TS = comm_nome_ts;
		this.COMM_MATRICULA = comm_matricula;
		this.COMM_CINSTIT = comm_cinstit;
		this.COMM_CODAGENC = comm_codagenc;
		this.COMM_STATUS = comm_status;
		this.COMM_TP_PES = comm_tp_pes;
		this.COMM_CPFCNPJ = comm_cpfcnpj;
		this.TS01_MENS_LEN = +83;
		this.TS01_RETORNO = ZEROS;
		this.TS01_MENSAGEM = SPACES;
		this.TS02_MENS_LEN = +103;
		this.TS02_NUMCONTA = ts02_numconta;
		this.TS02_NOM_CLI = ts02_nom_cli;
		this.TS02_TP_PES = ts02_tp_pes;
		this.TS02_CPFCNPJ = ts02_cpfcnpj;
		this.TS02_DATA_CAD = ts02_data_cad;
		this.TS02_DATA_FIN = ts02_data_fin;
		this.TS02_STATUS = ts02_status; 
	}
	public String getCOMM_PGM_CHAMADA() { return this.COMM_PGM_CHAMADA; }
	public String getCOMM_NOMEDATS() { return this.COMM_NOMEDATS; }
	public Long getCOMM_TAM_COMM() { return this.COMM_TAM_COMM; }
	public String getCOMM_NOME_TS() { return this.COMM_NOME_TS; }
	public Long getCOMM_MATRICULA() { return this.COMM_MATRICULA; }
	public Long getCOMM_CINSTIT() { return this.COMM_CINSTIT; }
	public Long getCOMM_CODAGENC() { return this.COMM_CODAGENC; }
	public String getCOMM_STATUS() { return this.COMM_STATUS; }
	public String getCOMM_TP_PES() { return this.COMM_TP_PES; }
	public String getCOMM_CPFCNPJ() { return this.COMM_CPFCNPJ; }
	public Long getTS01_MENS_LEN() { return this.TS01_MENS_LEN; }
	public Long getTS01_RETORNO() { return this.TS01_RETORNO; }
	public String getTS01_MENSAGEM() { return this.TS01_MENSAGEM; }
	public Long getTS02_MENS_LEN() { return this.TS02_MENS_LEN; }
	public String getTS02_NUMCONTA() { return this.TS02_NUMCONTA; }
	public String getTS02_NOM_CLI() { return this.TS02_NOM_CLI; }
	public String getTS02_TP_PES() { return this.TS02_TP_PES; }
	public String getTS02_CPFCNPJ() { return this.TS02_CPFCNPJ; }
	public String getTS02_DATA_CAD() { return this.TS02_DATA_CAD; }
	public String getTS02_DATA_FIN() { return this.TS02_DATA_FIN; }
	public String getTS02_STATUS() { return this.TS02_STATUS; }
	public void setCOMM_PGM_CHAMADA(String comm_pgm_chamada) { this.COMM_PGM_CHAMADA = comm_pgm_chamada; }
	public void setCOMM_NOMEDATS(String comm_nomedats) { this.COMM_NOMEDATS = comm_nomedats; }
	public void setCOMM_TAM_COMM(Long comm_tam_comm) { this.COMM_TAM_COMM = comm_tam_comm; }
	public void setCOMM_NOME_TS(String comm_nome_ts) { this.COMM_NOME_TS = comm_nome_ts; }
	public void setCOMM_MATRICULA(Long comm_matricula) { this.COMM_MATRICULA = comm_matricula; }
	public void setCOMM_CINSTIT(Long comm_cinstit) { this.COMM_CINSTIT = comm_cinstit; }
	public void setCOMM_CODAGENC(Long comm_codagenc) { this.COMM_CODAGENC = comm_codagenc; }
	public void setCOMM_STATUS(String comm_status) { this.COMM_STATUS = comm_status; }
	public void setCOMM_TP_PES(String comm_tp_pes) { this.COMM_TP_PES = comm_tp_pes; }
	public void setCOMM_CPFCNPJ(String comm_cpfcnpj) { this.COMM_CPFCNPJ = comm_cpfcnpj; }
	public void setTS01_MENS_LEN(Long ts01_mens_len) { this.TS01_MENS_LEN = ts01_mens_len; }
	public void setTS01_RETORNO(Long ts01_retorno) { this.TS01_RETORNO = ts01_retorno; }
	public void setTS01_MENSAGEM(String ts01_mensagem) { this.TS01_MENSAGEM = ts01_mensagem; }
	public void setTS02_MENS_LEN(Long ts02_mens_len) { this.TS02_MENS_LEN = ts02_mens_len; }
	public void setTS02_NUMCONTA(String ts02_numconta) { this.TS02_NUMCONTA = ts02_numconta; }
	public void setTS02_NOM_CLI(String ts02_nom_cli) { this.TS02_NOM_CLI = ts02_nom_cli; }
	public void setTS02_TP_PES(String ts02_tp_pes) { this.TS02_TP_PES = ts02_tp_pes; }
	public void setTS02_CPFCNPJ(String ts02_cpfcnpj) { this.TS02_CPFCNPJ = ts02_cpfcnpj; }
	public void setTS02_DATA_CAD(String ts02_data_cad) { this.TS02_DATA_CAD = ts02_data_cad; }
	public void setTS02_DATA_FIN(String ts02_data_fin) { this.TS02_DATA_FIN = ts02_data_fin; }
	public void setTS02_STATUS(String ts02_status) { this.TS02_STATUS = ts02_status; }
	*/
}