package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0030")
public class NQS0030 {
@PsFieldString(name="DTNASCI", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTNASCI;
@PsFieldString(name="DSPAINA", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSPAINA;
@PsFieldString(name="DSNASCI", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSNASCI;
@PsFieldString(name="NOMAE", length=60, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOMAE;
@PsFieldString(name="NOPAI", length=60, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOPAI;
@PsFieldString(name="ESCIVIL", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ESCIVIL;
@PsFieldString(name="NOCONJ", length=60, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOCONJ;
@PsFieldString(name="DSCONPE", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCONPE;
@PsFieldString(name="DSUNINE", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSUNINE;
@PsFieldString(name="COSITUA", length=2, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COSITUA;
@PsFieldString(name="NOSITUA", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOSITUA;
@PsFieldString(name="DTCLIDE", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTCLIDE;
@PsFieldString(name="DTULTAL", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTULTAL;
@PsFieldString(name="NOEMPRE", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOEMPRE;
@PsFieldString(name="COCNAE", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COCNAE;
@PsFieldString(name="DSATECO", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSATECO;
@PsFieldNumber(name="VLPATRI", length=15, decimal=2, defaultValue = "0" )
private double VLPATRI;
@PsFieldString(name="DSTICOM", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSTICOM;
@PsFieldString(name="DTPATRI", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTPATRI;
@PsFieldString(name="ICIMPED", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICIMPED;
@PsFieldString(name="ICPEP", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICPEP;

public String getDTNASCI() {
 return DTNASCI;
}
public void setDTNASCI(String DTNASCI) {
 this.DTNASCI = DTNASCI;
}

public String getDSPAINA() {
 return DSPAINA;
}
public void setDSPAINA(String DSPAINA) {
 this.DSPAINA = DSPAINA;
}

public String getDSNASCI() {
 return DSNASCI;
}
public void setDSNASCI(String DSNASCI) {
 this.DSNASCI = DSNASCI;
}

public String getNOMAE() {
 return NOMAE;
}
public void setNOMAE(String NOMAE) {
 this.NOMAE = NOMAE;
}

public String getNOPAI() {
 return NOPAI;
}
public void setNOPAI(String NOPAI) {
 this.NOPAI = NOPAI;
}

public String getESCIVIL() {
 return ESCIVIL;
}
public void setESCIVIL(String ESCIVIL) {
 this.ESCIVIL = ESCIVIL;
}

public String getNOCONJ() {
 return NOCONJ;
}
public void setNOCONJ(String NOCONJ) {
 this.NOCONJ = NOCONJ;
}

public String getDSCONPE() {
 return DSCONPE;
}
public void setDSCONPE(String DSCONPE) {
 this.DSCONPE = DSCONPE;
}

public String getDSUNINE() {
 return DSUNINE;
}
public void setDSUNINE(String DSUNINE) {
 this.DSUNINE = DSUNINE;
}

public String getCOSITUA() {
 return COSITUA;
}
public void setCOSITUA(String COSITUA) {
 this.COSITUA = COSITUA;
}

public String getNOSITUA() {
 return NOSITUA;
}
public void setNOSITUA(String NOSITUA) {
 this.NOSITUA = NOSITUA;
}

public String getDTCLIDE() {
 return DTCLIDE;
}
public void setDTCLIDE(String DTCLIDE) {
 this.DTCLIDE = DTCLIDE;
}

public String getDTULTAL() {
 return DTULTAL;
}
public void setDTULTAL(String DTULTAL) {
 this.DTULTAL = DTULTAL;
}

public String getNOEMPRE() {
 return NOEMPRE;
}
public void setNOEMPRE(String NOEMPRE) {
 this.NOEMPRE = NOEMPRE;
}

public String getCOCNAE() {
 return COCNAE;
}
public void setCOCNAE(String COCNAE) {
 this.COCNAE = COCNAE;
}

public String getDSATECO() {
 return DSATECO;
}
public void setDSATECO(String DSATECO) {
 this.DSATECO = DSATECO;
}
public double getVLPATRI() {
 return VLPATRI;
}
public void setVLPATRI(double vLPATRI) {
VLPATRI = vLPATRI;
}
public String getDSTICOM() {
 return DSTICOM;
}
public void setDSTICOM(String DSTICOM) {
 this.DSTICOM = DSTICOM;
}

public String getDTPATRI() {
 return DTPATRI;
}
public void setDTPATRI(String DTPATRI) {
 this.DTPATRI = DTPATRI;
}

public String getICIMPED() {
 return ICIMPED;
}
public void setICIMPED(String ICIMPED) {
 this.ICIMPED = ICIMPED;
}

public String getICPEP() {
 return ICPEP;
}
public void setICPEP(String ICPEP) {
 this.ICPEP = ICPEP;
}


}
