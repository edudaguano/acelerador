package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface HistoricoService {

	public String recuperaDadosAlt(String intConceito1, String intConceito2) throws BusinessException;

	public String recuperaDadosInc(String intHistorico, String intAgrupamento, String intConceito1, String intConceito2) throws BusinessException;

	public String consultarLista(String intOpcao, String intBanco, String intProduto, String intPeriodicidade) throws BusinessException;

	public String consultarBancoProdPeriod() throws BusinessException;

	public String IncluirHistorico(String intOpcao, String intBanco, String intPeriodicidade, String intProduto,
			String intCodHist, String intHistorico, String strUsuario, String strDescricao, String strConceito1,
			String strConceito2) throws BusinessException;

	public String AlterarHistorico(String intOpcao, String intBanco, String intPeriodicidade, String intProduto,
			String intCodHist, String intHistorico, String strUsuario, String strDescricao, String strConceito1, String strConceito2) throws BusinessException;

	public String ExclusaoItem(String intOpcao, String intBanco, String intProduto, String intPeriodicidade,
			String intCodHist, String intHistorico, String strUsuario) throws BusinessException;
}
