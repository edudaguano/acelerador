/*
package com.altec.bsbr.app.jab.nq.legado.messageGatewayImpl;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Queue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.ldaopsu.legado.dto.request.LDAOPSULegadoRequest;
import com.altec.bsbr.app.jab.ldaopsu.legado.dto.request.LDAOPSULegadoResponse;
import com.altec.bsbr.app.jab.ldaopsu.legado.dto.request.LDAOPSUMessagingGateway;
import com.altec.bsbr.app.jab.ldaopsu.legado.AbstractLegadoMessassingGatewayImpl;
import com.altec.bsbr.fw.jms.legado.LegadoUser;
@Service
public class LDAOPSUMessagingGatewayService extends AbstractLegadoMessassingGatewayImpl<LDAOPSULegadoRequest> implements LDAOPSUMessagingGateway {
	
	@Autowired
	@Qualifier("requestQueueLegado")
	private Queue requestQueue;

	@Autowired
	@Qualifier("responseQueueLegado")
	private Queue responseQueue;

	@Autowired
	@Qualifier("jmsConnectionFactoryLegado")
	private ConnectionFactory connectionFactory;

	@Autowired
	@Qualifier("requestMultiQueueLegado")
	private Queue requestMultiQueue;

	@Autowired
	@Qualifier("responseMultiQueueLegado")
	private Queue responseMultiQueue;

	public Class<?> getReplyFormat() {
		return LDAOPSULegadoResponse.class;
	}

	@Override
	public void setUser(LegadoUser u) {
		super.setLegadoUser(u);
	}

	@Override
	public ConnectionFactory getConnectionFactory() {
		return this.connectionFactory;
	}

	@Override
	protected String getIdCanal() {
		return "";
	}

	@Override
	protected String getIdTransacao() {
		return "LDAOPSU";
	}

	@Override
	protected String getNivelLog() {
		return "00";
	}

	@Override
	protected String getReplyToQClte() {
		try {
			String{} queueSplit = responseMultiQueue.getQueueName().split(Pattern.quote("///")); // queue:///<fila>
		} catch (JMSException e) {
			e.printStackTrace();
			return "";
		}
	}

	@Override
	public Queue getRequestMultiQueue() {
		return requestMultiQueue;
	}

	@Override
	public Queue getResponseMultiQueue() {
		return responseMultiQueue;
	}	

	@Override
	public Queue getRequestQueue() {
		return requestQueue;
	}

	@Override
	public Queue getResponseQueue() {
		return responseQueue;
	}		

	@Override
	protected String getTipoMensagem() {
		return "R";
	}

	@Override
	protected String getTipoMensaje() {
		return "R";
	}

	@Override
	protected String getTipoProcesso() {
		return " ";
	}

	@Override
	protected int getPosicaoTsEntrada() {
		return 0;
	}

	@Override
	protected int getPosicaoTsRetorno() {
		return 0;
	}
}*/