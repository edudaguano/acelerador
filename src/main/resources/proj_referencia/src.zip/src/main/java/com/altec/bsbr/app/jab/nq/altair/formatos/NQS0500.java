package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0500")
public class NQS0500 {
@PsFieldNumber(name="CDUNIOR", length=4, defaultValue = "0" )
private Integer CDUNIOR;
@PsFieldString(name="DSUNIOR", length=45, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSUNIOR;
public Integer getCDUNIOR() {
 return CDUNIOR;
}
public void setCDUNIOR(Integer cDUNIOR) {
CDUNIOR = cDUNIOR;
}
public String getDSUNIOR() {
 return DSUNIOR;
}
public void setDSUNIOR(String DSUNIOR) {
 this.DSUNIOR = DSUNIOR;
}


}
