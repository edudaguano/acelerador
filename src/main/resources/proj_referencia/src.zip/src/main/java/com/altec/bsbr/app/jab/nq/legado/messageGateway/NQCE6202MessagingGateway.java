package com.altec.bsbr.app.jab.nq.legado.messageGateway;

import java.util.List;

import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCE6202LegadoRequest;
import com.altec.bsbr.fw.jms.legado.LegadoException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;

public interface NQCE6202MessagingGateway {
	
	LegadoResult sendMessageLegado(NQCE6202LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageMultiLegado(NQCE6202LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageListLegado(List<NQCE6202LegadoRequest> arg0) throws LegadoException;

}