package com.altec.bsbr.app.jab.nq.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0030;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0130;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0260;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0300;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0340;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0030;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0130;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0260;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0300;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0340;
import com.altec.bsbr.app.jab.nq.dao.ComOpSusInfCliDao;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ComOpSusInfCliDaoImpl implements ComOpSusInfCliDao {
	private final Logger LOGGER = LoggerFactory.getLogger(ComOpSusInfCliDaoImpl.class);

	@Autowired
	private AltairService altairService;

	public String versao() {
		return "";
	}

	public String consultarAgencia(String strNUENTID, String strNUAGENC, String strNUCONTA, String strCOCLIEN) {
		NQE0130 request = new NQE0130();
		request.setNUENTID(strNUENTID);
		request.setNUAGENC(strNUAGENC);
		request.setNUCONTA(strNUCONTA);
		request.setCOCLIEN(strCOCLIEN);
		
		try {
			ResponseDto resp  = altairService.executar(PsFormatEnum.PS7, "NQB4", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0130.class));
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarSocio(String strPENUMPE) {
		NQE0260 request = new NQE0260();
		request.setPENUMPE(strPENUMPE);

		try {
			ResponseDto resp  = altairService.executar(PsFormatEnum.PS7, "NQC2", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0260.class));
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarClientePJ(String strCODENT, String strTPDOCTO, String strNUDOCTO, String strCDALERT) {
		NQE0300 request = new NQE0300();
		request.setCODENT(strCODENT);
		request.setTPDOCTO(strTPDOCTO);
		request.setNUDOCTO(strNUDOCTO);
		request.setCDALERT(strCDALERT);

		try {
			ResponseDto resp  = altairService.executar(PsFormatEnum.PS7, "NQA5", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0300.class));
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarClientePF(String strTPDOCTO, String strNUDOCTO, String strCDENTID, String strCDALERT) {
		NQE0030 request = new NQE0030();
		request.setTPDOCTO(strTPDOCTO);
		request.setNUDOCTO(strNUDOCTO);
		request.setCDENTID(strCDENTID);
		request.setCDALERT(strCDALERT);

		try {
			ResponseDto resp  = altairService.executar(PsFormatEnum.PS7, "NQA3", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0030.class));
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarClientePE(String strCOENTID, String strTPDOCTO, String strNUDOCTO) {
		NQE0340 request = new NQE0340();
		request.setCOENTID(strCOENTID);
		request.setTPDOCTO(strTPDOCTO);
		request.setNUDOCTO(strNUDOCTO);

		try {
			ResponseDto resp  = altairService.executar(PsFormatEnum.PS7, "NQC6", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0340.class));
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String log(String strTexto) {
		return "";
	}

}