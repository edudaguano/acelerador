package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.SistemasService;
import com.altec.bsbr.app.jab.nq.service.SistemasWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class SistemasEndPoint extends SpringBeanAutowiringSupport implements SistemasWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(SistemasEndPoint.class);
	@Autowired
	private SistemasService sistemas;

	@WebMethod
	public String listarSistema(String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = sistemas.listarSistema(strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarSistema(String strCodSist, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = sistemas.consultarSistema(strCodSist, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirSistema(String strCodSist, String strSigla, String strNmFuncao, String strDesc,
			String strAtivo, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = sistemas.incluirSistema(strCodSist, strSigla, strNmFuncao, strDesc, strAtivo, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarSistema(String strCodSist, String strSigla, String strNmFuncao, String strDesc,
			String strAtivo, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = sistemas.alterarSistema(strCodSist, strSigla, strNmFuncao, strDesc, strAtivo, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String excluirSistema(String strCodSist, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = sistemas.excluirSistema(strCodSist, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
	
	@WebMethod 
	public String inicializarinputArea(String tNQ_NQAT2001_NQCETB01_ENTRADA) throws WebServiceException{ 
		String retorno = ""; 
		try{ 
			LOGGER.info("Executar Teste Unitario");
			retorno = sistemas.inicializarinputArea(tNQ_NQAT2001_NQCETB01_ENTRADA);
		} catch (Exception e){
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1); 
		}
		return retorno;
	}
	
	@WebMethod 
	public String fnAddCaracter(String vlr,String tp, String tam) throws WebServiceException{ 
		String retorno = ""; 
		try{ 
			LOGGER.info("Executar Teste Unitario");
			retorno = sistemas.fnAddCaracter(vlr, tp, tam);
		} catch (Exception e){
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1); 
		} 
		return retorno; 
	}
}
