package com.altec.bsbr.app.jab.nq.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0090;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0320;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0380;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0390;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0400;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0090;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0320;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0380;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0390;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0400;
import com.altec.bsbr.app.jab.nq.dao.AlertaCliAnRespDao;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class AlertaCliAnRespDaoImpl implements AlertaCliAnRespDao {

	private final Logger LOGGER = LoggerFactory.getLogger(AlertaCliAnRespDaoImpl.class);

	@Autowired
	private AltairService altairService;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String versao() {
		return "";
	}

	public String recuperarPergunta(String strCOENTID, String strCOALERT) {
		NQE0320 request = new NQE0320();
		request.setCOALERT(strCOALERT);
		request.setCOENTID(strCOENTID);

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQC4", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0320.class));
			
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarHistorico(String strCOENTID, String strCOALERT, String strDTCOMIT, String strNUSEQUE) {
		NQE0090 request = new NQE0090();
		request.setCOALERT(strCOALERT);
		request.setCOENTID(strCOENTID);
		request.setDTCOMIT(strDTCOMIT);
		request.setNUSEQUE(Integer.parseInt(strNUSEQUE));

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQAA", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0090.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarJustificativa(String strCOENTI, String strCOALER) {
		NQE0380 request = new NQE0380();
		request.setCOALER(strCOALER);
		request.setCOENTI(strCOENTI);

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQCC", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0380.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarEnquadramento(String strCOENTID, String strCOALERT, String strCOORGEN, String strCOENQSI) {
		NQE0390 request = new NQE0390();
		request.setCOALERT(strCOALERT);
		request.setCOENQSI(strCOENQSI);
		request.setCOENTID(strCOENTID);
		request.setCOORGEN(Integer.parseInt(strCOORGEN));

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQD1", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0390.class));
			
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultaOrgaoEnquadramento(String strCORGENQ) {
		NQE0400 request = new NQE0400();
		request.setCORGENQ(Integer.parseInt(strCORGENQ));

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQD2", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0400.class));
			
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

}
