package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0130")
public class NQS0130 {
@PsFieldString(name="NOAGENC", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOAGENC;

public String getNOAGENC() {
 return NOAGENC;
}
public void setNOAGENC(String NOAGENC) {
 this.NOAGENC = NOAGENC;
}


}
