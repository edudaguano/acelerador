package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0060")
public class NQS0060 {
@PsFieldNumber(name="CORGEPA", length=2, defaultValue = "0" )
private Integer CORGEPA;
@PsFieldString(name="COENDRP", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COENDRP;
@PsFieldNumber(name="COORENE", length=2, defaultValue = "0" )
private Integer COORENE;
@PsFieldString(name="NMORGEN", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NMORGEN;
@PsFieldNumber(name="COENQDR", length=4, defaultValue = "0" )
private Integer COENQDR;
@PsFieldString(name="DSENQD1", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENQD1;
@PsFieldString(name="DSENQD2", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENQD2;
@PsFieldString(name="DSENQD3", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENQD3;
@PsFieldString(name="DSENQD4", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENQD4;
@PsFieldString(name="DSENQD5", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENQD5;
@PsFieldString(name="DSENQD6", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENQD6;
@PsFieldString(name="DSENQD7", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENQD7;
@PsFieldString(name="DSENQD8", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSENQD8;
public Integer getCORGEPA() {
 return CORGEPA;
}
public void setCORGEPA(Integer cORGEPA) {
CORGEPA = cORGEPA;
}
public String getCOENDRP() {
 return COENDRP;
}
public void setCOENDRP(String COENDRP) {
 this.COENDRP = COENDRP;
}
public Integer getCOORENE() {
 return COORENE;
}
public void setCOORENE(Integer cOORENE) {
COORENE = cOORENE;
}
public String getNMORGEN() {
 return NMORGEN;
}
public void setNMORGEN(String NMORGEN) {
 this.NMORGEN = NMORGEN;
}
public Integer getCOENQDR() {
 return COENQDR;
}
public void setCOENQDR(Integer cOENQDR) {
COENQDR = cOENQDR;
}
public String getDSENQD1() {
 return DSENQD1;
}
public void setDSENQD1(String DSENQD1) {
 this.DSENQD1 = DSENQD1;
}

public String getDSENQD2() {
 return DSENQD2;
}
public void setDSENQD2(String DSENQD2) {
 this.DSENQD2 = DSENQD2;
}

public String getDSENQD3() {
 return DSENQD3;
}
public void setDSENQD3(String DSENQD3) {
 this.DSENQD3 = DSENQD3;
}

public String getDSENQD4() {
 return DSENQD4;
}
public void setDSENQD4(String DSENQD4) {
 this.DSENQD4 = DSENQD4;
}

public String getDSENQD5() {
 return DSENQD5;
}
public void setDSENQD5(String DSENQD5) {
 this.DSENQD5 = DSENQD5;
}

public String getDSENQD6() {
 return DSENQD6;
}
public void setDSENQD6(String DSENQD6) {
 this.DSENQD6 = DSENQD6;
}

public String getDSENQD7() {
 return DSENQD7;
}
public void setDSENQD7(String DSENQD7) {
 this.DSENQD7 = DSENQD7;
}

public String getDSENQD8() {
 return DSENQD8;
}
public void setDSENQD8(String DSENQD8) {
 this.DSENQD8 = DSENQD8;
}


}
