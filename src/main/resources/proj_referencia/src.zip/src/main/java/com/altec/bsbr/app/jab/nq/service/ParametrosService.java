package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface ParametrosService {

	public String confirmarRegras(String acao, String intProduto, String intCodBanco, String intPeriodo,
			String intAgrupa, String lngAtividade, String lngOcupacao, String intSegmento, String dblValor,
			String strUsuario) throws BusinessException ;

	public String incluirValorOpSensib(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdSelecionada, String dblValor, String strUsuario) throws BusinessException;

	public String alterarValorOpSensib(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdSelecionada, String dblValor, String strUsuario) throws BusinessException;

	public String consultarBancoPeriodoProdAplic() throws BusinessException;

	public String consultarValorOpSensivel(String intBanco, String intAplicativo, String intPeriodo, String intProduto) throws BusinessException;

	public String consultarAgencias(String intBanco, String intAgencia, String strFuncao) throws BusinessException;

	public String consultarApoio(String intTabela, String number) throws BusinessException;

	public String consultarAtvEconomica(String intBanco, String intPeriodicidade) throws BusinessException;

	public String consultarRegras(String intBanco, String intProduto, String intPeriodicidade) throws BusinessException;

	public String consultarTipoAgrupamento(String intBanco, String intProduto, String intPeriodicidade) throws BusinessException;

	public String incluirAgencia(String intCodBancoSelecionado, String intCodAgSelecionada, String TpAgrupaTruncado,
			String strUsuario, String dblValor) throws BusinessException;

	public String alterarAgencia(String intCodBancoSelecionado, String intCodAgSelecionada, String TpAgrupaTruncado,
			String strUsuario, String dblValor) throws BusinessException;

	public String incluirApoio(String intCodTabelaSelecionada, String strCodItem, String strDescricao,
			String strDescResumida, String strStatus, String strUsuario) throws BusinessException;

	public String alterarApoio(String intCodTabelaSelecionada, String strCodItem, String strDescricao,
			String strDescResumida, String strStatus, String strUsuario) throws BusinessException;

	public String incluirAtividadeEconomica(String intCodBancoSelecionado, String intCodPeriododSelecionada,
			String intAtvSelecionada, String strUsuario, String strDescricao) throws BusinessException;

	public String carregaCombo(String intCodBancoSelecionado) throws BusinessException;

	public String incluirCtrlProcessamento(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdutoSelecionada, String auxData, String auxDataAnt,
			String strDescAplicativo, String strUsuario) throws BusinessException;

	public String alterarCtrlProcessamento(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdutoSelecionada, String auxData, String auxDataAnt,
			String strDescAplicativo, String strUsuario, String strStatus) throws BusinessException;

	public String recuperaProduto(String intCodBancoSelecionado) throws BusinessException;

	public String alterarFiltroSensib(String codTabela, String strCodItem, String strDescricao, String strDescResumida,
			String strStatus, String strUsuario) throws BusinessException;

	public String incluirPais(
			String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada,
			String intPaisSelecionado, /* right("0000000000" & intPaisSelecionado,10), _ */
			String intTipoPaisSelecionado, /* right("000" & intTipoPaisSelecionado,3), _ */
			String strUsuario, String strDescPais) throws BusinessException;

	public String alterarPais(
			String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada,
			String intPaisSelecionado, /* right("0000000000" & intPaisSelecionado,10), */
			String intTipoPaisSelecionado, /* right("000" & intTipoPaisSelecionado,3), */
			String strUsuario, String strDescPais) throws BusinessException;

	public String recuperaPaisesTipo() throws BusinessException;

	public String incluirReceptores(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodSegmentoSelecionado, /* right(intCodSegmentoSelecionado,3), */
			String intSequencia, String strNomeRecepItem, String strPrefEmailItem, String intCodSufixoSelecionado,
			String intCodTpEnvioSelecionado, String strUsuario) throws BusinessException;

	public String alterarReceptores(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodSegmentoSelecionado, String sequencia, String strNomeRecepItem, String strPrefEmailItem,
			String intCodSufixoSelecionado, String intCodTpEnvioSelecionado, String strUsuario) throws BusinessException;

	public String consultarSegmSufTpEnvio(String intCodBancoSelecionado) throws BusinessException;

	public String verificaStatusProduto(String intCodBancoSelecionado) throws BusinessException;

	public String recuperaTpHistAtvOcup(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipo1, String intTipo2, String intTipo3) throws BusinessException;

	public String recuperaAtvOcup(String intCodBancoSelecionado) throws BusinessException;

	public String incluirTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipo, String strUsuario, String strDescAgrupamento) throws BusinessException;

	public String recuperarTipoCombo(String banco) throws BusinessException;

	public String incluirValorTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipoSelecionado, String dblValor, String strUsuario,
			String strDescricao) throws BusinessException;

	public String alterarValorTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipoSelecionado, String dblValor, String strUsuario,
			String strDescricao) throws BusinessException;

	public String excluirAgencia(String intCodBancoItem, String intCodAgenciaItem, String strTipoAgrupamento,
			String strUsuario) throws BusinessException;

	public String consultarBancoAgencia() throws BusinessException;

	public String excluirApoio(String intTabelaItem, String strCodItem, String strDescTot, String strDescRes,
			String strStatus, String strUsuario) throws BusinessException;

	public String excluirAtividadeEconomica(String intCodBancoItem, String intCodPeriodoItem, String intCodAtividade,
			String strUsuario) throws BusinessException;

	public String consultarBancoPeriodo() throws BusinessException;

	public String consultarBancoPeriodoProduto() throws BusinessException;

	public String recuperaCtrlProcessamento(String banco, String aplicativo, String periodo) throws BusinessException;

	public String consultarBanco() throws BusinessException;

	public String consultarFiltroSensibilizacao(String intCodBancoSelecionado, String dblCodRetorno,
			String strMsgRetorno) throws BusinessException;

	public String excluirPais(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem,
			String intCDHISTItem, String intTPHISTItem, String strUsuario) throws BusinessException;

	public String consultarPaises(String banco, String produto, String periodo) throws BusinessException;

	public String excluirReceptores(String intCodBancoItem, String intCodProdItem, String intCodSegmentoItem,
			String intSequencia, String strNomeRecepItem, String strPrefEmailItem, String intCodSufixoEmailItem,
			String strTipoEnvioItem, String strUsuario) throws BusinessException;

	public String consultarBancoProduto() throws BusinessException;

	public String incluirSensibilizacao(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario) throws BusinessException;

	public String alterarSensibilizacao(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario) throws BusinessException;

	public String consultarSensibilizacao(String banco, String produto, String periodo) throws BusinessException;

	public String incluirTpValorPerfil(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario) throws BusinessException;

	public String alterarTpValorPerfil(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario) throws BusinessException;

	public String consultarTpValorPerfil(String banco, String produto, String periodo) throws BusinessException;

	public String excluirTipoAgrupamento(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem,
			String intCDHISTItem, String intTPHISTItem, String strUsuario) throws BusinessException;

	public String excluirValorTpAgrupamento(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem,
			String intTPHISTItem, String strUsuario) throws BusinessException; /* Left(Trim(strUsuario),8), */

	public String consultarValorTpAgrupamento(String banco, String produto, String periodo) throws BusinessException;
}
