package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@PsFormat(name = "NQCETB06LegadoRequest")
public class NQCETB06LegadoRequest {
// -*-
//        01     NQCETB06-ENTRADA.                                         
//                                                                         
	@PsFieldString(name = "NQCETB6E_NM_PROG", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6E_NM_PROG;// 05 NQCETB6E-NM-PROG PIC X(008).

//       *       NOME DO PROGRAMA CHAMADO                                  
//                                                                         
	@PsFieldString(name = "NQCETB6E_NM_AREA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6E_NM_AREA;// 05 NQCETB6E-NM-AREA PIC X(008).

//       *       NOME DA AREA DE TS                                        
//                                                                         
	@PsFieldString(name = "NQCETB6E_SG_FCAO", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6E_SG_FCAO;// 05 NQCETB6E-SG-FCAO PIC X(002).

//       *       FUNCAO A SER EXECUTADA                                    
//       *       C = CONSULTAR                                             
//       *       L = LISTAR                                                
//       *       I = INCLUIR                                               
//       *       A = ALTERAR                                               
//       *       E = EXCLUIR                                               
//                                                                         
	@PsFieldNumber(name = "NQCETB6E_QT_TAMA_AREA", decimal = 0, length = 7, signed = false, defaultValue = "0")
	private Long NQCETB6E_QT_TAMA_AREA;// 05 NQCETB6E-QT-TAMA-AREA PIC 9(007)V99.

//       *       TAMANHO DA AREA DE TS                                     
//                                                                         
	@PsFieldString(name = "NQCETB6E_CD_USUA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6E_CD_USUA;// 05 NQCETB6E-CD-USUA PIC X(008).

//       *       CODIGO DO USUARIO                                         
//                                                                         
	@PsFieldNumber(name = "NQCETB6E_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB6E_NR_SEQU_SIST;// 05 NQCETB6E-NR-SEQU-SIST PIC 9(004).

//       *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                         
	@PsFieldNumber(name = "NQCETB6E_NR_SEQU_CAPO_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB6E_NR_SEQU_CAPO_SIST;// 05 NQCETB6E-NR-SEQU-CAPO-SIST PIC 9(004).

//       *       NUMERO DE SEQUENCIA DO CAMPO DO SISTEMA                   
//                                                                         
	@PsFieldNumber(name = "NQCETB6E_NR_SEQU_PARM_FILT", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB6E_NR_SEQU_PARM_FILT;// 05 NQCETB6E-NR-SEQU-PARM-FILT PIC 9(004).

//       *       NUMERO DE SEQUENCIA DO PARAMETRO DE FILTRO                
//                                                                         
	@PsFieldNumber(name = "NQCETB6E_NR_SEQU_DOMI_OPER", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB6E_NR_SEQU_DOMI_OPER;// 05 NQCETB6E-NR-SEQU-DOMI-OPER PIC 9(004).

//       *       NUMERO DE SEQUENCIA DO DOMINIO DA OPERACAO                
//                                                                         
	@PsFieldString(name = "NQCETB6E_TX_CNTD_INIC_PARM", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6E_TX_CNTD_INIC_PARM;// 05 NQCETB6E-TX-CNTD-INIC-PARM PIC X(040).

//       *       TEXTO INICIAL DE COMPARACAO DO PARAMETRO                  
//                                                                         
	@PsFieldString(name = "NQCETB6E_TX_CNTD_FINA_PARM", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6E_TX_CNTD_FINA_PARM;// 05 NQCETB6E-TX-CNTD-FINA-PARM PIC X(040).

//       *       TEXTO FINAL DE COMPARACAO DO PARAMETRO                    
//                                                                         
	@PsFieldNumber(name = "NQCETB6E_NR_SEQU_LIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB6E_NR_SEQU_LIST;// 05 NQCETB6E-NR-SEQU-LIST PIC 9(004).

//       *       NUMERO DE SEQUENCIA DA LISTA DE COMPARACAO DO PARAMETRO   
//                                                                         
	@PsFieldString(name = "NQCETB6E_DS_PARM", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6E_DS_PARM;// 05 NQCETB6E-DS-PARM PIC X(040).

//       *       DESCRICAO DO PARAMETRO                                    
//                                                                         
	@PsFieldString(name = "NQCETB6E_CD_USUA_INCL_PARM", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6E_CD_USUA_INCL_PARM;// 05 NQCETB6E-CD-USUA-INCL-PARM PIC X(008).

//       *       CODIGO DO USUARIO QUE INCLUIU O PARAMETRO                 
//                                                                         
	@PsFieldString(name = "NQCETB6E_DH_INCL_PARM", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6E_DH_INCL_PARM;// 05 NQCETB6E-DH-INCL-PARM PIC X(026).

//       *       DATA/HORA INCLUSAO DO PARAMETRO                           
//                                                                         
	@PsFieldString(name = "NQCETB6E_CD_USUA_ALTR_PARM", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6E_CD_USUA_ALTR_PARM;// 05 NQCETB6E-CD-USUA-ALTR-PARM PIC X(008).

//       *       CODIGO DO USUARIO QUE ALTEROU O PARAMETRO                 
//                                                                         
	@PsFieldString(name = "NQCETB6E_DH_ALTR_PARM", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6E_DH_ALTR_PARM;// 05 NQCETB6E-DH-ALTR-PARM PIC X(026).

//       *       DATA/HORA ALTERACAO DO PARAMETRO                          
//                                                                         
	@PsFieldString(name = "NQCETB6E_IN_PARM_ATIV", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6E_IN_PARM_ATIV;// 05 NQCETB6E-IN-PARM-ATIV PIC X(001).
	
	public NQCETB06LegadoRequest() {
	}

	public String getNQCETB6E_NM_PROG() {
		return NQCETB6E_NM_PROG;
	}

	public void setNQCETB6E_NM_PROG(String nQCETB6E_NM_PROG) {
		NQCETB6E_NM_PROG = nQCETB6E_NM_PROG;
	}

	public String getNQCETB6E_NM_AREA() {
		return NQCETB6E_NM_AREA;
	}

	public void setNQCETB6E_NM_AREA(String nQCETB6E_NM_AREA) {
		NQCETB6E_NM_AREA = nQCETB6E_NM_AREA;
	}

	public String getNQCETB6E_SG_FCAO() {
		return NQCETB6E_SG_FCAO;
	}

	public void setNQCETB6E_SG_FCAO(String nQCETB6E_SG_FCAO) {
		NQCETB6E_SG_FCAO = nQCETB6E_SG_FCAO;
	}

	public Long getNQCETB6E_QT_TAMA_AREA() {
		return NQCETB6E_QT_TAMA_AREA;
	}

	public void setNQCETB6E_QT_TAMA_AREA(Long nQCETB6E_QT_TAMA_AREA) {
		NQCETB6E_QT_TAMA_AREA = nQCETB6E_QT_TAMA_AREA;
	}

	public String getNQCETB6E_CD_USUA() {
		return NQCETB6E_CD_USUA;
	}

	public void setNQCETB6E_CD_USUA(String nQCETB6E_CD_USUA) {
		NQCETB6E_CD_USUA = nQCETB6E_CD_USUA;
	}

	public Long getNQCETB6E_NR_SEQU_SIST() {
		return NQCETB6E_NR_SEQU_SIST;
	}

	public void setNQCETB6E_NR_SEQU_SIST(Long nQCETB6E_NR_SEQU_SIST) {
		NQCETB6E_NR_SEQU_SIST = nQCETB6E_NR_SEQU_SIST;
	}

	public Long getNQCETB6E_NR_SEQU_CAPO_SIST() {
		return NQCETB6E_NR_SEQU_CAPO_SIST;
	}

	public void setNQCETB6E_NR_SEQU_CAPO_SIST(Long nQCETB6E_NR_SEQU_CAPO_SIST) {
		NQCETB6E_NR_SEQU_CAPO_SIST = nQCETB6E_NR_SEQU_CAPO_SIST;
	}

	public Long getNQCETB6E_NR_SEQU_PARM_FILT() {
		return NQCETB6E_NR_SEQU_PARM_FILT;
	}

	public void setNQCETB6E_NR_SEQU_PARM_FILT(Long nQCETB6E_NR_SEQU_PARM_FILT) {
		NQCETB6E_NR_SEQU_PARM_FILT = nQCETB6E_NR_SEQU_PARM_FILT;
	}

	public Long getNQCETB6E_NR_SEQU_DOMI_OPER() {
		return NQCETB6E_NR_SEQU_DOMI_OPER;
	}

	public void setNQCETB6E_NR_SEQU_DOMI_OPER(Long nQCETB6E_NR_SEQU_DOMI_OPER) {
		NQCETB6E_NR_SEQU_DOMI_OPER = nQCETB6E_NR_SEQU_DOMI_OPER;
	}

	public String getNQCETB6E_TX_CNTD_INIC_PARM() {
		return NQCETB6E_TX_CNTD_INIC_PARM;
	}

	public void setNQCETB6E_TX_CNTD_INIC_PARM(String nQCETB6E_TX_CNTD_INIC_PARM) {
		NQCETB6E_TX_CNTD_INIC_PARM = nQCETB6E_TX_CNTD_INIC_PARM;
	}

	public String getNQCETB6E_TX_CNTD_FINA_PARM() {
		return NQCETB6E_TX_CNTD_FINA_PARM;
	}

	public void setNQCETB6E_TX_CNTD_FINA_PARM(String nQCETB6E_TX_CNTD_FINA_PARM) {
		NQCETB6E_TX_CNTD_FINA_PARM = nQCETB6E_TX_CNTD_FINA_PARM;
	}

	public Long getNQCETB6E_NR_SEQU_LIST() {
		return NQCETB6E_NR_SEQU_LIST;
	}

	public void setNQCETB6E_NR_SEQU_LIST(Long nQCETB6E_NR_SEQU_LIST) {
		NQCETB6E_NR_SEQU_LIST = nQCETB6E_NR_SEQU_LIST;
	}

	public String getNQCETB6E_DS_PARM() {
		return NQCETB6E_DS_PARM;
	}

	public void setNQCETB6E_DS_PARM(String nQCETB6E_DS_PARM) {
		NQCETB6E_DS_PARM = nQCETB6E_DS_PARM;
	}

	public String getNQCETB6E_CD_USUA_INCL_PARM() {
		return NQCETB6E_CD_USUA_INCL_PARM;
	}

	public void setNQCETB6E_CD_USUA_INCL_PARM(String nQCETB6E_CD_USUA_INCL_PARM) {
		NQCETB6E_CD_USUA_INCL_PARM = nQCETB6E_CD_USUA_INCL_PARM;
	}

	public String getNQCETB6E_DH_INCL_PARM() {
		return NQCETB6E_DH_INCL_PARM;
	}

	public void setNQCETB6E_DH_INCL_PARM(String nQCETB6E_DH_INCL_PARM) {
		NQCETB6E_DH_INCL_PARM = nQCETB6E_DH_INCL_PARM;
	}

	public String getNQCETB6E_CD_USUA_ALTR_PARM() {
		return NQCETB6E_CD_USUA_ALTR_PARM;
	}

	public void setNQCETB6E_CD_USUA_ALTR_PARM(String nQCETB6E_CD_USUA_ALTR_PARM) {
		NQCETB6E_CD_USUA_ALTR_PARM = nQCETB6E_CD_USUA_ALTR_PARM;
	}

	public String getNQCETB6E_DH_ALTR_PARM() {
		return NQCETB6E_DH_ALTR_PARM;
	}

	public void setNQCETB6E_DH_ALTR_PARM(String nQCETB6E_DH_ALTR_PARM) {
		NQCETB6E_DH_ALTR_PARM = nQCETB6E_DH_ALTR_PARM;
	}

	public String getNQCETB6E_IN_PARM_ATIV() {
		return NQCETB6E_IN_PARM_ATIV;
	}

	public void setNQCETB6E_IN_PARM_ATIV(String nQCETB6E_IN_PARM_ATIV) {
		NQCETB6E_IN_PARM_ATIV = nQCETB6E_IN_PARM_ATIV;
	}

}