package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE7036LegadoRequest {
	/*
// -*-NQCE7036
//         01          NQCE7036-COMMAREA.                                   
	@FixedLenghtField(position = 1,315, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7036_COMMAREA_LEN;//             05      NQCE7036-COMMAREA-LEN       PIC 9(07).               

	@FixedLenghtField(position = 1,316, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7036_CODTABE;//             05      NQCE7036-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = 1,317, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7036_CODITEM;//             05      NQCE7036-CODITEM            PIC X(10).               

	@FixedLenghtField(position = 1,318, lenght = 40, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7036_ENVIA_DESCTOT;//             05      NQCE7036-ENVIA-DESCTOT      PIC X(40).               

	@FixedLenghtField(position = 1,319, lenght = 15, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7036_ENVIA_DESCRES;//             05      NQCE7036-ENVIA-DESCRES      PIC X(15).               

	@FixedLenghtField(position = 1,320, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7036_ENVIA_STATUS;//             05      NQCE7036-ENVIA-STATUS       PIC X(01).               

	@FixedLenghtField(position = 1,321, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7036_ENVIA_USERID;//             05      NQCE7036-ENVIA-USERID       PIC X(10).               

	@FixedLenghtField(position = 1,322, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7036_ENVIA_DATAJUST;//             05      NQCE7036-ENVIA-DATAJUST     PIC 9(08).               

	@FixedLenghtField(position = 1,323, lenght = 6, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7036_ENVIA_HORAJUST;//             05      NQCE7036-ENVIA-HORAJUST     PIC 9(06).               

	@FixedLenghtField(position = 1,324, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7036_ENVIA_COD_RETORNO;//             05      NQCE7036-ENVIA-COD-RETORNO  PIC 9(03).               

	@FixedLenghtField(position = 1,325, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7036_ENVIA_DES_MENSAGEM;//             05      NQCE7036-ENVIA-DES-MENSAGEM PIC X(80).               

//                                                                          
	public NQCE7036LegadoRequest() { }
	public NQCE7036LegadoRequest(Long nqce7036_commarea_len, Long nqce7036_codtabe, String nqce7036_coditem, String nqce7036_envia_desctot, String nqce7036_envia_descres, String nqce7036_envia_status, String nqce7036_envia_userid, Long nqce7036_envia_datajust, Long nqce7036_envia_horajust, Long nqce7036_envia_cod_retorno, String nqce7036_envia_des_mensagem) { 		this.NQCE7036_COMMAREA_LEN = nqce7036_commarea_len;
		this.NQCE7036_CODTABE = nqce7036_codtabe;
		this.NQCE7036_CODITEM = nqce7036_coditem;
		this.NQCE7036_ENVIA_DESCTOT = nqce7036_envia_desctot;
		this.NQCE7036_ENVIA_DESCRES = nqce7036_envia_descres;
		this.NQCE7036_ENVIA_STATUS = nqce7036_envia_status;
		this.NQCE7036_ENVIA_USERID = nqce7036_envia_userid;
		this.NQCE7036_ENVIA_DATAJUST = nqce7036_envia_datajust;
		this.NQCE7036_ENVIA_HORAJUST = nqce7036_envia_horajust;
		this.NQCE7036_ENVIA_COD_RETORNO = nqce7036_envia_cod_retorno;
		this.NQCE7036_ENVIA_DES_MENSAGEM = nqce7036_envia_des_mensagem; 
	}
	public Long getNQCE7036_COMMAREA_LEN() { return this.NQCE7036_COMMAREA_LEN; }
	public Long getNQCE7036_CODTABE() { return this.NQCE7036_CODTABE; }
	public String getNQCE7036_CODITEM() { return this.NQCE7036_CODITEM; }
	public String getNQCE7036_ENVIA_DESCTOT() { return this.NQCE7036_ENVIA_DESCTOT; }
	public String getNQCE7036_ENVIA_DESCRES() { return this.NQCE7036_ENVIA_DESCRES; }
	public String getNQCE7036_ENVIA_STATUS() { return this.NQCE7036_ENVIA_STATUS; }
	public String getNQCE7036_ENVIA_USERID() { return this.NQCE7036_ENVIA_USERID; }
	public Long getNQCE7036_ENVIA_DATAJUST() { return this.NQCE7036_ENVIA_DATAJUST; }
	public Long getNQCE7036_ENVIA_HORAJUST() { return this.NQCE7036_ENVIA_HORAJUST; }
	public Long getNQCE7036_ENVIA_COD_RETORNO() { return this.NQCE7036_ENVIA_COD_RETORNO; }
	public String getNQCE7036_ENVIA_DES_MENSAGEM() { return this.NQCE7036_ENVIA_DES_MENSAGEM; }
	public void setNQCE7036_COMMAREA_LEN(Long nqce7036_commarea_len) { this.NQCE7036_COMMAREA_LEN = nqce7036_commarea_len; }
	public void setNQCE7036_CODTABE(Long nqce7036_codtabe) { this.NQCE7036_CODTABE = nqce7036_codtabe; }
	public void setNQCE7036_CODITEM(String nqce7036_coditem) { this.NQCE7036_CODITEM = nqce7036_coditem; }
	public void setNQCE7036_ENVIA_DESCTOT(String nqce7036_envia_desctot) { this.NQCE7036_ENVIA_DESCTOT = nqce7036_envia_desctot; }
	public void setNQCE7036_ENVIA_DESCRES(String nqce7036_envia_descres) { this.NQCE7036_ENVIA_DESCRES = nqce7036_envia_descres; }
	public void setNQCE7036_ENVIA_STATUS(String nqce7036_envia_status) { this.NQCE7036_ENVIA_STATUS = nqce7036_envia_status; }
	public void setNQCE7036_ENVIA_USERID(String nqce7036_envia_userid) { this.NQCE7036_ENVIA_USERID = nqce7036_envia_userid; }
	public void setNQCE7036_ENVIA_DATAJUST(Long nqce7036_envia_datajust) { this.NQCE7036_ENVIA_DATAJUST = nqce7036_envia_datajust; }
	public void setNQCE7036_ENVIA_HORAJUST(Long nqce7036_envia_horajust) { this.NQCE7036_ENVIA_HORAJUST = nqce7036_envia_horajust; }
	public void setNQCE7036_ENVIA_COD_RETORNO(Long nqce7036_envia_cod_retorno) { this.NQCE7036_ENVIA_COD_RETORNO = nqce7036_envia_cod_retorno; }
	public void setNQCE7036_ENVIA_DES_MENSAGEM(String nqce7036_envia_des_mensagem) { this.NQCE7036_ENVIA_DES_MENSAGEM = nqce7036_envia_des_mensagem; }
	*/
}