package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException; 

 public interface AlertaCliAnRespService{ 
public String versao() throws BusinessException; 
public String recuperarPergunta(String strCOENTID,String strCOALERT) throws BusinessException; 
public String consultarHistorico(String strCOENTID,String strCOALERT,String strDTCOMIT,String strNUSEQUE) throws BusinessException; 
public String consultarJustificativa(String strCOENTI,String strCOALER) throws BusinessException; 
public String consultarEnquadramento(String strCOENTID,String strCOALERT,String strCOORGEN,String strCOENQSI) throws BusinessException; 
public String consultaOrgaoEnquadramento(String strCORGENQ) throws BusinessException; 
}

