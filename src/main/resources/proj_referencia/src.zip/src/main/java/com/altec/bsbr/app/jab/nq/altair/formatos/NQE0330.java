package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0330")
public class NQE0330 {
@PsFieldString(name="TPUORCM", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPUORCM;
@PsFieldString(name="CDUORCM", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDUORCM;
@PsFieldString(name="DTCOMIT", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTCOMIT;

public String getTPUORCM() {
 return TPUORCM;
}
public void setTPUORCM(String TPUORCM) {
 this.TPUORCM = TPUORCM;
}

public String getCDUORCM() {
 return CDUORCM;
}
public void setCDUORCM(String CDUORCM) {
 this.CDUORCM = CDUORCM;
}

public String getDTCOMIT() {
 return DTCOMIT;
}
public void setDTCOMIT(String DTCOMIT) {
 this.DTCOMIT = DTCOMIT;
}


}
