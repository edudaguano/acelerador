package com.altec.bsbr.app.jab.nq.dao;

import com.altec.bsbr.fw.BusinessException;

public interface DominiosDao {
	
	
	
	public String listarDominio(String strCodUser) throws BusinessException;

	public String consultarDominio(String strCodDom, String strCodUser) throws BusinessException;

	public String incluirDominio(String strVlrDom, String strDesDom, String strTpUsuDom, String strIndDomAtv,
			String strCodUser)  throws BusinessException;

	public String alterarDominio(String strCodDom, String strVlrDom, String strDesDom, String strTpUsuDom,
			String strIndDomAtv, String strCodUser)  throws BusinessException;

	public String excluirDominio(String strCodDom, String strCodUser)  throws BusinessException;

	public String inicializarinputArea(String tNQ_NQAT2005_NQCETB05_ENTRADA);

	public String fnAddCaracter(String Vlr, String Tp, String Tam);
}
