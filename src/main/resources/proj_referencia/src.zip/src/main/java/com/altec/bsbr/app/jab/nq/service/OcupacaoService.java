package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface OcupacaoService {

	public String consOcupCadastradas(String intBanco, String intPeriodicidade) throws BusinessException;

	public String recuperaDados(String intOcupacao) throws BusinessException;

	public String incluirOcupacao(String intBanco, String intPeriod, String intCodOcup, String strDescOcup,
			 String strUserId) throws BusinessException;

	public String consultarBancoProdPeriod() throws BusinessException;

	public String exclusaoOcupacao(String intBanco, String intPeriod, String intCodOcup, String strUsuario) throws BusinessException;

}
