package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name = "NQCETB06AreaDados")
public class NQCETB06AreaDados {
	
	//*       INDICADOR DE PARAMETRO ATIVO                              
	//
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*
	//
	//01     NQCETB06-SAIDA.                                           
	//03    NQCETB6S-DATA.                                            
	@PsFieldNumber(name = "NQCETB6S_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB6S_NR_SEQU_SIST;// 05 NQCETB6S-NR-SEQU-SIST PIC 9(004).
	
	//*       NUMERO DE SEQUENCIA DO SISTEMA                            
	//
	@PsFieldNumber(name = "NQCETB6S_NR_SEQU_CAPO_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB6S_NR_SEQU_CAPO_SIST;// 05 NQCETB6S-NR-SEQU-CAPO-SIST PIC 9(004).
	
	//*       NUMERO DE SEQUENCIA DO CAMPO DO SISTEMA                   
	//
	@PsFieldNumber(name = "NQCETB6S_NR_SEQU_PARM_FILT", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB6S_NR_SEQU_PARM_FILT;// 05 NQCETB6S-NR-SEQU-PARM-FILT PIC 9(004).
	
	//*       NUMERO DE SEQUENCIA DO PARAMETRO DE FILTRO                
	//
	@PsFieldNumber(name = "NQCETB6S_NR_SEQU_DOMI_OPER", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB6S_NR_SEQU_DOMI_OPER;// 05 NQCETB6S-NR-SEQU-DOMI-OPER PIC 9(004).
	
	//*       NUMERO DE SEQUENCIA DO DOMINIO DA OPERACAO                
	//
	@PsFieldString(name = "NQCETB6S_TX_CNTD_INIC_PARM", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6S_TX_CNTD_INIC_PARM;// 05 NQCETB6S-TX-CNTD-INIC-PARM PIC X(040).
	
	//*       TEXTO INICIAL DE COMPARACAO DO PARAMETRO                  
	//
	@PsFieldString(name = "NQCETB6S_TX_CNTD_FINA_PARM", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6S_TX_CNTD_FINA_PARM;// 05 NQCETB6S-TX-CNTD-FINA-PARM PIC X(040).
	
	//*       TEXTO FINAL DE COMPARACAO DO PARAMETRO                    
	//
	@PsFieldNumber(name = "NQCETB6S_NR_SEQU_LIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB6S_NR_SEQU_LIST;// 05 NQCETB6S-NR-SEQU-LIST PIC 9(004).
	
	//*       NUMERO DE SEQUENCIA DA LISTA DE COMPARACAO DO PARAMETRO   
	//
	@PsFieldString(name = "NQCETB6S_DS_PARM", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6S_DS_PARM;// 05 NQCETB6S-DS-PARM PIC X(040).
	
	//*       DESCRICAO DO PARAMETRO                                    
	//
	@PsFieldString(name = "NQCETB6S_CD_USUA_INCL_PARM", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6S_CD_USUA_INCL_PARM;// 05 NQCETB6S-CD-USUA-INCL-PARM PIC X(008).
	
	//*       CODIGO DO USUARIO QUE INCLUIU O PARAMETRO                 
	//
	@PsFieldString(name = "NQCETB6S_DH_INCL_PARM", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6S_DH_INCL_PARM;// 05 NQCETB6S-DH-INCL-PARM PIC X(026).
	
	//*       DATA/HORA INCLUSAO DO PARAMETRO                           
	//
	@PsFieldString(name = "NQCETB6S_CD_USUA_ALTR_PARM", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6S_CD_USUA_ALTR_PARM;// 05 NQCETB6S-CD-USUA-ALTR-PARM PIC X(008).
	
	//*       CODIGO DO USUARIO QUE ALTEROU O PARAMETRO                 
	//
	@PsFieldString(name = "NQCETB6S_DH_ALTR_PARM", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6S_DH_ALTR_PARM;// 05 NQCETB6S-DH-ALTR-PARM PIC X(026).
	
	//*       DATA/HORA ALTERACAO DO PARAMETRO                          
	//
	@PsFieldString(name = "NQCETB6S_IN_PARM_ATIV", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6S_IN_PARM_ATIV;// 05 NQCETB6S-IN-PARM-ATIV PIC X(001).
	
	//*       INDICADOR DE PARAMETRO ATIVO                              
	//
	@PsFieldString(name = "NQCETB6S_DS_CAPO", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6S_DS_CAPO;// 05 NQCETB6S-DS-CAPO PIC X(040).
	
	//*       DESCRICAO DE CAMPO                                        
	//
	@PsFieldString(name = "NQCETB6S_DS_PARM_DOMI_OPER", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6S_DS_PARM_DOMI_OPER;// 05 NQCETB6S-DS-PARM-DOMI-OPER PIC X(040).
	
	//*       DESCRICAO DE DOMINIO                                      
	//
	@PsFieldString(name = "NQCETB6S_DS_LIST", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB6S_DS_LIST;// 05 NQCETB6S-DS-LIST PIC X(040).

	public Long getNQCETB6S_NR_SEQU_SIST() {
		return NQCETB6S_NR_SEQU_SIST;
	}

	public void setNQCETB6S_NR_SEQU_SIST(Long nQCETB6S_NR_SEQU_SIST) {
		NQCETB6S_NR_SEQU_SIST = nQCETB6S_NR_SEQU_SIST;
	}

	public Long getNQCETB6S_NR_SEQU_CAPO_SIST() {
		return NQCETB6S_NR_SEQU_CAPO_SIST;
	}

	public void setNQCETB6S_NR_SEQU_CAPO_SIST(Long nQCETB6S_NR_SEQU_CAPO_SIST) {
		NQCETB6S_NR_SEQU_CAPO_SIST = nQCETB6S_NR_SEQU_CAPO_SIST;
	}

	public Long getNQCETB6S_NR_SEQU_PARM_FILT() {
		return NQCETB6S_NR_SEQU_PARM_FILT;
	}

	public void setNQCETB6S_NR_SEQU_PARM_FILT(Long nQCETB6S_NR_SEQU_PARM_FILT) {
		NQCETB6S_NR_SEQU_PARM_FILT = nQCETB6S_NR_SEQU_PARM_FILT;
	}

	public Long getNQCETB6S_NR_SEQU_DOMI_OPER() {
		return NQCETB6S_NR_SEQU_DOMI_OPER;
	}

	public void setNQCETB6S_NR_SEQU_DOMI_OPER(Long nQCETB6S_NR_SEQU_DOMI_OPER) {
		NQCETB6S_NR_SEQU_DOMI_OPER = nQCETB6S_NR_SEQU_DOMI_OPER;
	}

	public String getNQCETB6S_TX_CNTD_INIC_PARM() {
		return NQCETB6S_TX_CNTD_INIC_PARM;
	}

	public void setNQCETB6S_TX_CNTD_INIC_PARM(String nQCETB6S_TX_CNTD_INIC_PARM) {
		NQCETB6S_TX_CNTD_INIC_PARM = nQCETB6S_TX_CNTD_INIC_PARM;
	}

	public String getNQCETB6S_TX_CNTD_FINA_PARM() {
		return NQCETB6S_TX_CNTD_FINA_PARM;
	}

	public void setNQCETB6S_TX_CNTD_FINA_PARM(String nQCETB6S_TX_CNTD_FINA_PARM) {
		NQCETB6S_TX_CNTD_FINA_PARM = nQCETB6S_TX_CNTD_FINA_PARM;
	}

	public Long getNQCETB6S_NR_SEQU_LIST() {
		return NQCETB6S_NR_SEQU_LIST;
	}

	public void setNQCETB6S_NR_SEQU_LIST(Long nQCETB6S_NR_SEQU_LIST) {
		NQCETB6S_NR_SEQU_LIST = nQCETB6S_NR_SEQU_LIST;
	}

	public String getNQCETB6S_DS_PARM() {
		return NQCETB6S_DS_PARM;
	}

	public void setNQCETB6S_DS_PARM(String nQCETB6S_DS_PARM) {
		NQCETB6S_DS_PARM = nQCETB6S_DS_PARM;
	}

	public String getNQCETB6S_CD_USUA_INCL_PARM() {
		return NQCETB6S_CD_USUA_INCL_PARM;
	}

	public void setNQCETB6S_CD_USUA_INCL_PARM(String nQCETB6S_CD_USUA_INCL_PARM) {
		NQCETB6S_CD_USUA_INCL_PARM = nQCETB6S_CD_USUA_INCL_PARM;
	}

	public String getNQCETB6S_DH_INCL_PARM() {
		return NQCETB6S_DH_INCL_PARM;
	}

	public void setNQCETB6S_DH_INCL_PARM(String nQCETB6S_DH_INCL_PARM) {
		NQCETB6S_DH_INCL_PARM = nQCETB6S_DH_INCL_PARM;
	}

	public String getNQCETB6S_CD_USUA_ALTR_PARM() {
		return NQCETB6S_CD_USUA_ALTR_PARM;
	}

	public void setNQCETB6S_CD_USUA_ALTR_PARM(String nQCETB6S_CD_USUA_ALTR_PARM) {
		NQCETB6S_CD_USUA_ALTR_PARM = nQCETB6S_CD_USUA_ALTR_PARM;
	}

	public String getNQCETB6S_DH_ALTR_PARM() {
		return NQCETB6S_DH_ALTR_PARM;
	}

	public void setNQCETB6S_DH_ALTR_PARM(String nQCETB6S_DH_ALTR_PARM) {
		NQCETB6S_DH_ALTR_PARM = nQCETB6S_DH_ALTR_PARM;
	}

	public String getNQCETB6S_IN_PARM_ATIV() {
		return NQCETB6S_IN_PARM_ATIV;
	}

	public void setNQCETB6S_IN_PARM_ATIV(String nQCETB6S_IN_PARM_ATIV) {
		NQCETB6S_IN_PARM_ATIV = nQCETB6S_IN_PARM_ATIV;
	}

	public String getNQCETB6S_DS_CAPO() {
		return NQCETB6S_DS_CAPO;
	}

	public void setNQCETB6S_DS_CAPO(String nQCETB6S_DS_CAPO) {
		NQCETB6S_DS_CAPO = nQCETB6S_DS_CAPO;
	}

	public String getNQCETB6S_DS_PARM_DOMI_OPER() {
		return NQCETB6S_DS_PARM_DOMI_OPER;
	}

	public void setNQCETB6S_DS_PARM_DOMI_OPER(String nQCETB6S_DS_PARM_DOMI_OPER) {
		NQCETB6S_DS_PARM_DOMI_OPER = nQCETB6S_DS_PARM_DOMI_OPER;
	}

	public String getNQCETB6S_DS_LIST() {
		return NQCETB6S_DS_LIST;
	}

	public void setNQCETB6S_DS_LIST(String nQCETB6S_DS_LIST) {
		NQCETB6S_DS_LIST = nQCETB6S_DS_LIST;
	}
	
	//*       DESCRICAO DE LISTA   
	
	
}