package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE0011LegadoRequest {
	// -*-NQCE0011         
	//        *----------------------------------------------------------------*
	//        *    CODIGO  : NQVO011A                                          *
	//        *    NOME    : CADASTRO DE ISENCAO                               *
	//        *    TIPO    : VSAM                                              *
	//        *    BOOK    : NQCE0011                                          *
	//        *    TAMANHO : 060 BYTES                                         *
	//        *    CHAVE   : ISEN-CHVIDENT     TAM.CHAVE: 11 BYTES             *
	//        *    ALTER1  : ISEN-CHVIDENT1    TAM.CHAVE: 06 BYTES             *
	//        *----------------------------------------------------------------*
	//        * NOME         DESCRICAO                                         *
	//        * ============ ================================================= *
	//        * CHVIDENT     CHAVE PRIMARIA DO ARQUIVO                         *
	//        * ..CCLI       CODIGO DO CLIENTE NO PERSONAS                     *
	//        * ..DTINIISE   DATA INICIO DE VIGENCIA DA ISENCAO (SSAAMMDD)     *
	//        * DTFIMISE     DATA FINAL DE VIGENCIA DA ISENCAO (SSAAMMDD)      *
	//        * CUSUALT      CODIGO DO USUARIO DA ULTIMA ATUALIZACAO           *
	//        * DTUALT       DATA DA ULTIMA ATUALIZACAO (SSAAMMDD)             *
	//        * HRUALT       HORA DA ULTIMA ATUALIZACAO (SSAAMMDD)             *
	//        * CUSINC       CODIGO DO USUARIO QUE EFETUOU A INCLUSAO          *
	//        * DTINC        DATA DA INCLUSAO (SSAAMMDD)                       *
	//        * HRINC        HORA DA INCLUSAO (SSAAMMDD)                       *
	//        * CHVIDENT1    CHAVE SEGUNDARIA DO ARQUIVO                       *
	//        * ..CODSEG     CODIGO DO SEGMENTO (UNIDADE DE NEGOCIO PERSONAS)  *
	//        * ..CODCAR     CODIGO DA CARTEIRA (SUB.SEGMENTO PERSONAS)        *
	//        *----------------------------------------------------------------*
	//         01          ISEN-REG.                                            
	//        		05      ISEN-CHVIDENT.                                       
	@FixedLenghtField(position = 1, lenght = 10, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long ISEN_CCLI;//        		10  	ISEN-CCLI           PIC 9(10)       COMP-3.          

	@FixedLenghtField(position = 2, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long ISEN_DTINIISE;//        		10  	ISEN-DTINIISE       PIC 9(08)       COMP-3.          

	@FixedLenghtField(position = 3, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long ISEN_DTFIMISE;//        		05      ISEN-DTFIMISE       PIC 9(08)       COMP-3.          

	@FixedLenghtField(position = 4, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String ISEN_CUSUALT;//        		05      ISEN-CUSUALT        PIC X(08).                       

	@FixedLenghtField(position = 5, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long ISEN_DTUALT;//        		05      ISEN-DTUALT         PIC 9(08)       COMP-3.          

	@FixedLenghtField(position = 6, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long ISEN_HRUALT;//        		05      ISEN-HRUALT         PIC 9(08)       COMP-3.          

	@FixedLenghtField(position = 7, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String ISEN_CUSINC;//        		05      ISEN-CUSINC         PIC X(08).                       

	@FixedLenghtField(position = 8, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long ISEN_DTINC;//        		05      ISEN-DTINC          PIC 9(08)       COMP-3.          

	@FixedLenghtField(position = 9, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long ISEN_HRINC;//        		05      ISEN-HRINC          PIC 9(08)       COMP-3.          

	//        		05      ISEN-CHVIDENT1.                                      
	@FixedLenghtField(position = 10, lenght = 3, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String ISEN_CODSEG;//        		10  	ISEN-CODSEG         PIC X(03).                       

	@FixedLenghtField(position = 11, lenght = 3, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String ISEN_CODCAR;//        		10  	ISEN-CODCAR         PIC X(03).                       

	@FixedLenghtField(position = 12, lenght = 2, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String ISEN_FILLER0;//        		05      ISEN-FILLER         PIC X(02).                       

	public NQCE0011LegadoRequest() { }
	public NQCE0011LegadoRequest(Long isen_ccli, Long isen_dtiniise, Long isen_dtfimise, String isen_cusualt, Long isen_dtualt, Long isen_hrualt, String isen_cusinc, Long isen_dtinc, Long isen_hrinc, String isen_codseg, String isen_codcar, String isen_filler0) { 		this.ISEN_CCLI = isen_ccli;
	this.ISEN_DTINIISE = isen_dtiniise;
	this.ISEN_DTFIMISE = isen_dtfimise;
	this.ISEN_CUSUALT = isen_cusualt;
	this.ISEN_DTUALT = isen_dtualt;
	this.ISEN_HRUALT = isen_hrualt;
	this.ISEN_CUSINC = isen_cusinc;
	this.ISEN_DTINC = isen_dtinc;
	this.ISEN_HRINC = isen_hrinc;
	this.ISEN_CODSEG = isen_codseg;
	this.ISEN_CODCAR = isen_codcar;
	this.ISEN_FILLER0 = isen_filler0; 
	}
	public Long getISEN_CCLI() { return this.ISEN_CCLI; }
	public Long getISEN_DTINIISE() { return this.ISEN_DTINIISE; }
	public Long getISEN_DTFIMISE() { return this.ISEN_DTFIMISE; }
	public String getISEN_CUSUALT() { return this.ISEN_CUSUALT; }
	public Long getISEN_DTUALT() { return this.ISEN_DTUALT; }
	public Long getISEN_HRUALT() { return this.ISEN_HRUALT; }
	public String getISEN_CUSINC() { return this.ISEN_CUSINC; }
	public Long getISEN_DTINC() { return this.ISEN_DTINC; }
	public Long getISEN_HRINC() { return this.ISEN_HRINC; }
	public String getISEN_CODSEG() { return this.ISEN_CODSEG; }
	public String getISEN_CODCAR() { return this.ISEN_CODCAR; }
	public String getISEN_FILLER0() { return this.ISEN_FILLER0; }
	public void setISEN_CCLI(Long isen_ccli) { this.ISEN_CCLI = isen_ccli; }
	public void setISEN_DTINIISE(Long isen_dtiniise) { this.ISEN_DTINIISE = isen_dtiniise; }
	public void setISEN_DTFIMISE(Long isen_dtfimise) { this.ISEN_DTFIMISE = isen_dtfimise; }
	public void setISEN_CUSUALT(String isen_cusualt) { this.ISEN_CUSUALT = isen_cusualt; }
	public void setISEN_DTUALT(Long isen_dtualt) { this.ISEN_DTUALT = isen_dtualt; }
	public void setISEN_HRUALT(Long isen_hrualt) { this.ISEN_HRUALT = isen_hrualt; }
	public void setISEN_CUSINC(String isen_cusinc) { this.ISEN_CUSINC = isen_cusinc; }
	public void setISEN_DTINC(Long isen_dtinc) { this.ISEN_DTINC = isen_dtinc; }
	public void setISEN_HRINC(Long isen_hrinc) { this.ISEN_HRINC = isen_hrinc; }
	public void setISEN_CODSEG(String isen_codseg) { this.ISEN_CODSEG = isen_codseg; }
	public void setISEN_CODCAR(String isen_codcar) { this.ISEN_CODCAR = isen_codcar; }
	public void setISEN_FILLER0(String isen_filler0) { this.ISEN_FILLER0 = isen_filler0; }
}