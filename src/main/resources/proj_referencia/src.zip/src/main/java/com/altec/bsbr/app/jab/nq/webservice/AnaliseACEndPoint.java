package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.AnaliseACService;
import com.altec.bsbr.app.jab.nq.service.AnaliseACWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class AnaliseACEndPoint extends SpringBeanAutowiringSupport implements AnaliseACWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(AnaliseACEndPoint.class);
	@Autowired
	private AnaliseACService analiseac;

	@WebMethod
	public String consultarAnalises(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser, String strFuncao) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = analiseac.consultarAnalises(strCodSist, strBanco, strCodCliente, strDtOcorr, strNotUPLD,
					strParOper, strParGer, strParUPLD, strRegra, strPeriodo, strCodUser, strFuncao);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String listarPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = analiseac.listarPareceres(strCodSist, strBanco, strCodCliente, strDtOcorr, strNotUPLD, strParOper,
					strParGer, strParUPLD, strRegra, strPeriodo, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String listarClientes(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = analiseac.listarClientes(strCodSist, strBanco, strCodCliente, strDtOcorr, strNotUPLD, strParOper,
					strParGer, strParUPLD, strRegra, strPeriodo, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String fnAddCaracter(String vlr, String tp, String tam) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = analiseac.fnAddCaracter(vlr, tp, tam);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String dataAlta(String dtBaixa) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = analiseac.dataAlta(dtBaixa);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
}
