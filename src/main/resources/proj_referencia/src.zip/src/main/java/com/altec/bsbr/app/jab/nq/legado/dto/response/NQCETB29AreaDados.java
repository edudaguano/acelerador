package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name = "NQCETB29AreaDados")
public class NQCETB29AreaDados {
	
//  
	//*       AREA DE DADOS                                             
	//  
//	@PsFieldNumber(name = "NQCETB29_S_DATA_LEN", length = 0, binary = true, signed = true, decimal = 0)
//	private Long NQCETB29_S_DATA_LEN;// 03 NQCETB29-S-DATA-LEN COMP PIC S9(04) VALUE +228.
	
	//03    NQCETB29-S-DATA.                                          
	//  
	@PsFieldNumber(name = "NQCETB29_S_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB29_S_NR_SEQU_SIST;// 05 NQCETB29-S-NR-SEQU-SIST PIC 9(004).
	
	//*       NUMERO DE SEQUENCIA DO SISTEMA                            
	//  
	@PsFieldString(name = "NQCETB29_S_SG_SIST", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_S_SG_SIST;// 05 NQCETB29-S-SG-SIST PIC X(002).
	
	//*       SIGLA DO SISTEMA                                          
	//  
	@PsFieldString(name = "NQCETB29_S_DS_FCAO_SIST", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_S_DS_FCAO_SIST;// 05 NQCETB29-S-DS-FCAO-SIST PIC X(040).
	
	//*       DESCRICAO DA FUNCAO DO SISTEMA                            
	//  
	@PsFieldString(name = "NQCETB29_S_DT_OCOR", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_S_DT_OCOR;// 05 NQCETB29-S-DT-OCOR PIC X(010).
	
	//*       DATA DE OCORRENCIA                                        
	//  
	@PsFieldNumber(name = "NQCETB29_S_NR_SEQU_CAPO", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB29_S_NR_SEQU_CAPO;// 05 NQCETB29-S-NR-SEQU-CAPO PIC 9(004).
	
	//*       NUMERO DE SEQUENCIA DO CAMPO                              
	//  
	@PsFieldString(name = "NQCETB29_S_DS_CAPO", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_S_DS_CAPO;// 05 NQCETB29-S-DS-CAPO PIC X(040).
	
	//*       DESCRICAO DO CAMPO                                        
	//  
	@PsFieldString(name = "NQCETB29_S_TP_CAPO", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_S_TP_CAPO;// 05 NQCETB29-S-TP-CAPO PIC X(002).
	
	//*       TIPO DE CAMPO                                             
	//  
	@PsFieldNumber(name = "NQCETB29_S_VL_INIC_FILT_CAPO", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB29_S_VL_INIC_FILT_CAPO;// 05 NQCETB29-S-VL-INIC-FILT-CAPO PIC 9(004).
	
	//*       POSICAO INICIAL DO CAMPO                                  
	//  
	@PsFieldNumber(name = "NQCETB29_S_QT_TAMA_CAPO", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB29_S_QT_TAMA_CAPO;// 05 NQCETB29-S-QT-TAMA-CAPO PIC 9(004).
	
	//*       TAMANHO DO CAMPO                                          
	//  
	@PsFieldNumber(name = "NQCETB29_S_NR_SEQU_DOMI_OPER", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB29_S_NR_SEQU_DOMI_OPER;// 05 NQCETB29-S-NR-SEQU-DOMI-OPER PIC 9(004).
	
	//*       NUMERO DE SEQUENCIA DO DOMINIO OPERACAO                   
	//  
	@PsFieldString(name = "NQCETB29_S_VL_PARM_DOMI_OPER", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_S_VL_PARM_DOMI_OPER;// 05 NQCETB29-S-VL-PARM-DOMI-OPER PIC X(040).
	
	//*       DESCRICAO DO PARAMETRO DOMINIO OPERACAO                   
	//  
	@PsFieldString(name = "NQCETB29_S_TX_CNTD", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_S_TX_CNTD;// 05 NQCETB29-S-TX-CNTD PIC X(040).
	
	//*       DESCRICAO DO CONTEUDO                                     
	//  
	@PsFieldString(name = "NQCETB29_S_CD_USUA_ULTI_ALTR", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_S_CD_USUA_ULTI_ALTR;// 05 NQCETB29-S-CD-USUA-ULTI-ALTR PIC X(008).
	
	//*       CODIGO DA SITUACAO                                        
	//  
	@PsFieldString(name = "NQCETB29_S_DH_ULTI_ALTR", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_S_DH_ULTI_ALTR;// 05 NQCETB29-S-DH-ULTI-ALTR PIC X(026).
	
	//*       DATA/HORA ULTIMO PROCESSAMENTO         
		
//	public Long getNQCETB29_S_DATA_LEN() {
//		return NQCETB29_S_DATA_LEN;
//	}
//
//	public void setNQCETB29_S_DATA_LEN(Long nQCETB29_S_DATA_LEN) {
//		NQCETB29_S_DATA_LEN = nQCETB29_S_DATA_LEN;
//	}

	public Long getNQCETB29_S_NR_SEQU_SIST() {
		return NQCETB29_S_NR_SEQU_SIST;
	}

	public void setNQCETB29_S_NR_SEQU_SIST(Long nQCETB29_S_NR_SEQU_SIST) {
		NQCETB29_S_NR_SEQU_SIST = nQCETB29_S_NR_SEQU_SIST;
	}

	public String getNQCETB29_S_SG_SIST() {
		return NQCETB29_S_SG_SIST;
	}

	public void setNQCETB29_S_SG_SIST(String nQCETB29_S_SG_SIST) {
		NQCETB29_S_SG_SIST = nQCETB29_S_SG_SIST;
	}

	public String getNQCETB29_S_DS_FCAO_SIST() {
		return NQCETB29_S_DS_FCAO_SIST;
	}

	public void setNQCETB29_S_DS_FCAO_SIST(String nQCETB29_S_DS_FCAO_SIST) {
		NQCETB29_S_DS_FCAO_SIST = nQCETB29_S_DS_FCAO_SIST;
	}

	public String getNQCETB29_S_DT_OCOR() {
		return NQCETB29_S_DT_OCOR;
	}

	public void setNQCETB29_S_DT_OCOR(String nQCETB29_S_DT_OCOR) {
		NQCETB29_S_DT_OCOR = nQCETB29_S_DT_OCOR;
	}

	public Long getNQCETB29_S_NR_SEQU_CAPO() {
		return NQCETB29_S_NR_SEQU_CAPO;
	}

	public void setNQCETB29_S_NR_SEQU_CAPO(Long nQCETB29_S_NR_SEQU_CAPO) {
		NQCETB29_S_NR_SEQU_CAPO = nQCETB29_S_NR_SEQU_CAPO;
	}

	public String getNQCETB29_S_DS_CAPO() {
		return NQCETB29_S_DS_CAPO;
	}

	public void setNQCETB29_S_DS_CAPO(String nQCETB29_S_DS_CAPO) {
		NQCETB29_S_DS_CAPO = nQCETB29_S_DS_CAPO;
	}

	public String getNQCETB29_S_TP_CAPO() {
		return NQCETB29_S_TP_CAPO;
	}

	public void setNQCETB29_S_TP_CAPO(String nQCETB29_S_TP_CAPO) {
		NQCETB29_S_TP_CAPO = nQCETB29_S_TP_CAPO;
	}

	public Long getNQCETB29_S_VL_INIC_FILT_CAPO() {
		return NQCETB29_S_VL_INIC_FILT_CAPO;
	}

	public void setNQCETB29_S_VL_INIC_FILT_CAPO(Long nQCETB29_S_VL_INIC_FILT_CAPO) {
		NQCETB29_S_VL_INIC_FILT_CAPO = nQCETB29_S_VL_INIC_FILT_CAPO;
	}

	public Long getNQCETB29_S_QT_TAMA_CAPO() {
		return NQCETB29_S_QT_TAMA_CAPO;
	}

	public void setNQCETB29_S_QT_TAMA_CAPO(Long nQCETB29_S_QT_TAMA_CAPO) {
		NQCETB29_S_QT_TAMA_CAPO = nQCETB29_S_QT_TAMA_CAPO;
	}

	public Long getNQCETB29_S_NR_SEQU_DOMI_OPER() {
		return NQCETB29_S_NR_SEQU_DOMI_OPER;
	}

	public void setNQCETB29_S_NR_SEQU_DOMI_OPER(Long nQCETB29_S_NR_SEQU_DOMI_OPER) {
		NQCETB29_S_NR_SEQU_DOMI_OPER = nQCETB29_S_NR_SEQU_DOMI_OPER;
	}

	public String getNQCETB29_S_VL_PARM_DOMI_OPER() {
		return NQCETB29_S_VL_PARM_DOMI_OPER;
	}

	public void setNQCETB29_S_VL_PARM_DOMI_OPER(String nQCETB29_S_VL_PARM_DOMI_OPER) {
		NQCETB29_S_VL_PARM_DOMI_OPER = nQCETB29_S_VL_PARM_DOMI_OPER;
	}

	public String getNQCETB29_S_TX_CNTD() {
		return NQCETB29_S_TX_CNTD;
	}

	public void setNQCETB29_S_TX_CNTD(String nQCETB29_S_TX_CNTD) {
		NQCETB29_S_TX_CNTD = nQCETB29_S_TX_CNTD;
	}

	public String getNQCETB29_S_CD_USUA_ULTI_ALTR() {
		return NQCETB29_S_CD_USUA_ULTI_ALTR;
	}

	public void setNQCETB29_S_CD_USUA_ULTI_ALTR(String nQCETB29_S_CD_USUA_ULTI_ALTR) {
		NQCETB29_S_CD_USUA_ULTI_ALTR = nQCETB29_S_CD_USUA_ULTI_ALTR;
	}

	public String getNQCETB29_S_DH_ULTI_ALTR() {
		return NQCETB29_S_DH_ULTI_ALTR;
	}

	public void setNQCETB29_S_DH_ULTI_ALTR(String nQCETB29_S_DH_ULTI_ALTR) {
		NQCETB29_S_DH_ULTI_ALTR = nQCETB29_S_DH_ULTI_ALTR;
	}

	
}
