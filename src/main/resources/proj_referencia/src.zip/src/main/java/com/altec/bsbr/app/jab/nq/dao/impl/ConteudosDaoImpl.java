package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.ConteudosDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB04LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.AreaMensagem;
import com.altec.bsbr.app.jab.nq.legado.dto.response.FullAreaResponse;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCE7023AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB04AreaDados;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB04MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ConteudosDaoImpl implements ConteudosDao {
	
	private final Logger LOGGER = LoggerFactory.getLogger(ConteudosDaoImpl.class);

	@Autowired
	private JSONMapper jsonMapper;
	
	@Autowired
	private NQCETB04MessagingGateway NQCETB04Service;
	
	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String listarConteudo(String strCodSist, String strCodList, String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB04LegadoRequest req = new NQCETB04LegadoRequest();
		
			req.setNQCETB4E_SG_FCAO("L");
			req.setNQCETB4E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB4E_NR_SEQU_LIST(strCodList.isEmpty()? null : Long.valueOf(strCodList));
			req.setNQCETB4E_CD_USUA(strCodUser);
						
			LegadoResult res = NQCETB04Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB04AreaDados> ret = decoder.parseRetorno(res, NQCETB04AreaDados.class, 83, 162);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String consultarConteudo(String strCodSist, String strCodList, String strCodCntd, String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB04LegadoRequest req = new NQCETB04LegadoRequest();
		
			req.setNQCETB4E_SG_FCAO("C");
			req.setNQCETB4E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB4E_NR_SEQU_LIST(strCodList.isEmpty()? null : Long.valueOf(strCodList));
			req.setNQCETB4E_NR_SEQU_CNTD(strCodCntd.isEmpty()? null : Long.valueOf(strCodCntd));
			req.setNQCETB4E_CD_USUA(strCodUser);
			
			LegadoResult res = NQCETB04Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB04AreaDados> ret = decoder.parseRetorno(res, NQCETB04AreaDados.class, 83, 162);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;

	}

	public String incluirConteudo(String strCodSist, String strCodList, String strTxtCntd, String strDescCntd,
			String strDtHr, String strAtivo, String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB04LegadoRequest req = new NQCETB04LegadoRequest();
			req.setNQCETB4E_SG_FCAO("I");
			req.setNQCETB4E_CD_USUA(strCodUser);
			req.setNQCETB4E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB4E_NR_SEQU_LIST(strCodList.isEmpty()? null : Long.valueOf(strCodList));
			req.setNQCETB4E_TX_CNTD(strTxtCntd);
			req.setNQCETB4E_DS_CNTD(strDescCntd);
			req.setNQCETB4E_IN_CNTD_ATIV(strAtivo);
			req.setNQCETB4E_CD_USUA_INCL_CNTD(strCodUser);
			req.setNQCETB4E_DH_INCL_CNTD(new Date().toString()); //TODO: verificar formatacao Data
			
			LegadoResult res = NQCETB04Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB04AreaDados> ret = decoder.parseRetorno(res, NQCETB04AreaDados.class, 83, 162);
			json =  new ObjectMapper().writeValueAsString(ret);			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;

	}

	public String alterarConteudo(String strCodSist, String strCodList, String strCodCntd, String strTxtCntd,
			String strDescCntd, String strDtHr, String strAtivo, String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			
			NQCETB04LegadoRequest req = new NQCETB04LegadoRequest();
			
			req.setNQCETB4E_SG_FCAO("A");
			req.setNQCETB4E_CD_USUA(strCodUser);
			req.setNQCETB4E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB4E_NR_SEQU_LIST(strCodList.isEmpty()? null : Long.valueOf(strCodList));
			req.setNQCETB4E_NR_SEQU_CNTD(strCodCntd.isEmpty()? null : Long.valueOf(strCodCntd));
			req.setNQCETB4E_TX_CNTD(strTxtCntd);
			req.setNQCETB4E_DS_CNTD(strDescCntd);
			req.setNQCETB4E_CD_USUA_ALTR_CNTD(strCodUser);
			req.setNQCETB4E_DH_ALTR_CNTD(new Date().toString()); //TODO: verificar formatacao Data  
			req.setNQCETB4E_IN_CNTD_ATIV(strAtivo);
			
			LegadoResult res = NQCETB04Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB04AreaDados> ret = decoder.parseRetorno(res, NQCETB04AreaDados.class, 83, 162);
			json =  new ObjectMapper().writeValueAsString(ret);			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;

	}

	public String excluirConteudo(String strCodSist, String strCodList, String strCodCntd, String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB04LegadoRequest req = new NQCETB04LegadoRequest();
		
			req.setNQCETB4E_SG_FCAO("E");
			req.setNQCETB4E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB4E_NR_SEQU_LIST(strCodList.isEmpty()? null : Long.valueOf(strCodList));
			req.setNQCETB4E_NR_SEQU_CNTD(strCodCntd.isEmpty()? null : Long.valueOf(strCodCntd));
			req.setNQCETB4E_CD_USUA(strCodUser);
						
			LegadoResult res = NQCETB04Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB04AreaDados> ret = decoder.parseRetorno(res, NQCETB04AreaDados.class, 83, 162);
			json =  new ObjectMapper().writeValueAsString(ret);			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String inicializarinputArea(String tNQ_NQAT2004_NQCETB04_ENTRADA) {
		String json = "";
		return json;
	};

	public String fnAddCaracter(String Vlr, String Tp, String Tam) {
		String json = "";
		return json;
	};

}
