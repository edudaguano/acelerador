package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0050")
public class NQE0050 {
@PsFieldString(name="CDENTID", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDENTID;
@PsFieldString(name="CDAGENC", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDAGENC;
@PsFieldString(name="CDALERT", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDALERT;
@PsFieldNumber(name="CDUNIOR", length=4, defaultValue = "0" )
private Integer CDUNIOR;
@PsFieldNumber(name="TPUNIOR", length=4, defaultValue = "0" )
private Integer TPUNIOR;
@PsFieldString(name="TXPAR01", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPAR01;
@PsFieldString(name="TXPAR02", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPAR02;
@PsFieldString(name="TXPAR03", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPAR03;
@PsFieldString(name="TXPAR04", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPAR04;
@PsFieldString(name="TXPAR05", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPAR05;
@PsFieldString(name="TXPAR06", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPAR06;
@PsFieldString(name="TXPAR07", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPAR07;
@PsFieldString(name="TXPAR08", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPAR08;
@PsFieldString(name="TXPAR09", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPAR09;
@PsFieldString(name="TXPAR10", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPAR10;
@PsFieldNumber(name="TPPAREC", length=2, defaultValue = "0" )
private Integer TPPAREC;
@PsFieldString(name="DTCOMIT", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTCOMIT;
@PsFieldString(name="CDUSRES", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDUSRES;
@PsFieldNumber(name="NUSEQUE", length=3, defaultValue = "0" )
private Integer NUSEQUE;
@PsFieldString(name="TPCHAMA", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPCHAMA;

public String getCDENTID() {
 return CDENTID;
}
public void setCDENTID(String CDENTID) {
 this.CDENTID = CDENTID;
}

public String getCDAGENC() {
 return CDAGENC;
}
public void setCDAGENC(String CDAGENC) {
 this.CDAGENC = CDAGENC;
}

public String getCDALERT() {
 return CDALERT;
}
public void setCDALERT(String CDALERT) {
 this.CDALERT = CDALERT;
}
public Integer getCDUNIOR() {
 return CDUNIOR;
}
public void setCDUNIOR(Integer cDUNIOR) {
CDUNIOR = cDUNIOR;
}public Integer getTPUNIOR() {
 return TPUNIOR;
}
public void setTPUNIOR(Integer tPUNIOR) {
TPUNIOR = tPUNIOR;
}
public String getTXPAR01() {
 return TXPAR01;
}
public void setTXPAR01(String TXPAR01) {
 this.TXPAR01 = TXPAR01;
}

public String getTXPAR02() {
 return TXPAR02;
}
public void setTXPAR02(String TXPAR02) {
 this.TXPAR02 = TXPAR02;
}

public String getTXPAR03() {
 return TXPAR03;
}
public void setTXPAR03(String TXPAR03) {
 this.TXPAR03 = TXPAR03;
}

public String getTXPAR04() {
 return TXPAR04;
}
public void setTXPAR04(String TXPAR04) {
 this.TXPAR04 = TXPAR04;
}

public String getTXPAR05() {
 return TXPAR05;
}
public void setTXPAR05(String TXPAR05) {
 this.TXPAR05 = TXPAR05;
}

public String getTXPAR06() {
 return TXPAR06;
}
public void setTXPAR06(String TXPAR06) {
 this.TXPAR06 = TXPAR06;
}

public String getTXPAR07() {
 return TXPAR07;
}
public void setTXPAR07(String TXPAR07) {
 this.TXPAR07 = TXPAR07;
}

public String getTXPAR08() {
 return TXPAR08;
}
public void setTXPAR08(String TXPAR08) {
 this.TXPAR08 = TXPAR08;
}

public String getTXPAR09() {
 return TXPAR09;
}
public void setTXPAR09(String TXPAR09) {
 this.TXPAR09 = TXPAR09;
}

public String getTXPAR10() {
 return TXPAR10;
}
public void setTXPAR10(String TXPAR10) {
 this.TXPAR10 = TXPAR10;
}
public Integer getTPPAREC() {
 return TPPAREC;
}
public void setTPPAREC(Integer tPPAREC) {
TPPAREC = tPPAREC;
}
public String getDTCOMIT() {
 return DTCOMIT;
}
public void setDTCOMIT(String DTCOMIT) {
 this.DTCOMIT = DTCOMIT;
}

public String getCDUSRES() {
 return CDUSRES;
}
public void setCDUSRES(String CDUSRES) {
 this.CDUSRES = CDUSRES;
}
public Integer getNUSEQUE() {
 return NUSEQUE;
}
public void setNUSEQUE(Integer nUSEQUE) {
NUSEQUE = nUSEQUE;
}
public String getTPCHAMA() {
 return TPCHAMA;
}
public void setTPCHAMA(String TPCHAMA) {
 this.TPCHAMA = TPCHAMA;
}


}
