package com.altec.bsbr.app.jab.nq.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0010;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0040;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0010;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0040;
import com.altec.bsbr.app.jab.nq.dao.AlertaPendenteDao;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;

@Repository
public class AlertaPendenteDaoImpl implements AlertaPendenteDao {
	private final Logger LOGGER = LoggerFactory.getLogger(AlertaPendenteDaoImpl.class);

	@Autowired
	private AltairService altairService;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String versao() {
		return "";
	}

	public String consultarAlerta(String strCOENTID, String strTPUNIOR, String strCDUNIOR, String strCOALERP,
			String strDTQUEST, String strDTGERPA, String strIDORDPA) {

		NQE0010 request = new NQE0010();
		request.setCOENTID(strCOENTID);
		request.setTPUNIOR(strTPUNIOR.isEmpty()? null : Integer.valueOf(strTPUNIOR));
		request.setCDUNIOR(strCDUNIOR.isEmpty()? null : Integer.valueOf(strCDUNIOR));
		request.setCOALERP(strCOALERP);
		request.setDTQUEST(strDTQUEST);
		request.setDTGERPA(strDTGERPA);
		request.setIDORDPA(strIDORDPA);
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQA1", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0010.class));
			
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

}
