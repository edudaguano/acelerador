package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0370")
public class NQE0370 {
@PsFieldString(name="COPRSPR", length=6, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COPRSPR;

public String getCOPRSPR() {
 return COPRSPR;
}
public void setCOPRSPR(String COPRSPR) {
 this.COPRSPR = COPRSPR;
}


}
