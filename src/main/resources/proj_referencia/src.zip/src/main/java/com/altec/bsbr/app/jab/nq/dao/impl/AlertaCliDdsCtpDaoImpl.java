package com.altec.bsbr.app.jab.nq.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0040;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0240;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0040;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0240;
import com.altec.bsbr.app.jab.nq.dao.AlertaCliDdsCtpDao;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class AlertaCliDdsCtpDaoImpl implements AlertaCliDdsCtpDao {
	private final Logger LOGGER = LoggerFactory.getLogger(AlertaCliDdsCtpDaoImpl.class);

	@Autowired
	private AltairService altairService;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String versao() {
		return "";
	}

	public String consultarContraparte(String strCOENTID, String strCOALERT, String strCDCENAR, String strCDDETIN,
			String strCDOCOPE, String strNUCNTR) {
		
		NQE0040 request = new NQE0040();
		request.setCOENTID(strCOENTID);
		request.setCOALERT(strCOALERT);
		request.setCDCENAR(strCDCENAR);
		request.setCDDETIN(strCDDETIN);
		request.setCDOCOPE(strCDOCOPE);
		request.setNUCNTR(strNUCNTR);
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQA6", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0040.class));
			
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

}
