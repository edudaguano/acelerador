package com.altec.bsbr.app.jab.nq.util;

import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.jab.nq.dto.RespostaGenerica;
import com.altec.bsbr.fw.ps.parser.object.PsObjectReturn;
import com.altec.bsbr.fw.ps.parser.object.PsScreen;

public class Utils {

	public static <E> RespostaGenerica gerarRespostaGenericaAltair(PsObjectReturn resp, Class<E> clazz) {

		RespostaGenerica respostaGenerica = new RespostaGenerica();
		respostaGenerica.setCodigoRetorno(resp.getCodigoRetorno());
		respostaGenerica.setErros(resp.getListaErros());
		respostaGenerica.setMensagem(resp.getListaMensagem());

		List<E> listResult = new ArrayList<E>();
		try {
			for (PsScreen obj : resp.getListaFormatos()) {
				listResult.add((E) obj.getFormato());
			}
			respostaGenerica.setFormatos(listResult);
		} catch (Exception e) {
			e.printStackTrace();

		}
		return respostaGenerica;
	}
}
