package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0200")
public class NQE0200 {
@PsFieldString(name="COSIGLA", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COSIGLA;
@PsFieldNumber(name="NUSEQSI", length=2, defaultValue = "0" )
private Integer NUSEQSI;
@PsFieldString(name="CODETIN", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODETIN;
@PsFieldString(name="COOPINT", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COOPINT;
@PsFieldString(name="NOOPEIN", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOOPEIN;
@PsFieldString(name="ICMONIT", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMONIT;
@PsFieldString(name="TPOPERA", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPOPERA;
@PsFieldString(name="DTHROPE", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTHROPE;
@PsFieldString(name="CDUSRES", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDUSRES;
@PsFieldString(name="TPMANUT", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPMANUT;

public String getCOSIGLA() {
 return COSIGLA;
}
public void setCOSIGLA(String COSIGLA) {
 this.COSIGLA = COSIGLA;
}
public Integer getNUSEQSI() {
 return NUSEQSI;
}
public void setNUSEQSI(Integer nUSEQSI) {
NUSEQSI = nUSEQSI;
}
public String getCODETIN() {
 return CODETIN;
}
public void setCODETIN(String CODETIN) {
 this.CODETIN = CODETIN;
}

public String getCOOPINT() {
 return COOPINT;
}
public void setCOOPINT(String COOPINT) {
 this.COOPINT = COOPINT;
}

public String getNOOPEIN() {
 return NOOPEIN;
}
public void setNOOPEIN(String NOOPEIN) {
 this.NOOPEIN = NOOPEIN;
}

public String getICMONIT() {
 return ICMONIT;
}
public void setICMONIT(String ICMONIT) {
 this.ICMONIT = ICMONIT;
}

public String getTPOPERA() {
 return TPOPERA;
}
public void setTPOPERA(String TPOPERA) {
 this.TPOPERA = TPOPERA;
}

public String getDTHROPE() {
 return DTHROPE;
}
public void setDTHROPE(String DTHROPE) {
 this.DTHROPE = DTHROPE;
}

public String getCDUSRES() {
 return CDUSRES;
}
public void setCDUSRES(String CDUSRES) {
 this.CDUSRES = CDUSRES;
}

public String getTPMANUT() {
 return TPMANUT;
}
public void setTPMANUT(String TPMANUT) {
 this.TPMANUT = TPMANUT;
}


}
