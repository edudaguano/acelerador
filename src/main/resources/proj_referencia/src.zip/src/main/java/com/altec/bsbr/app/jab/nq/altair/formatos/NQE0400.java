package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0400")
public class NQE0400 {
@PsFieldNumber(name="CORGENQ", length=2, defaultValue = "0" )
private Integer CORGENQ;
public Integer getCORGENQ() {
 return CORGENQ;
}
public void setCORGENQ(Integer cORGENQ) {
CORGENQ = cORGENQ;
}

}
