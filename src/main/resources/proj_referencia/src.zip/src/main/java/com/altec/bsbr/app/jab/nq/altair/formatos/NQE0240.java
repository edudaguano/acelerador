package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0240")
public class NQE0240 {
@PsFieldString(name="CODENTI", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODENTI;
@PsFieldString(name="CODALER", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODALER;
@PsFieldString(name="CODCENA", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODCENA;

public String getCODENTI() {
 return CODENTI;
}
public void setCODENTI(String CODENTI) {
 this.CODENTI = CODENTI;
}

public String getCODALER() {
 return CODALER;
}
public void setCODALER(String CODALER) {
 this.CODALER = CODALER;
}

public String getCODCENA() {
 return CODCENA;
}
public void setCODCENA(String CODCENA) {
 this.CODCENA = CODCENA;
}


}
