package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class LDAOPSULegadoRequest {
// -*-LDCE0UB2
//    20    LDCE0UB2.                                              
	@FixedLenghtField(position = 1, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String LDCE0UB2_CD_SIGLA_ACES;// 30 LDCE0UB2-CD-SIGLA-ACES PIC X(8).

// *                 CODIGO DE SIGLA DE ACESSO                     
	@FixedLenghtField(position = 2, lenght = 15, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long LDCE0UB2_CD_MATRIC;// 30 LDCE0UB2-CD-MATRIC PIC 9(15).

// *                 CODIGO DE MATRICULA                           
	@FixedLenghtField(position = 3, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String LDCE0UB2_CD_SIGLA_ADM;// 30 LDCE0UB2-CD-SIGLA-ADM PIC X(8).

// *                 CODIGO DA SIGLA DE ACESSO SOLICITANTE         
	@FixedLenghtField(position = 4, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String LDCE0UB2_DS_MENSAGEM;// 30 LDCE0UB2-DS-MENSAGEM PIC X(50).

// *                 DESCRICAO DA MENSAGEM                         
	@FixedLenghtField(position = 5, lenght = 1119, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String FILLER0;// 30 FILLER PIC X(1119).

// *                 FILLER                                        
	public LDAOPSULegadoRequest() {
	}

	public LDAOPSULegadoRequest(String ldce0ub2_cd_sigla_aces, Long ldce0ub2_cd_matric, String ldce0ub2_cd_sigla_adm,
			String ldce0ub2_ds_mensagem, String filler0) {
		this.LDCE0UB2_CD_SIGLA_ACES = ldce0ub2_cd_sigla_aces;
		this.LDCE0UB2_CD_MATRIC = ldce0ub2_cd_matric;
		this.LDCE0UB2_CD_SIGLA_ADM = ldce0ub2_cd_sigla_adm;
		this.LDCE0UB2_DS_MENSAGEM = ldce0ub2_ds_mensagem;
		this.FILLER0 = filler0;
	}

	public String getLDCE0UB2_CD_SIGLA_ACES() {
		return this.LDCE0UB2_CD_SIGLA_ACES;
	}

	public Long getLDCE0UB2_CD_MATRIC() {
		return this.LDCE0UB2_CD_MATRIC;
	}

	public String getLDCE0UB2_CD_SIGLA_ADM() {
		return this.LDCE0UB2_CD_SIGLA_ADM;
	}

	public String getLDCE0UB2_DS_MENSAGEM() {
		return this.LDCE0UB2_DS_MENSAGEM;
	}

	public String getFILLER0() {
		return this.FILLER0;
	}

	public void setLDCE0UB2_CD_SIGLA_ACES(String ldce0ub2_cd_sigla_aces) {
		this.LDCE0UB2_CD_SIGLA_ACES = ldce0ub2_cd_sigla_aces;
	}

	public void setLDCE0UB2_CD_MATRIC(Long ldce0ub2_cd_matric) {
		this.LDCE0UB2_CD_MATRIC = ldce0ub2_cd_matric;
	}

	public void setLDCE0UB2_CD_SIGLA_ADM(String ldce0ub2_cd_sigla_adm) {
		this.LDCE0UB2_CD_SIGLA_ADM = ldce0ub2_cd_sigla_adm;
	}

	public void setLDCE0UB2_DS_MENSAGEM(String ldce0ub2_ds_mensagem) {
		this.LDCE0UB2_DS_MENSAGEM = ldce0ub2_ds_mensagem;
	}

	public void setFILLER0(String filler0) {
		this.FILLER0 = filler0;
	}
}