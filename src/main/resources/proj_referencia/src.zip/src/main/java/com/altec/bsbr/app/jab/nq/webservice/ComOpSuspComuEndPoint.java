package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.ComOpSuspComuService;
import com.altec.bsbr.app.jab.nq.service.ComOpSuspComuWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class ComOpSuspComuEndPoint extends SpringBeanAutowiringSupport implements ComOpSuspComuWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(ComOpSuspComuEndPoint.class);
	@Autowired
	private ComOpSuspComuService comOpSuspComu;

	@WebMethod
	public String versao() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = comOpSuspComu.versao();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String salvaComunicacao(String strCOENTID, String strCODAGEN, String strTPUNIOR, String strNUNIORG,
			String strNUCONTA, String strNUPENUM, String strTPDOCTO, String strNUDOCTO, String strNOPESSO,
			String strCOSEGPR, String strCOSEGSE, String strCOAREAT, String strTCOPROF, String strVLRENDA,
			String strDTRENDA, String strCOTPREN, String strVLPATRI, String strDTPATRI, String strICCEP,
			String strNOEMPRE, String strCOATIVI, String strCOATCNA, String strCOTPCOR, String strVLFATAN,
			String strDTFATAN, String strTXPARA1, String strTXPARA2, String strTXPARA3, String strTXPARA4,
			String strTXPARA5, String strTXPARA6, String strTXPARA7, String strTXPARA8, String strTXPARA9,
			String strTXPAR10, String strNOCONJU, String strICORREN, String strCDUSRES, String strICIMPED)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = comOpSuspComu.salvaComunicacao(strCOENTID, strCODAGEN, strTPUNIOR, strNUNIORG, strNUCONTA,
					strNUPENUM, strTPDOCTO, strNUDOCTO, strNOPESSO, strCOSEGPR, strCOSEGSE, strCOAREAT, strTCOPROF,
					strVLRENDA, strDTRENDA, strCOTPREN, strVLPATRI, strDTPATRI, strICCEP, strNOEMPRE, strCOATIVI,
					strCOATCNA, strCOTPCOR, strVLFATAN, strDTFATAN, strTXPARA1, strTXPARA2, strTXPARA3, strTXPARA4,
					strTXPARA5, strTXPARA6, strTXPARA7, strTXPARA8, strTXPARA9, strTXPAR10, strNOCONJU, strICORREN,
					strCDUSRES, strICIMPED);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
}
