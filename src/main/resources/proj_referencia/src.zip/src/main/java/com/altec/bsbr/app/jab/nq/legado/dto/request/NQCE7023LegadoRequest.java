package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name= "NQCE7023LegadoRequest")
public class NQCE7023LegadoRequest {


/*-------------------------------------------- CONSTRUTOR --------------------------------------------*/
	public NQCE7023LegadoRequest() {
		super();
	}
	
/*--------------------------------------------- SEND AREA --------------------------------------------*/

	@PsFieldString(name= "NQCE7023_PROG_CALLED", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_PROG_CALLED;//            05      NQCE7023-PROG-CALLED        PIC X(08).               

	@PsFieldString(name= "NQCE7023_NOMEDATS", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_NOMEDATS;//            05      NQCE7023-NOMEDATS           PIC X(10).               

	@PsFieldNumber(name= "NQCE7023_COMMAREA_LEN", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long NQCE7023_COMMAREA_LEN;//            05      NQCE7023-COMMAREA-LEN       PIC 9(07).               

	@PsFieldString(name= "NQCE7023_FUNCAO", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_FUNCAO;//            05      NQCE7023-FUNCAO             PIC X(01).               

	@PsFieldNumber(name= "NQCE7023_CINSTIT", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCE7023_CINSTIT;//            05      NQCE7023-CINSTIT            PIC 9(03).               

	@PsFieldString(name= "NQCE7023_CODPROD", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_CODPROD;//            05      NQCE7023-CODPROD            PIC X(10).               

/*-------------------------------------------- GETTER/SETTER --------------------------------------------*/

	public String getNQCE7023_PROG_CALLED() {
		return NQCE7023_PROG_CALLED;
	}

	public void setNQCE7023_PROG_CALLED(String nQCE7023_PROG_CALLED) {
		NQCE7023_PROG_CALLED = nQCE7023_PROG_CALLED;
	}

	public String getNQCE7023_NOMEDATS() {
		return NQCE7023_NOMEDATS;
	}

	public void setNQCE7023_NOMEDATS(String nQCE7023_NOMEDATS) {
		NQCE7023_NOMEDATS = nQCE7023_NOMEDATS;
	}

	public Long getNQCE7023_COMMAREA_LEN() {
		return NQCE7023_COMMAREA_LEN;
	}

	public void setNQCE7023_COMMAREA_LEN(Long nQCE7023_COMMAREA_LEN) {
		NQCE7023_COMMAREA_LEN = nQCE7023_COMMAREA_LEN;
	}

	public String getNQCE7023_FUNCAO() {
		return NQCE7023_FUNCAO;
	}

	public void setNQCE7023_FUNCAO(String nQCE7023_FUNCAO) {
		NQCE7023_FUNCAO = nQCE7023_FUNCAO;
	}

	public Long getNQCE7023_CINSTIT() {
		return NQCE7023_CINSTIT;
	}

	public void setNQCE7023_CINSTIT(Long nQCE7023_CINSTIT) {
		NQCE7023_CINSTIT = nQCE7023_CINSTIT;
	}

	public String getNQCE7023_CODPROD() {
		return NQCE7023_CODPROD;
	}

	public void setNQCE7023_CODPROD(String nQCE7023_CODPROD) {
		NQCE7023_CODPROD = nQCE7023_CODPROD;
	}
	
}
