package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name = "NQCETB05AreaDados")
public class NQCETB05AreaDados {

/*-------------------------------- CONSTRUTOR ------------------------------*/
	
	public NQCETB05AreaDados() {
		super();
	}

	
/*-------------------------------- Response Area ------------------------------*/                                             
	
	//@PsFieldNumber(name = "NQCETB5S_DATA_LEN", length = 4, binary = true, signed = true, decimal = 0)
	//private Long NQCETB5S_DATA_LEN;// 03 NQCETB5S-DATA-LEN COMP PIC S9(04) VALUE +107.

	//  03    NQCETB5S-DATA.                                            
	@PsFieldNumber(name = "NQCETB5S_NR_SEQU_DOMI_OPER", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB5S_NR_SEQU_DOMI_OPER;// 05 NQCETB5S-NR-SEQU-DOMI-OPER PIC 9(004).

	//       NUMERO DE SEQUENCIA DO DOMINIO                            
	@PsFieldString(name = "NQCETB5S_VL_PARM_DOMI_OPER", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5S_VL_PARM_DOMI_OPER;// 05 NQCETB5S-VL-PARM-DOMI-OPER PIC X(020).

	//       VALOR DO DOMINIO                                          
	@PsFieldString(name = "NQCETB5S_DS_PARM_DOMI_OPER", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5S_DS_PARM_DOMI_OPER;// 05 NQCETB5S-DS-PARM-DOMI-OPER PIC X(040).

	//       DESCRICAO DO DOMINIO                                      
	@PsFieldString(name = "NQCETB5S_TP_USO_DOMI_OPER", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5S_TP_USO_DOMI_OPER;// 05 NQCETB5S-TP-USO-DOMI-OPER PIC X(002).

	//       TIPO DE USO DO DOMINIO                                    
	@PsFieldString(name = "NQCETB5S_IN_DOMI_OPER_ATIV", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5S_IN_DOMI_OPER_ATIV;// 05 NQCETB5S-IN-DOMI-OPER-ATIV PIC X(001).

	//       INDICADOR DE DOMINIO ATIVO                                
	@PsFieldString(name = "NQCETB5S_DS_CNTD", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5S_DS_CNTD;// 05 NQCETB5S-DS-CNTD PIC X(040).


/*-------------------------------- GETTER/SETTER------------------------------*/
	
	public Long getNQCETB5S_NR_SEQU_DOMI_OPER() {
		return NQCETB5S_NR_SEQU_DOMI_OPER;
	}
	
	public void setNQCETB5S_NR_SEQU_DOMI_OPER(Long nQCETB5S_NR_SEQU_DOMI_OPER) {
		NQCETB5S_NR_SEQU_DOMI_OPER = nQCETB5S_NR_SEQU_DOMI_OPER;
	}
	
	public String getNQCETB5S_VL_PARM_DOMI_OPER() {
		return NQCETB5S_VL_PARM_DOMI_OPER;
	}
	
	public void setNQCETB5S_VL_PARM_DOMI_OPER(String nQCETB5S_VL_PARM_DOMI_OPER) {
		NQCETB5S_VL_PARM_DOMI_OPER = nQCETB5S_VL_PARM_DOMI_OPER;
	}
	
	public String getNQCETB5S_DS_PARM_DOMI_OPER() {
		return NQCETB5S_DS_PARM_DOMI_OPER;
	}
	
	public void setNQCETB5S_DS_PARM_DOMI_OPER(String nQCETB5S_DS_PARM_DOMI_OPER) {
		NQCETB5S_DS_PARM_DOMI_OPER = nQCETB5S_DS_PARM_DOMI_OPER;
	}
	
	public String getNQCETB5S_TP_USO_DOMI_OPER() {
		return NQCETB5S_TP_USO_DOMI_OPER;
	}
	
	public void setNQCETB5S_TP_USO_DOMI_OPER(String nQCETB5S_TP_USO_DOMI_OPER) {
		NQCETB5S_TP_USO_DOMI_OPER = nQCETB5S_TP_USO_DOMI_OPER;
	}
	
	public String getNQCETB5S_IN_DOMI_OPER_ATIV() {
		return NQCETB5S_IN_DOMI_OPER_ATIV;
	}
	
	public void setNQCETB5S_IN_DOMI_OPER_ATIV(String nQCETB5S_IN_DOMI_OPER_ATIV) {
		NQCETB5S_IN_DOMI_OPER_ATIV = nQCETB5S_IN_DOMI_OPER_ATIV;
	}
	
	public String getNQCETB5S_DS_CNTD() {
		return NQCETB5S_DS_CNTD;
	}
	
	public void setNQCETB5S_DS_CNTD(String nQCETB5S_DS_CNTD) {
		NQCETB5S_DS_CNTD = nQCETB5S_DS_CNTD;
	}
	

/*------------------- (Arquivo Morto) - AREA DE MENSAGEM ----------------*/                                          
	//@PsFieldNumber(name = "NQCETB5S_MENS_LEN", length = 4, binary = true, signed = true, decimal = 0)
	//private Long NQCETB5S_MENS_LEN;// 03 NQCETB5S-MENS-LEN COMP PIC S9(04) VALUE +83.
	//
	////03    NQCETB5S-MENS.                                            
	//@PsFieldNumber(name = "NQCETB5S_RETORNO", decimal = 0, length = 3, signed = false, defaultValue = "0")
	//private Long NQCETB5S_RETORNO;// 05 NQCETB5S-RETORNO PIC 9(003) VALUE ZEROS.
	//
	//@PsFieldString(name = "NQCETB5S_MENSAGEM", length = 80, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	//private String NQCETB5S_MENSAGEM;// 05 NQCETB5S-MENSAGEM PIC X(080) VALUE SPACES.

}
