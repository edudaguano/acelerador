package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.ParticipaComiteService;
import com.altec.bsbr.app.jab.nq.service.ParticipaComiteWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class ParticipaComiteEndPoint extends SpringBeanAutowiringSupport implements ParticipaComiteWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(ParticipaComiteEndPoint.class);
	@Autowired
	private ParticipaComiteService participaComite;

	@WebMethod
	public String versao() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = participaComite.versao();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarMatricula(String strNUMATRI) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = participaComite.consultarMatricula(strNUMATRI);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarParticipante(String strTPUORCM, String strCDUORCM, String strDTCOMIT)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = participaComite.consultarParticipante(strTPUORCM, strCDUORCM, strDTCOMIT);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String inserirParticipante(String strTPUNIOR, String strCDAGENC, String strDTCOMIT, String strNMMATR1,
			String strDSCARG1, String strNMMATR2, String strDSCARG2, String strNMMATR3, String strDSCARG3,
			String strNMMATR4, String strDSCARG4, String strNMMATR5, String strDSCARG5, String strNMMATR6,
			String strDSCARG6, String strNMMATR7, String strDSCARG7, String strNMMATR8, String strDSCARG8,
			String strNMMATR9, String strDSCARG9, String strNMMATR10, String strDSCARG10, String strCDUSRES)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = participaComite.inserirParticipante(strTPUNIOR, strCDAGENC, strDTCOMIT, strNMMATR1, strDSCARG1,
					strNMMATR2, strDSCARG2, strNMMATR3, strDSCARG3, strNMMATR4, strDSCARG4, strNMMATR5, strDSCARG5,
					strNMMATR6, strDSCARG6, strNMMATR7, strDSCARG7, strNMMATR8, strDSCARG8, strNMMATR9, strDSCARG9,
					strNMMATR10, strDSCARG10, strCDUSRES);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
}
