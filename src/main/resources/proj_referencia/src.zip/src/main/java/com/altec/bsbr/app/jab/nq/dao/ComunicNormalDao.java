package com.altec.bsbr.app.jab.nq.dao;

public interface ComunicNormalDao {
	public String versao();

	public String enviaMensagem(String strCDENTID, String strCDAGENC, String strCDALERT, String strCDUNIOR,
			String strTPUNIOR, String strTXPAR01, String strTXPAR02, String strTXPAR03, String strTXPAR04,
			String strTXPAR05, String strTXPAR06, String strTXPAR07, String strTXPAR08, String strTXPAR09,
			String strTXPAR10, String strTPPAREC, String strDTCOMIT, String strCDUSRES, String strNUSEQUE,
			String strTPCHAMA);
}
