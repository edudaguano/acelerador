package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0380")
public class NQE0380 {
@PsFieldString(name="COENTI", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COENTI;
@PsFieldString(name="COALER", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALER;

public String getCOENTI() {
 return COENTI;
}
public void setCOENTI(String COENTI) {
 this.COENTI = COENTI;
}

public String getCOALER() {
 return COALER;
}
public void setCOALER(String COALER) {
 this.COALER = COALER;
}


}
