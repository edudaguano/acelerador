package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@PsFormat(name = "NQCETB02LegadoRequest")
public class NQCETB02LegadoRequest {
// -*-
//        01     NQCETB02-ENTRADA.                                         
//                                                                         
	@PsFieldString(name = "NQCETB2E_NM_PROG", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB2E_NM_PROG;// 05 NQCETB2E-NM-PROG PIC X(008).

//       *       NOME DO PROGRAMA CHAMADO                                  
//                                                                         
	@PsFieldString(name = "NQCETB2E_NM_AREA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB2E_NM_AREA;// 05 NQCETB2E-NM-AREA PIC X(008).

//       *       NOME DA AREA DE TS                                        
//                                                                         
	@PsFieldString(name = "NQCETB2E_SG_FCAO", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB2E_SG_FCAO;// 05 NQCETB2E-SG-FCAO PIC X(002).

//       *       FUNCAO A SER EXECUTADA                                    
//       *       C = CONSULTAR                                             
//       *       L = LISTAR                                                
//       *       I = INCLUIR                                               
//       *       A = ALTERAR                                               
//       *       E = EXCLUIR                                               
//                                                                         
	@PsFieldNumber(name = "NQCETB2E_QT_TAMA_AREA", decimal = 0, length = 7, signed = false, defaultValue = "0")
	private Long NQCETB2E_QT_TAMA_AREA;// 05 NQCETB2E-QT-TAMA-AREA PIC 9(007).

//       *       TAMANHO DA AREA DE TS                                     
//                                                                         
	@PsFieldString(name = "NQCETB2E_CD_USUA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB2E_CD_USUA;// 05 NQCETB2E-CD-USUA PIC X(008).

//       *       CODIGO DO USUARIO                                         
//                                                                         
	@PsFieldNumber(name = "NQCETB2E_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB2E_NR_SEQU_SIST;// 05 NQCETB2E-NR-SEQU-SIST PIC 9(004).

//       *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                         
	@PsFieldNumber(name = "NQCETB2E_NR_SEQU_CAPO", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB2E_NR_SEQU_CAPO;// 05 NQCETB2E-NR-SEQU-CAPO PIC 9(004).

//       *       NUMERO DE SEQUENCIA DO CAMPO DO SISTEMA                   
//                                                                         
	@PsFieldString(name = "NQCETB2E_DS_CAPO", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB2E_DS_CAPO;// 05 NQCETB2E-DS-CAPO PIC X(040).

//       *       DESCRICAO DO CAMPO DO SISTEMA                             
//                                                                         
	@PsFieldString(name = "NQCETB2E_TP_CAPO", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB2E_TP_CAPO;// 05 NQCETB2E-TP-CAPO PIC X(002).

//       *       TIPO DE CAMPO DO SISTEMA                                  
//                                                                         
	@PsFieldNumber(name = "NQCETB2E_QT_TAMA_CAPO", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB2E_QT_TAMA_CAPO;// 05 NQCETB2E-QT-TAMA-CAPO PIC 9(004).

//       *       TAMANHO DO CAMPO DO SISTEMA                               
//                                                                         
	@PsFieldNumber(name = "NQCETB2E_VL_INIC_FILT_CAPO", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB2E_VL_INIC_FILT_CAPO;// 05 NQCETB2E-VL-INIC-FILT-CAPO PIC 9(004).

//       *       POSICAO INICIAL DO CAMPO NO ARQUIVO                       
//                                                                         
	@PsFieldString(name = "NQCETB2E_IN_CAPO_ATIV", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB2E_IN_CAPO_ATIV;// 05 NQCETB2E-IN-CAPO-ATIV PIC X(001).
                               
	public NQCETB02LegadoRequest() {
	}

	public String getNQCETB2E_NM_PROG() {
		return NQCETB2E_NM_PROG;
	}

	public void setNQCETB2E_NM_PROG(String nQCETB2E_NM_PROG) {
		NQCETB2E_NM_PROG = nQCETB2E_NM_PROG;
	}

	public String getNQCETB2E_NM_AREA() {
		return NQCETB2E_NM_AREA;
	}

	public void setNQCETB2E_NM_AREA(String nQCETB2E_NM_AREA) {
		NQCETB2E_NM_AREA = nQCETB2E_NM_AREA;
	}

	public String getNQCETB2E_SG_FCAO() {
		return NQCETB2E_SG_FCAO;
	}

	public void setNQCETB2E_SG_FCAO(String nQCETB2E_SG_FCAO) {
		NQCETB2E_SG_FCAO = nQCETB2E_SG_FCAO;
	}

	public Long getNQCETB2E_QT_TAMA_AREA() {
		return NQCETB2E_QT_TAMA_AREA;
	}

	public void setNQCETB2E_QT_TAMA_AREA(Long nQCETB2E_QT_TAMA_AREA) {
		NQCETB2E_QT_TAMA_AREA = nQCETB2E_QT_TAMA_AREA;
	}

	public String getNQCETB2E_CD_USUA() {
		return NQCETB2E_CD_USUA;
	}

	public void setNQCETB2E_CD_USUA(String nQCETB2E_CD_USUA) {
		NQCETB2E_CD_USUA = nQCETB2E_CD_USUA;
	}

	public Long getNQCETB2E_NR_SEQU_SIST() {
		return NQCETB2E_NR_SEQU_SIST;
	}

	public void setNQCETB2E_NR_SEQU_SIST(Long nQCETB2E_NR_SEQU_SIST) {
		NQCETB2E_NR_SEQU_SIST = nQCETB2E_NR_SEQU_SIST;
	}

	public Long getNQCETB2E_NR_SEQU_CAPO() {
		return NQCETB2E_NR_SEQU_CAPO;
	}

	public void setNQCETB2E_NR_SEQU_CAPO(Long nQCETB2E_NR_SEQU_CAPO) {
		NQCETB2E_NR_SEQU_CAPO = nQCETB2E_NR_SEQU_CAPO;
	}

	public String getNQCETB2E_DS_CAPO() {
		return NQCETB2E_DS_CAPO;
	}

	public void setNQCETB2E_DS_CAPO(String nQCETB2E_DS_CAPO) {
		NQCETB2E_DS_CAPO = nQCETB2E_DS_CAPO;
	}

	public String getNQCETB2E_TP_CAPO() {
		return NQCETB2E_TP_CAPO;
	}

	public void setNQCETB2E_TP_CAPO(String nQCETB2E_TP_CAPO) {
		NQCETB2E_TP_CAPO = nQCETB2E_TP_CAPO;
	}

	public Long getNQCETB2E_QT_TAMA_CAPO() {
		return NQCETB2E_QT_TAMA_CAPO;
	}

	public void setNQCETB2E_QT_TAMA_CAPO(Long nQCETB2E_QT_TAMA_CAPO) {
		NQCETB2E_QT_TAMA_CAPO = nQCETB2E_QT_TAMA_CAPO;
	}

	public Long getNQCETB2E_VL_INIC_FILT_CAPO() {
		return NQCETB2E_VL_INIC_FILT_CAPO;
	}

	public void setNQCETB2E_VL_INIC_FILT_CAPO(Long nQCETB2E_VL_INIC_FILT_CAPO) {
		NQCETB2E_VL_INIC_FILT_CAPO = nQCETB2E_VL_INIC_FILT_CAPO;
	}

	public String getNQCETB2E_IN_CAPO_ATIV() {
		return NQCETB2E_IN_CAPO_ATIV;
	}

	public void setNQCETB2E_IN_CAPO_ATIV(String nQCETB2E_IN_CAPO_ATIV) {
		NQCETB2E_IN_CAPO_ATIV = nQCETB2E_IN_CAPO_ATIV;
	}

}