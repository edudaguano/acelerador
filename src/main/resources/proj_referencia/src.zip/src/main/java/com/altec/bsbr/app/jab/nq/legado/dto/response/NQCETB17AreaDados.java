package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB17AreaDados")
public class NQCETB17AreaDados {

	// *       NUMERO SEQUENCIAL DA OPERACAO                             
	//                                                                   
	// *----------------------------------------------------------------*
	// *       AREA DE SAIDA                                             
	// *----------------------------------------------------------------*                                          
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_CD_BANC_CLIE;//          05   NQCETB17-S-CD-BANC-CLIE       PIC  X(004).                
	
	// *       CODIGO DO BANCO                                           
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_CD_CLIE;//          05   NQCETB17-S-CD-CLIE            PIC  X(008).                
	
	// *       CODIGO DO CLIENTE                                         
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_DT_MOVI", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_DT_MOVI;//          05   NQCETB17-S-DT-MOVI            PIC  X(010).                
	
	// *       DATA DO MOVIMENTO                                         
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_CD_TITU", length= 11, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_CD_TITU;//          05   NQCETB17-S-CD-TITU            PIC  X(011).                
	
	// *       CODIGO DO TITULO                                          
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_NR_CNTA_CLIE", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_NR_CNTA_CLIE;//     05   NQCETB17-S-NR-CNTA-CLIE       PIC  X(020).                
	
	//*       NUMERO DA CONTA CLIENTE                                   
	//                                                                   
	@PsFieldNumber(name= "NQCETB17_S_VL_RECB", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB17_S_VL_RECB;//          05   NQCETB17-S-VL-RECB            PIC S9(015)V99.             
	
	// *       VALOR RECEBIDO                                            
	//                                                                   
	@PsFieldNumber(name= "NQCETB17_S_VL_RESG", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB17_S_VL_RESG;//          05   NQCETB17-S-VL-RESG            PIC S9(015)V99.             
	
	// *       VALOR DO RESGATE                                          
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_TP_FORM_PGTO", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_TP_FORM_PGTO;//          05   NQCETB17-S-TP-FORM-PGTO       PIC  X(001).                
	
	// *       TIPO DA FORMA DE PAGAMENTO                                
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_TP_FORM_RESG", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_TP_FORM_RESG;//          05   NQCETB17-S-TP-FORM-RESG       PIC  X(001).                
	
	// *       TIPO DA FORMA DE RESGATE                                  
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_DT_CNTR", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_DT_CNTR;//          05   NQCETB17-S-DT-CNTR            PIC  X(010).                
	
	// *       DATA DA CONTRATACAO                                       
	//                                                                   
	@PsFieldNumber(name= "NQCETB17_S_QT_TITU", decimal= 0, length= 3, signed= true, defaultValue="0")
	private Long NQCETB17_S_QT_TITU;//          05   NQCETB17-S-QT-TITU            PIC S9(003).                
	
	// *       QUANTIDADE DE TITULOS                                     
	//                                                                   
	@PsFieldNumber(name= "NQCETB17_S_VL_UNIT_TITU", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB17_S_VL_UNIT_TITU;//          05   NQCETB17-S-VL-UNIT-TITU       PIC S9(015)V99.             
	
	// *       VALOR UNITARIO DO TITULO                                  
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_DT_PGTO", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_DT_PGTO;//          05   NQCETB17-S-DT-PGTO            PIC  X(010).                
	
	// *       DATA DE PAGAMENTO DO TITULO                               
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_DT_RESG", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_DT_RESG;//          05   NQCETB17-S-DT-RESG            PIC  X(010).                
	
	// *       DATA DE RESGATE DO TITULO                                 
	//                                                                   
	@PsFieldNumber(name= "NQCETB17_S_VL_RECB_SORT", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB17_S_VL_RECB_SORT;//          05   NQCETB17-S-VL-RECB-SORT       PIC S9(015)V99.             
	
	// *       VALOR RECEBIDO DO SORTEIO                                 
	//                                                                   
	@PsFieldNumber(name= "NQCETB17_S_VL_SALD_RESE_MTMA", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB17_S_VL_SALD_RESE_MTMA;//          05   NQCETB17-S-VL-SALD-RESE-MTMA  PIC S9(015)V99.             
	
	// *       VALOR DO SALDO DA RESERVA MATEMATICA                      
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_TP_TRAN", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_TP_TRAN;//          05   NQCETB17-S-TP-TRAN            PIC  X(001).                
	
	// *       TIPO DE TRANSACAO                                         
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_CD_BANC_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_CD_BANC_CNTR;//          05   NQCETB17-S-CD-BANC-CNTR       PIC  X(004).                
	
	// *       CODIGO DO BANCO DO CONTRATO                               
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_CD_AGEN_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_CD_AGEN_CNTR;//          05   NQCETB17-S-CD-AGEN-CNTR       PIC  X(004).                
	
	// *       CODIGO DA AGENCIA DO CONTRATO                             
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_NR_CNTR_A", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_NR_CNTR_A;//          05   NQCETB17-S-NR-CNTR-A          PIC  X(020).                
	
	// *       NUMERO DO CONTRATO ALTAIR                                 
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_CD_PROD_ALTAIR;//          05   NQCETB17-S-CD-PROD-ALTAIR     PIC  X(002).                
	
	// *       CODIGO DO PRODUTO                                         
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_CD_SUBP_ALTAIR;//          05   NQCETB17-S-CD-SUBP-ALTAIR     PIC  X(004).                
	
	// *       CODIGO DO SUBPRODUTO                                      
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_CD_MOED", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_CD_MOED;//          05   NQCETB17-S-CD-MOED            PIC  X(003).                
	
	// *       CODIGO DA MOEDA                                           
	//                                                                   
	@PsFieldNumber(name= "NQCETB17_S_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB17_S_NR_SEQU_OPER;//          05   NQCETB17-S-NR-SEQU-OPER       PIC  9(003).                
	
	// *       NUMERO SEQUENCIAL DA OPERACAO                             
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_CD_IDEF_OPER", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_CD_IDEF_OPER;//          05   NQCETB17-S-CD-IDEF-OPER       PIC  X(020).                
	
	// *       CODIGO DA IDENTIFICACAO DA OPERACAO                       
	//                                                                   
	@PsFieldString(name= "NQCETB17_S_NM_CLIE", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_S_NM_CLIE;//     05   NQCETB17-S-NM-CLIE            PIC  X(040).                	
	//*       NOME DO CLIENTE                                           

	public String getNQCETB17_S_CD_BANC_CLIE() {
		return NQCETB17_S_CD_BANC_CLIE;
	}

	public void setNQCETB17_S_CD_BANC_CLIE(String nQCETB17_S_CD_BANC_CLIE) {
		NQCETB17_S_CD_BANC_CLIE = nQCETB17_S_CD_BANC_CLIE;
	}

	public String getNQCETB17_S_CD_CLIE() {
		return NQCETB17_S_CD_CLIE;
	}

	public void setNQCETB17_S_CD_CLIE(String nQCETB17_S_CD_CLIE) {
		NQCETB17_S_CD_CLIE = nQCETB17_S_CD_CLIE;
	}

	public String getNQCETB17_S_DT_MOVI() {
		return NQCETB17_S_DT_MOVI;
	}

	public void setNQCETB17_S_DT_MOVI(String nQCETB17_S_DT_MOVI) {
		NQCETB17_S_DT_MOVI = nQCETB17_S_DT_MOVI;
	}

	public String getNQCETB17_S_CD_TITU() {
		return NQCETB17_S_CD_TITU;
	}

	public void setNQCETB17_S_CD_TITU(String nQCETB17_S_CD_TITU) {
		NQCETB17_S_CD_TITU = nQCETB17_S_CD_TITU;
	}

	public String getNQCETB17_S_NR_CNTA_CLIE() {
		return NQCETB17_S_NR_CNTA_CLIE;
	}

	public void setNQCETB17_S_NR_CNTA_CLIE(String nQCETB17_S_NR_CNTA_CLIE) {
		NQCETB17_S_NR_CNTA_CLIE = nQCETB17_S_NR_CNTA_CLIE;
	}

	public Double getNQCETB17_S_VL_RECB() {
		return NQCETB17_S_VL_RECB;
	}

	public void setNQCETB17_S_VL_RECB(Double nQCETB17_S_VL_RECB) {
		NQCETB17_S_VL_RECB = nQCETB17_S_VL_RECB;
	}

	public Double getNQCETB17_S_VL_RESG() {
		return NQCETB17_S_VL_RESG;
	}

	public void setNQCETB17_S_VL_RESG(Double nQCETB17_S_VL_RESG) {
		NQCETB17_S_VL_RESG = nQCETB17_S_VL_RESG;
	}

	public String getNQCETB17_S_TP_FORM_PGTO() {
		return NQCETB17_S_TP_FORM_PGTO;
	}

	public void setNQCETB17_S_TP_FORM_PGTO(String nQCETB17_S_TP_FORM_PGTO) {
		NQCETB17_S_TP_FORM_PGTO = nQCETB17_S_TP_FORM_PGTO;
	}

	public String getNQCETB17_S_TP_FORM_RESG() {
		return NQCETB17_S_TP_FORM_RESG;
	}

	public void setNQCETB17_S_TP_FORM_RESG(String nQCETB17_S_TP_FORM_RESG) {
		NQCETB17_S_TP_FORM_RESG = nQCETB17_S_TP_FORM_RESG;
	}

	public String getNQCETB17_S_DT_CNTR() {
		return NQCETB17_S_DT_CNTR;
	}

	public void setNQCETB17_S_DT_CNTR(String nQCETB17_S_DT_CNTR) {
		NQCETB17_S_DT_CNTR = nQCETB17_S_DT_CNTR;
	}

	public Long getNQCETB17_S_QT_TITU() {
		return NQCETB17_S_QT_TITU;
	}

	public void setNQCETB17_S_QT_TITU(Long nQCETB17_S_QT_TITU) {
		NQCETB17_S_QT_TITU = nQCETB17_S_QT_TITU;
	}

	public Double getNQCETB17_S_VL_UNIT_TITU() {
		return NQCETB17_S_VL_UNIT_TITU;
	}

	public void setNQCETB17_S_VL_UNIT_TITU(Double nQCETB17_S_VL_UNIT_TITU) {
		NQCETB17_S_VL_UNIT_TITU = nQCETB17_S_VL_UNIT_TITU;
	}

	public String getNQCETB17_S_DT_PGTO() {
		return NQCETB17_S_DT_PGTO;
	}

	public void setNQCETB17_S_DT_PGTO(String nQCETB17_S_DT_PGTO) {
		NQCETB17_S_DT_PGTO = nQCETB17_S_DT_PGTO;
	}

	public String getNQCETB17_S_DT_RESG() {
		return NQCETB17_S_DT_RESG;
	}

	public void setNQCETB17_S_DT_RESG(String nQCETB17_S_DT_RESG) {
		NQCETB17_S_DT_RESG = nQCETB17_S_DT_RESG;
	}

	public Double getNQCETB17_S_VL_RECB_SORT() {
		return NQCETB17_S_VL_RECB_SORT;
	}

	public void setNQCETB17_S_VL_RECB_SORT(Double nQCETB17_S_VL_RECB_SORT) {
		NQCETB17_S_VL_RECB_SORT = nQCETB17_S_VL_RECB_SORT;
	}

	public Double getNQCETB17_S_VL_SALD_RESE_MTMA() {
		return NQCETB17_S_VL_SALD_RESE_MTMA;
	}

	public void setNQCETB17_S_VL_SALD_RESE_MTMA(Double nQCETB17_S_VL_SALD_RESE_MTMA) {
		NQCETB17_S_VL_SALD_RESE_MTMA = nQCETB17_S_VL_SALD_RESE_MTMA;
	}

	public String getNQCETB17_S_TP_TRAN() {
		return NQCETB17_S_TP_TRAN;
	}

	public void setNQCETB17_S_TP_TRAN(String nQCETB17_S_TP_TRAN) {
		NQCETB17_S_TP_TRAN = nQCETB17_S_TP_TRAN;
	}

	public String getNQCETB17_S_CD_BANC_CNTR() {
		return NQCETB17_S_CD_BANC_CNTR;
	}

	public void setNQCETB17_S_CD_BANC_CNTR(String nQCETB17_S_CD_BANC_CNTR) {
		NQCETB17_S_CD_BANC_CNTR = nQCETB17_S_CD_BANC_CNTR;
	}

	public String getNQCETB17_S_CD_AGEN_CNTR() {
		return NQCETB17_S_CD_AGEN_CNTR;
	}

	public void setNQCETB17_S_CD_AGEN_CNTR(String nQCETB17_S_CD_AGEN_CNTR) {
		NQCETB17_S_CD_AGEN_CNTR = nQCETB17_S_CD_AGEN_CNTR;
	}

	public String getNQCETB17_S_NR_CNTR_A() {
		return NQCETB17_S_NR_CNTR_A;
	}

	public void setNQCETB17_S_NR_CNTR_A(String nQCETB17_S_NR_CNTR_A) {
		NQCETB17_S_NR_CNTR_A = nQCETB17_S_NR_CNTR_A;
	}

	public String getNQCETB17_S_CD_PROD_ALTAIR() {
		return NQCETB17_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB17_S_CD_PROD_ALTAIR(String nQCETB17_S_CD_PROD_ALTAIR) {
		NQCETB17_S_CD_PROD_ALTAIR = nQCETB17_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB17_S_CD_SUBP_ALTAIR() {
		return NQCETB17_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB17_S_CD_SUBP_ALTAIR(String nQCETB17_S_CD_SUBP_ALTAIR) {
		NQCETB17_S_CD_SUBP_ALTAIR = nQCETB17_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB17_S_CD_MOED() {
		return NQCETB17_S_CD_MOED;
	}

	public void setNQCETB17_S_CD_MOED(String nQCETB17_S_CD_MOED) {
		NQCETB17_S_CD_MOED = nQCETB17_S_CD_MOED;
	}

	public Long getNQCETB17_S_NR_SEQU_OPER() {
		return NQCETB17_S_NR_SEQU_OPER;
	}

	public void setNQCETB17_S_NR_SEQU_OPER(Long nQCETB17_S_NR_SEQU_OPER) {
		NQCETB17_S_NR_SEQU_OPER = nQCETB17_S_NR_SEQU_OPER;
	}

	public String getNQCETB17_S_CD_IDEF_OPER() {
		return NQCETB17_S_CD_IDEF_OPER;
	}

	public void setNQCETB17_S_CD_IDEF_OPER(String nQCETB17_S_CD_IDEF_OPER) {
		NQCETB17_S_CD_IDEF_OPER = nQCETB17_S_CD_IDEF_OPER;
	}

	public String getNQCETB17_S_NM_CLIE() {
		return NQCETB17_S_NM_CLIE;
	}

	public void setNQCETB17_S_NM_CLIE(String nQCETB17_S_NM_CLIE) {
		NQCETB17_S_NM_CLIE = nQCETB17_S_NM_CLIE;
	}
	 
	

	
}