package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0320")
public class NQS0320 {
@PsFieldString(name="DTCOMIT", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTCOMIT;
@PsFieldNumber(name="COPAREC", length=2, defaultValue = "0" )
private Integer COPAREC;
@PsFieldNumber(name="NUSEQPA", length=3, defaultValue = "0" )
private Integer NUSEQPA;
@PsFieldString(name="TXTPA01", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPA01;
@PsFieldString(name="TXTPA02", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPA02;
@PsFieldString(name="TXTPA03", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPA03;
@PsFieldString(name="TXTPA04", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPA04;
@PsFieldString(name="TXTPA05", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPA05;
@PsFieldString(name="TXTPA06", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPA06;
@PsFieldString(name="TXTPA07", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPA07;
@PsFieldString(name="TXTPA08", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPA08;
@PsFieldString(name="TXTPA09", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPA09;
@PsFieldString(name="TXTPA10", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPA10;

public String getDTCOMIT() {
 return DTCOMIT;
}
public void setDTCOMIT(String DTCOMIT) {
 this.DTCOMIT = DTCOMIT;
}
public Integer getCOPAREC() {
 return COPAREC;
}
public void setCOPAREC(Integer cOPAREC) {
COPAREC = cOPAREC;
}public Integer getNUSEQPA() {
 return NUSEQPA;
}
public void setNUSEQPA(Integer nUSEQPA) {
NUSEQPA = nUSEQPA;
}
public String getTXTPA01() {
 return TXTPA01;
}
public void setTXTPA01(String TXTPA01) {
 this.TXTPA01 = TXTPA01;
}

public String getTXTPA02() {
 return TXTPA02;
}
public void setTXTPA02(String TXTPA02) {
 this.TXTPA02 = TXTPA02;
}

public String getTXTPA03() {
 return TXTPA03;
}
public void setTXTPA03(String TXTPA03) {
 this.TXTPA03 = TXTPA03;
}

public String getTXTPA04() {
 return TXTPA04;
}
public void setTXTPA04(String TXTPA04) {
 this.TXTPA04 = TXTPA04;
}

public String getTXTPA05() {
 return TXTPA05;
}
public void setTXTPA05(String TXTPA05) {
 this.TXTPA05 = TXTPA05;
}

public String getTXTPA06() {
 return TXTPA06;
}
public void setTXTPA06(String TXTPA06) {
 this.TXTPA06 = TXTPA06;
}

public String getTXTPA07() {
 return TXTPA07;
}
public void setTXTPA07(String TXTPA07) {
 this.TXTPA07 = TXTPA07;
}

public String getTXTPA08() {
 return TXTPA08;
}
public void setTXTPA08(String TXTPA08) {
 this.TXTPA08 = TXTPA08;
}

public String getTXTPA09() {
 return TXTPA09;
}
public void setTXTPA09(String TXTPA09) {
 this.TXTPA09 = TXTPA09;
}

public String getTXTPA10() {
 return TXTPA10;
}
public void setTXTPA10(String TXTPA10) {
 this.TXTPA10 = TXTPA10;
}


}
