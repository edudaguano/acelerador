package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0230")
public class NQS0230 {
@PsFieldString(name="COSITUA", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COSITUA;
@PsFieldString(name="COSITU1", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COSITU1;
@PsFieldString(name="DSSIT01", length=80, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSSIT01;

public String getCOSITUA() {
 return COSITUA;
}
public void setCOSITUA(String COSITUA) {
 this.COSITUA = COSITUA;
}

public String getCOSITU1() {
 return COSITU1;
}
public void setCOSITU1(String COSITU1) {
 this.COSITU1 = COSITU1;
}

public String getDSSIT01() {
 return DSSIT01;
}
public void setDSSIT01(String DSSIT01) {
 this.DSSIT01 = DSSIT01;
}


}
