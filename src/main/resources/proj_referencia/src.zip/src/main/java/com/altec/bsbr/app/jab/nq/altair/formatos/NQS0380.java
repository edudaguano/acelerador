package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0380")
public class NQS0380 {
@PsFieldNumber(name="COPAREC", length=2, defaultValue = "0" )
private Integer COPAREC;
@PsFieldString(name="TXPARE1", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARE1;
@PsFieldString(name="TXPARE2", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARE2;
@PsFieldString(name="TXPARE3", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARE3;
@PsFieldString(name="TXPARE4", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARE4;
@PsFieldString(name="TXPARE5", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARE5;
@PsFieldString(name="TXPARE6", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARE6;
@PsFieldString(name="TXPARE7", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARE7;
@PsFieldString(name="TXPARE8", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARE8;
@PsFieldString(name="TXPARE9", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARE9;
@PsFieldString(name="TXPAR10", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPAR10;
public Integer getCOPAREC() {
 return COPAREC;
}
public void setCOPAREC(Integer cOPAREC) {
COPAREC = cOPAREC;
}
public String getTXPARE1() {
 return TXPARE1;
}
public void setTXPARE1(String TXPARE1) {
 this.TXPARE1 = TXPARE1;
}

public String getTXPARE2() {
 return TXPARE2;
}
public void setTXPARE2(String TXPARE2) {
 this.TXPARE2 = TXPARE2;
}

public String getTXPARE3() {
 return TXPARE3;
}
public void setTXPARE3(String TXPARE3) {
 this.TXPARE3 = TXPARE3;
}

public String getTXPARE4() {
 return TXPARE4;
}
public void setTXPARE4(String TXPARE4) {
 this.TXPARE4 = TXPARE4;
}

public String getTXPARE5() {
 return TXPARE5;
}
public void setTXPARE5(String TXPARE5) {
 this.TXPARE5 = TXPARE5;
}

public String getTXPARE6() {
 return TXPARE6;
}
public void setTXPARE6(String TXPARE6) {
 this.TXPARE6 = TXPARE6;
}

public String getTXPARE7() {
 return TXPARE7;
}
public void setTXPARE7(String TXPARE7) {
 this.TXPARE7 = TXPARE7;
}

public String getTXPARE8() {
 return TXPARE8;
}
public void setTXPARE8(String TXPARE8) {
 this.TXPARE8 = TXPARE8;
}

public String getTXPARE9() {
 return TXPARE9;
}
public void setTXPARE9(String TXPARE9) {
 this.TXPARE9 = TXPARE9;
}

public String getTXPAR10() {
 return TXPAR10;
}
public void setTXPAR10(String TXPAR10) {
 this.TXPAR10 = TXPAR10;
}


}
