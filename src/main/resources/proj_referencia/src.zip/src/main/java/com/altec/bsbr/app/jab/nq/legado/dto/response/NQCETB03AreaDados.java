package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;


@PsFormat(name= "NQCETB03AreaDados")
public class NQCETB03AreaDados {

	//     03    NQCETB3S-DATA.                                            
	@PsFieldNumber(name= "NQCETB3S_NR_SEQU_SIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB3S_NR_SEQU_SIST;//      05   NQCETB3S-NR-SEQU-SIST         PIC  9(004).                

//   *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                     
	@PsFieldNumber(name= "NQCETB3S_NR_SEQU_LIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB3S_NR_SEQU_LIST;//      05   NQCETB3S-NR-SEQU-LIST         PIC  9(004).                

//   *       NUMERO DE SEQUENCIA DA LISTA                              
//                                                                     
	@PsFieldString(name= "NQCETB3S_DS_LIST", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB3S_DS_LIST;//      05   NQCETB3S-DS-LIST              PIC  X(040).                

//   *       DESCRICAO DA LISTA                                        
//                                                                     
	@PsFieldNumber(name= "NQCETB3S_NR_SEQU_CAPO_SIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB3S_NR_SEQU_CAPO_SIST;//      05   NQCETB3S-NR-SEQU-CAPO-SIST    PIC  9(004).                

//   *       NUMERO DE SEQUENCIA DO CAMPO DO SISTEMA ASSOCIADO         
//                                                                     
	@PsFieldString(name= "NQCETB3S_IN_LIST_ATIV", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB3S_IN_LIST_ATIV;//      05   NQCETB3S-IN-LIST-ATIV         PIC  X(001).                

//   *       INDICADOR DE LISTA ATIVA                                  
//                                                                     
	@PsFieldString(name= "NQCETB3S_DS_CAPO", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB3S_DS_CAPO;//      05   NQCETB3S-DS-CAPO              PIC  X(040).                

//   *       DESCRICAO DO CAMPO                                                                                                           
	public NQCETB03AreaDados() { }

	public Long getNQCETB3S_NR_SEQU_SIST() {
		return NQCETB3S_NR_SEQU_SIST;
	}

	public void setNQCETB3S_NR_SEQU_SIST(Long nQCETB3S_NR_SEQU_SIST) {
		NQCETB3S_NR_SEQU_SIST = nQCETB3S_NR_SEQU_SIST;
	}

	public Long getNQCETB3S_NR_SEQU_LIST() {
		return NQCETB3S_NR_SEQU_LIST;
	}

	public void setNQCETB3S_NR_SEQU_LIST(Long nQCETB3S_NR_SEQU_LIST) {
		NQCETB3S_NR_SEQU_LIST = nQCETB3S_NR_SEQU_LIST;
	}

	public String getNQCETB3S_DS_LIST() {
		return NQCETB3S_DS_LIST;
	}

	public void setNQCETB3S_DS_LIST(String nQCETB3S_DS_LIST) {
		NQCETB3S_DS_LIST = nQCETB3S_DS_LIST;
	}

	public Long getNQCETB3S_NR_SEQU_CAPO_SIST() {
		return NQCETB3S_NR_SEQU_CAPO_SIST;
	}

	public void setNQCETB3S_NR_SEQU_CAPO_SIST(Long nQCETB3S_NR_SEQU_CAPO_SIST) {
		NQCETB3S_NR_SEQU_CAPO_SIST = nQCETB3S_NR_SEQU_CAPO_SIST;
	}

	public String getNQCETB3S_IN_LIST_ATIV() {
		return NQCETB3S_IN_LIST_ATIV;
	}

	public void setNQCETB3S_IN_LIST_ATIV(String nQCETB3S_IN_LIST_ATIV) {
		NQCETB3S_IN_LIST_ATIV = nQCETB3S_IN_LIST_ATIV;
	}

	public String getNQCETB3S_DS_CAPO() {
		return NQCETB3S_DS_CAPO;
	}

	public void setNQCETB3S_DS_CAPO(String nQCETB3S_DS_CAPO) {
		NQCETB3S_DS_CAPO = nQCETB3S_DS_CAPO;
	}

	
}