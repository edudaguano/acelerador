package com.altec.bsbr.app.jab.nq.dao;

public interface HistoricoDao {
	
	public String recuperaDadosAlt(String intConceito1, String intConceito2);

	public String recuperaDadosInc(String intHistorico,String intAgrupamento, String intConceito1, String intConceito2);
	
	public String consultarLista(String intOpcao, String intBanco, String intProduto, String intPeriodicidade);
	
	public String consultarBancoProdPeriod();
	
	public String IncluirHistorico(String intOpcao, String intBanco, String intPeriodicidade,
String intProduto, String intCodHist, String intHistorico, String strUsuario, String strDescricao,
String strConceito1, String strConceito2);
	
	public String AlterarHistorico(String intOpcao, String intBanco, String intPeriodicidade, 
String intProduto, String intCodHist, String intHistorico, String strUsuario,
String strDescricao,  //Right("000" & Trim(strDescricao),3), _
String strConceito1, String strConceito2);
	
	public String ExclusaoItem(String intOpcao, String intBanco, String intProduto, 
String intPeriodicidade, String intCodHist, String intHistorico, String strUsuario);
	
}
