package com.altec.bsbr.app.jab.nq.service.impl;

import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.altec.bsbr.app.jab.nq.dao.VisitasDao;
import com.altec.bsbr.app.jab.nq.service.VisitasService;
import com.altec.bsbr.fw.BusinessException;

@Service 
public class VisitasServiceImpl implements VisitasService{ 
	private final Logger LOGGER = LoggerFactory.getLogger(VisitasServiceImpl.class); 
	@Autowired
	private VisitasDao visitas;
	
	public String grid6070(String NQAT6070p, String NQAT6070s, String campoNumerico, 
			String campoAlfanumerico, long lngMatricula, String banco, String agencia, String status, 
			String pessoa, long cnpjCpf, int codigo, String mensagem) throws BusinessException { 
		
		return visitas.grid6070(NQAT6070p,  NQAT6070s,  campoNumerico, campoAlfanumerico,  
				lngMatricula,  banco,  agencia,  status, pessoa,  cnpjCpf,  codigo,  mensagem);
	}

	public String especifica6071(String NQAT6071p, String NQAT6071s,
			String campoNumerico, String campoAlfanumerico, long lngMatricula, 
			String chave1, String chave2, String chave3, String chave4,  
			String chave5, String chave6, String texto1, int codigo, String mensagem) throws BusinessException { 
		
		return visitas.especifica6071( NQAT6071p,  NQAT6071s, campoNumerico,  campoAlfanumerico, 
				lngMatricula, chave1,  chave2,  chave3,  chave4,  chave5,  chave6,  texto1,  codigo,  mensagem);
	}

	public String parecer6072(String NQAT6072p, String NQAT6072s, 
			 String numericoUm,  String campoAlfanumerico,  long lngMatricula, 
			 String cboBanco,  String txtAgencia,  String tpPessoa, String cpfCnpj, 
			 String texto1, String texto2, String texto3, String texto4, String texto5, 
			 String motivo, long longMatricula, Date data, String tpPerfil, String acao, 
			 int codigo, String mensagem) throws BusinessException { 
		return visitas.parecer6072( NQAT6072p,  NQAT6072s, numericoUm,   campoAlfanumerico,   lngMatricula, 
				  cboBanco,   txtAgencia,   tpPessoa,  cpfCnpj, texto1,  texto2,  texto3,  texto4,  texto5, 
				  motivo,  longMatricula,  data,  tpPerfil,  acao, codigo,  mensagem);
	}
	
	public String incExc6073(String NQAT6073p, String NQAT6073s, 
			String campoNumerico, String campoAlfanumerico, long matricula, 
			String banco, String agencia, String pessoa, String documento, 
			String conta, String acao, int codigo, String mensagem) throws BusinessException{ 
		return visitas.incExc6073( NQAT6073p,  NQAT6073s, campoNumerico,  campoAlfanumerico,  matricula, 
				 banco,  agencia,  pessoa,  documento, conta,  acao,  codigo,  mensagem);
	}

	public String gridTotal6074(String NQAT6074p,  String NQAT6074s, 
			String campoNumerico, String campoAlfanumerico,  long matricula, 
			String banco,  Date data,  String texto1, int codigo, String parm) throws BusinessException{ 
		return visitas.gridTotal6074( NQAT6074p,   NQAT6074s, campoNumerico,  campoAlfanumerico,   matricula, 
				 banco,  data,   texto1,  codigo,  parm);
	}
	
	
}

