package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface FiltrosACService {
	public String consultarFiltros2(String strCodSist, String strDtOcorr, String strCodUser)
			throws BusinessException;

	public String consultarFiltros(String strCodSist, String strDtOcorr, String strCodUser)
			throws BusinessException;

	public String fnAddCaracter(String vlr, String tp, String tam) throws BusinessException;

	public String dataAlta(String dtBaixa) throws BusinessException;
}
