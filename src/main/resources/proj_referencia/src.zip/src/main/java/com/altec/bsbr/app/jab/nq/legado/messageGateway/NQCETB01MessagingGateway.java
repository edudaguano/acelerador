package com.altec.bsbr.app.jab.nq.legado.messageGateway;

import java.util.List;

import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB01LegadoRequest;
import com.altec.bsbr.fw.jms.legado.LegadoException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;

public interface NQCETB01MessagingGateway {
	
	LegadoResult sendMessageLegado(NQCETB01LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageMultiLegado(NQCETB01LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageListLegado(List<NQCETB01LegadoRequest> arg0) throws LegadoException;

}