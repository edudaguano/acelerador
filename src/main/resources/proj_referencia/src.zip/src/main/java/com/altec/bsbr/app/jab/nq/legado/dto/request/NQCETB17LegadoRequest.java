package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name= "NQCETB17")
public class NQCETB17LegadoRequest {

	//  -*-
	//  01     NQCETB17-ENTRADA.                                         
	//                                                                   
	@PsFieldString(name= "NQCETB17_E_NM_PROG", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_E_NM_PROG;//          05   NQCETB17-E-NM-PROG            PIC  X(008).                
	
	// *       NOME DO PROGRAMA CHAMADO                                  
	//                                                                   
	@PsFieldString(name= "NQCETB17_E_NM_AREA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_E_NM_AREA;//          05   NQCETB17-E-NM-AREA            PIC  X(008).                
	
	// *       NOME DA AREA DE TS                                        
	//                                                                   
	@PsFieldString(name= "NQCETB17_E_SG_FCAO", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_E_SG_FCAO;//          05   NQCETB17-E-SG-FCAO            PIC  X(002).                
	
	// *       FUNCAO A SER EXECUTADA                                    
	// *       L = LISTAR                                                
	// *       C = CONSULTA                                              
	//                                                                   
	@PsFieldNumber(name= "NQCETB17_E_QT_TAMA_AREA", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long NQCETB17_E_QT_TAMA_AREA;//          05   NQCETB17-E-QT-TAMA-AREA       PIC  9(007).                
	
	// *       TAMANHO DA AREA DE TS                                     
	//                                                                   
	@PsFieldString(name= "NQCETB17_E_CD_USUA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_E_CD_USUA;//          05   NQCETB17-E-CD-USUA            PIC  X(008).                
	
	// *       CODIGO DO USUARIO                                         
	//                                                                   
	@PsFieldNumber(name= "NQCETB17_E_NR_SEQU_SIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB17_E_NR_SEQU_SIST;//          05   NQCETB17-E-NR-SEQU-SIST       PIC  9(004).                
	
	// *       NUMERO SEQUENCIAL DO SISTEMA                              
	//                                                                   
	@PsFieldString(name= "NQCETB17_E_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_E_CD_BANC_CLIE;//          05   NQCETB17-E-CD-BANC-CLIE       PIC  X(004).                
	
	// *       CODIGO DO BANCO                                           
	//                                                                   
	@PsFieldString(name= "NQCETB17_E_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_E_CD_CLIE;//          05   NQCETB17-E-CD-CLIE            PIC  X(008).                
	
	// *       CODIGO DO CLIENTE                                         
	//                                                                   
	@PsFieldString(name= "NQCETB17_E_DT_INICIO", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_E_DT_INICIO;//          05   NQCETB17-E-DT-INICIO          PIC  X(010).                
	
	// *       DATA INICIO DO PERIODO                                    
	//                                                                   
	@PsFieldString(name= "NQCETB17_E_DT_FIM", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_E_DT_FIM;//          05   NQCETB17-E-DT-FIM             PIC  X(010).                
	
	// *       DATA FIM DO PERIODO                                       
	//                                                                   
	@PsFieldString(name= "NQCETB17_E_CD_TITU", length= 11, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB17_E_CD_TITU;//          05   NQCETB17-E-CD-TITU            PIC  X(011).                
	
	// *       CODIGO DO TITULO                                          
	//                                                                   
	@PsFieldNumber(name= "NQCETB17_E_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB17_E_NR_SEQU_OPER;//          05   NQCETB17-E-NR-SEQU-OPER       PIC  9(003).                
	
	public NQCETB17LegadoRequest() { }
	
	public String getNQCETB17_E_NM_PROG() {
		return NQCETB17_E_NM_PROG;
	}
	
	public void setNQCETB17_E_NM_PROG(String nQCETB17_E_NM_PROG) {
		NQCETB17_E_NM_PROG = nQCETB17_E_NM_PROG;
	}
	
	public String getNQCETB17_E_NM_AREA() {
		return NQCETB17_E_NM_AREA;
	}
	
	public void setNQCETB17_E_NM_AREA(String nQCETB17_E_NM_AREA) {
		NQCETB17_E_NM_AREA = nQCETB17_E_NM_AREA;
	}
	
	public String getNQCETB17_E_SG_FCAO() {
		return NQCETB17_E_SG_FCAO;
	}
	
	public void setNQCETB17_E_SG_FCAO(String nQCETB17_E_SG_FCAO) {
		NQCETB17_E_SG_FCAO = nQCETB17_E_SG_FCAO;
	}
	
	public Long getNQCETB17_E_QT_TAMA_AREA() {
		return NQCETB17_E_QT_TAMA_AREA;
	}
	
	public void setNQCETB17_E_QT_TAMA_AREA(Long nQCETB17_E_QT_TAMA_AREA) {
		NQCETB17_E_QT_TAMA_AREA = nQCETB17_E_QT_TAMA_AREA;
	}
	
	public String getNQCETB17_E_CD_USUA() {
		return NQCETB17_E_CD_USUA;
	}
	
	public void setNQCETB17_E_CD_USUA(String nQCETB17_E_CD_USUA) {
		NQCETB17_E_CD_USUA = nQCETB17_E_CD_USUA;
	}
	
	public Long getNQCETB17_E_NR_SEQU_SIST() {
		return NQCETB17_E_NR_SEQU_SIST;
	}
	
	public void setNQCETB17_E_NR_SEQU_SIST(Long nQCETB17_E_NR_SEQU_SIST) {
		NQCETB17_E_NR_SEQU_SIST = nQCETB17_E_NR_SEQU_SIST;
	}
	
	public String getNQCETB17_E_CD_BANC_CLIE() {
		return NQCETB17_E_CD_BANC_CLIE;
	}
	
	public void setNQCETB17_E_CD_BANC_CLIE(String nQCETB17_E_CD_BANC_CLIE) {
		NQCETB17_E_CD_BANC_CLIE = nQCETB17_E_CD_BANC_CLIE;
	}
	
	public String getNQCETB17_E_CD_CLIE() {
		return NQCETB17_E_CD_CLIE;
	}
	
	public void setNQCETB17_E_CD_CLIE(String nQCETB17_E_CD_CLIE) {
		NQCETB17_E_CD_CLIE = nQCETB17_E_CD_CLIE;
	}
	
	public String getNQCETB17_E_DT_INICIO() {
		return NQCETB17_E_DT_INICIO;
	}
	
	public void setNQCETB17_E_DT_INICIO(String nQCETB17_E_DT_INICIO) {
		NQCETB17_E_DT_INICIO = nQCETB17_E_DT_INICIO;
	}
	
	public String getNQCETB17_E_DT_FIM() {
		return NQCETB17_E_DT_FIM;
	}
	
	public void setNQCETB17_E_DT_FIM(String nQCETB17_E_DT_FIM) {
		NQCETB17_E_DT_FIM = nQCETB17_E_DT_FIM;
	}
	
	public String getNQCETB17_E_CD_TITU() {
		return NQCETB17_E_CD_TITU;
	}
	
	public void setNQCETB17_E_CD_TITU(String nQCETB17_E_CD_TITU) {
		NQCETB17_E_CD_TITU = nQCETB17_E_CD_TITU;
	}
	
	public Long getNQCETB17_E_NR_SEQU_OPER() {
		return NQCETB17_E_NR_SEQU_OPER;
	}
	
	public void setNQCETB17_E_NR_SEQU_OPER(Long nQCETB17_E_NR_SEQU_OPER) {
		NQCETB17_E_NR_SEQU_OPER = nQCETB17_E_NR_SEQU_OPER;
	}

	
}