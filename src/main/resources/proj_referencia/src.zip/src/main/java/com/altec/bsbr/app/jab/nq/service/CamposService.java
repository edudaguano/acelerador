package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface CamposService {
	public String listarCampos(String strCodSist, String strCodUser) throws BusinessException;

	public String consultarCampos(String strCodSist, String strCodCampo, String strCodUser) throws BusinessException;

	public String incluirCampos(String strCodSist, String strTpCampo, String strDescCampo, String strTamCampo,
			String strPosIni, String strAtivo, String strCodUser) throws BusinessException;

	public String alterarCampos(String strCodSist, String strCodCampo, String strTpCampo, String strDescCampo,
			String strTamCampo, String strPosIni, String strAtivo, String strCodUser) throws BusinessException;

	public String excluirCampos(String strCodSist, String strCodCampo, String strCodUser) throws BusinessException;

	public String inicializarinputArea(String tNQ_NQAT2002_NQCETB02_ENTRADA) throws BusinessException;

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws BusinessException;
}
