package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0020")
public class NQS0020 {
@PsFieldString(name="NOCLIEN", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOCLIEN;
@PsFieldString(name="TPDOCTO", length=2, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPDOCTO;
@PsFieldString(name="NUDOCTO", length=15, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUDOCTO;
@PsFieldString(name="DSSEGPR", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSSEGPR;
@PsFieldString(name="DSSEGSE", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSSEGSE;
@PsFieldString(name="DSATUAC", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSATUAC;
@PsFieldString(name="DSPROPR", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSPROPR;
@PsFieldNumber(name="VLRENDA", length=15, decimal=2, defaultValue = "0" )
private double VLRENDA;
@PsFieldString(name="DTRENDA", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTRENDA;
@PsFieldString(name="TPRENDA", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPRENDA;
@PsFieldNumber(name="VLPATRI", length=15, decimal=2, defaultValue = "0" )
private double VLPATRI;
@PsFieldString(name="ICMARPE", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMARPE;
@PsFieldString(name="DTPATRI", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTPATRI;

public String getNOCLIEN() {
 return NOCLIEN;
}
public void setNOCLIEN(String NOCLIEN) {
 this.NOCLIEN = NOCLIEN;
}

public String getTPDOCTO() {
 return TPDOCTO;
}
public void setTPDOCTO(String TPDOCTO) {
 this.TPDOCTO = TPDOCTO;
}

public String getNUDOCTO() {
 return NUDOCTO;
}
public void setNUDOCTO(String NUDOCTO) {
 this.NUDOCTO = NUDOCTO;
}

public String getDSSEGPR() {
 return DSSEGPR;
}
public void setDSSEGPR(String DSSEGPR) {
 this.DSSEGPR = DSSEGPR;
}

public String getDSSEGSE() {
 return DSSEGSE;
}
public void setDSSEGSE(String DSSEGSE) {
 this.DSSEGSE = DSSEGSE;
}

public String getDSATUAC() {
 return DSATUAC;
}
public void setDSATUAC(String DSATUAC) {
 this.DSATUAC = DSATUAC;
}

public String getDSPROPR() {
 return DSPROPR;
}
public void setDSPROPR(String DSPROPR) {
 this.DSPROPR = DSPROPR;
}
public double getVLRENDA() {
 return VLRENDA;
}
public void setVLRENDA(double vLRENDA) {
VLRENDA = vLRENDA;
}
public String getDTRENDA() {
 return DTRENDA;
}
public void setDTRENDA(String DTRENDA) {
 this.DTRENDA = DTRENDA;
}

public String getTPRENDA() {
 return TPRENDA;
}
public void setTPRENDA(String TPRENDA) {
 this.TPRENDA = TPRENDA;
}
public double getVLPATRI() {
 return VLPATRI;
}
public void setVLPATRI(double vLPATRI) {
VLPATRI = vLPATRI;
}
public String getICMARPE() {
 return ICMARPE;
}
public void setICMARPE(String ICMARPE) {
 this.ICMARPE = ICMARPE;
}

public String getDTPATRI() {
 return DTPATRI;
}
public void setDTPATRI(String DTPATRI) {
 this.DTPATRI = DTPATRI;
}


}
