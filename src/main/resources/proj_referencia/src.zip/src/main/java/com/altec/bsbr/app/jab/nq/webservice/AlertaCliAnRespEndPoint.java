package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
 

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.AlertaCliAnRespService;
import com.altec.bsbr.app.jab.nq.service.AlertaCliAnRespWebService;
import com.altec.bsbr.fw.webservice.WebServiceException; 

@WebService 
 @SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL) 
public class AlertaCliAnRespEndPoint extends SpringBeanAutowiringSupport implements AlertaCliAnRespWebService{ 
private final Logger LOGGER = LoggerFactory.getLogger(AlertaCliAnRespEndPoint.class); 
@Autowired
private AlertaCliAnRespService alertaclianresp; 
@WebMethod 
 public String versao() throws WebServiceException{ 
String retorno = ""; 
try{ 
LOGGER.info("Executar Teste Unitario");
retorno = alertaclianresp.versao();
}
catch(Exception e){
LOGGER.error(e.getMessage());
throw new WebServiceException(e.getMessage(), -1); 
 } 
 return retorno; 
 }@WebMethod 
 public String recuperarPergunta(String strCOENTID,String strCOALERT) throws WebServiceException{ 
String retorno = ""; 
try{ 
LOGGER.info("Executar Teste Unitario");
retorno = alertaclianresp.recuperarPergunta(strCOENTID, strCOALERT);
}
catch(Exception e){
LOGGER.error(e.getMessage());
throw new WebServiceException(e.getMessage(), -1); 
 } 
 return retorno; 
 }@WebMethod 
 public String consultarHistorico(String strCOENTID,String strCOALERT,String strDTCOMIT,String strNUSEQUE) throws WebServiceException{ 
String retorno = ""; 
try{ 
LOGGER.info("Executar Teste Unitario");
retorno = alertaclianresp.consultarHistorico(strCOENTID, strCOALERT, strDTCOMIT, strNUSEQUE);
}
catch(Exception e){
LOGGER.error(e.getMessage());
throw new WebServiceException(e.getMessage(), -1); 
 } 
 return retorno; 
 }@WebMethod 
 public String consultarJustificativa(String strCOENTI,String strCOALER) throws WebServiceException{ 
String retorno = ""; 
try{ 
LOGGER.info("Executar Teste Unitario");
retorno = alertaclianresp.consultarJustificativa(strCOENTI, strCOALER);
}
catch(Exception e){
LOGGER.error(e.getMessage());
throw new WebServiceException(e.getMessage(), -1); 
 } 
 return retorno; 
 }@WebMethod 
 public String consultarEnquadramento(String strCOENTID,String strCOALERT,String strCOORGEN,String strCOENQSI) throws WebServiceException{ 
String retorno = ""; 
try{ 
LOGGER.info("Executar Teste Unitario");
retorno = alertaclianresp.consultarEnquadramento(strCOENTID, strCOALERT, strCOORGEN, strCOENQSI);
}
catch(Exception e){
LOGGER.error(e.getMessage());
throw new WebServiceException(e.getMessage(), -1); 
 } 
 return retorno; 
 }@WebMethod 
 public String consultaOrgaoEnquadramento(String strCORGENQ) throws WebServiceException{ 
String retorno = ""; 
try{ 
LOGGER.info("Executar Teste Unitario");
retorno = alertaclianresp.consultaOrgaoEnquadramento(strCORGENQ);
}
catch(Exception e){
LOGGER.error(e.getMessage());
throw new WebServiceException(e.getMessage(), -1); 
 } 
 return retorno; 
 }}

