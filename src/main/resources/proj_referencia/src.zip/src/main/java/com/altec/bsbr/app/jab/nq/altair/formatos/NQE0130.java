package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0130")
public class NQE0130 {
@PsFieldString(name="NUENTID", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUENTID;
@PsFieldString(name="NUAGENC", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUAGENC;
@PsFieldString(name="NUCONTA", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUCONTA;
@PsFieldString(name="COCLIEN", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COCLIEN;

public String getNUENTID() {
 return NUENTID;
}
public void setNUENTID(String NUENTID) {
 this.NUENTID = NUENTID;
}

public String getNUAGENC() {
 return NUAGENC;
}
public void setNUAGENC(String NUAGENC) {
 this.NUAGENC = NUAGENC;
}

public String getNUCONTA() {
 return NUCONTA;
}
public void setNUCONTA(String NUCONTA) {
 this.NUCONTA = NUCONTA;
}

public String getCOCLIEN() {
 return COCLIEN;
}
public void setCOCLIEN(String COCLIEN) {
 this.COCLIEN = COCLIEN;
}


}
