package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name= "NQCETB12LegadoRequest")
public class NQCETB12LegadoRequest {
//  -*-
//        01     NQCETB12-ENTRADA.                                         
//                                                                         
	@PsFieldString(name= "NQCETB12_E_NM_PROG", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_E_NM_PROG;//          05   NQCETB12-E-NM-PROG            PIC  X(008).                

//       *       NOME DO PROGRAMA CHAMADO                                  
//                                                                         
	@PsFieldString(name= "NQCETB12_E_NM_AREA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_E_NM_AREA;//          05   NQCETB12-E-NM-AREA            PIC  X(008).                

//       *       NOME DA AREA DE TS                                        
//                                                                         
	@PsFieldString(name= "NQCETB12_E_SG_FCAO", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_E_SG_FCAO;//          05   NQCETB12-E-SG-FCAO            PIC  X(002).                

//       *       FUNCAO A SER EXECUTADA                                    
//       *       L = LISTAR                                                
//                                                                         
	@PsFieldNumber(name= "NQCETB12_E_QT_TAMA_AREA", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long NQCETB12_E_QT_TAMA_AREA;//          05   NQCETB12-E-QT-TAMA-AREA       PIC  9(007).                

//       *       TAMANHO DA AREA DE TS                                     
//                                                                         
	@PsFieldString(name= "NQCETB12_E_CD_USUA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_E_CD_USUA;//          05   NQCETB12-E-CD-USUA            PIC  X(008).                

//       *       CODIGO DO USUARIO                                         
//                                                                         
	@PsFieldString(name= "NQCETB12_E_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_E_CD_BANC_CLIE;//          05   NQCETB12-E-CD-BANC-CLIE       PIC  X(004).                

//       *       CODIGO DO BANCO                                           
//                                                                         
	@PsFieldString(name= "NQCETB12_E_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_E_CD_CLIE;//          05   NQCETB12-E-CD-CLIE            PIC  X(008).                

//       *       CODIGO DO CLIENTE                                         
//                                                                         
//       *----------------------------------------------------------------*
//       *       AREA DE SAIDA                                             
//       *----------------------------------------------------------------*
//                                                                         
//        01     NQCETB12-SAIDA.                                           
//                                                                         
//       *       AREA DE MENSAGEM                                          
//                                                                         
	@PsFieldNumber(name= "NQCETB12_S_MENS_LEN", length= 4, binary= true, signed= true, decimal= 0)
	private Long NQCETB12_S_MENS_LEN;//         03    NQCETB12-S-MENS-LEN    COMP   PIC  S9(04) VALUE +83.      

//         03    NQCETB12-S-MENS.                                          
	@PsFieldNumber(name= "NQCETB12_S_RETORNO", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB12_S_RETORNO;//          05   NQCETB12-S-RETORNO            PIC  9(003) VALUE ZEROS.    

	@PsFieldString(name= "NQCETB12_S_MENSAGEM", length= 80, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_MENSAGEM;//          05   NQCETB12-S-MENSAGEM           PIC  X(080) VALUE SPACES.   

//                                                                         
//       *       AREA DE DADOS                                             
//                                                                         
	@PsFieldNumber(name= "NQCETB12_S_DATA_LEN", length= 4, binary= true, signed= true, decimal= 0)
	private Long NQCETB12_S_DATA_LEN;//         03    NQCETB12-S-DATA-LEN    COMP   PIC  S9(04) VALUE +60.      

//         03    NQCETB12-S-DATA.                                          
//                                                                         
	@PsFieldString(name= "NQCETB12_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_CD_BANC_CLIE;//          05   NQCETB12-S-CD-BANC-CLIE       PIC  X(004).                

//       *       CODIGO DO BANCO                                           
//                                                                         
	@PsFieldString(name= "NQCETB12_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_CD_CLIE;//          05   NQCETB12-S-CD-CLIE            PIC  X(008).                

//       *       CODIGO DO CLIENTE                                         
//                                                                         
	@PsFieldString(name= "NQCETB12_S_NR_CNTR", length= 12, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_NR_CNTR;//          05   NQCETB12-S-NR-CNTR            PIC  X(012).                

//       *       NUMERO DO CONTRATO                                        
//                                                                         
	@PsFieldString(name= "NQCETB12_S_CD_PROD", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_CD_PROD;//          05   NQCETB12-S-CD-PROD            PIC  X(002).                

//       *       CODIGO DO PRODUTO                                         
//                                                                         
	@PsFieldString(name= "NQCETB12_S_CD_SUBP", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_CD_SUBP;//          05   NQCETB12-S-CD-SUBP            PIC  X(004).                

//       *       CODIGO DO SUBPRODUTO                                      
//                                                                         
	@PsFieldString(name= "NQCETB12_S_DT_INIC_RELA", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_DT_INIC_RELA;//          05   NQCETB12-S-DT-INIC-RELA       PIC  X(010).                

//       *       DATA DE INICIO DE RELACIONAMENTO                          
//                                                                         
	@PsFieldString(name= "NQCETB12_S_DT_INIC_CNTR_PROD", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_DT_INIC_CNTR_PROD;//          05   NQCETB12-S-DT-INIC-CNTR-PROD  PIC  X(010).                

//       *       DATA DE INICIO DA CONTRATACAO                             
//                                                                         
	@PsFieldString(name= "NQCETB12_S_DT_VENC_CNTR_PROD", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_DT_VENC_CNTR_PROD;//          05   NQCETB12-S-DT-VENC-CNTR-PROD  PIC  X(010).                

//       *       DATA DE VENCIMENTO DA CONTRATACAO                         
//                                                                         
	public NQCETB12LegadoRequest() { }

	public String getNQCETB12_E_NM_PROG() {
		return NQCETB12_E_NM_PROG;
	}

	public void setNQCETB12_E_NM_PROG(String nQCETB12_E_NM_PROG) {
		NQCETB12_E_NM_PROG = nQCETB12_E_NM_PROG;
	}

	public String getNQCETB12_E_NM_AREA() {
		return NQCETB12_E_NM_AREA;
	}

	public void setNQCETB12_E_NM_AREA(String nQCETB12_E_NM_AREA) {
		NQCETB12_E_NM_AREA = nQCETB12_E_NM_AREA;
	}

	public String getNQCETB12_E_SG_FCAO() {
		return NQCETB12_E_SG_FCAO;
	}

	public void setNQCETB12_E_SG_FCAO(String nQCETB12_E_SG_FCAO) {
		NQCETB12_E_SG_FCAO = nQCETB12_E_SG_FCAO;
	}

	public Long getNQCETB12_E_QT_TAMA_AREA() {
		return NQCETB12_E_QT_TAMA_AREA;
	}

	public void setNQCETB12_E_QT_TAMA_AREA(Long nQCETB12_E_QT_TAMA_AREA) {
		NQCETB12_E_QT_TAMA_AREA = nQCETB12_E_QT_TAMA_AREA;
	}

	public String getNQCETB12_E_CD_USUA() {
		return NQCETB12_E_CD_USUA;
	}

	public void setNQCETB12_E_CD_USUA(String nQCETB12_E_CD_USUA) {
		NQCETB12_E_CD_USUA = nQCETB12_E_CD_USUA;
	}

	public String getNQCETB12_E_CD_BANC_CLIE() {
		return NQCETB12_E_CD_BANC_CLIE;
	}

	public void setNQCETB12_E_CD_BANC_CLIE(String nQCETB12_E_CD_BANC_CLIE) {
		NQCETB12_E_CD_BANC_CLIE = nQCETB12_E_CD_BANC_CLIE;
	}

	public String getNQCETB12_E_CD_CLIE() {
		return NQCETB12_E_CD_CLIE;
	}

	public void setNQCETB12_E_CD_CLIE(String nQCETB12_E_CD_CLIE) {
		NQCETB12_E_CD_CLIE = nQCETB12_E_CD_CLIE;
	}

	public Long getNQCETB12_S_MENS_LEN() {
		return NQCETB12_S_MENS_LEN;
	}

	public void setNQCETB12_S_MENS_LEN(Long nQCETB12_S_MENS_LEN) {
		NQCETB12_S_MENS_LEN = nQCETB12_S_MENS_LEN;
	}

	public Long getNQCETB12_S_RETORNO() {
		return NQCETB12_S_RETORNO;
	}

	public void setNQCETB12_S_RETORNO(Long nQCETB12_S_RETORNO) {
		NQCETB12_S_RETORNO = nQCETB12_S_RETORNO;
	}

	public String getNQCETB12_S_MENSAGEM() {
		return NQCETB12_S_MENSAGEM;
	}

	public void setNQCETB12_S_MENSAGEM(String nQCETB12_S_MENSAGEM) {
		NQCETB12_S_MENSAGEM = nQCETB12_S_MENSAGEM;
	}

	public Long getNQCETB12_S_DATA_LEN() {
		return NQCETB12_S_DATA_LEN;
	}

	public void setNQCETB12_S_DATA_LEN(Long nQCETB12_S_DATA_LEN) {
		NQCETB12_S_DATA_LEN = nQCETB12_S_DATA_LEN;
	}

	public String getNQCETB12_S_CD_BANC_CLIE() {
		return NQCETB12_S_CD_BANC_CLIE;
	}

	public void setNQCETB12_S_CD_BANC_CLIE(String nQCETB12_S_CD_BANC_CLIE) {
		NQCETB12_S_CD_BANC_CLIE = nQCETB12_S_CD_BANC_CLIE;
	}

	public String getNQCETB12_S_CD_CLIE() {
		return NQCETB12_S_CD_CLIE;
	}

	public void setNQCETB12_S_CD_CLIE(String nQCETB12_S_CD_CLIE) {
		NQCETB12_S_CD_CLIE = nQCETB12_S_CD_CLIE;
	}

	public String getNQCETB12_S_NR_CNTR() {
		return NQCETB12_S_NR_CNTR;
	}

	public void setNQCETB12_S_NR_CNTR(String nQCETB12_S_NR_CNTR) {
		NQCETB12_S_NR_CNTR = nQCETB12_S_NR_CNTR;
	}

	public String getNQCETB12_S_CD_PROD() {
		return NQCETB12_S_CD_PROD;
	}

	public void setNQCETB12_S_CD_PROD(String nQCETB12_S_CD_PROD) {
		NQCETB12_S_CD_PROD = nQCETB12_S_CD_PROD;
	}

	public String getNQCETB12_S_CD_SUBP() {
		return NQCETB12_S_CD_SUBP;
	}

	public void setNQCETB12_S_CD_SUBP(String nQCETB12_S_CD_SUBP) {
		NQCETB12_S_CD_SUBP = nQCETB12_S_CD_SUBP;
	}

	public String getNQCETB12_S_DT_INIC_RELA() {
		return NQCETB12_S_DT_INIC_RELA;
	}

	public void setNQCETB12_S_DT_INIC_RELA(String nQCETB12_S_DT_INIC_RELA) {
		NQCETB12_S_DT_INIC_RELA = nQCETB12_S_DT_INIC_RELA;
	}

	public String getNQCETB12_S_DT_INIC_CNTR_PROD() {
		return NQCETB12_S_DT_INIC_CNTR_PROD;
	}

	public void setNQCETB12_S_DT_INIC_CNTR_PROD(String nQCETB12_S_DT_INIC_CNTR_PROD) {
		NQCETB12_S_DT_INIC_CNTR_PROD = nQCETB12_S_DT_INIC_CNTR_PROD;
	}

	public String getNQCETB12_S_DT_VENC_CNTR_PROD() {
		return NQCETB12_S_DT_VENC_CNTR_PROD;
	}

	public void setNQCETB12_S_DT_VENC_CNTR_PROD(String nQCETB12_S_DT_VENC_CNTR_PROD) {
		NQCETB12_S_DT_VENC_CNTR_PROD = nQCETB12_S_DT_VENC_CNTR_PROD;
	}
}