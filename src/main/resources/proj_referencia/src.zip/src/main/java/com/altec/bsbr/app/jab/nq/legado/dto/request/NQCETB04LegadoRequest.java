package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name = "NQCETB04LegadoRequest")
public class NQCETB04LegadoRequest {
// -*-
//        01     NQCETB04-ENTRADA.                                         
//                                                                         
	@PsFieldString(name = "NQCETB4E_NM_PROG", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4E_NM_PROG;// 05 NQCETB4E-NM-PROG PIC X(008).

//       *       NOME DO PROGRAMA CHAMADO                                  
//                                                                         
	@PsFieldString(name = "NQCETB4E_NM_AREA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4E_NM_AREA;// 05 NQCETB4E-NM-AREA PIC X(008).

//       *       NOME DA AREA DE TS                                        
//                                                                         
	@PsFieldString(name = "NQCETB4E_SG_FCAO", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4E_SG_FCAO;// 05 NQCETB4E-SG-FCAO PIC X(002).

//       *       FUNCAO A SER EXECUTADA                                    
//       *       C = CONSULTAR                                             
//       *       L = LISTAR                                                
//       *       I = INCLUIR                                               
//       *       A = ALTERAR                                               
//       *       E = EXCLUIR                                               
//                                                                         
	@PsFieldNumber(name = "NQCETB4E_QT_TAMA_AREA", decimal = 0, length = 7, signed = false, defaultValue = "0")
	private Long NQCETB4E_QT_TAMA_AREA;// 05 NQCETB4E-QT-TAMA-AREA PIC 9(007).

//       *       TAMANHO DA AREA DE TS                                     
//                                                                         
	@PsFieldString(name = "NQCETB4E_CD_USUA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4E_CD_USUA;// 05 NQCETB4E-CD-USUA PIC X(008).

//       *       CODIGO DO USUARIO                                         
//                                                                         
	@PsFieldNumber(name = "NQCETB4E_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB4E_NR_SEQU_SIST;// 05 NQCETB4E-NR-SEQU-SIST PIC 9(004).

//       *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                         
	@PsFieldNumber(name = "NQCETB4E_NR_SEQU_LIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB4E_NR_SEQU_LIST;// 05 NQCETB4E-NR-SEQU-LIST PIC 9(004).

//       *       NUMERO DE SEQUENCIA DA LISTA                              
//                                                                         
	@PsFieldNumber(name = "NQCETB4E_NR_SEQU_CNTD", decimal = 0, length = 5, signed = false, defaultValue = "0")
	private Long NQCETB4E_NR_SEQU_CNTD;// 05 NQCETB4E-NR-SEQU-CNTD PIC 9(005).

//       *       NUMERO DE SEQUENCIA DO CONTEUDO                           
//                                                                         
	@PsFieldString(name = "NQCETB4E_TX_CNTD", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4E_TX_CNTD;// 05 NQCETB4E-TX-CNTD PIC X(040).

//       *       TEXTO DO CONTEUDO                                         
//                                                                         
	@PsFieldString(name = "NQCETB4E_DS_CNTD", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4E_DS_CNTD;// 05 NQCETB4E-DS-CNTD PIC X(040).

//       *       DESCRICAO DO CONTEUDO                                     
//                                                                         
	@PsFieldString(name = "NQCETB4E_CD_USUA_INCL_CNTD", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4E_CD_USUA_INCL_CNTD;// 05 NQCETB4E-CD-USUA-INCL-CNTD PIC X(008).

//       *       CODIGO DO USUARIO QUE INCLUIU O CONTEUDO                  
//                                                                         
	@PsFieldString(name = "NQCETB4E_DH_INCL_CNTD", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4E_DH_INCL_CNTD;// 05 NQCETB4E-DH-INCL-CNTD PIC X(026).

//       *       DATA/HORA DE INCLUSAO DO CONTEUDO                         
//                                                                         
	@PsFieldString(name = "NQCETB4E_CD_USUA_ALTR_CNTD", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4E_CD_USUA_ALTR_CNTD;// 05 NQCETB4E-CD-USUA-ALTR-CNTD PIC X(008).

//       *       CODIGO DO USUARIO QUE ALTEROU O CONTEUDO                  
//                                                                         
	@PsFieldString(name = "NQCETB4E_DH_ALTR_CNTD", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4E_DH_ALTR_CNTD;// 05 NQCETB4E-DH-ALTR-CNTD PIC X(026).

//       *       DATA/HORA DE ALTERACAO DO CONTEUDO                        
//                                                                         
	@PsFieldString(name = "NQCETB4E_IN_CNTD_ATIV", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4E_IN_CNTD_ATIV;// 05 NQCETB4E-IN-CNTD-ATIV PIC X(001).
                              
	public NQCETB04LegadoRequest() {
	}

	public String getNQCETB4E_NM_PROG() {
		return NQCETB4E_NM_PROG;
	}

	public void setNQCETB4E_NM_PROG(String nQCETB4E_NM_PROG) {
		NQCETB4E_NM_PROG = nQCETB4E_NM_PROG;
	}

	public String getNQCETB4E_NM_AREA() {
		return NQCETB4E_NM_AREA;
	}

	public void setNQCETB4E_NM_AREA(String nQCETB4E_NM_AREA) {
		NQCETB4E_NM_AREA = nQCETB4E_NM_AREA;
	}

	public String getNQCETB4E_SG_FCAO() {
		return NQCETB4E_SG_FCAO;
	}

	public void setNQCETB4E_SG_FCAO(String nQCETB4E_SG_FCAO) {
		NQCETB4E_SG_FCAO = nQCETB4E_SG_FCAO;
	}

	public Long getNQCETB4E_QT_TAMA_AREA() {
		return NQCETB4E_QT_TAMA_AREA;
	}

	public void setNQCETB4E_QT_TAMA_AREA(Long nQCETB4E_QT_TAMA_AREA) {
		NQCETB4E_QT_TAMA_AREA = nQCETB4E_QT_TAMA_AREA;
	}

	public String getNQCETB4E_CD_USUA() {
		return NQCETB4E_CD_USUA;
	}

	public void setNQCETB4E_CD_USUA(String nQCETB4E_CD_USUA) {
		NQCETB4E_CD_USUA = nQCETB4E_CD_USUA;
	}

	public Long getNQCETB4E_NR_SEQU_SIST() {
		return NQCETB4E_NR_SEQU_SIST;
	}

	public void setNQCETB4E_NR_SEQU_SIST(Long nQCETB4E_NR_SEQU_SIST) {
		NQCETB4E_NR_SEQU_SIST = nQCETB4E_NR_SEQU_SIST;
	}

	public Long getNQCETB4E_NR_SEQU_LIST() {
		return NQCETB4E_NR_SEQU_LIST;
	}

	public void setNQCETB4E_NR_SEQU_LIST(Long nQCETB4E_NR_SEQU_LIST) {
		NQCETB4E_NR_SEQU_LIST = nQCETB4E_NR_SEQU_LIST;
	}

	public Long getNQCETB4E_NR_SEQU_CNTD() {
		return NQCETB4E_NR_SEQU_CNTD;
	}

	public void setNQCETB4E_NR_SEQU_CNTD(Long nQCETB4E_NR_SEQU_CNTD) {
		NQCETB4E_NR_SEQU_CNTD = nQCETB4E_NR_SEQU_CNTD;
	}

	public String getNQCETB4E_TX_CNTD() {
		return NQCETB4E_TX_CNTD;
	}

	public void setNQCETB4E_TX_CNTD(String nQCETB4E_TX_CNTD) {
		NQCETB4E_TX_CNTD = nQCETB4E_TX_CNTD;
	}

	public String getNQCETB4E_DS_CNTD() {
		return NQCETB4E_DS_CNTD;
	}

	public void setNQCETB4E_DS_CNTD(String nQCETB4E_DS_CNTD) {
		NQCETB4E_DS_CNTD = nQCETB4E_DS_CNTD;
	}

	public String getNQCETB4E_CD_USUA_INCL_CNTD() {
		return NQCETB4E_CD_USUA_INCL_CNTD;
	}

	public void setNQCETB4E_CD_USUA_INCL_CNTD(String nQCETB4E_CD_USUA_INCL_CNTD) {
		NQCETB4E_CD_USUA_INCL_CNTD = nQCETB4E_CD_USUA_INCL_CNTD;
	}

	public String getNQCETB4E_DH_INCL_CNTD() {
		return NQCETB4E_DH_INCL_CNTD;
	}

	public void setNQCETB4E_DH_INCL_CNTD(String nQCETB4E_DH_INCL_CNTD) {
		NQCETB4E_DH_INCL_CNTD = nQCETB4E_DH_INCL_CNTD;
	}

	public String getNQCETB4E_CD_USUA_ALTR_CNTD() {
		return NQCETB4E_CD_USUA_ALTR_CNTD;
	}

	public void setNQCETB4E_CD_USUA_ALTR_CNTD(String nQCETB4E_CD_USUA_ALTR_CNTD) {
		NQCETB4E_CD_USUA_ALTR_CNTD = nQCETB4E_CD_USUA_ALTR_CNTD;
	}

	public String getNQCETB4E_DH_ALTR_CNTD() {
		return NQCETB4E_DH_ALTR_CNTD;
	}

	public void setNQCETB4E_DH_ALTR_CNTD(String nQCETB4E_DH_ALTR_CNTD) {
		NQCETB4E_DH_ALTR_CNTD = nQCETB4E_DH_ALTR_CNTD;
	}

	public String getNQCETB4E_IN_CNTD_ATIV() {
		return NQCETB4E_IN_CNTD_ATIV;
	}

	public void setNQCETB4E_IN_CNTD_ATIV(String nQCETB4E_IN_CNTD_ATIV) {
		NQCETB4E_IN_CNTD_ATIV = nQCETB4E_IN_CNTD_ATIV;
	}


}