package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB30AreaDados")
public class NQCETB30AreaDados {
    
//          03    NQCETB30-S-DATA.                                          
//                                                                          
	@PsFieldNumber(name= "NQCETB30_S_NR_SEQU_SIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB30_S_NR_SEQU_SIST;//           05   NQCETB30-S-NR-SEQU-SIST       PIC  9(004).                

//        *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                          
	@PsFieldString(name= "NQCETB30_S_SG_SIST", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_SG_SIST;//           05   NQCETB30-S-SG-SIST            PIC  X(002).                

//        *       SIGLA DO SISTEMA                                          
//                                                                          
	@PsFieldNumber(name= "NQCETB30_S_NR_SEQU_REGR", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB30_S_NR_SEQU_REGR;//           05   NQCETB30-S-NR-SEQU-REGR       PIC  9(004).                

//        *       NUMERO DE SEQUENCIA DA REGRA                              
//                                                                          
	@PsFieldString(name= "NQCETB30_S_DT_OCOR", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_DT_OCOR;//           05   NQCETB30-S-DT-OCOR            PIC  X(010).                

//        *       DATA DE OCORRENCIA                                        
//                                                                          
	@PsFieldString(name= "NQCETB30_S_TP_PERI", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_TP_PERI;//           05   NQCETB30-S-TP-PERI            PIC  X(001).                

//        *       TIPO DE PERIODO                                           
//                                                                          
	@PsFieldString(name= "NQCETB30_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_CD_PROD_ALTAIR;//           05   NQCETB30-S-CD-PROD-ALTAIR     PIC  X(002).                

//        *       CODIGO DO PRODUTO                                         
//                                                                          
	@PsFieldString(name= "NQCETB30_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_CD_SUBP_ALTAIR;//           05   NQCETB30-S-CD-SUBP-ALTAIR     PIC  X(004).                

//        *       CODIGO DO SUBPRODUTO                                      
//                                                                          
	@PsFieldString(name= "NQCETB30_S_IN_PEP", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_IN_PEP;//           05   NQCETB30-S-IN-PEP             PIC  X(001).                

//        *       INDICADOR DE CLIENTE PEP                                  
//                                                                          
	@PsFieldString(name= "NQCETB30_S_IN_FUNC", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_IN_FUNC;//           05   NQCETB30-S-IN-FUNC            PIC  X(001).                

//        *       INDICADOR DE CLIENTE FUNCIONARIO                          
//                                                                          
	@PsFieldString(name= "NQCETB30_S_TP_TRAN", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_TP_TRAN;//           05   NQCETB30-S-TP-TRAN            PIC  X(001).                

//        *       IDENTIFICACAO DO TIPO DE TRANSACAO                        
//                                                                          
	@PsFieldNumber(name= "NQCETB30_S_QT_TRAN", decimal= 0, length= 9, signed= false, defaultValue="0")
	private Long NQCETB30_S_QT_TRAN;//           05   NQCETB30-S-QT-TRAN            PIC  9(009).                

//        *       QUANTIDADE DE TRANSACOES                                  
//                                                                          
	@PsFieldNumber(name= "NQCETB30_S_VL_PERC_FATU_REND", decimal= 2, length= 5, signed= false, defaultValue="0")
	private Double NQCETB30_S_VL_PERC_FATU_REND;//           05   NQCETB30-S-VL-PERC-FATU-REND  PIC  9(003)V99.             

//        *       VALOR DA PORCENTAGEM SOBRE FATURAMENTO / RENDA            
//                                                                          
	@PsFieldNumber(name= "NQCETB30_S_VL_TRAN", decimal= 2, length= 17, signed= false, defaultValue="0")
	private Double NQCETB30_S_VL_TRAN;//           05   NQCETB30-S-VL-TRAN            PIC  9(015)V99.             

//        *       VALOR DE TRANSACOES                                       
//                                                                          
	@PsFieldString(name= "NQCETB30_S_CD_SITU", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_CD_SITU;//           05   NQCETB30-S-CD-SITU            PIC  X(001).                

//        *       CODIGO DA SITUACAO                                        
//                                                                          
	@PsFieldString(name= "NQCETB30_S_CD_USUA_ULTI_ALTR", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_CD_USUA_ULTI_ALTR;//           05   NQCETB30-S-CD-USUA-ULTI-ALTR  PIC  X(008).                

//        *       CODIGO DA SITUACAO                                        
//                                                                          
	@PsFieldString(name= "NQCETB30_S_DH_ULTI_ALTR", length= 26, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_DH_ULTI_ALTR;//           05   NQCETB30-S-DH-ULTI-ALTR       PIC  X(026).                

//        *       DATA/HORA ULTIMO PROCESSAMENTO                            
	public NQCETB30AreaDados() { }


	public Long getNQCETB30_S_NR_SEQU_SIST() {
		return NQCETB30_S_NR_SEQU_SIST;
	}

	public void setNQCETB30_S_NR_SEQU_SIST(Long nQCETB30_S_NR_SEQU_SIST) {
		NQCETB30_S_NR_SEQU_SIST = nQCETB30_S_NR_SEQU_SIST;
	}

	public String getNQCETB30_S_SG_SIST() {
		return NQCETB30_S_SG_SIST;
	}

	public void setNQCETB30_S_SG_SIST(String nQCETB30_S_SG_SIST) {
		NQCETB30_S_SG_SIST = nQCETB30_S_SG_SIST;
	}

	public Long getNQCETB30_S_NR_SEQU_REGR() {
		return NQCETB30_S_NR_SEQU_REGR;
	}

	public void setNQCETB30_S_NR_SEQU_REGR(Long nQCETB30_S_NR_SEQU_REGR) {
		NQCETB30_S_NR_SEQU_REGR = nQCETB30_S_NR_SEQU_REGR;
	}

	public String getNQCETB30_S_DT_OCOR() {
		return NQCETB30_S_DT_OCOR;
	}

	public void setNQCETB30_S_DT_OCOR(String nQCETB30_S_DT_OCOR) {
		NQCETB30_S_DT_OCOR = nQCETB30_S_DT_OCOR;
	}

	public String getNQCETB30_S_TP_PERI() {
		return NQCETB30_S_TP_PERI;
	}

	public void setNQCETB30_S_TP_PERI(String nQCETB30_S_TP_PERI) {
		NQCETB30_S_TP_PERI = nQCETB30_S_TP_PERI;
	}

	public String getNQCETB30_S_CD_PROD_ALTAIR() {
		return NQCETB30_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB30_S_CD_PROD_ALTAIR(String nQCETB30_S_CD_PROD_ALTAIR) {
		NQCETB30_S_CD_PROD_ALTAIR = nQCETB30_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB30_S_CD_SUBP_ALTAIR() {
		return NQCETB30_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB30_S_CD_SUBP_ALTAIR(String nQCETB30_S_CD_SUBP_ALTAIR) {
		NQCETB30_S_CD_SUBP_ALTAIR = nQCETB30_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB30_S_IN_PEP() {
		return NQCETB30_S_IN_PEP;
	}

	public void setNQCETB30_S_IN_PEP(String nQCETB30_S_IN_PEP) {
		NQCETB30_S_IN_PEP = nQCETB30_S_IN_PEP;
	}

	public String getNQCETB30_S_IN_FUNC() {
		return NQCETB30_S_IN_FUNC;
	}

	public void setNQCETB30_S_IN_FUNC(String nQCETB30_S_IN_FUNC) {
		NQCETB30_S_IN_FUNC = nQCETB30_S_IN_FUNC;
	}

	public String getNQCETB30_S_TP_TRAN() {
		return NQCETB30_S_TP_TRAN;
	}

	public void setNQCETB30_S_TP_TRAN(String nQCETB30_S_TP_TRAN) {
		NQCETB30_S_TP_TRAN = nQCETB30_S_TP_TRAN;
	}

	public Long getNQCETB30_S_QT_TRAN() {
		return NQCETB30_S_QT_TRAN;
	}

	public void setNQCETB30_S_QT_TRAN(Long nQCETB30_S_QT_TRAN) {
		NQCETB30_S_QT_TRAN = nQCETB30_S_QT_TRAN;
	}

	public Double getNQCETB30_S_VL_PERC_FATU_REND() {
		return NQCETB30_S_VL_PERC_FATU_REND;
	}

	public void setNQCETB30_S_VL_PERC_FATU_REND(Double nQCETB30_S_VL_PERC_FATU_REND) {
		NQCETB30_S_VL_PERC_FATU_REND = nQCETB30_S_VL_PERC_FATU_REND;
	}

	public Double getNQCETB30_S_VL_TRAN() {
		return NQCETB30_S_VL_TRAN;
	}

	public void setNQCETB30_S_VL_TRAN(Double nQCETB30_S_VL_TRAN) {
		NQCETB30_S_VL_TRAN = nQCETB30_S_VL_TRAN;
	}

	public String getNQCETB30_S_CD_SITU() {
		return NQCETB30_S_CD_SITU;
	}

	public void setNQCETB30_S_CD_SITU(String nQCETB30_S_CD_SITU) {
		NQCETB30_S_CD_SITU = nQCETB30_S_CD_SITU;
	}

	public String getNQCETB30_S_CD_USUA_ULTI_ALTR() {
		return NQCETB30_S_CD_USUA_ULTI_ALTR;
	}

	public void setNQCETB30_S_CD_USUA_ULTI_ALTR(String nQCETB30_S_CD_USUA_ULTI_ALTR) {
		NQCETB30_S_CD_USUA_ULTI_ALTR = nQCETB30_S_CD_USUA_ULTI_ALTR;
	}

	public String getNQCETB30_S_DH_ULTI_ALTR() {
		return NQCETB30_S_DH_ULTI_ALTR;
	}

	public void setNQCETB30_S_DH_ULTI_ALTR(String nQCETB30_S_DH_ULTI_ALTR) {
		NQCETB30_S_DH_ULTI_ALTR = nQCETB30_S_DH_ULTI_ALTR;
	}

	
}