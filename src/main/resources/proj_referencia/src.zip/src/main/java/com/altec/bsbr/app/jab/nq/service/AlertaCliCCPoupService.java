package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface AlertaCliCCPoupService {
	public String versao() throws BusinessException;

	public String consultarCenario(String strCODENTI, String strCODALER, String strCODCENA) throws BusinessException;

	public String consultarDadoProduto(String strCDENTI, String strCDALER, String strCDCENA, String strCDDTINT,
			String strCDPROD, String strNUCNTR) throws BusinessException;

	public String consultarClientePJ(String strCOENTID, String strCOALER) throws BusinessException;

	public String consultarClientePF(String strCOENTID, String strCOALER) throws BusinessException;

	public String consultarOperacao(String strCDENTID, String strCDALERT, String strCDCENAR, String strCDDETIN,
			String strCDDOCOP, String strNUCNTR) throws BusinessException;
}
