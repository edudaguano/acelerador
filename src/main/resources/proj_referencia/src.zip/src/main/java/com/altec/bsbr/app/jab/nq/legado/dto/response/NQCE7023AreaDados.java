package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name= "NQCE7023AreaDados")
public class NQCE7023AreaDados {

	
	public NQCE7023AreaDados() {
		super();
	}

/*------------------------------------ RESPONSE AREA ------------------------------------*/
	
//	@PsFieldNumber(name= "NQCE7023_TS01_MENS_LEN", length= 4, binary= true, signed= true, decimal= 0)
//	private Long NQCE7023_TS01_MENS_LEN;//            05  NQCE7023-TS01-MENS-LEN         PIC S9(04) COMP VALUE +83.

	@PsFieldNumber(name= "NQCE7023_TS01_COD_RETORNO", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCE7023_TS01_COD_RETORNO;//                10  NQCE7023-TS01-COD-RETORNO   PIC 9(03).               

	@PsFieldString(name= "NQCE7023_TS01_DES_MENSAGEM", length= 80, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS01_DES_MENSAGEM;//                10  NQCE7023-TS01-DES-MENSAGEM  PIC X(80).               

	@PsFieldNumber(name= "NQCE7023_TS02_MENS_LENG", length= 4, binary= true, signed= true, decimal= 0)
	private Long NQCE7023_TS02_MENS_LENG;//            05  NQCE7023-TS02-MENS-LENG       PIC S9(04) COMP VALUE +290.

//            05  NQCE7023-TS02-AREA-ENVIO.                                
	@PsFieldNumber(name= "NQCE7023_TS02_CINSTIT", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCE7023_TS02_CINSTIT;//                10  NQCE7023-TS02-CINSTIT       PIC 9(03).               

	@PsFieldString(name= "NQCE7023_TS02_CPROD", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_CPROD;//                10  NQCE7023-TS02-CPROD         PIC X(10).               

	@PsFieldString(name= "NQCE7023_TS02_DESCPROD", length= 15, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_DESCPROD;//                10  NQCE7023-TS02-DESCPROD      PIC X(15).               

	@PsFieldNumber(name= "NQCE7023_TS02_CSEGM", decimal= 0, length= 5, signed= false, defaultValue="0")
	private Long NQCE7023_TS02_CSEGM;//                10  NQCE7023-TS02-CSEGM         PIC 9(05).               

	@PsFieldNumber(name= "NQCE7023_TS02_NRSEQUE", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCE7023_TS02_NRSEQUE;//                10  NQCE7023-TS02-NRSEQUE       PIC 9(03).               

	@PsFieldString(name= "NQCE7023_TS02_DESCSEGM", length= 50, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_DESCSEGM;//                10  NQCE7023-TS02-DESCSEGM      PIC X(50).               

	@PsFieldString(name= "NQCE7023_TS02_NOMRECE", length= 50, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_NOMRECE;//                10  NQCE7023-TS02-NOMRECE       PIC X(50).               

	@PsFieldString(name= "NQCE7023_TS02_PRERECE", length= 50, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_PRERECE;//                10  NQCE7023-TS02-PRERECE       PIC X(50).               

	@PsFieldNumber(name= "NQCE7023_TS02_CODSUFI", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCE7023_TS02_CODSUFI;//                10  NQCE7023-TS02-CODSUFI       PIC 9(03).               

	@PsFieldString(name= "NQCE7023_TS02_DESCSUF", length= 50, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_DESCSUF;//                10  NQCE7023-TS02-DESCSUF       PIC X(50).               

	@PsFieldString(name= "NQCE7023_TS02_TPENVIO", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_TPENVIO;//                10  NQCE7023-TS02-TPENVIO       PIC X(01).               

	@PsFieldString(name= "NQCE7023_TS02_DESCENV", length= 50, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_DESCENV;//                10  NQCE7023-TS02-DESCENV       PIC X(50).               


/*-------------------------------------------- GETTER/SETTER ------------------------------------------*/
	public Long getNQCE7023_TS01_COD_RETORNO() {
		return NQCE7023_TS01_COD_RETORNO;
	}

	public void setNQCE7023_TS01_COD_RETORNO(Long nQCE7023_TS01_COD_RETORNO) {
		NQCE7023_TS01_COD_RETORNO = nQCE7023_TS01_COD_RETORNO;
	}

	public String getNQCE7023_TS01_DES_MENSAGEM() {
		return NQCE7023_TS01_DES_MENSAGEM;
	}

	public void setNQCE7023_TS01_DES_MENSAGEM(String nQCE7023_TS01_DES_MENSAGEM) {
		NQCE7023_TS01_DES_MENSAGEM = nQCE7023_TS01_DES_MENSAGEM;
	}

	public Long getNQCE7023_TS02_MENS_LENG() {
		return NQCE7023_TS02_MENS_LENG;
	}

	public void setNQCE7023_TS02_MENS_LENG(Long nQCE7023_TS02_MENS_LENG) {
		NQCE7023_TS02_MENS_LENG = nQCE7023_TS02_MENS_LENG;
	}

	public Long getNQCE7023_TS02_CINSTIT() {
		return NQCE7023_TS02_CINSTIT;
	}

	public void setNQCE7023_TS02_CINSTIT(Long nQCE7023_TS02_CINSTIT) {
		NQCE7023_TS02_CINSTIT = nQCE7023_TS02_CINSTIT;
	}

	public String getNQCE7023_TS02_CPROD() {
		return NQCE7023_TS02_CPROD;
	}

	public void setNQCE7023_TS02_CPROD(String nQCE7023_TS02_CPROD) {
		NQCE7023_TS02_CPROD = nQCE7023_TS02_CPROD;
	}

	public String getNQCE7023_TS02_DESCPROD() {
		return NQCE7023_TS02_DESCPROD;
	}

	public void setNQCE7023_TS02_DESCPROD(String nQCE7023_TS02_DESCPROD) {
		NQCE7023_TS02_DESCPROD = nQCE7023_TS02_DESCPROD;
	}

	public Long getNQCE7023_TS02_CSEGM() {
		return NQCE7023_TS02_CSEGM;
	}

	public void setNQCE7023_TS02_CSEGM(Long nQCE7023_TS02_CSEGM) {
		NQCE7023_TS02_CSEGM = nQCE7023_TS02_CSEGM;
	}

	public Long getNQCE7023_TS02_NRSEQUE() {
		return NQCE7023_TS02_NRSEQUE;
	}

	public void setNQCE7023_TS02_NRSEQUE(Long nQCE7023_TS02_NRSEQUE) {
		NQCE7023_TS02_NRSEQUE = nQCE7023_TS02_NRSEQUE;
	}

	public String getNQCE7023_TS02_DESCSEGM() {
		return NQCE7023_TS02_DESCSEGM;
	}

	public void setNQCE7023_TS02_DESCSEGM(String nQCE7023_TS02_DESCSEGM) {
		NQCE7023_TS02_DESCSEGM = nQCE7023_TS02_DESCSEGM;
	}

	public String getNQCE7023_TS02_NOMRECE() {
		return NQCE7023_TS02_NOMRECE;
	}

	public void setNQCE7023_TS02_NOMRECE(String nQCE7023_TS02_NOMRECE) {
		NQCE7023_TS02_NOMRECE = nQCE7023_TS02_NOMRECE;
	}

	public String getNQCE7023_TS02_PRERECE() {
		return NQCE7023_TS02_PRERECE;
	}

	public void setNQCE7023_TS02_PRERECE(String nQCE7023_TS02_PRERECE) {
		NQCE7023_TS02_PRERECE = nQCE7023_TS02_PRERECE;
	}

	public Long getNQCE7023_TS02_CODSUFI() {
		return NQCE7023_TS02_CODSUFI;
	}

	public void setNQCE7023_TS02_CODSUFI(Long nQCE7023_TS02_CODSUFI) {
		NQCE7023_TS02_CODSUFI = nQCE7023_TS02_CODSUFI;
	}

	public String getNQCE7023_TS02_DESCSUF() {
		return NQCE7023_TS02_DESCSUF;
	}

	public void setNQCE7023_TS02_DESCSUF(String nQCE7023_TS02_DESCSUF) {
		NQCE7023_TS02_DESCSUF = nQCE7023_TS02_DESCSUF;
	}

	public String getNQCE7023_TS02_TPENVIO() {
		return NQCE7023_TS02_TPENVIO;
	}

	public void setNQCE7023_TS02_TPENVIO(String nQCE7023_TS02_TPENVIO) {
		NQCE7023_TS02_TPENVIO = nQCE7023_TS02_TPENVIO;
	}

	public String getNQCE7023_TS02_DESCENV() {
		return NQCE7023_TS02_DESCENV;
	}

	public void setNQCE7023_TS02_DESCENV(String nQCE7023_TS02_DESCENV) {
		NQCE7023_TS02_DESCENV = nQCE7023_TS02_DESCENV;
	}

	
/*------------------------------------- ARQUIVO MORTO ----------------------------------------*/

//01          NQCE7023-COMMAREA.                                   
//@PsFieldString(name= "NQCE7023_PROG_CALLED", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
//private String NQCE7023_PROG_CALLED;//            05      NQCE7023-PROG-CALLED        PIC X(08).               
//
//@PsFieldString(name= "NQCE7023_NOMEDATS", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
//private String NQCE7023_NOMEDATS;//            05      NQCE7023-NOMEDATS           PIC X(10).               
//
//@PsFieldNumber(name= "NQCE7023_COMMAREA_LEN", decimal= 0, length= 7, signed= false, defaultValue="0")
//private Long NQCE7023_COMMAREA_LEN;//            05      NQCE7023-COMMAREA-LEN       PIC 9(07).               
//
//@PsFieldString(name= "NQCE7023_FUNCAO", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
//private String NQCE7023_FUNCAO;//            05      NQCE7023-FUNCAO             PIC X(01).               
//
//@PsFieldNumber(name= "NQCE7023_CINSTIT", decimal= 0, length= 3, signed= false, defaultValue="0")
//private Long NQCE7023_CINSTIT;//            05      NQCE7023-CINSTIT            PIC 9(03).               
//
//@PsFieldString(name= "NQCE7023_CODPROD", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
//private String NQCE7023_CODPROD;//            05      NQCE7023-CODPROD            PIC X(10).               

}
