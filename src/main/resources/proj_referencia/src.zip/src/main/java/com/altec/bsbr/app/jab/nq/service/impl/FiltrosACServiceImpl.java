package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.FiltrosACDao;
import com.altec.bsbr.app.jab.nq.service.FiltrosACService;
import com.altec.bsbr.fw.BusinessException;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;

@Service
public class FiltrosACServiceImpl implements FiltrosACService {
	private final Logger LOGGER = LoggerFactory.getLogger(FiltrosACServiceImpl.class);
	@Autowired
	private FiltrosACDao filtrosac;

	public String consultarFiltros2(String strCodSist, String strDtOcorr, String strCodUser)
			throws BusinessException {
		return filtrosac.consultarFiltros2(strCodSist, strDtOcorr, strCodUser);
	}

	public String consultarFiltros(String strCodSist, String strDtOcorr, String strCodUser)
			throws BusinessException {
		return filtrosac.consultarFiltros(strCodSist, strDtOcorr, strCodUser);
	}

	public String fnAddCaracter(String vlr, String tp, String tam) throws BusinessException {
		return filtrosac.fnAddCaracter(vlr, tp, tam);
	}

	public String dataAlta(String dtBaixa) throws BusinessException {
		return filtrosac.dataAlta(dtBaixa);
	}
}
