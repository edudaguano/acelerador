package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0300")
public class NQS0300 {
@PsFieldString(name="PENUMPE", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String PENUMPE;
@PsFieldString(name="NOFANTA", length=30, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFANTA;
@PsFieldString(name="DTFUNDA", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTFUNDA;
@PsFieldString(name="NOPAISO", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOPAISO;
@PsFieldString(name="COCNAE", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COCNAE;
@PsFieldString(name="TPATEC", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPATEC;
@PsFieldString(name="DTINCAT", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTINCAT;
@PsFieldString(name="TPADMIN", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPADMIN;
@PsFieldString(name="DTCLIDE", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTCLIDE;
@PsFieldNumber(name="COSITUA", length=2, defaultValue = "0" )
private Integer COSITUA;
@PsFieldString(name="NOSITUA", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOSITUA;
@PsFieldString(name="DTULALT", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTULALT;
@PsFieldString(name="ICPEP", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICPEP;
@PsFieldString(name="ICIMPED", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICIMPED;

public String getPENUMPE() {
 return PENUMPE;
}
public void setPENUMPE(String PENUMPE) {
 this.PENUMPE = PENUMPE;
}

public String getNOFANTA() {
 return NOFANTA;
}
public void setNOFANTA(String NOFANTA) {
 this.NOFANTA = NOFANTA;
}

public String getDTFUNDA() {
 return DTFUNDA;
}
public void setDTFUNDA(String DTFUNDA) {
 this.DTFUNDA = DTFUNDA;
}

public String getNOPAISO() {
 return NOPAISO;
}
public void setNOPAISO(String NOPAISO) {
 this.NOPAISO = NOPAISO;
}

public String getCOCNAE() {
 return COCNAE;
}
public void setCOCNAE(String COCNAE) {
 this.COCNAE = COCNAE;
}

public String getTPATEC() {
 return TPATEC;
}
public void setTPATEC(String TPATEC) {
 this.TPATEC = TPATEC;
}

public String getDTINCAT() {
 return DTINCAT;
}
public void setDTINCAT(String DTINCAT) {
 this.DTINCAT = DTINCAT;
}

public String getTPADMIN() {
 return TPADMIN;
}
public void setTPADMIN(String TPADMIN) {
 this.TPADMIN = TPADMIN;
}

public String getDTCLIDE() {
 return DTCLIDE;
}
public void setDTCLIDE(String DTCLIDE) {
 this.DTCLIDE = DTCLIDE;
}
public Integer getCOSITUA() {
 return COSITUA;
}
public void setCOSITUA(Integer cOSITUA) {
COSITUA = cOSITUA;
}
public String getNOSITUA() {
 return NOSITUA;
}
public void setNOSITUA(String NOSITUA) {
 this.NOSITUA = NOSITUA;
}

public String getDTULALT() {
 return DTULALT;
}
public void setDTULALT(String DTULALT) {
 this.DTULALT = DTULALT;
}

public String getICPEP() {
 return ICPEP;
}
public void setICPEP(String ICPEP) {
 this.ICPEP = ICPEP;
}

public String getICIMPED() {
 return ICIMPED;
}
public void setICIMPED(String ICIMPED) {
 this.ICIMPED = ICIMPED;
}


}
