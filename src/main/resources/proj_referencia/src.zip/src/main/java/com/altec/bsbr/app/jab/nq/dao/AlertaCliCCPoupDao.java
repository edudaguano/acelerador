package com.altec.bsbr.app.jab.nq.dao;

public interface AlertaCliCCPoupDao {
	public String versao();

	public String consultarCenario(String strCODENTI, String strCODALER, String strCODCENA);

	public String consultarDadoProduto(String strCDENTI, String strCDALER, String strCDCENA, String strCDDTINT,
			String strCDPROD, String strNUCNTR);

	public String consultarClientePJ(String strCOENTID, String strCOALER);

	public String consultarClientePF(String strCOENTID, String strCOALER);

	public String consultarOperacao(String strCDENTID, String strCDALERT, String strCDCENAR, String strCDDETIN,
			String strCDDOCOP, String strNUCNTR);
}
