package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB16AreaDados")
public class NQCETB16AreaDados {

	//  *       NUMERO SEQUENCIAL DA OPERACAO                             
	//  
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*
	//  
	//01     NQCETB16-SAIDA.                                           
	  
	@PsFieldString(name= "NQCETB16_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_CD_BANC_CLIE;//          05   NQCETB16-S-CD-BANC-CLIE       PIC  X(004).                
	
	//*       CODIGO DO BANCO                                           
	//  
	@PsFieldString(name= "NQCETB16_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_CD_CLIE;//          05   NQCETB16-S-CD-CLIE            PIC  X(008).                
	
	//*       CODIGO DO CLIENTE                                         
	//  
	@PsFieldString(name= "NQCETB16_S_DT_MOVI", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_DT_MOVI;//          05   NQCETB16-S-DT-MOVI            PIC  X(010).                
	
	//*       DATA DO MOVIMENTO                                         
	//  
	@PsFieldString(name= "NQCETB16_S_NR_CNTR", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_NR_CNTR;//          05   NQCETB16-S-NR-CNTR            PIC  X(020).                
	
	//*       NUMERO DO CONTRATO                                        
	//  
	@PsFieldString(name= "NQCETB16_S_DT_FORZ", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_DT_FORZ;//          05   NQCETB16-S-DT-FORZ            PIC  X(010).                
	
	//*       DATA DE FORMALIZACAO                                      
	//  
	@PsFieldString(name= "NQCETB16_S_NR_CNPJ_LOJI", length= 15, paddingAlign= PsAlign.LEFT, paddingChar= '0')
	private String NQCETB16_S_NR_CNPJ_LOJI;//          05   NQCETB16-S-NR-CNPJ-LOJI       PIC  9(015).                
	
	//*       NUMERO DO CNPJ DO LOJISTA                                 
	//  
	@PsFieldString(name= "NQCETB16_S_NM_LOJI", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_NM_LOJI;//          05   NQCETB16-S-NM-LOJI            PIC  X(040).                
	
	//*       NOME DO LOJISTA                                           
	//  
	@PsFieldNumber(name= "NQCETB16_S_VL_COMI_LOJI", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB16_S_VL_COMI_LOJI;//          05   NQCETB16-S-VL-COMI-LOJI       PIC S9(015)V99.             
	
	//*       VALOR DA COMISSAO DO LOJISTA                              
	//  
	@PsFieldString(name= "NQCETB16_S_NM_FILI_LOJI", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_NM_FILI_LOJI;//          05   NQCETB16-S-NM-FILI-LOJI       PIC  X(040).                
	
	//*       NOME DA FILIAL DO LOJISTA                                 
	//  
	@PsFieldNumber(name= "NQCETB16_S_VL_FATU_REND_LOJI", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB16_S_VL_FATU_REND_LOJI;//          05   NQCETB16-S-VL-FATU-REND-LOJI  PIC S9(015)V99.             
	
	//*       VALOR DO FATURAMENTO / RENDA DO LOJISTA                   
	//  
	@PsFieldString(name= "NQCETB16_S_CD_ATVD_OCUP_LOJI", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_CD_ATVD_OCUP_LOJI;//          05   NQCETB16-S-CD-ATVD-OCUP-LOJI  PIC  X(004).                
	
	//*       CODIGO DA ATIVIDADE / OCUPACAO DO LOJISTA                 
	//  
	@PsFieldString(name= "NQCETB16_S_TP_FORM_CMPV_REND", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_TP_FORM_CMPV_REND;//          05   NQCETB16-S-TP-FORM-CMPV-REND  PIC  X(001).                
	
	//*       TIPO DA FORMA DE COMPROVACAO DA RENDA                     
	//  
	@PsFieldString(name= "NQCETB16_S_CD_BANC_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_CD_BANC_CNTR;//          05   NQCETB16-S-CD-BANC-CNTR       PIC  X(004).                
	
	//*       CODIGO DO BANCO DO CONTRATO                               
	//  
	@PsFieldString(name= "NQCETB16_S_CD_AGEN_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_CD_AGEN_CNTR;//          05   NQCETB16-S-CD-AGEN-CNTR       PIC  X(004).                
	
	//*       CODIGO DA AGENCIA DO CONTRATO                             
	//  
	@PsFieldString(name= "NQCETB16_S_NR_CNTR_A", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_NR_CNTR_A;//          05   NQCETB16-S-NR-CNTR-A          PIC  X(020).                
	
	//*       NUMERO DO CONTRATO ALTAIR                                 
	//  
	@PsFieldString(name= "NQCETB16_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_CD_PROD_ALTAIR;//          05   NQCETB16-S-CD-PROD-ALTAIR     PIC  X(002).                
	
	//*       CODIGO DO PRODUTO                                         
	//  
	@PsFieldString(name= "NQCETB16_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_CD_SUBP_ALTAIR;//          05   NQCETB16-S-CD-SUBP-ALTAIR     PIC  X(004).                
	
	//*       CODIGO DO SUBPRODUTO                                      
	//  
	@PsFieldString(name= "NQCETB16_S_CD_MOED", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_CD_MOED;//          05   NQCETB16-S-CD-MOED            PIC  X(003).                
	
	//*       CODIGO DA MOEDA                                           
	//  
	@PsFieldNumber(name= "NQCETB16_S_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB16_S_NR_SEQU_OPER;//          05   NQCETB16-S-NR-SEQU-OPER       PIC  9(003).                
	
	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//  
	@PsFieldString(name= "NQCETB16_S_CD_IDEF_OPER", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_CD_IDEF_OPER;//          05   NQCETB16-S-CD-IDEF-OPER       PIC  X(020).                
	
	//*       CODIGO DA IDENTIFICACAO DA OPERACAO                       
	//  
	@PsFieldString(name= "NQCETB16_S_NM_CLIE", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_S_NM_CLIE;//     05   NQCETB16-S-NM-CLIE            PIC  X(040).                

	public String getNQCETB16_S_CD_BANC_CLIE() {
		return NQCETB16_S_CD_BANC_CLIE;
	}

	public void setNQCETB16_S_CD_BANC_CLIE(String nQCETB16_S_CD_BANC_CLIE) {
		NQCETB16_S_CD_BANC_CLIE = nQCETB16_S_CD_BANC_CLIE;
	}

	public String getNQCETB16_S_CD_CLIE() {
		return NQCETB16_S_CD_CLIE;
	}

	public void setNQCETB16_S_CD_CLIE(String nQCETB16_S_CD_CLIE) {
		NQCETB16_S_CD_CLIE = nQCETB16_S_CD_CLIE;
	}

	public String getNQCETB16_S_DT_MOVI() {
		return NQCETB16_S_DT_MOVI;
	}

	public void setNQCETB16_S_DT_MOVI(String nQCETB16_S_DT_MOVI) {
		NQCETB16_S_DT_MOVI = nQCETB16_S_DT_MOVI;
	}

	public String getNQCETB16_S_NR_CNTR() {
		return NQCETB16_S_NR_CNTR;
	}

	public void setNQCETB16_S_NR_CNTR(String nQCETB16_S_NR_CNTR) {
		NQCETB16_S_NR_CNTR = nQCETB16_S_NR_CNTR;
	}

	public String getNQCETB16_S_DT_FORZ() {
		return NQCETB16_S_DT_FORZ;
	}

	public void setNQCETB16_S_DT_FORZ(String nQCETB16_S_DT_FORZ) {
		NQCETB16_S_DT_FORZ = nQCETB16_S_DT_FORZ;
	}

	public String getNQCETB16_S_NR_CNPJ_LOJI() {
		return NQCETB16_S_NR_CNPJ_LOJI;
	}

	public void setNQCETB16_S_NR_CNPJ_LOJI(String nQCETB16_S_NR_CNPJ_LOJI) {
		NQCETB16_S_NR_CNPJ_LOJI = nQCETB16_S_NR_CNPJ_LOJI;
	}

	public String getNQCETB16_S_NM_LOJI() {
		return NQCETB16_S_NM_LOJI;
	}

	public void setNQCETB16_S_NM_LOJI(String nQCETB16_S_NM_LOJI) {
		NQCETB16_S_NM_LOJI = nQCETB16_S_NM_LOJI;
	}

	public Double getNQCETB16_S_VL_COMI_LOJI() {
		return NQCETB16_S_VL_COMI_LOJI;
	}

	public void setNQCETB16_S_VL_COMI_LOJI(Double nQCETB16_S_VL_COMI_LOJI) {
		NQCETB16_S_VL_COMI_LOJI = nQCETB16_S_VL_COMI_LOJI;
	}

	public String getNQCETB16_S_NM_FILI_LOJI() {
		return NQCETB16_S_NM_FILI_LOJI;
	}

	public void setNQCETB16_S_NM_FILI_LOJI(String nQCETB16_S_NM_FILI_LOJI) {
		NQCETB16_S_NM_FILI_LOJI = nQCETB16_S_NM_FILI_LOJI;
	}

	public Double getNQCETB16_S_VL_FATU_REND_LOJI() {
		return NQCETB16_S_VL_FATU_REND_LOJI;
	}

	public void setNQCETB16_S_VL_FATU_REND_LOJI(Double nQCETB16_S_VL_FATU_REND_LOJI) {
		NQCETB16_S_VL_FATU_REND_LOJI = nQCETB16_S_VL_FATU_REND_LOJI;
	}

	public String getNQCETB16_S_CD_ATVD_OCUP_LOJI() {
		return NQCETB16_S_CD_ATVD_OCUP_LOJI;
	}

	public void setNQCETB16_S_CD_ATVD_OCUP_LOJI(String nQCETB16_S_CD_ATVD_OCUP_LOJI) {
		NQCETB16_S_CD_ATVD_OCUP_LOJI = nQCETB16_S_CD_ATVD_OCUP_LOJI;
	}

	public String getNQCETB16_S_TP_FORM_CMPV_REND() {
		return NQCETB16_S_TP_FORM_CMPV_REND;
	}

	public void setNQCETB16_S_TP_FORM_CMPV_REND(String nQCETB16_S_TP_FORM_CMPV_REND) {
		NQCETB16_S_TP_FORM_CMPV_REND = nQCETB16_S_TP_FORM_CMPV_REND;
	}

	public String getNQCETB16_S_CD_BANC_CNTR() {
		return NQCETB16_S_CD_BANC_CNTR;
	}

	public void setNQCETB16_S_CD_BANC_CNTR(String nQCETB16_S_CD_BANC_CNTR) {
		NQCETB16_S_CD_BANC_CNTR = nQCETB16_S_CD_BANC_CNTR;
	}

	public String getNQCETB16_S_CD_AGEN_CNTR() {
		return NQCETB16_S_CD_AGEN_CNTR;
	}

	public void setNQCETB16_S_CD_AGEN_CNTR(String nQCETB16_S_CD_AGEN_CNTR) {
		NQCETB16_S_CD_AGEN_CNTR = nQCETB16_S_CD_AGEN_CNTR;
	}

	public String getNQCETB16_S_NR_CNTR_A() {
		return NQCETB16_S_NR_CNTR_A;
	}

	public void setNQCETB16_S_NR_CNTR_A(String nQCETB16_S_NR_CNTR_A) {
		NQCETB16_S_NR_CNTR_A = nQCETB16_S_NR_CNTR_A;
	}

	public String getNQCETB16_S_CD_PROD_ALTAIR() {
		return NQCETB16_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB16_S_CD_PROD_ALTAIR(String nQCETB16_S_CD_PROD_ALTAIR) {
		NQCETB16_S_CD_PROD_ALTAIR = nQCETB16_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB16_S_CD_SUBP_ALTAIR() {
		return NQCETB16_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB16_S_CD_SUBP_ALTAIR(String nQCETB16_S_CD_SUBP_ALTAIR) {
		NQCETB16_S_CD_SUBP_ALTAIR = nQCETB16_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB16_S_CD_MOED() {
		return NQCETB16_S_CD_MOED;
	}

	public void setNQCETB16_S_CD_MOED(String nQCETB16_S_CD_MOED) {
		NQCETB16_S_CD_MOED = nQCETB16_S_CD_MOED;
	}

	public Long getNQCETB16_S_NR_SEQU_OPER() {
		return NQCETB16_S_NR_SEQU_OPER;
	}

	public void setNQCETB16_S_NR_SEQU_OPER(Long nQCETB16_S_NR_SEQU_OPER) {
		NQCETB16_S_NR_SEQU_OPER = nQCETB16_S_NR_SEQU_OPER;
	}

	public String getNQCETB16_S_CD_IDEF_OPER() {
		return NQCETB16_S_CD_IDEF_OPER;
	}

	public void setNQCETB16_S_CD_IDEF_OPER(String nQCETB16_S_CD_IDEF_OPER) {
		NQCETB16_S_CD_IDEF_OPER = nQCETB16_S_CD_IDEF_OPER;
	}

	public String getNQCETB16_S_NM_CLIE() {
		return NQCETB16_S_NM_CLIE;
	}

	public void setNQCETB16_S_NM_CLIE(String nQCETB16_S_NM_CLIE) {
		NQCETB16_S_NM_CLIE = nQCETB16_S_NM_CLIE;
	}
	
	//*       NOME DO CLIENTE                                           
	//
	
	
	
}