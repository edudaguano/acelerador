package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0350")
public class NQE0350 {
@PsFieldString(name="COENTID", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COENTID;
@PsFieldString(name="CODAGEN", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODAGEN;
@PsFieldNumber(name="TPUNIOR", length=4, defaultValue = "0" )
private Integer TPUNIOR;
@PsFieldNumber(name="NUNIORG", length=4, defaultValue = "0" )
private Integer NUNIORG;
@PsFieldString(name="NUCONTA", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUCONTA;
@PsFieldString(name="NUPENUM", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUPENUM;
@PsFieldString(name="TPDOCTO", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPDOCTO;
@PsFieldString(name="NUDOCTO", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUDOCTO;
@PsFieldString(name="NOPESSO", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOPESSO;
@PsFieldString(name="COSEGPR", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COSEGPR;
@PsFieldString(name="COSEGSE", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COSEGSE;
@PsFieldString(name="COAREAT", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COAREAT;
@PsFieldString(name="COPROF", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COPROF;
@PsFieldNumber(name="VLRENDA", length=15, decimal=2, defaultValue = "0" )
private double VLRENDA;
@PsFieldString(name="DTRENDA", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTRENDA;
@PsFieldString(name="COTPREN", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COTPREN;
@PsFieldNumber(name="VLPATRI", length=15, decimal=2, defaultValue = "0" )
private double VLPATRI;
@PsFieldString(name="DTPATRI", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTPATRI;
@PsFieldString(name="ICCEP", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICCEP;
@PsFieldString(name="NOEMPRE", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOEMPRE;
@PsFieldString(name="COATIVI", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COATIVI;
@PsFieldString(name="COATCNA", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COATCNA;
@PsFieldString(name="COTPCOR", length=2, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COTPCOR;
@PsFieldNumber(name="VLFATAN", length=15, decimal=2, defaultValue = "0" )
private double VLFATAN;
@PsFieldString(name="DTFATAN", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTFATAN;
@PsFieldString(name="TXPARA1", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARA1;
@PsFieldString(name="TXPARA2", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARA2;
@PsFieldString(name="TXPARA3", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARA3;
@PsFieldString(name="TXPARA4", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARA4;
@PsFieldString(name="TXPARA5", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARA5;
@PsFieldString(name="TXPARA6", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARA6;
@PsFieldString(name="TXPARA7", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARA7;
@PsFieldString(name="TXPARA8", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARA8;
@PsFieldString(name="TXPARA9", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPARA9;
@PsFieldString(name="TXPAR10", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXPAR10;
@PsFieldString(name="NOCONJU", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOCONJU;
@PsFieldString(name="ICORREN", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICORREN;
@PsFieldString(name="CDUSRES", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDUSRES;
@PsFieldString(name="ICIMPED", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICIMPED;

public String getCOENTID() {
 return COENTID;
}
public void setCOENTID(String COENTID) {
 this.COENTID = COENTID;
}

public String getCODAGEN() {
 return CODAGEN;
}
public void setCODAGEN(String CODAGEN) {
 this.CODAGEN = CODAGEN;
}
public Integer getTPUNIOR() {
 return TPUNIOR;
}
public void setTPUNIOR(Integer tPUNIOR) {
TPUNIOR = tPUNIOR;
}public Integer getNUNIORG() {
 return NUNIORG;
}
public void setNUNIORG(Integer nUNIORG) {
NUNIORG = nUNIORG;
}
public String getNUCONTA() {
 return NUCONTA;
}
public void setNUCONTA(String NUCONTA) {
 this.NUCONTA = NUCONTA;
}

public String getNUPENUM() {
 return NUPENUM;
}
public void setNUPENUM(String NUPENUM) {
 this.NUPENUM = NUPENUM;
}

public String getTPDOCTO() {
 return TPDOCTO;
}
public void setTPDOCTO(String TPDOCTO) {
 this.TPDOCTO = TPDOCTO;
}

public String getNUDOCTO() {
 return NUDOCTO;
}
public void setNUDOCTO(String NUDOCTO) {
 this.NUDOCTO = NUDOCTO;
}

public String getNOPESSO() {
 return NOPESSO;
}
public void setNOPESSO(String NOPESSO) {
 this.NOPESSO = NOPESSO;
}

public String getCOSEGPR() {
 return COSEGPR;
}
public void setCOSEGPR(String COSEGPR) {
 this.COSEGPR = COSEGPR;
}

public String getCOSEGSE() {
 return COSEGSE;
}
public void setCOSEGSE(String COSEGSE) {
 this.COSEGSE = COSEGSE;
}

public String getCOAREAT() {
 return COAREAT;
}
public void setCOAREAT(String COAREAT) {
 this.COAREAT = COAREAT;
}

public String getCOPROF() {
 return COPROF;
}
public void setCOPROF(String COPROF) {
 this.COPROF = COPROF;
}
public double getVLRENDA() {
 return VLRENDA;
}
public void setVLRENDA(double vLRENDA) {
VLRENDA = vLRENDA;
}
public String getDTRENDA() {
 return DTRENDA;
}
public void setDTRENDA(String DTRENDA) {
 this.DTRENDA = DTRENDA;
}

public String getCOTPREN() {
 return COTPREN;
}
public void setCOTPREN(String COTPREN) {
 this.COTPREN = COTPREN;
}
public double getVLPATRI() {
 return VLPATRI;
}
public void setVLPATRI(double vLPATRI) {
VLPATRI = vLPATRI;
}
public String getDTPATRI() {
 return DTPATRI;
}
public void setDTPATRI(String DTPATRI) {
 this.DTPATRI = DTPATRI;
}

public String getICCEP() {
 return ICCEP;
}
public void setICCEP(String ICCEP) {
 this.ICCEP = ICCEP;
}

public String getNOEMPRE() {
 return NOEMPRE;
}
public void setNOEMPRE(String NOEMPRE) {
 this.NOEMPRE = NOEMPRE;
}

public String getCOATIVI() {
 return COATIVI;
}
public void setCOATIVI(String COATIVI) {
 this.COATIVI = COATIVI;
}

public String getCOATCNA() {
 return COATCNA;
}
public void setCOATCNA(String COATCNA) {
 this.COATCNA = COATCNA;
}

public String getCOTPCOR() {
 return COTPCOR;
}
public void setCOTPCOR(String COTPCOR) {
 this.COTPCOR = COTPCOR;
}
public double getVLFATAN() {
 return VLFATAN;
}
public void setVLFATAN(double vLFATAN) {
VLFATAN = vLFATAN;
}
public String getDTFATAN() {
 return DTFATAN;
}
public void setDTFATAN(String DTFATAN) {
 this.DTFATAN = DTFATAN;
}

public String getTXPARA1() {
 return TXPARA1;
}
public void setTXPARA1(String TXPARA1) {
 this.TXPARA1 = TXPARA1;
}

public String getTXPARA2() {
 return TXPARA2;
}
public void setTXPARA2(String TXPARA2) {
 this.TXPARA2 = TXPARA2;
}

public String getTXPARA3() {
 return TXPARA3;
}
public void setTXPARA3(String TXPARA3) {
 this.TXPARA3 = TXPARA3;
}

public String getTXPARA4() {
 return TXPARA4;
}
public void setTXPARA4(String TXPARA4) {
 this.TXPARA4 = TXPARA4;
}

public String getTXPARA5() {
 return TXPARA5;
}
public void setTXPARA5(String TXPARA5) {
 this.TXPARA5 = TXPARA5;
}

public String getTXPARA6() {
 return TXPARA6;
}
public void setTXPARA6(String TXPARA6) {
 this.TXPARA6 = TXPARA6;
}

public String getTXPARA7() {
 return TXPARA7;
}
public void setTXPARA7(String TXPARA7) {
 this.TXPARA7 = TXPARA7;
}

public String getTXPARA8() {
 return TXPARA8;
}
public void setTXPARA8(String TXPARA8) {
 this.TXPARA8 = TXPARA8;
}

public String getTXPARA9() {
 return TXPARA9;
}
public void setTXPARA9(String TXPARA9) {
 this.TXPARA9 = TXPARA9;
}

public String getTXPAR10() {
 return TXPAR10;
}
public void setTXPAR10(String TXPAR10) {
 this.TXPAR10 = TXPAR10;
}

public String getNOCONJU() {
 return NOCONJU;
}
public void setNOCONJU(String NOCONJU) {
 this.NOCONJU = NOCONJU;
}

public String getICORREN() {
 return ICORREN;
}
public void setICORREN(String ICORREN) {
 this.ICORREN = ICORREN;
}

public String getCDUSRES() {
 return CDUSRES;
}
public void setCDUSRES(String CDUSRES) {
 this.CDUSRES = CDUSRES;
}

public String getICIMPED() {
 return ICIMPED;
}
public void setICIMPED(String ICIMPED) {
 this.ICIMPED = ICIMPED;
}


}
