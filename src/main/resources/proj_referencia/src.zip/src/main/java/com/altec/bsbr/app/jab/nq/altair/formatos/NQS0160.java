package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0160")
public class NQS0160 {
@PsFieldString(name="SIGLA", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SIGLA;
@PsFieldNumber(name="SQSISOR", length=2, defaultValue = "0" )
private Integer SQSISOR;
@PsFieldString(name="DETINTE", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DETINTE;
@PsFieldString(name="NOMPROD", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOMPROD;
@PsFieldNumber(name="VLRMIN", length=15, decimal=2, defaultValue = "0" )
private double VLRMIN;
@PsFieldString(name="TPOPER", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPOPER;

public String getSIGLA() {
 return SIGLA;
}
public void setSIGLA(String SIGLA) {
 this.SIGLA = SIGLA;
}
public Integer getSQSISOR() {
 return SQSISOR;
}
public void setSQSISOR(Integer sQSISOR) {
SQSISOR = sQSISOR;
}
public String getDETINTE() {
 return DETINTE;
}
public void setDETINTE(String DETINTE) {
 this.DETINTE = DETINTE;
}

public String getNOMPROD() {
 return NOMPROD;
}
public void setNOMPROD(String NOMPROD) {
 this.NOMPROD = NOMPROD;
}
public double getVLRMIN() {
 return VLRMIN;
}
public void setVLRMIN(double vLRMIN) {
VLRMIN = vLRMIN;
}
public String getTPOPER() {
 return TPOPER;
}
public void setTPOPER(String TPOPER) {
 this.TPOPER = TPOPER;
}


}
