package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface AlertaPendenteService {
	public String versao() throws BusinessException;

	public String consultarAlerta(String strCOENTID, String strTPUNIOR, String strCDUNIOR, String strCOALERP,
			String strDTQUEST, String strDTGERPA, String strIDORDPA) throws BusinessException;
}
