package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0110")
public class NQE0110 {
@PsFieldString(name="TPUNIOR", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPUNIOR;
@PsFieldString(name="CDAGENC", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDAGENC;
@PsFieldString(name="DTCOMIT", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTCOMIT;
@PsFieldNumber(name="NMMATR1", length=11, defaultValue = "0" )
private Long NMMATR1;
@PsFieldString(name="DSCARG1", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCARG1;
@PsFieldNumber(name="NMMATR2", length=11, defaultValue = "0" )
private Long NMMATR2;
@PsFieldString(name="DSCARG2", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCARG2;
@PsFieldNumber(name="NMMATR3", length=11, defaultValue = "0" )
private Long NMMATR3;
@PsFieldString(name="DSCARG3", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCARG3;
@PsFieldNumber(name="NMMATR4", length=11, defaultValue = "0" )
private Long NMMATR4;
@PsFieldString(name="DSCARG4", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCARG4;
@PsFieldNumber(name="NMMATR5", length=11, defaultValue = "0" )
private Long NMMATR5;
@PsFieldString(name="DSCARG5", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCARG5;
@PsFieldNumber(name="NMMATR6", length=11, defaultValue = "0" )
private Long NMMATR6;
@PsFieldString(name="DSCARG6", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCARG6;
@PsFieldNumber(name="NMMATR7", length=11, defaultValue = "0" )
private Long NMMATR7;
@PsFieldString(name="DSCARG7", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCARG7;
@PsFieldNumber(name="NMMATR8", length=11, defaultValue = "0" )
private Long NMMATR8;
@PsFieldString(name="DSCARG8", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCARG8;
@PsFieldNumber(name="NMMATR9", length=11, defaultValue = "0" )
private Long NMMATR9;
@PsFieldString(name="DSCARG9", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCARG9;
@PsFieldNumber(name="NMMAT10", length=11, defaultValue = "0" )
private Long NMMAT10;
@PsFieldString(name="DSCAR10", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR10;
@PsFieldString(name="CDUSRES", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDUSRES;

public String getTPUNIOR() {
 return TPUNIOR;
}
public void setTPUNIOR(String TPUNIOR) {
 this.TPUNIOR = TPUNIOR;
}

public String getCDAGENC() {
 return CDAGENC;
}
public void setCDAGENC(String CDAGENC) {
 this.CDAGENC = CDAGENC;
}

public String getDTCOMIT() {
 return DTCOMIT;
}
public void setDTCOMIT(String DTCOMIT) {
 this.DTCOMIT = DTCOMIT;
}
public Long getNMMATR1() {
 return NMMATR1;
}
public void setNMMATR1(Long nMMATR1) {
NMMATR1 = nMMATR1;
}
public String getDSCARG1() {
 return DSCARG1;
}
public void setDSCARG1(String DSCARG1) {
 this.DSCARG1 = DSCARG1;
}
public Long getNMMATR2() {
 return NMMATR2;
}
public void setNMMATR2(Long nMMATR2) {
NMMATR2 = nMMATR2;
}
public String getDSCARG2() {
 return DSCARG2;
}
public void setDSCARG2(String DSCARG2) {
 this.DSCARG2 = DSCARG2;
}
public Long getNMMATR3() {
 return NMMATR3;
}
public void setNMMATR3(Long nMMATR3) {
NMMATR3 = nMMATR3;
}
public String getDSCARG3() {
 return DSCARG3;
}
public void setDSCARG3(String DSCARG3) {
 this.DSCARG3 = DSCARG3;
}
public Long getNMMATR4() {
 return NMMATR4;
}
public void setNMMATR4(Long nMMATR4) {
NMMATR4 = nMMATR4;
}
public String getDSCARG4() {
 return DSCARG4;
}
public void setDSCARG4(String DSCARG4) {
 this.DSCARG4 = DSCARG4;
}
public Long getNMMATR5() {
 return NMMATR5;
}
public void setNMMATR5(Long nMMATR5) {
NMMATR5 = nMMATR5;
}
public String getDSCARG5() {
 return DSCARG5;
}
public void setDSCARG5(String DSCARG5) {
 this.DSCARG5 = DSCARG5;
}
public Long getNMMATR6() {
 return NMMATR6;
}
public void setNMMATR6(Long nMMATR6) {
NMMATR6 = nMMATR6;
}
public String getDSCARG6() {
 return DSCARG6;
}
public void setDSCARG6(String DSCARG6) {
 this.DSCARG6 = DSCARG6;
}
public Long getNMMATR7() {
 return NMMATR7;
}
public void setNMMATR7(Long nMMATR7) {
NMMATR7 = nMMATR7;
}
public String getDSCARG7() {
 return DSCARG7;
}
public void setDSCARG7(String DSCARG7) {
 this.DSCARG7 = DSCARG7;
}
public Long getNMMATR8() {
 return NMMATR8;
}
public void setNMMATR8(Long nMMATR8) {
NMMATR8 = nMMATR8;
}
public String getDSCARG8() {
 return DSCARG8;
}
public void setDSCARG8(String DSCARG8) {
 this.DSCARG8 = DSCARG8;
}
public Long getNMMATR9() {
 return NMMATR9;
}
public void setNMMATR9(Long nMMATR9) {
NMMATR9 = nMMATR9;
}
public String getDSCARG9() {
 return DSCARG9;
}
public void setDSCARG9(String DSCARG9) {
 this.DSCARG9 = DSCARG9;
}
public Long getNMMAT10() {
 return NMMAT10;
}
public void setNMMAT10(Long nMMAT10) {
NMMAT10 = nMMAT10;
}
public String getDSCAR10() {
 return DSCAR10;
}
public void setDSCAR10(String DSCAR10) {
 this.DSCAR10 = DSCAR10;
}

public String getCDUSRES() {
 return CDUSRES;
}
public void setCDUSRES(String CDUSRES) {
 this.CDUSRES = CDUSRES;
}


}
