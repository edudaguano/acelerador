package com.altec.bsbr.app.jab.nq.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0120;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0230;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0120;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0230;
import com.altec.bsbr.app.jab.nq.dao.AlertaGeradoDao;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class AlertaGeradoDaoImpl implements AlertaGeradoDao {
	private final Logger LOGGER = LoggerFactory.getLogger(AlertaGeradoDaoImpl.class);

	@Autowired
	private AltairService altairService;
	
	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String versao() {
		return "";
	}

	public String montarComboSituacao(String strCDSITU) {
		NQE0230 request = new NQE0230();
		request.setCDSITU(strCDSITU);
		
		try {
			ResponseDto resp  = altairService.executar(PsFormatEnum.PS7, "NQB9", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0230.class));
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultaFiltroAlerta(String strCOENTID, String strCOALERT, String strCOAGENC, String strCOUNIOR,
			String strTPDOC, String strNUDOC, String strDTINICI, String strDTFIM, String strCOSITUA, String strIDORDPA,
			String strTPCHM, String strCOALNKM) {
		//TODO: Precisa de dados válidos
		NQE0120 request = new NQE0120();
		request.setCOENTID(strCOENTID);
		request.setCOALERT(strCOALERT);
		request.setCOAGENC(strCOAGENC);
		request.setCOUNIOR(Integer.valueOf(strCOUNIOR));
		request.setTPDOC(strTPDOC);
		request.setNUDOC(strNUDOC);
		request.setDTINICI(strDTINICI);
		request.setDTFIM(strDTFIM);
		request.setCOSITUA(strCOSITUA);
		request.setIDORDPA(strIDORDPA);
		request.setTPCHM(Integer.valueOf(strTPCHM));
		request.setCOALNKM(strCOALNKM);

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQB3", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0120.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
			
	}

}
