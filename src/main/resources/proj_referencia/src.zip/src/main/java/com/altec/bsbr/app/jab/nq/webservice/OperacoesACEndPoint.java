package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.OperacoesACService;
import com.altec.bsbr.app.jab.nq.service.OperacoesACWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class OperacoesACEndPoint extends SpringBeanAutowiringSupport implements OperacoesACWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(OperacoesACEndPoint.class);

	@Autowired
	private OperacoesACService operacoesACService;

	@WebMethod
	public String operacoesGC(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.operacoesGC(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumContrato, strNumOper, strTpOperacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String operacoesMP(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCartaoCred, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.operacoesMP(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumCartaoCred, strNumOper, strTpOperacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String operacoesUG(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strDtFormaliz, String strNumContrato, String strNumOper, String strTpOperacao,
			String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.operacoesUG(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strDtFormaliz, strNumContrato, strNumOper, strTpOperacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String operacoesLI(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strDtFormaliz, String strNumContrato, String strNumOper, String strCNPJLoji,
			String strTpOperacao, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.operacoesLI(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strDtFormaliz, strNumContrato, strNumOper, strCNPJLoji, strTpOperacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String operacoesKM(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumTitulo, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.operacoesKM(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumTitulo, strNumOper, strTpOperacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String operacoesOX(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumProposta, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.operacoesOX(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumProposta, strNumOper, strTpOperacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String operacoesEZ(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumBoleto, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.operacoesEZ(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumBoleto, strNumOper, strTpOperacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String operacoesAR(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumOperacao, String strTpOperacao, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.operacoesAR(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumOperacao, strTpOperacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String operacoesGR(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.operacoesGR(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumContrato, strNumOper, strTpOperacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String operacoesYZ(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.operacoesYZ(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumContrato, strNumOper, strTpOperacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String operacoesVC(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCtaDebito, String strNumProposta, String strNumApolice, String strNumOper,
			String strTpOperacao, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.operacoesVC(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumCtaDebito, strNumProposta, strNumApolice, strNumOper, strTpOperacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String operacoesIY(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCtaDebito, String strNumProposta, String strNumApolice, String strNumOper,
			String strTpOperacao, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.operacoesIY(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumCtaDebito, strNumProposta, strNumApolice, strNumOper, strTpOperacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.fnAddCaracter(Vlr, Tp, Tam);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String fnAddCaracterCliente(String Vlr, String Tp, String Tam) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.fnAddCaracterCliente(Vlr, Tp, Tam);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String dataAlta(String dtBaixa) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = operacoesACService.dataAlta(dtBaixa);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
}
