package com.altec.bsbr.app.jab.nq.dao;

import com.altec.bsbr.fw.BusinessException;

public interface RegrasACDao {
	public String consultarRegras(String strCodSist, String strPeriodo, String strSituacao, String strCodUser) throws BusinessException;

	public String incluirRegras(String strCodSist, String strAtivo, String strCodUser, String strPeriodo,
			String strRegra, String strProduto, String strSubProduto, String StrPEP, String strFunc,
			String strTpTransacao, String strQtdTransacao, String strPercRenda, String strVlTransacao) throws BusinessException;

	public String alterarRegras(String strCodSist, String strAtivo, String strCodUser, String strPeriodo,
			String strRegra, String strProduto, String strSubProduto, String StrPEP, String strFunc,
			String strTpTransacao, String strQtdTransacao, String strPercRenda, String strVlTransacao) throws BusinessException;

	public String inicializarinputArea(String tNQ_NQAT2007_NQCETB07_Entrada);

	public String fnAddCaracter(String Vlr, String Tp, String Tam);
}
