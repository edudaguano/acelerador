package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name = "AreaMensagem")
public class AreaMensagem {
	
	//  
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*                                        
                                          
	@PsFieldNumber(name = "RETORNO", decimal = 0, length = 3, signed = false, defaultValue = "0")
	private Long RETORNO;// 05 NQCETB29-S-RETORNO PIC 9(003) VALUE ZEROS.
	
	@PsFieldString(name = "MENSAGEM", length = 80, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String MENSAGEM;// 05 NQCETB29-S-MENSAGEM PIC X(080) VALUE SPACES.

	public Long getRETORNO() {
		return RETORNO;
	}

	public void setRETORNO(Long rETORNO) {
		RETORNO = rETORNO;
	}

	public String getMENSAGEM() {
		return MENSAGEM;
	}

	public void setMENSAGEM(String mENSAGEM) {
		MENSAGEM = mENSAGEM;
	}


	
	 
		
}
