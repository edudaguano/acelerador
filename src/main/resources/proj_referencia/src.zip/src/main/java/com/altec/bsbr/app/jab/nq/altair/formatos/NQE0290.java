package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0290")
public class NQE0290 {
@PsFieldString(name="COENTID", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COENTID;
@PsFieldString(name="COALERT", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALERT;

public String getCOENTID() {
 return COENTID;
}
public void setCOENTID(String COENTID) {
 this.COENTID = COENTID;
}

public String getCOALERT() {
 return COALERT;
}
public void setCOALERT(String COALERT) {
 this.COALERT = COALERT;
}


}
