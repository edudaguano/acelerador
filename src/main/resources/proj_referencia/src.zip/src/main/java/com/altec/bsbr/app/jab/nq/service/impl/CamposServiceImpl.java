package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.CamposDao;
import com.altec.bsbr.app.jab.nq.service.CamposService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class CamposServiceImpl implements CamposService {
	private final Logger LOGGER = LoggerFactory.getLogger(CamposServiceImpl.class);
	@Autowired
	private CamposDao campos;

	public String listarCampos(String strCodSist, String strCodUser) throws BusinessException {
		return campos.listarCampos(strCodSist, strCodUser);
	}

	public String consultarCampos(String strCodSist, String strCodCampo, String strCodUser) throws BusinessException {
		return campos.consultarCampos(strCodSist, strCodCampo, strCodUser);
	}

	public String incluirCampos(String strCodSist, String strTpCampo, String strDescCampo, String strTamCampo,
			String strPosIni, String strAtivo, String strCodUser) throws BusinessException {
		return campos.incluirCampos(strCodSist, strTpCampo, strDescCampo, strTamCampo, strPosIni, strAtivo, strCodUser);
	}

	public String alterarCampos(String strCodSist, String strCodCampo, String strTpCampo, String strDescCampo,
			String strTamCampo, String strPosIni, String strAtivo, String strCodUser) throws BusinessException {
		return campos.alterarCampos(strCodSist, strCodCampo, strTpCampo, strDescCampo, strTamCampo, strPosIni, strAtivo,
				strCodUser);
	}

	public String excluirCampos(String strCodSist, String strCodCampo, String strCodUser) throws BusinessException {
		return campos.excluirCampos(strCodSist, strCodCampo, strCodUser);
	}

	public String inicializarinputArea(String tNQ_NQAT2002_NQCETB02_ENTRADA) throws BusinessException {
		return campos.inicializarinputArea(tNQ_NQAT2002_NQCETB02_ENTRADA);
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws BusinessException {
		return campos.fnAddCaracter(Vlr, Tp, Tam);
	}
}
