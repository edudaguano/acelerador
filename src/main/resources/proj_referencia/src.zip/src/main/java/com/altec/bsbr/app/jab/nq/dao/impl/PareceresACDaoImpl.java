package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.PareceresACDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB10LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB10AreaDados;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB10MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class PareceresACDaoImpl implements PareceresACDao {
	
	private final Logger LOGGER = LoggerFactory.getLogger(PareceresACDaoImpl.class);
	
	@Autowired
 	private JSONMapper jsonMapper;
	
	@Autowired
	private NQCETB10MessagingGateway NQCETB10Service;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}
	
	public String consultarRegistros(String strCodSist, String strBanco, String strCodCliente, String strDtOcorrenca,
			String strNotUPLD, String strRegra, String strIndParecer, String strPeriodo, String strCodUser) throws BusinessException {
		
		String json = "";
		try {
			NQCETB10LegadoRequest req = new NQCETB10LegadoRequest();
			req.setNQCETB10_E_SG_FCAO("C");
			req.setNQCETB10_E_CD_USUA_ULTI_ALTR(strCodUser);
			req.setNQCETB10_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB10_E_CD_CLIE(strCodCliente);
			req.setNQCETB10_E_DT_OCOR(strDtOcorrenca);
			req.setNQCETB10_E_IN_NOTI_UPLD(strNotUPLD);
			req.setNQCETB10_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB10_E_NR_SEQU_REGR(strRegra.isEmpty()? null : Long.valueOf(strRegra));
			req.setNQCETB10_E_TP_INDC_PARE(strIndParecer);
			req.setNQCETB10_E_TP_PERI(strPeriodo);
			
			LegadoResult res = NQCETB10Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB10AreaDados> ret = decoder.parseRetorno(res, NQCETB10AreaDados.class, 83, 300);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String incluirPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorrenca,
			String strNotUPLD, String strRegra, String strIndParecer, String strPeriodo, String strTxtParecer,
			String strCodUser) throws BusinessException {
		
		String json = "";
		try {
			NQCETB10LegadoRequest req = new NQCETB10LegadoRequest();
			req.setNQCETB10_E_SG_FCAO("I");
			req.setNQCETB10_E_CD_USUA_ULTI_ALTR(strCodUser);
			req.setNQCETB10_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB10_E_CD_CLIE(strCodCliente);
			req.setNQCETB10_E_DT_OCOR(strDtOcorrenca);
			req.setNQCETB10_E_IN_NOTI_UPLD(strNotUPLD);
			req.setNQCETB10_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB10_E_NR_SEQU_REGR(strRegra.isEmpty()? null : Long.valueOf(strRegra));
			req.setNQCETB10_E_TP_INDC_PARE(strIndParecer);
			req.setNQCETB10_E_TP_PERI(strPeriodo);
			req.setNQCETB10_E_TX_PARE(strTxtParecer);
			
			LegadoResult res = NQCETB10Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB10AreaDados> ret = decoder.parseRetorno(res, NQCETB10AreaDados.class, 83, 300);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String alterarPareceres(String strCodSist,String strBanco,String strCodCliente,String strDtOcorrenca,String strNotUPLD,String strRegra,String strIndParecer,String strPeriodo,String strTxtParecer,String strCodUser) throws BusinessException { 
		String json = "";
		try {
			NQCETB10LegadoRequest req = new NQCETB10LegadoRequest();
			req.setNQCETB10_E_SG_FCAO("A");
			req.setNQCETB10_E_CD_USUA_ULTI_ALTR(strCodUser);
			req.setNQCETB10_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB10_E_CD_CLIE(strCodCliente);
			req.setNQCETB10_E_DT_OCOR(strDtOcorrenca);
			req.setNQCETB10_E_IN_NOTI_UPLD(strNotUPLD);
			req.setNQCETB10_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB10_E_NR_SEQU_REGR(strRegra.isEmpty()? null : Long.valueOf(strRegra));
			req.setNQCETB10_E_TP_INDC_PARE(strIndParecer);
			req.setNQCETB10_E_TP_PERI(strPeriodo);
			req.setNQCETB10_E_TX_PARE(strTxtParecer);
			
			LegadoResult res = NQCETB10Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB10AreaDados> ret = decoder.parseRetorno(res, NQCETB10AreaDados.class, 83, 300);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}
	
	//TBL
	public String inicializarinputArea(String tNQ_NQAT2010_NQCETB10_Entrada) { 
		return "";
	}
	
	public String fnAddCaracter(String vlr, String tp, String tam) { 
		return "";
	}
	
	public String dataAlta(String dtBaixa) { 
		return "";
	}

}
