package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0060")
public class NQE0060 {
@PsFieldNumber(name="CORGPAG", length=2, defaultValue = "0" )
private Integer CORGPAG;
@PsFieldString(name="COENPAG", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COENPAG;
public Integer getCORGPAG() {
 return CORGPAG;
}
public void setCORGPAG(Integer cORGPAG) {
CORGPAG = cORGPAG;
}
public String getCOENPAG() {
 return COENPAG;
}
public void setCOENPAG(String COENPAG) {
 this.COENPAG = COENPAG;
}


}
