package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB19AreaDados")
public class NQCETB19AreaDados {

	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*

	@PsFieldString(name= "NQCETB19_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_CD_BANC_CLIE;//          05   NQCETB19-S-CD-BANC-CLIE       PIC  X(004).                
	
	//*       CODIGO DO BANCO                                           
	//
	@PsFieldString(name= "NQCETB19_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_CD_CLIE;//          05   NQCETB19-S-CD-CLIE            PIC  X(008).                
	
	//*       CODIGO DO CLIENTE                                         
	//
	@PsFieldString(name= "NQCETB19_S_DT_MOVI", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_DT_MOVI;//          05   NQCETB19-S-DT-MOVI            PIC  X(010).                
	
	//*       DATA DO MOVIMENTO                                         
	//
	@PsFieldString(name= "NQCETB19_S_NR_BOLT_OPER", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_NR_BOLT_OPER;//          05   NQCETB19-S-NR-BOLT-OPER       PIC  X(020).                
	
	//*       NUMERO DO BOLETO                                          
	//
	@PsFieldString(name= "NQCETB19_S_CD_PROD", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_CD_PROD;//          05   NQCETB19-S-CD-PROD            PIC  X(004).                
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name= "NQCETB19_S_TP_OPER", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_TP_OPER;//          05   NQCETB19-S-TP-OPER            PIC  X(001).                
	
	//*       TIPO DE OPERACAO                                          
	//
	@PsFieldNumber(name= "NQCETB19_S_VL_OPER", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB19_S_VL_OPER;//          05   NQCETB19-S-VL-OPER            PIC S9(015)V99.             
	
	//*       VALOR DA OPERACAO                                         
	//
	@PsFieldString(name= "NQCETB19_S_CD_MOED_1", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_CD_MOED_1;//          05   NQCETB19-S-CD-MOED-1          PIC  X(003).                
	
	//*       CODIGO DA MOEDA                                           
	//
	@PsFieldNumber(name= "NQCETB19_S_VL_OPER_DOLA", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB19_S_VL_OPER_DOLA;//          05   NQCETB19-S-VL-OPER-DOLA       PIC S9(015)V99.             
	
	//*       VALOR DO OPERACAO EM DOLLAR                               
	//
	@PsFieldString(name= "NQCETB19_S_DT_EMIS", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_DT_EMIS;//          05   NQCETB19-S-DT-EMIS            PIC  X(010).                
	
	//*       DATA DA EMISSAO DA OPERACAO                               
	//
	@PsFieldString(name= "NQCETB19_S_DT_VALO_OPER", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_DT_VALO_OPER;//          05   NQCETB19-S-DT-VALO-OPER       PIC  X(010).                
	
	//*       DATA DO VALOR DA OPERACAO                                 
	//
	@PsFieldString(name= "NQCETB19_S_DT_VENC", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_DT_VENC;//          05   NQCETB19-S-DT-VENC            PIC  X(010).                
	
	//*       DATA DE VENCIMENTO DA OPERACAO                            
	//
	@PsFieldString(name= "NQCETB19_S_CD_BANC_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_CD_BANC_CNTR;//          05   NQCETB19-S-CD-BANC-CNTR       PIC  X(004).                
	
	//*       CODIGO DO BANCO DO CONTRATO                               
	//
	@PsFieldString(name= "NQCETB19_S_CD_AGEN_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_CD_AGEN_CNTR;//          05   NQCETB19-S-CD-AGEN-CNTR       PIC  X(004).                
	
	//*       CODIGO DA AGENCIA DO CONTRATO                             
	//
	@PsFieldString(name= "NQCETB19_S_NR_CNTR_A", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_NR_CNTR_A;//          05   NQCETB19-S-NR-CNTR-A          PIC  X(020).                
	
	//*       NUMERO DO CONTRATO ALTAIR                                 
	//
	@PsFieldString(name= "NQCETB19_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_CD_PROD_ALTAIR;//          05   NQCETB19-S-CD-PROD-ALTAIR     PIC  X(002).                
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name= "NQCETB19_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_CD_SUBP_ALTAIR;//          05   NQCETB19-S-CD-SUBP-ALTAIR     PIC  X(004).                
	
	//*       CODIGO DO SUBPRODUTO                                      
	//
	@PsFieldString(name= "NQCETB19_S_CD_MOED_2", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_CD_MOED_2;//          05   NQCETB19-S-CD-MOED-2          PIC  X(003).                
	
	//*       CODIGO DA MOEDA                                           
	//
	@PsFieldNumber(name= "NQCETB19_S_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB19_S_NR_SEQU_OPER;//          05   NQCETB19-S-NR-SEQU-OPER       PIC  9(003).                
	
	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	@PsFieldString(name= "NQCETB19_S_CD_IDEF_OPER", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_CD_IDEF_OPER;//          05   NQCETB19-S-CD-IDEF-OPER       PIC  X(020).                
	
	//*       CODIGO DA IDENTIFICACAO DA OPERACAO                       
	//
	@PsFieldString(name= "NQCETB19_S_NM_CLIE", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB19_S_NM_CLIE;//     05   NQCETB19-S-NM-CLIE            PIC  X(040).                
	//*       NOME DO CLIENTE                                           
	
	public String getNQCETB19_S_CD_BANC_CLIE() {
		return NQCETB19_S_CD_BANC_CLIE;
	}

	public void setNQCETB19_S_CD_BANC_CLIE(String nQCETB19_S_CD_BANC_CLIE) {
		NQCETB19_S_CD_BANC_CLIE = nQCETB19_S_CD_BANC_CLIE;
	}

	public String getNQCETB19_S_CD_CLIE() {
		return NQCETB19_S_CD_CLIE;
	}

	public void setNQCETB19_S_CD_CLIE(String nQCETB19_S_CD_CLIE) {
		NQCETB19_S_CD_CLIE = nQCETB19_S_CD_CLIE;
	}

	public String getNQCETB19_S_DT_MOVI() {
		return NQCETB19_S_DT_MOVI;
	}

	public void setNQCETB19_S_DT_MOVI(String nQCETB19_S_DT_MOVI) {
		NQCETB19_S_DT_MOVI = nQCETB19_S_DT_MOVI;
	}

	public String getNQCETB19_S_NR_BOLT_OPER() {
		return NQCETB19_S_NR_BOLT_OPER;
	}

	public void setNQCETB19_S_NR_BOLT_OPER(String nQCETB19_S_NR_BOLT_OPER) {
		NQCETB19_S_NR_BOLT_OPER = nQCETB19_S_NR_BOLT_OPER;
	}

	public String getNQCETB19_S_CD_PROD() {
		return NQCETB19_S_CD_PROD;
	}

	public void setNQCETB19_S_CD_PROD(String nQCETB19_S_CD_PROD) {
		NQCETB19_S_CD_PROD = nQCETB19_S_CD_PROD;
	}

	public String getNQCETB19_S_TP_OPER() {
		return NQCETB19_S_TP_OPER;
	}

	public void setNQCETB19_S_TP_OPER(String nQCETB19_S_TP_OPER) {
		NQCETB19_S_TP_OPER = nQCETB19_S_TP_OPER;
	}

	public Double getNQCETB19_S_VL_OPER() {
		return NQCETB19_S_VL_OPER;
	}

	public void setNQCETB19_S_VL_OPER(Double nQCETB19_S_VL_OPER) {
		NQCETB19_S_VL_OPER = nQCETB19_S_VL_OPER;
	}

	public String getNQCETB19_S_CD_MOED_1() {
		return NQCETB19_S_CD_MOED_1;
	}

	public void setNQCETB19_S_CD_MOED_1(String nQCETB19_S_CD_MOED_1) {
		NQCETB19_S_CD_MOED_1 = nQCETB19_S_CD_MOED_1;
	}

	public Double getNQCETB19_S_VL_OPER_DOLA() {
		return NQCETB19_S_VL_OPER_DOLA;
	}

	public void setNQCETB19_S_VL_OPER_DOLA(Double nQCETB19_S_VL_OPER_DOLA) {
		NQCETB19_S_VL_OPER_DOLA = nQCETB19_S_VL_OPER_DOLA;
	}

	public String getNQCETB19_S_DT_EMIS() {
		return NQCETB19_S_DT_EMIS;
	}

	public void setNQCETB19_S_DT_EMIS(String nQCETB19_S_DT_EMIS) {
		NQCETB19_S_DT_EMIS = nQCETB19_S_DT_EMIS;
	}

	public String getNQCETB19_S_DT_VALO_OPER() {
		return NQCETB19_S_DT_VALO_OPER;
	}

	public void setNQCETB19_S_DT_VALO_OPER(String nQCETB19_S_DT_VALO_OPER) {
		NQCETB19_S_DT_VALO_OPER = nQCETB19_S_DT_VALO_OPER;
	}

	public String getNQCETB19_S_DT_VENC() {
		return NQCETB19_S_DT_VENC;
	}

	public void setNQCETB19_S_DT_VENC(String nQCETB19_S_DT_VENC) {
		NQCETB19_S_DT_VENC = nQCETB19_S_DT_VENC;
	}

	public String getNQCETB19_S_CD_BANC_CNTR() {
		return NQCETB19_S_CD_BANC_CNTR;
	}

	public void setNQCETB19_S_CD_BANC_CNTR(String nQCETB19_S_CD_BANC_CNTR) {
		NQCETB19_S_CD_BANC_CNTR = nQCETB19_S_CD_BANC_CNTR;
	}

	public String getNQCETB19_S_CD_AGEN_CNTR() {
		return NQCETB19_S_CD_AGEN_CNTR;
	}

	public void setNQCETB19_S_CD_AGEN_CNTR(String nQCETB19_S_CD_AGEN_CNTR) {
		NQCETB19_S_CD_AGEN_CNTR = nQCETB19_S_CD_AGEN_CNTR;
	}

	public String getNQCETB19_S_NR_CNTR_A() {
		return NQCETB19_S_NR_CNTR_A;
	}

	public void setNQCETB19_S_NR_CNTR_A(String nQCETB19_S_NR_CNTR_A) {
		NQCETB19_S_NR_CNTR_A = nQCETB19_S_NR_CNTR_A;
	}

	public String getNQCETB19_S_CD_PROD_ALTAIR() {
		return NQCETB19_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB19_S_CD_PROD_ALTAIR(String nQCETB19_S_CD_PROD_ALTAIR) {
		NQCETB19_S_CD_PROD_ALTAIR = nQCETB19_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB19_S_CD_SUBP_ALTAIR() {
		return NQCETB19_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB19_S_CD_SUBP_ALTAIR(String nQCETB19_S_CD_SUBP_ALTAIR) {
		NQCETB19_S_CD_SUBP_ALTAIR = nQCETB19_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB19_S_CD_MOED_2() {
		return NQCETB19_S_CD_MOED_2;
	}

	public void setNQCETB19_S_CD_MOED_2(String nQCETB19_S_CD_MOED_2) {
		NQCETB19_S_CD_MOED_2 = nQCETB19_S_CD_MOED_2;
	}

	public Long getNQCETB19_S_NR_SEQU_OPER() {
		return NQCETB19_S_NR_SEQU_OPER;
	}

	public void setNQCETB19_S_NR_SEQU_OPER(Long nQCETB19_S_NR_SEQU_OPER) {
		NQCETB19_S_NR_SEQU_OPER = nQCETB19_S_NR_SEQU_OPER;
	}

	public String getNQCETB19_S_CD_IDEF_OPER() {
		return NQCETB19_S_CD_IDEF_OPER;
	}

	public void setNQCETB19_S_CD_IDEF_OPER(String nQCETB19_S_CD_IDEF_OPER) {
		NQCETB19_S_CD_IDEF_OPER = nQCETB19_S_CD_IDEF_OPER;
	}

	public String getNQCETB19_S_NM_CLIE() {
		return NQCETB19_S_NM_CLIE;
	}

	public void setNQCETB19_S_NM_CLIE(String nQCETB19_S_NM_CLIE) {
		NQCETB19_S_NM_CLIE = nQCETB19_S_NM_CLIE;
	}

	
}