package com.altec.bsbr.app.jab.nq.legado.messageGateway;

import java.util.List;

import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCE6203LegadoRequest;
import com.altec.bsbr.fw.jms.legado.LegadoException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;

public interface NQCE6203MessagingGateway {
	
	LegadoResult sendMessageLegado(NQCE6203LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageMultiLegado(NQCE6203LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageListLegado(List<NQCE6203LegadoRequest> arg0) throws LegadoException;

}