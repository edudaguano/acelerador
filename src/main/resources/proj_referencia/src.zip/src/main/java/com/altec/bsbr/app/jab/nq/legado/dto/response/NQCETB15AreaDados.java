package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB15AreaDados")
public class NQCETB15AreaDados {

	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*
	
	@PsFieldString(name= "NQCETB15_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_CD_BANC_CLIE;//          05   NQCETB15-S-CD-BANC-CLIE       PIC  X(004).                
	
	//*       CODIGO DO BANCO                                           
	//
	@PsFieldString(name= "NQCETB15_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_CD_CLIE;//          05   NQCETB15-S-CD-CLIE            PIC  X(008).                
	
	//*       CODIGO DO CLIENTE                                         
	//
	@PsFieldString(name= "NQCETB15_S_DT_MOVI", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_DT_MOVI;//          05   NQCETB15-S-DT-MOVI            PIC  X(010).                
	
	//*       DATA DO MOVIMENTO                                         
	//
	@PsFieldString(name= "NQCETB15_S_NR_CNTR", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_NR_CNTR;//          05   NQCETB15-S-NR-CNTR            PIC  X(020).                
	
	//*       NUMERO DO CONTRATO                                        
	//
	@PsFieldString(name= "NQCETB15_S_DT_FORZ", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_DT_FORZ;//          05   NQCETB15-S-DT-FORZ            PIC  X(010).                
	
	//*       DATA DE FORMALIZACAO                                      
	//
	@PsFieldString(name= "NQCETB15_S_DT_INIC_VIGE", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_DT_INIC_VIGE;//          05   NQCETB15-S-DT-INIC-VIGE       PIC  X(010).                
	
	//*       DATA DE INICIO DA VIGENCIA                                
	//
	@PsFieldString(name= "NQCETB15_S_DT_FIM_VIGE", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_DT_FIM_VIGE;//          05   NQCETB15-S-DT-FIM-VIGE        PIC  X(010).                
	
	//*       DATA DE FIM DA VIGENCIA                                   
	//
	@PsFieldString(name= "NQCETB15_S_DT_LIQU", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_DT_LIQU;//          05   NQCETB15-S-DT-LIQU            PIC  X(010).                
	
	//*       DATA DE LIQUIDACAO                                        
	//
	@PsFieldString(name= "NQCETB15_S_DT_PGTO_ANTC", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_DT_PGTO_ANTC;//          05   NQCETB15-S-DT-PGTO-ANTC       PIC  X(010).                
	
	//*       DATA DE PAGAMENTO ANTECIPADO                              
	//
	@PsFieldNumber(name= "NQCETB15_S_VL_LIQU_TOTL_ANTC", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB15_S_VL_LIQU_TOTL_ANTC;//          05   NQCETB15-S-VL-LIQU-TOTL-ANTC  PIC S9(015)V99.             
	
	//*       VALOR DA LIQUIDACAO TOTAL ANTECIPADA                      
	//
	@PsFieldNumber(name= "NQCETB15_S_VL_PGTO_ANTC_PARC", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB15_S_VL_PGTO_ANTC_PARC;//          05   NQCETB15-S-VL-PGTO-ANTC-PARC  PIC S9(015)V99.             
	
	//*       VALOR DO PAGAMENTO ANTECIPADO                             
	//
	@PsFieldNumber(name= "NQCETB15_S_VL_FINC_CNTR", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB15_S_VL_FINC_CNTR;//          05   NQCETB15-S-VL-FINC-CNTR       PIC S9(015)V99.             
	
	//*       VALOR DO FINANCIAMENTO DO CONTRATO                        
	//
	@PsFieldNumber(name= "NQCETB15_S_VL_PARC_PAGA", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB15_S_VL_PARC_PAGA;//          05   NQCETB15-S-VL-PARC-PAGA       PIC S9(015)V99.             
	
	//*       VALOR DA PARCELA PAGA                                     
	//
	@PsFieldString(name= "NQCETB15_S_TP_FINC", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_TP_FINC;//          05   NQCETB15-S-TP-FINC            PIC  X(002).                
	
	//*       TIPO DE FINANCIAMENTO                                     
	//
	@PsFieldString(name= "NQCETB15_S_TP_FORM_PGTO", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_TP_FORM_PGTO;//          05   NQCETB15-S-TP-FORM-PGTO       PIC  X(001).                
	
	//*       TIPO DA FORMA DE PAGAMENTO                                
	//
	@PsFieldString(name= "NQCETB15_S_TP_TRAN", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_TP_TRAN;//          05   NQCETB15-S-TP-TRAN            PIC  X(001).                
	
	//*       TIPO DE TRANSACAO                                         
	//
	@PsFieldString(name= "NQCETB15_S_CD_BANC_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_CD_BANC_CNTR;//          05   NQCETB15-S-CD-BANC-CNTR       PIC  X(004).                
	
	//*       CODIGO DO BANCO DO CONTRATO                               
	//
	@PsFieldString(name= "NQCETB15_S_CD_AGEN_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_CD_AGEN_CNTR;//          05   NQCETB15-S-CD-AGEN-CNTR       PIC  X(004).                
	
	//*       CODIGO DA AGENCIA DO CONTRATO                             
	//
	@PsFieldString(name= "NQCETB15_S_NR_CNTR_A", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_NR_CNTR_A;//          05   NQCETB15-S-NR-CNTR-A          PIC  X(020).                
	
	//*       NUMERO DO CONTRATO ALTAIR                                 
	//
	@PsFieldString(name= "NQCETB15_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_CD_PROD_ALTAIR;//          05   NQCETB15-S-CD-PROD-ALTAIR     PIC  X(002).                
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name= "NQCETB15_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_CD_SUBP_ALTAIR;//          05   NQCETB15-S-CD-SUBP-ALTAIR     PIC  X(004).                
	
	//*       CODIGO DO SUBPRODUTO                                      
	//
	@PsFieldString(name= "NQCETB15_S_CD_MOED", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_CD_MOED;//          05   NQCETB15-S-CD-MOED            PIC  X(003).                
	
	//*       CODIGO DA MOEDA                                           
	//
	@PsFieldNumber(name= "NQCETB15_S_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB15_S_NR_SEQU_OPER;//          05   NQCETB15-S-NR-SEQU-OPER       PIC  9(003).                
	
	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	@PsFieldString(name= "NQCETB15_S_CD_IDEF_OPER", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_CD_IDEF_OPER;//          05   NQCETB15-S-CD-IDEF-OPER       PIC  X(020).                
	
	//*       CODIGO DA IDENTIFICACAO DA OPERACAO                       
	//
	@PsFieldString(name= "NQCETB15_S_NM_CLIE", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB15_S_NM_CLIE;//     05   NQCETB15-S-NM-CLIE            PIC  X(040).                

	public String getNQCETB15_S_CD_BANC_CLIE() {
		return NQCETB15_S_CD_BANC_CLIE;
	}

	public void setNQCETB15_S_CD_BANC_CLIE(String nQCETB15_S_CD_BANC_CLIE) {
		NQCETB15_S_CD_BANC_CLIE = nQCETB15_S_CD_BANC_CLIE;
	}

	public String getNQCETB15_S_CD_CLIE() {
		return NQCETB15_S_CD_CLIE;
	}

	public void setNQCETB15_S_CD_CLIE(String nQCETB15_S_CD_CLIE) {
		NQCETB15_S_CD_CLIE = nQCETB15_S_CD_CLIE;
	}

	public String getNQCETB15_S_DT_MOVI() {
		return NQCETB15_S_DT_MOVI;
	}

	public void setNQCETB15_S_DT_MOVI(String nQCETB15_S_DT_MOVI) {
		NQCETB15_S_DT_MOVI = nQCETB15_S_DT_MOVI;
	}

	public String getNQCETB15_S_NR_CNTR() {
		return NQCETB15_S_NR_CNTR;
	}

	public void setNQCETB15_S_NR_CNTR(String nQCETB15_S_NR_CNTR) {
		NQCETB15_S_NR_CNTR = nQCETB15_S_NR_CNTR;
	}

	public String getNQCETB15_S_DT_FORZ() {
		return NQCETB15_S_DT_FORZ;
	}

	public void setNQCETB15_S_DT_FORZ(String nQCETB15_S_DT_FORZ) {
		NQCETB15_S_DT_FORZ = nQCETB15_S_DT_FORZ;
	}

	public String getNQCETB15_S_DT_INIC_VIGE() {
		return NQCETB15_S_DT_INIC_VIGE;
	}

	public void setNQCETB15_S_DT_INIC_VIGE(String nQCETB15_S_DT_INIC_VIGE) {
		NQCETB15_S_DT_INIC_VIGE = nQCETB15_S_DT_INIC_VIGE;
	}

	public String getNQCETB15_S_DT_FIM_VIGE() {
		return NQCETB15_S_DT_FIM_VIGE;
	}

	public void setNQCETB15_S_DT_FIM_VIGE(String nQCETB15_S_DT_FIM_VIGE) {
		NQCETB15_S_DT_FIM_VIGE = nQCETB15_S_DT_FIM_VIGE;
	}

	public String getNQCETB15_S_DT_LIQU() {
		return NQCETB15_S_DT_LIQU;
	}

	public void setNQCETB15_S_DT_LIQU(String nQCETB15_S_DT_LIQU) {
		NQCETB15_S_DT_LIQU = nQCETB15_S_DT_LIQU;
	}

	public String getNQCETB15_S_DT_PGTO_ANTC() {
		return NQCETB15_S_DT_PGTO_ANTC;
	}

	public void setNQCETB15_S_DT_PGTO_ANTC(String nQCETB15_S_DT_PGTO_ANTC) {
		NQCETB15_S_DT_PGTO_ANTC = nQCETB15_S_DT_PGTO_ANTC;
	}

	public Double getNQCETB15_S_VL_LIQU_TOTL_ANTC() {
		return NQCETB15_S_VL_LIQU_TOTL_ANTC;
	}

	public void setNQCETB15_S_VL_LIQU_TOTL_ANTC(Double nQCETB15_S_VL_LIQU_TOTL_ANTC) {
		NQCETB15_S_VL_LIQU_TOTL_ANTC = nQCETB15_S_VL_LIQU_TOTL_ANTC;
	}

	public Double getNQCETB15_S_VL_PGTO_ANTC_PARC() {
		return NQCETB15_S_VL_PGTO_ANTC_PARC;
	}

	public void setNQCETB15_S_VL_PGTO_ANTC_PARC(Double nQCETB15_S_VL_PGTO_ANTC_PARC) {
		NQCETB15_S_VL_PGTO_ANTC_PARC = nQCETB15_S_VL_PGTO_ANTC_PARC;
	}

	public Double getNQCETB15_S_VL_FINC_CNTR() {
		return NQCETB15_S_VL_FINC_CNTR;
	}

	public void setNQCETB15_S_VL_FINC_CNTR(Double nQCETB15_S_VL_FINC_CNTR) {
		NQCETB15_S_VL_FINC_CNTR = nQCETB15_S_VL_FINC_CNTR;
	}

	public Double getNQCETB15_S_VL_PARC_PAGA() {
		return NQCETB15_S_VL_PARC_PAGA;
	}

	public void setNQCETB15_S_VL_PARC_PAGA(Double nQCETB15_S_VL_PARC_PAGA) {
		NQCETB15_S_VL_PARC_PAGA = nQCETB15_S_VL_PARC_PAGA;
	}

	public String getNQCETB15_S_TP_FINC() {
		return NQCETB15_S_TP_FINC;
	}

	public void setNQCETB15_S_TP_FINC(String nQCETB15_S_TP_FINC) {
		NQCETB15_S_TP_FINC = nQCETB15_S_TP_FINC;
	}

	public String getNQCETB15_S_TP_FORM_PGTO() {
		return NQCETB15_S_TP_FORM_PGTO;
	}

	public void setNQCETB15_S_TP_FORM_PGTO(String nQCETB15_S_TP_FORM_PGTO) {
		NQCETB15_S_TP_FORM_PGTO = nQCETB15_S_TP_FORM_PGTO;
	}

	public String getNQCETB15_S_TP_TRAN() {
		return NQCETB15_S_TP_TRAN;
	}

	public void setNQCETB15_S_TP_TRAN(String nQCETB15_S_TP_TRAN) {
		NQCETB15_S_TP_TRAN = nQCETB15_S_TP_TRAN;
	}

	public String getNQCETB15_S_CD_BANC_CNTR() {
		return NQCETB15_S_CD_BANC_CNTR;
	}

	public void setNQCETB15_S_CD_BANC_CNTR(String nQCETB15_S_CD_BANC_CNTR) {
		NQCETB15_S_CD_BANC_CNTR = nQCETB15_S_CD_BANC_CNTR;
	}

	public String getNQCETB15_S_CD_AGEN_CNTR() {
		return NQCETB15_S_CD_AGEN_CNTR;
	}

	public void setNQCETB15_S_CD_AGEN_CNTR(String nQCETB15_S_CD_AGEN_CNTR) {
		NQCETB15_S_CD_AGEN_CNTR = nQCETB15_S_CD_AGEN_CNTR;
	}

	public String getNQCETB15_S_NR_CNTR_A() {
		return NQCETB15_S_NR_CNTR_A;
	}

	public void setNQCETB15_S_NR_CNTR_A(String nQCETB15_S_NR_CNTR_A) {
		NQCETB15_S_NR_CNTR_A = nQCETB15_S_NR_CNTR_A;
	}

	public String getNQCETB15_S_CD_PROD_ALTAIR() {
		return NQCETB15_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB15_S_CD_PROD_ALTAIR(String nQCETB15_S_CD_PROD_ALTAIR) {
		NQCETB15_S_CD_PROD_ALTAIR = nQCETB15_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB15_S_CD_SUBP_ALTAIR() {
		return NQCETB15_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB15_S_CD_SUBP_ALTAIR(String nQCETB15_S_CD_SUBP_ALTAIR) {
		NQCETB15_S_CD_SUBP_ALTAIR = nQCETB15_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB15_S_CD_MOED() {
		return NQCETB15_S_CD_MOED;
	}

	public void setNQCETB15_S_CD_MOED(String nQCETB15_S_CD_MOED) {
		NQCETB15_S_CD_MOED = nQCETB15_S_CD_MOED;
	}

	public Long getNQCETB15_S_NR_SEQU_OPER() {
		return NQCETB15_S_NR_SEQU_OPER;
	}

	public void setNQCETB15_S_NR_SEQU_OPER(Long nQCETB15_S_NR_SEQU_OPER) {
		NQCETB15_S_NR_SEQU_OPER = nQCETB15_S_NR_SEQU_OPER;
	}

	public String getNQCETB15_S_CD_IDEF_OPER() {
		return NQCETB15_S_CD_IDEF_OPER;
	}

	public void setNQCETB15_S_CD_IDEF_OPER(String nQCETB15_S_CD_IDEF_OPER) {
		NQCETB15_S_CD_IDEF_OPER = nQCETB15_S_CD_IDEF_OPER;
	}

	public String getNQCETB15_S_NM_CLIE() {
		return NQCETB15_S_NM_CLIE;
	}

	public void setNQCETB15_S_NM_CLIE(String nQCETB15_S_NM_CLIE) {
		NQCETB15_S_NM_CLIE = nQCETB15_S_NM_CLIE;
	}	
}