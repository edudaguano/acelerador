package com.altec.bsbr.app.jab.nq.legado.messageGateway;

import java.util.List;

import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCE6201LegadoRequest;
import com.altec.bsbr.fw.jms.legado.LegadoException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;

public interface NQCE6201MessagingGateway {
	
	LegadoResult sendMessageLegado(NQCE6201LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageMultiLegado(NQCE6201LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageListLegado(List<NQCE6201LegadoRequest> arg0) throws LegadoException;

}