package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.ListasDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB03LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.AreaMensagem;
import com.altec.bsbr.app.jab.nq.legado.dto.response.FullAreaResponse;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB03AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB29AreaDados;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB03MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ListasDaoImpl implements ListasDao {

	private final Logger LOGGER = LoggerFactory.getLogger(ListasDaoImpl.class);

	@Autowired
	private JSONMapper jsonMapper;
	
	@Autowired
	private NQCETB03MessagingGateway NQCETB03Service;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String listarLista(String strCodSist, String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB03LegadoRequest req = new NQCETB03LegadoRequest();
		
			req.setNQCETB3E_SG_FCAO("L");
			req.setNQCETB3E_CD_USUA(strCodUser);
			req.setNQCETB3E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			
			LegadoResult res = NQCETB03Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB03AreaDados> ret = decoder.parseRetorno(res, NQCETB03AreaDados.class, 83, 93);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String consultarLista(String strCodSist, String strCodList, String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB03LegadoRequest req = new NQCETB03LegadoRequest();
		
			req.setNQCETB3E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB3E_NR_SEQU_LIST(strCodList.isEmpty()? null : Long.valueOf(strCodList));
			req.setNQCETB3E_SG_FCAO("C");
			req.setNQCETB3E_CD_USUA(strCodUser);
			
			LegadoResult res = NQCETB03Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB03AreaDados> ret = decoder.parseRetorno(res, NQCETB03AreaDados.class, 83, 93);
			json =  new ObjectMapper().writeValueAsString(ret);		
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String incluirLista(String strCodSist, String strCodCamp, String strDsList, String strListAtiv,
			String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB03LegadoRequest req = new NQCETB03LegadoRequest();
		
			req.setNQCETB3E_SG_FCAO("I");
			req.setNQCETB3E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB3E_NR_SEQU_CAPO_SIST(strCodCamp.isEmpty()? null : Long.valueOf(strCodCamp));
			req.setNQCETB3E_DS_LIST(strDsList);
			req.setNQCETB3E_IN_LIST_ATIV(strListAtiv);
			req.setNQCETB3E_CD_USUA(strCodUser);
	
			LegadoResult res = NQCETB03Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB03AreaDados> ret = decoder.parseRetorno(res, NQCETB03AreaDados.class, 83, 93);
			json =  new ObjectMapper().writeValueAsString(ret);		
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String alterarLista(String strCodSist, String strCodList, String strCodCamp, String strDsList,
			String strListAtiv, String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB03LegadoRequest req = new NQCETB03LegadoRequest();
		
			req.setNQCETB3E_SG_FCAO("A");
			req.setNQCETB3E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB3E_NR_SEQU_CAPO_SIST(strCodCamp.isEmpty()? null : Long.valueOf(strCodCamp));
			req.setNQCETB3E_NR_SEQU_LIST(strCodList.isEmpty()? null : Long.valueOf(strCodList));
			req.setNQCETB3E_DS_LIST(strDsList);
			req.setNQCETB3E_IN_LIST_ATIV(strListAtiv);
			req.setNQCETB3E_CD_USUA(strCodUser);
			
			LegadoResult res = NQCETB03Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB03AreaDados> ret = decoder.parseRetorno(res, NQCETB03AreaDados.class, 83, 93);
			json =  new ObjectMapper().writeValueAsString(ret);			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String excluirLista(String strCodSist, String strCodList, String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB03LegadoRequest req = new NQCETB03LegadoRequest();
		
			req.setNQCETB3E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB3E_NR_SEQU_LIST(strCodList.isEmpty()? null : Long.valueOf(strCodList));
			req.setNQCETB3E_CD_USUA(strCodUser);
			req.setNQCETB3E_SG_FCAO("E");
			
			LegadoResult res = NQCETB03Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB03AreaDados> ret = decoder.parseRetorno(res, NQCETB03AreaDados.class, 83, 93);
			json =  new ObjectMapper().writeValueAsString(ret);		
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String inicializarinputArea(String tNQ_NQAT2003_NQCETB03_ENTRADA) {
		String json = "";
		return json;
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) {
		String json = "";
		return json;
	}

}
