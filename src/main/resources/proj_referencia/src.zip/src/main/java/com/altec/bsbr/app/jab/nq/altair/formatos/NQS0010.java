package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0010")
public class NQS0010 {
@PsFieldString(name="COALERP", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALERP;
@PsFieldString(name="DTQUEPA", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTQUEPA;
@PsFieldString(name="DTGERPA", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTGERPA;
@PsFieldString(name="COCLIEN", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COCLIEN;
@PsFieldString(name="NOCLIEN", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOCLIEN;
@PsFieldString(name="TPDOCTO", length=2, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPDOCTO;
@PsFieldString(name="NUDOCTO", length=15, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUDOCTO;
@PsFieldString(name="COALERT", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALERT;
@PsFieldString(name="TPALERT", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPALERT;
@PsFieldString(name="DTGERAC", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTGERAC;
@PsFieldString(name="DTQUEST", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTQUEST;
@PsFieldNumber(name="CDPAREC", length=2, defaultValue = "0" )
private Integer CDPAREC;
@PsFieldString(name="COALNKM", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALNKM;

public String getCOALERP() {
 return COALERP;
}
public void setCOALERP(String COALERP) {
 this.COALERP = COALERP;
}

public String getDTQUEPA() {
 return DTQUEPA;
}
public void setDTQUEPA(String DTQUEPA) {
 this.DTQUEPA = DTQUEPA;
}

public String getDTGERPA() {
 return DTGERPA;
}
public void setDTGERPA(String DTGERPA) {
 this.DTGERPA = DTGERPA;
}

public String getCOCLIEN() {
 return COCLIEN;
}
public void setCOCLIEN(String COCLIEN) {
 this.COCLIEN = COCLIEN;
}

public String getNOCLIEN() {
 return NOCLIEN;
}
public void setNOCLIEN(String NOCLIEN) {
 this.NOCLIEN = NOCLIEN;
}

public String getTPDOCTO() {
 return TPDOCTO;
}
public void setTPDOCTO(String TPDOCTO) {
 this.TPDOCTO = TPDOCTO;
}

public String getNUDOCTO() {
 return NUDOCTO;
}
public void setNUDOCTO(String NUDOCTO) {
 this.NUDOCTO = NUDOCTO;
}

public String getCOALERT() {
 return COALERT;
}
public void setCOALERT(String COALERT) {
 this.COALERT = COALERT;
}

public String getTPALERT() {
 return TPALERT;
}
public void setTPALERT(String TPALERT) {
 this.TPALERT = TPALERT;
}

public String getDTGERAC() {
 return DTGERAC;
}
public void setDTGERAC(String DTGERAC) {
 this.DTGERAC = DTGERAC;
}

public String getDTQUEST() {
 return DTQUEST;
}
public void setDTQUEST(String DTQUEST) {
 this.DTQUEST = DTQUEST;
}
public Integer getCDPAREC() {
 return CDPAREC;
}
public void setCDPAREC(Integer cDPAREC) {
CDPAREC = cDPAREC;
}
public String getCOALNKM() {
 return COALNKM;
}
public void setCOALNKM(String COALNKM) {
 this.COALNKM = COALNKM;
}


}
