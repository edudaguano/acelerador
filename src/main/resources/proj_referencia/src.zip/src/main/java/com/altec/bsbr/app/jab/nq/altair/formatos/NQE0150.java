package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0150")
public class NQE0150 {
@PsFieldString(name="SIGLA", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SIGLA;
@PsFieldNumber(name="NUSEQ", length=2, defaultValue = "0" )
private Integer NUSEQ;
@PsFieldString(name="DETINTE", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DETINTE;
@PsFieldString(name="NOMEPRO", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOMEPRO;
@PsFieldString(name="IDORDPA", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String IDORDPA;

public String getSIGLA() {
 return SIGLA;
}
public void setSIGLA(String SIGLA) {
 this.SIGLA = SIGLA;
}
public Integer getNUSEQ() {
 return NUSEQ;
}
public void setNUSEQ(Integer nUSEQ) {
NUSEQ = nUSEQ;
}
public String getDETINTE() {
 return DETINTE;
}
public void setDETINTE(String DETINTE) {
 this.DETINTE = DETINTE;
}

public String getNOMEPRO() {
 return NOMEPRO;
}
public void setNOMEPRO(String NOMEPRO) {
 this.NOMEPRO = NOMEPRO;
}

public String getIDORDPA() {
 return IDORDPA;
}
public void setIDORDPA(String IDORDPA) {
 this.IDORDPA = IDORDPA;
}


}
