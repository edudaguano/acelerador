package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.PareceresACService;
import com.altec.bsbr.app.jab.nq.service.PareceresACWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class PareceresACEndPoint extends SpringBeanAutowiringSupport implements PareceresACWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(PareceresACEndPoint.class);
	
	@Autowired
	private PareceresACService pareceresac;

	@WebMethod
	public String consultarRegistros(String strCodSist, String strBanco, String strCodCliente, String strDtOcorrenca,
			String strNotUPLD, String strRegra, String strIndParecer, String strPeriodo, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = pareceresac.consultarRegistros(strCodSist, strBanco, strCodCliente, strDtOcorrenca, strNotUPLD,
					strRegra, strIndParecer, strPeriodo, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			e.printStackTrace();
			System.out.println("erro");
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorrenca,
			String strNotUPLD, String strRegra, String strIndParecer, String strPeriodo, String strTxtParecer,
			String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = pareceresac.incluirPareceres(strCodSist, strBanco, strCodCliente, strDtOcorrenca, strNotUPLD,
					strRegra, strIndParecer, strPeriodo, strTxtParecer, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorrenca,
			String strNotUPLD, String strRegra, String strIndParecer, String strPeriodo, String strTxtParecer,
			String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = pareceresac.alterarPareceres(strCodSist, strBanco, strCodCliente, strDtOcorrenca, strNotUPLD,
					strRegra, strIndParecer, strPeriodo, strTxtParecer, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
	
	@WebMethod 
	public String inicializarinputArea(String tNQ_NQAT2010_NQCETB10_Entrada) throws WebServiceException{ 
		String retorno = ""; 
		try{ 
			LOGGER.info("Executar Teste Unitario");
			retorno = pareceresac.inicializarinputArea(tNQ_NQAT2010_NQCETB10_Entrada);
		}catch(Exception e){
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1); 
		 }
		return retorno;
	}
	
	@WebMethod 
	public String fnAddCaracter(String vlr, String tp, String tam) throws WebServiceException{ 
		String retorno = ""; 
		try{ 
			LOGGER.info("Executar Teste Unitario");
			retorno = pareceresac.fnAddCaracter(vlr, tp, tam);
		} catch(Exception e){
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1); 
		} 
	 	return retorno; 
	 }
	
	@WebMethod 
	public String dataAlta(String dtBaixa) throws WebServiceException{ 
		String retorno = ""; 
		try{ 
			LOGGER.info("Executar Teste Unitario");
			retorno = pareceresac.dataAlta(dtBaixa);
		} catch(Exception e){
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(),-1);
		}
		return retorno;
	}
}
