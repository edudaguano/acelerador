package com.altec.bsbr.app.jab.nq.dao;

import com.altec.bsbr.fw.BusinessException;

public interface ConteudosDao {
	public String listarConteudo(String strCodSist, String strCodList, String strCodUser) throws BusinessException;

	public String consultarConteudo(String strCodSist, String strCodList, String strCodCntd, String strCodUser) throws BusinessException;

	public String incluirConteudo(String strCodSist, String strCodList, String strTxtCntd, String strDescCntd,
			String strDtHr, String strAtivo, String strCodUser) throws BusinessException;

	public String alterarConteudo(String strCodSist, String strCodList, String strCodCntd, String strTxtCntd,
			String strDescCntd, String strDtHr, String strAtivo, String strCodUser) throws BusinessException;

	public String excluirConteudo(String strCodSist, String strCodList, String strCodCntd, String strCodUser) throws BusinessException;

	public String inicializarinputArea(String tNQ_NQAT2004_NQCETB04_ENTRADA);

	public String fnAddCaracter(String Vlr, String Tp, String Tam);
}
