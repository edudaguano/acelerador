package com.altec.bsbr.app.jab.nq.service.impl;

import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.AlertaGeradoDao;
import com.altec.bsbr.app.jab.nq.service.AlertaGeradoService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class AlertaGeradoServiceImpl implements AlertaGeradoService {
	private final Logger LOGGER = LoggerFactory.getLogger(AlertaGeradoServiceImpl.class);
	@Autowired
	private AlertaGeradoDao alertagerado;

	public String versao() throws BusinessException {
		return alertagerado.versao();
	}

	public String montarComboSituacao(String strCDSITU) throws BusinessException {
		return alertagerado.montarComboSituacao(strCDSITU);
	}

	public String consultaFiltroAlerta(String strCOENTID, String strCOALERT, String strCOAGENC, String strCOUNIOR,
			String strTPDOC, String strNUDOC, String strDTINICI, String strDTFIM, String strCOSITUA, String strIDORDPA,
			String strTPCHM, String strCOALNKM) throws BusinessException {
		return alertagerado.consultaFiltroAlerta(strCOENTID, strCOALERT, strCOAGENC, strCOUNIOR, strTPDOC, strNUDOC,
				strDTINICI, strDTFIM, strCOSITUA, strIDORDPA, strTPCHM, strCOALNKM);
	}
}
