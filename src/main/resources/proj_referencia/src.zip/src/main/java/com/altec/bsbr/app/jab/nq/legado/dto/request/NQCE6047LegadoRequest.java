package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE6047LegadoRequest {
	/*
// -*-NQCE6047                                                                            
//     01      RECEIVE-COMMAREA.                                                              
	@FixedLenghtField(position = 6, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_PGM_CHAMADA;//                 03  COMM-PGM-CHAMADA      PIC  X(008).                   

	@FixedLenghtField(position = 7, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOMEDATS;//                 03  COMM-NOMEDATS         PIC  X(010).                   

	@FixedLenghtField(position = 8, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_TAM_COMM;//                 03  COMM-TAM-COMM         PIC  9(007).                   

	@FixedLenghtField(position = 9, lenght = 9, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_MATRICULA;//                 03  COMM-MATRICULA        PIC  9(009).                   

	@FixedLenghtField(position = 10, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CINSTIT;//                 03  COMM-CINSTIT          PIC  9(003).                   

	@FixedLenghtField(position = 11, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CODAGENC;//                 03  COMM-CODAGENC         PIC  9(004).                   

	@FixedLenghtField(position = 12, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 03;//  PJ0004         03  COMM-CCLI             PIC  9(010).                   

	@FixedLenghtField(position = 13, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 03;//  PJ0004         03  COMM-DTMOVTO          PIC  9(008).                                              

//         01      SEND-AREA.                                                                 
	@FixedLenghtField(position = 14, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN;//                 03  TS01-MENS-LEN         PIC S9(004) COMP VALUE +83.    

//                 03  TS01-AREA-MENSAGEM.                                  
	@FixedLenghtField(position = 15, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO;//                     05  TS01-RETORNO      PIC  9(003) VALUE ZEROS.       

	@FixedLenghtField(position = 16, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM;//                     05  TS01-MENSAGEM     PIC  X(080) VALUE SPACES.                                             

	@FixedLenghtField(position = 17, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_MENS_LEN;//                 03  TS02-MENS-LEN         PIC S9(004) COMP VALUE +98.    

//                 03  TS02-AREA-NQCE6047.                                  
	@FixedLenghtField(position = 18, lenght = 30, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NCLI;//                     05 TS02-NCLI          PIC  X(030).                   

	@FixedLenghtField(position = 19, lenght = 20, paddingAlign = Align.LEFT, paddingChar = '0')
	private String TS02_CNPJCPF;//                     05 TS02-CNPJCPF       PIC  X(020).                   

	@FixedLenghtField(position = 20, lenght = 10, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_CCLI;//                     05 TS02-CCLI          PIC  9(010).                   

	@FixedLenghtField(position = 21, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_DTMOVTO;//                     05 TS02-DTMOVTO       PIC  9(008).                   

	@FixedLenghtField(position = 22, lenght = 10, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_NUMCONTA;//                     05 TS02-NUMCONTA      PIC  9(010).                   

	@FixedLenghtField(position = 23, lenght = 4, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_CPROD;//                     05 TS02-CPROD         PIC  X(004).                   

	@FixedLenghtField(position = 24, lenght = 13, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_VALORLAN;//                     05 TS02-VALORLAN      PIC  X(013).                   

	@FixedLenghtField(position = 25, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_CSEQUE;//                     05 TS02-CSEQUE        PIC  9(003).                   

	public NQCE6047LegadoRequest() { }
	public NQCE6047LegadoRequest(String comm_pgm_chamada, String comm_nomedats, Long comm_tam_comm, Long comm_matricula, Long comm_cinstit, Long comm_codagenc, Long 03, Long 03, String ts02_ncli, String ts02_cnpjcpf, Long ts02_ccli, Long ts02_dtmovto, Long ts02_numconta, String ts02_cprod, String ts02_valorlan, Long ts02_cseque) { 		this.COMM_PGM_CHAMADA = comm_pgm_chamada;
		this.COMM_NOMEDATS = comm_nomedats;
		this.COMM_TAM_COMM = comm_tam_comm;
		this.COMM_MATRICULA = comm_matricula;
		this.COMM_CINSTIT = comm_cinstit;
		this.COMM_CODAGENC = comm_codagenc;
		this.03 = 03;
		this.03 = 03;
		this.TS01_MENS_LEN = +83;
		this.TS01_RETORNO = ZEROS;
		this.TS01_MENSAGEM = SPACES;
		this.TS02_MENS_LEN = +98;
		this.TS02_NCLI = ts02_ncli;
		this.TS02_CNPJCPF = ts02_cnpjcpf;
		this.TS02_CCLI = ts02_ccli;
		this.TS02_DTMOVTO = ts02_dtmovto;
		this.TS02_NUMCONTA = ts02_numconta;
		this.TS02_CPROD = ts02_cprod;
		this.TS02_VALORLAN = ts02_valorlan;
		this.TS02_CSEQUE = ts02_cseque; 
	}
	public String getCOMM_PGM_CHAMADA() { return this.COMM_PGM_CHAMADA; }
	public String getCOMM_NOMEDATS() { return this.COMM_NOMEDATS; }
	public Long getCOMM_TAM_COMM() { return this.COMM_TAM_COMM; }
	public Long getCOMM_MATRICULA() { return this.COMM_MATRICULA; }
	public Long getCOMM_CINSTIT() { return this.COMM_CINSTIT; }
	public Long getCOMM_CODAGENC() { return this.COMM_CODAGENC; }
	public Long get03() { return this.03; }
	public Long get03() { return this.03; }
	public Long getTS01_MENS_LEN() { return this.TS01_MENS_LEN; }
	public Long getTS01_RETORNO() { return this.TS01_RETORNO; }
	public String getTS01_MENSAGEM() { return this.TS01_MENSAGEM; }
	public Long getTS02_MENS_LEN() { return this.TS02_MENS_LEN; }
	public String getTS02_NCLI() { return this.TS02_NCLI; }
	public String getTS02_CNPJCPF() { return this.TS02_CNPJCPF; }
	public Long getTS02_CCLI() { return this.TS02_CCLI; }
	public Long getTS02_DTMOVTO() { return this.TS02_DTMOVTO; }
	public Long getTS02_NUMCONTA() { return this.TS02_NUMCONTA; }
	public String getTS02_CPROD() { return this.TS02_CPROD; }
	public String getTS02_VALORLAN() { return this.TS02_VALORLAN; }
	public Long getTS02_CSEQUE() { return this.TS02_CSEQUE; }
	public void setCOMM_PGM_CHAMADA(String comm_pgm_chamada) { this.COMM_PGM_CHAMADA = comm_pgm_chamada; }
	public void setCOMM_NOMEDATS(String comm_nomedats) { this.COMM_NOMEDATS = comm_nomedats; }
	public void setCOMM_TAM_COMM(Long comm_tam_comm) { this.COMM_TAM_COMM = comm_tam_comm; }
	public void setCOMM_MATRICULA(Long comm_matricula) { this.COMM_MATRICULA = comm_matricula; }
	public void setCOMM_CINSTIT(Long comm_cinstit) { this.COMM_CINSTIT = comm_cinstit; }
	public void setCOMM_CODAGENC(Long comm_codagenc) { this.COMM_CODAGENC = comm_codagenc; }
	public void set03(Long 03) { this.03 = 03; }
	public void set03(Long 03) { this.03 = 03; }
	public void setTS01_MENS_LEN(Long ts01_mens_len) { this.TS01_MENS_LEN = ts01_mens_len; }
	public void setTS01_RETORNO(Long ts01_retorno) { this.TS01_RETORNO = ts01_retorno; }
	public void setTS01_MENSAGEM(String ts01_mensagem) { this.TS01_MENSAGEM = ts01_mensagem; }
	public void setTS02_MENS_LEN(Long ts02_mens_len) { this.TS02_MENS_LEN = ts02_mens_len; }
	public void setTS02_NCLI(String ts02_ncli) { this.TS02_NCLI = ts02_ncli; }
	public void setTS02_CNPJCPF(String ts02_cnpjcpf) { this.TS02_CNPJCPF = ts02_cnpjcpf; }
	public void setTS02_CCLI(Long ts02_ccli) { this.TS02_CCLI = ts02_ccli; }
	public void setTS02_DTMOVTO(Long ts02_dtmovto) { this.TS02_DTMOVTO = ts02_dtmovto; }
	public void setTS02_NUMCONTA(Long ts02_numconta) { this.TS02_NUMCONTA = ts02_numconta; }
	public void setTS02_CPROD(String ts02_cprod) { this.TS02_CPROD = ts02_cprod; }
	public void setTS02_VALORLAN(String ts02_valorlan) { this.TS02_VALORLAN = ts02_valorlan; }
	public void setTS02_CSEQUE(Long ts02_cseque) { this.TS02_CSEQUE = ts02_cseque; }
	*/
}