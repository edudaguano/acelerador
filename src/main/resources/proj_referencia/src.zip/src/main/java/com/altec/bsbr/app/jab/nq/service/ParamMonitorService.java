package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface ParamMonitorService {
	public String versao() throws BusinessException;

	public String listaTipoMovimentoMonitorado(String strCOSIGLA, String strNUSEQSI, String strCODETIN,
			String strCOOPINT, String strNOOPEIN, String strIDORDPA) throws BusinessException;

	public String incluirTipoMovimentoMonitorado(String strCOSIGLA, String strNUSEQSI, String strCODETIN,
			String strCOOPINT, String strNOOPEIN, String strICMONIT, String strTPOPERA, String strDTHROPE,
			String strCDUSRES, String strTPMANUT) throws BusinessException;

	public String montarComboProduto(String strCOPRSPR) throws BusinessException;
}
