package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.ParamMonitorDao;
import com.altec.bsbr.app.jab.nq.service.ParamMonitorService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class ParamMonitorServiceImpl implements ParamMonitorService {
	private final Logger LOGGER = LoggerFactory.getLogger(ParamMonitorServiceImpl.class);
	@Autowired
	private ParamMonitorDao paramMonitor;

	public String versao() throws BusinessException {
		return paramMonitor.versao();
	}

	public String listaTipoMovimentoMonitorado(String strCOSIGLA, String strNUSEQSI, String strCODETIN,
			String strCOOPINT, String strNOOPEIN, String strIDORDPA) throws BusinessException {
		return paramMonitor.listaTipoMovimentoMonitorado(strCOSIGLA, strNUSEQSI, strCODETIN, strCOOPINT, strNOOPEIN,
				strIDORDPA);
	}

	public String incluirTipoMovimentoMonitorado(String strCOSIGLA, String strNUSEQSI, String strCODETIN,
			String strCOOPINT, String strNOOPEIN, String strICMONIT, String strTPOPERA, String strDTHROPE,
			String strCDUSRES, String strTPMANUT) throws BusinessException {
		return paramMonitor.incluirTipoMovimentoMonitorado(strCOSIGLA, strNUSEQSI, strCODETIN, strCOOPINT, strNOOPEIN,
				strICMONIT, strTPOPERA, strDTHROPE, strCDUSRES, strTPMANUT);
	}

	public String montarComboProduto(String strCOPRSPR) throws BusinessException {
		return paramMonitor.montarComboProduto(strCOPRSPR);
	}
}
