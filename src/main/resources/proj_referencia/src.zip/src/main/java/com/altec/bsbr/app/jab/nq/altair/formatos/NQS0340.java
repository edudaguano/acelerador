package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0340")
public class NQS0340 {
@PsFieldString(name="COCLIEN", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COCLIEN;
@PsFieldString(name="NOCLIEN", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOCLIEN;
@PsFieldNumber(name="COSEG1", length=3, defaultValue = "0" )
private Integer COSEG1;
@PsFieldString(name="DSSEG1", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSSEG1;
@PsFieldNumber(name="COSEG2", length=3, defaultValue = "0" )
private Integer COSEG2;
@PsFieldString(name="DSSEG2", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSSEG2;
@PsFieldString(name="COPROF", length=5, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COPROF;
@PsFieldString(name="DSPROF", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSPROF;
@PsFieldNumber(name="COATIVI", length=3, defaultValue = "0" )
private Integer COATIVI;
@PsFieldString(name="DSATIVI", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSATIVI;
@PsFieldNumber(name="COAREA", length=4, defaultValue = "0" )
private Integer COAREA;
@PsFieldString(name="DSAREA", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSAREA;
@PsFieldNumber(name="VLRENDA", length=15, decimal=2, defaultValue = "0" )
private double VLRENDA;
@PsFieldString(name="DTRENDA", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTRENDA;
@PsFieldString(name="TPRENDA", length=43, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPRENDA;
@PsFieldNumber(name="VLPATRI", length=15, decimal=2, defaultValue = "0" )
private double VLPATRI;
@PsFieldNumber(name="VLFATUR", length=15, decimal=2, defaultValue = "0" )
private double VLFATUR;
@PsFieldString(name="DTFATUR", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTFATUR;
@PsFieldString(name="DTULTVI", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTULTVI;
@PsFieldString(name="ICPEP", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICPEP;

public String getCOCLIEN() {
 return COCLIEN;
}
public void setCOCLIEN(String COCLIEN) {
 this.COCLIEN = COCLIEN;
}

public String getNOCLIEN() {
 return NOCLIEN;
}
public void setNOCLIEN(String NOCLIEN) {
 this.NOCLIEN = NOCLIEN;
}
public Integer getCOSEG1() {
 return COSEG1;
}
public void setCOSEG1(Integer cOSEG1) {
COSEG1 = cOSEG1;
}
public String getDSSEG1() {
 return DSSEG1;
}
public void setDSSEG1(String DSSEG1) {
 this.DSSEG1 = DSSEG1;
}
public Integer getCOSEG2() {
 return COSEG2;
}
public void setCOSEG2(Integer cOSEG2) {
COSEG2 = cOSEG2;
}
public String getDSSEG2() {
 return DSSEG2;
}
public void setDSSEG2(String DSSEG2) {
 this.DSSEG2 = DSSEG2;
}

public String getCOPROF() {
 return COPROF;
}
public void setCOPROF(String COPROF) {
 this.COPROF = COPROF;
}

public String getDSPROF() {
 return DSPROF;
}
public void setDSPROF(String DSPROF) {
 this.DSPROF = DSPROF;
}
public Integer getCOATIVI() {
 return COATIVI;
}
public void setCOATIVI(Integer cOATIVI) {
COATIVI = cOATIVI;
}
public String getDSATIVI() {
 return DSATIVI;
}
public void setDSATIVI(String DSATIVI) {
 this.DSATIVI = DSATIVI;
}
public Integer getCOAREA() {
 return COAREA;
}
public void setCOAREA(Integer cOAREA) {
COAREA = cOAREA;
}
public String getDSAREA() {
 return DSAREA;
}
public void setDSAREA(String DSAREA) {
 this.DSAREA = DSAREA;
}
public double getVLRENDA() {
 return VLRENDA;
}
public void setVLRENDA(double vLRENDA) {
VLRENDA = vLRENDA;
}
public String getDTRENDA() {
 return DTRENDA;
}
public void setDTRENDA(String DTRENDA) {
 this.DTRENDA = DTRENDA;
}

public String getTPRENDA() {
 return TPRENDA;
}
public void setTPRENDA(String TPRENDA) {
 this.TPRENDA = TPRENDA;
}
public double getVLPATRI() {
 return VLPATRI;
}
public void setVLPATRI(double vLPATRI) {
VLPATRI = vLPATRI;
}public double getVLFATUR() {
 return VLFATUR;
}
public void setVLFATUR(double vLFATUR) {
VLFATUR = vLFATUR;
}
public String getDTFATUR() {
 return DTFATUR;
}
public void setDTFATUR(String DTFATUR) {
 this.DTFATUR = DTFATUR;
}

public String getDTULTVI() {
 return DTULTVI;
}
public void setDTULTVI(String DTULTVI) {
 this.DTULTVI = DTULTVI;
}

public String getICPEP() {
 return ICPEP;
}
public void setICPEP(String ICPEP) {
 this.ICPEP = ICPEP;
}


}
