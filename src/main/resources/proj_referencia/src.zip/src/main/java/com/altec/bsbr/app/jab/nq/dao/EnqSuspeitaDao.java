package com.altec.bsbr.app.jab.nq.dao;

import java.util.List;

import com.altec.bsbr.fw.ps.parser.object.PsScreen;

public interface EnqSuspeitaDao {
	public String versao();

	public String inserirEnquadramento(String strCDENTID, String strCDALERT, String strCDOREN1, String strCDENQ01,
			String strCDUSRES);

	public String listarOrgaoEnquadramento(String strCORGPAG);

	public String consultarEnquadramento(String strCORGENQ, String strCOENPAG);
}
