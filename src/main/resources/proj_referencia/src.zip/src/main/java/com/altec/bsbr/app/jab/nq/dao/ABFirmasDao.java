package com.altec.bsbr.app.jab.nq.dao;

public interface ABFirmasDao { 
	public String rsConsultaProcuradores(String nu_banco, String nu_agencia, String tpConta, String Conta); 
}

