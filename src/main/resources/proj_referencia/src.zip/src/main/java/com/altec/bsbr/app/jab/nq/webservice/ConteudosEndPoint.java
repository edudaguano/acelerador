package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.ConteudosService;
import com.altec.bsbr.app.jab.nq.service.ConteudosWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class ConteudosEndPoint extends SpringBeanAutowiringSupport implements ConteudosWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(ConteudosEndPoint.class);
	
	@Autowired
	private ConteudosService conteudos;

	@WebMethod
	public String listarConteudo(String strCodSist, String strCodList, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = conteudos.listarConteudo(strCodSist, strCodList, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarConteudo(String strCodSist, String strCodList, String strCodCntd, String strCodUser)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = conteudos.consultarConteudo(strCodSist, strCodList, strCodCntd, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirConteudo(String strCodSist, String strCodList, String strTxtCntd, String strDescCntd,
			String strDtHr, String strAtivo, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = conteudos.incluirConteudo(strCodSist, strCodList, strTxtCntd, strDescCntd, strDtHr, strAtivo,
					strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarConteudo(String strCodSist, String strCodList, String strCodCntd, String strTxtCntd,
			String strDescCntd, String strDtHr, String strAtivo, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = conteudos.alterarConteudo(strCodSist, strCodList, strCodCntd, strTxtCntd, strDescCntd, strDtHr,
					strAtivo, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String excluirConteudo(String strCodSist, String strCodList, String strCodCntd, String strCodUser)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = conteudos.excluirConteudo(strCodSist, strCodList, strCodCntd, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String inicializarinputArea(String tNQ_NQAT2004_NQCETB04_ENTRADA) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = conteudos.inicializarinputArea(tNQ_NQAT2004_NQCETB04_ENTRADA);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = conteudos.fnAddCaracter(Vlr, Tp, Tam);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

}