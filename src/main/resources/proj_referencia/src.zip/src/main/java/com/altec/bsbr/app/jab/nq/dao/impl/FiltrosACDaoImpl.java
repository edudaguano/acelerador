package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.altec.bsbr.app.jab.nq.dao.FiltrosACDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB29LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB30LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.AreaMensagem;
import com.altec.bsbr.app.jab.nq.legado.dto.response.FullAreaResponse;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB04AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB05AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB29AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB30AreaDados;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB29MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB30MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class FiltrosACDaoImpl implements FiltrosACDao {
	
	private final Logger LOGGER = LoggerFactory.getLogger(FiltrosACDaoImpl.class);

	@Autowired
 	private JSONMapper jsonMapper;
	
	@Autowired
	private NQCETB29MessagingGateway NQCETB29Service;

	@Autowired
	private NQCETB30MessagingGateway NQCETB30Service;
	
	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String consultarFiltros2(String strCodSist, String strDtOcorr, String strCodUser) throws BusinessException {		
		String json = "";		
		try {
			NQCETB30LegadoRequest req = new NQCETB30LegadoRequest();
			req.setNQCETB30_E_NM_AREA("NQAT2030");
			req.setNQCETB30_E_NM_PROG("NQAT2030");
			req.setNQCETB30_E_QT_TAMA_AREA(Long.valueOf(47));
			req.setNQCETB30_E_SG_FCAO("L");
			req.setNQCETB30_E_CD_USUA_ULTI_ALTR(strCodUser);
			req.setNQCETB30_E_DT_OCOR(strDtOcorr);
			req.setNQCETB30_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			
			LegadoResult res = NQCETB30Service.sendMessageMultiLegado(req);
			
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB30AreaDados> ret = decoder.parseRetorno(res, NQCETB30AreaDados.class, 83, 96);
			json =  new ObjectMapper().writeValueAsString(ret);			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String consultarFiltros(String strCodSist, String strDtOcorr, String strCodUser) throws BusinessException {		
		String json = "";
		try {
			NQCETB29LegadoRequest req = new NQCETB29LegadoRequest();
			req.setNQCETB29_E_NM_AREA("NQAT2029");
			req.setNQCETB29_E_NM_PROG("NQAT2029");
			req.setNQCETB29_E_QT_TAMA_AREA(Long.valueOf(47));
			req.setNQCETB29_E_SG_FCAO("L");
			req.setNQCETB29_E_CD_USUA_ULTI_ALTR(strCodUser);
			req.setNQCETB29_E_DT_OCOR(strDtOcorr);
			req.setNQCETB29_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
						
			LegadoResult res = NQCETB29Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB29AreaDados> ret = decoder.parseRetorno(res, NQCETB29AreaDados.class, 83, 228);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String fnAddCaracter(String vlr, String tp, String tam) {
		return "";
	}

	public String dataAlta(String dtBaixa) {
		return "";
	}

}
