package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.CamposDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB02LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.AreaMensagem;
import com.altec.bsbr.app.jab.nq.legado.dto.response.FullAreaResponse;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB02AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB07AreaDados;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB02MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class CamposDaoImpl implements CamposDao {
	private final Logger LOGGER = LoggerFactory.getLogger(CamposDaoImpl.class);

	@Autowired
	private JSONMapper jsonMapper;

	@Autowired
	private NQCETB02MessagingGateway NQCETB02Service;
	
	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String listarCampos(String strCodSist, String strCodUser) throws BusinessException {
		String json = "";
		try {
			
			NQCETB02LegadoRequest req = new NQCETB02LegadoRequest();
			req.setNQCETB2E_SG_FCAO("L");
			req.setNQCETB2E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB2E_CD_USUA(strCodUser);
						
			LegadoResult res = NQCETB02Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB02AreaDados> ret = decoder.parseRetorno(res, NQCETB02AreaDados.class, 83, 59);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String consultarCampos(String strCodSist, String strCodCampo, String strCodUser) throws BusinessException {
		String json = "";
		try {
			
			NQCETB02LegadoRequest req = new NQCETB02LegadoRequest();
			req.setNQCETB2E_SG_FCAO("C");
			req.setNQCETB2E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB2E_NR_SEQU_CAPO(strCodCampo.isEmpty()? null : Long.valueOf(strCodCampo));
			req.setNQCETB2E_CD_USUA(strCodUser);
		
			LegadoResult res = NQCETB02Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB02AreaDados> ret = decoder.parseRetorno(res, NQCETB02AreaDados.class, 83, 59);
			json =  new ObjectMapper().writeValueAsString(ret);			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String incluirCampos(String strCodSist, String strTpCampo, String strDescCampo, String strTamCampo,
			String strPosIni, String strAtivo, String strCodUser) throws BusinessException {
		String json = "";
		try {
			
			NQCETB02LegadoRequest req = new NQCETB02LegadoRequest();
			req.setNQCETB2E_SG_FCAO("I");
			req.setNQCETB2E_CD_USUA(strCodUser);
			req.setNQCETB2E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB2E_TP_CAPO(strTpCampo);
			req.setNQCETB2E_DS_CAPO(strDescCampo);
			req.setNQCETB2E_QT_TAMA_CAPO(strTamCampo.isEmpty()? null : Long.valueOf(strTamCampo));
			req.setNQCETB2E_VL_INIC_FILT_CAPO(strPosIni.isEmpty()? null : Long.valueOf(strPosIni));
			req.setNQCETB2E_IN_CAPO_ATIV(strAtivo);
			
			LegadoResult res = NQCETB02Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB02AreaDados> ret = decoder.parseRetorno(res, NQCETB02AreaDados.class, 83, 59);
			json =  new ObjectMapper().writeValueAsString(ret);		
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String alterarCampos(String strCodSist, String strCodCampo, String strTpCampo, String strDescCampo,
			String strTamCampo, String strPosIni, String strAtivo, String strCodUser) throws BusinessException {
		String json = "";
		try {
			
			NQCETB02LegadoRequest req = new NQCETB02LegadoRequest();
			req.setNQCETB2E_SG_FCAO("A");
			req.setNQCETB2E_CD_USUA(strCodUser);
			req.setNQCETB2E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB2E_NR_SEQU_CAPO(strCodCampo.isEmpty()? null : Long.valueOf(strCodCampo));
			req.setNQCETB2E_TP_CAPO(strTpCampo);
			req.setNQCETB2E_DS_CAPO(strDescCampo);
			req.setNQCETB2E_QT_TAMA_CAPO(strTamCampo.isEmpty()? null : Long.valueOf(strTamCampo));
			req.setNQCETB2E_VL_INIC_FILT_CAPO(strPosIni.isEmpty()? null : Long.valueOf(strPosIni));
			req.setNQCETB2E_IN_CAPO_ATIV(strAtivo);
			
			LegadoResult res = NQCETB02Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB02AreaDados> ret = decoder.parseRetorno(res, NQCETB02AreaDados.class, 83, 59);
			json =  new ObjectMapper().writeValueAsString(ret);		
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String excluirCampos(String strCodSist, String strCodCampo, String strCodUser) throws BusinessException {
		String json = "";
		try {
			
			NQCETB02LegadoRequest req = new NQCETB02LegadoRequest();
			req.setNQCETB2E_SG_FCAO("E");
			req.setNQCETB2E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB2E_NR_SEQU_CAPO(strCodCampo.isEmpty()? null : Long.valueOf(strCodCampo));
			req.setNQCETB2E_CD_USUA(strCodUser);
			
			LegadoResult res = NQCETB02Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB02AreaDados> ret = decoder.parseRetorno(res, NQCETB02AreaDados.class, 83, 59);
			json =  new ObjectMapper().writeValueAsString(ret);			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String inicializarinputArea(String tNQ_NQAT2002_NQCETB02_ENTRADA) {
		return "";
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) {
		return "";
	}

}
