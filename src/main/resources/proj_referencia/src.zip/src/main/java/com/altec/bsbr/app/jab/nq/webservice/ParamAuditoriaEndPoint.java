package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.ParamAuditoriaService;
import com.altec.bsbr.app.jab.nq.service.ParamAuditoriaWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class ParamAuditoriaEndPoint extends SpringBeanAutowiringSupport implements ParamAuditoriaWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(ParamAuditoriaEndPoint.class);

	@Autowired
	private ParamAuditoriaService paramAuditoria;

	@WebMethod
	public String listarParametro(String strCodSist, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramAuditoria.listarParametro(strCodSist, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramAuditoria.consultarParametro(strCodSist, strCodCamp, strCodParam, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirParametro(String strCodSist, String strCodCamp, String strCodDomin, String strCntd1,
			String strCntd2, String strCodList, String strDesc, String strCodUser, String strDtIncAlt, String strAtivo) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramAuditoria.incluirParametro(strCodSist, strCodCamp, strCodDomin, strCntd1, strCntd2, strCodList, strDesc, strCodUser, strDtIncAlt, strAtivo);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodDomin,
			String strCntd1, String strCntd2, String strCodList, String strDesc, String strCodUser, String strDtIncAlt,
			String strAtivo) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramAuditoria.alterarParametro(strCodSist, strCodCamp, strCodParam, strCodDomin, strCntd1, strCntd2, strCodList, strDesc, strCodUser, strDtIncAlt, strAtivo);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String excluirParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodUser) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramAuditoria.excluirParametro(strCodSist, strCodCamp, strCodParam, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String inicializarinputArea(String TNQ_NQAT2006_NQCETB06_INPUT_AREA) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramAuditoria.inicializarinputArea(TNQ_NQAT2006_NQCETB06_INPUT_AREA);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramAuditoria.fnAddCaracter(Vlr, Tp, Tam);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
	
}
