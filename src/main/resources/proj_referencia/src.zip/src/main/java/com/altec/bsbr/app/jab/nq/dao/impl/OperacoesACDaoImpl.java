package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.OperacoesACDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB13LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB14LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB15LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB16LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB17LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB18LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB19LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB20LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB21LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB22LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB23LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB24LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.AreaMensagem;
import com.altec.bsbr.app.jab.nq.legado.dto.response.FullAreaResponse;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB13AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB14AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB15AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB16AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB17AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB18AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB19AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB20AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB21AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB22AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB23AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB24AreaDados;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB13MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB14MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB15MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB16MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB17MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB18MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB19MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB20MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB21MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB22MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB23MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB24MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class OperacoesACDaoImpl implements OperacoesACDao {
	private final Logger LOGGER = LoggerFactory.getLogger(OperacoesACDaoImpl.class);

	@Autowired
	private JSONMapper jsonMapper;

	@Autowired
	private NQCETB13MessagingGateway NQCETB13Service;
	
	@Autowired
	private NQCETB14MessagingGateway NQCETB14Service;
	
	@Autowired
	private NQCETB15MessagingGateway NQCETB15Service;
	
	@Autowired
	private NQCETB16MessagingGateway NQCETB16Service;
	
	@Autowired
	private NQCETB17MessagingGateway NQCETB17Service;
	
	@Autowired
	private NQCETB18MessagingGateway NQCETB18Service;
	
	@Autowired
	private NQCETB19MessagingGateway NQCETB19Service;
	
	@Autowired
	private NQCETB20MessagingGateway NQCETB20Service;
	
	@Autowired
	private NQCETB21MessagingGateway NQCETB21Service;
	
	@Autowired
	private NQCETB22MessagingGateway NQCETB22Service;
	
	@Autowired
	private NQCETB23MessagingGateway NQCETB23Service;
	
	@Autowired
	private NQCETB24MessagingGateway NQCETB24Service;
	
	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String operacoesGC(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException {
//NQAT2013 - NQCETB13
		String json = "";
		
		try {
			NQCETB13LegadoRequest req = new NQCETB13LegadoRequest();
			req.setNQCETB13_E_NM_PROG("NQAT2013");
			req.setNQCETB13_E_NM_AREA("NQAT2013");
			req.setNQCETB13_E_QT_TAMA_AREA(Long.valueOf("94"));
			req.setNQCETB13_E_SG_FCAO(strTpOperacao);
			req.setNQCETB13_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB13_E_CD_CLIE(strCodCliente);
			req.setNQCETB13_E_CD_USUA(strCodUser);
			req.setNQCETB13_E_DT_INICIO(strDtInicio);
			req.setNQCETB13_E_DT_FIM(strDtFinal);
			req.setNQCETB13_E_NR_CNTR(strNumContrato);
			req.setNQCETB13_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB13_E_NR_SEQU_OPER(strNumOper.isEmpty()? null : Long.valueOf(strNumOper));
			
			LegadoResult res = NQCETB13Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB13AreaDados> ret = decoder.parseRetorno(res, NQCETB13AreaDados.class, 83, 273);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String operacoesMP(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCartaoCred, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException {
//NQAT2014 - NQCETB14
		String json = "";
		
		try {
			NQCETB14LegadoRequest req = new NQCETB14LegadoRequest();
			req.setNQCETB14_E_NM_PROG("NQAT2014");
			req.setNQCETB14_E_NM_AREA("NQAT2014");
			req.setNQCETB14_E_QT_TAMA_AREA(Long.valueOf("84"));
			req.setNQCETB14_E_SG_FCAO(strTpOperacao);
			req.setNQCETB14_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB14_E_CD_CLIE(strCodCliente);
			req.setNQCETB14_E_CD_USUA(strCodUser);
			req.setNQCETB14_E_DT_INICIO(strDtInicio);
			req.setNQCETB14_E_DT_FIM(strDtFinal);
			req.setNQCETB14_E_NR_CRTO_CRED(strNumCartaoCred);
			req.setNQCETB14_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB14_E_NR_SEQU_OPER(strNumOper.isEmpty()? null : Long.valueOf(strNumOper));
			
			LegadoResult res = NQCETB14Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB14AreaDados> ret = decoder.parseRetorno(res, NQCETB14AreaDados.class, 83, 242);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String operacoesUG(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strDtFormaliz, String strNumContrato, String strNumOper, String strTpOperacao,
			String strCodUser) throws BusinessException {
//NQAT2015 - NQCETB15
		String json = "";
		
		try {
			NQCETB15LegadoRequest req = new NQCETB15LegadoRequest();
			req.setNQCETB15_E_NM_PROG("NQAT2015");
			req.setNQCETB15_E_NM_AREA("NQAT2015");
			req.setNQCETB15_E_QT_TAMA_AREA(Long.valueOf("102"));
			req.setNQCETB15_E_SG_FCAO(strTpOperacao);
			req.setNQCETB15_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB15_E_CD_CLIE(strCodCliente);
			req.setNQCETB15_E_CD_USUA(strCodUser);
			req.setNQCETB15_E_DT_INICIO(strDtInicio);
			req.setNQCETB15_E_DT_FIM(strDtFinal);
			req.setNQCETB15_E_DT_FORZ(strDtFormaliz);
			req.setNQCETB15_E_NR_CNTR(strNumContrato);
			req.setNQCETB15_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB15_E_NR_SEQU_OPER(strNumOper.isEmpty()? null : Long.valueOf(strNumOper));

	
			LegadoResult res = NQCETB15Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB15AreaDados> ret = decoder.parseRetorno(res, NQCETB15AreaDados.class, 83, 264);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String operacoesLI(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strDtFormaliz, String strNumContrato, String strNumOper, String strCNPJLoji,
			String strTpOperacao, String strCodUser) throws BusinessException {
//NQAT2016 - NQCETB16
		String json = "";
		
		try {
			NQCETB16LegadoRequest req = new NQCETB16LegadoRequest();
			req.setNQCETB16_E_NM_PROG("NQAT2016");
			req.setNQCETB16_E_NM_AREA("NQAT2016");
			req.setNQCETB16_E_QT_TAMA_AREA(Long.valueOf("99"));
			req.setNQCETB16_E_SG_FCAO(strTpOperacao);
			req.setNQCETB16_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB16_E_CD_CLIE(strCodCliente);
			req.setNQCETB16_E_CD_USUA(strCodUser);
			req.setNQCETB16_E_DT_INICIO(strDtInicio);
			req.setNQCETB16_E_DT_FIM(strDtFinal);
			req.setNQCETB16_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB16_E_NR_SEQU_OPER(strNumOper.isEmpty()? null : Long.valueOf(strNumOper));
			req.setNQCETB16_E_NR_CNTR(strNumContrato);
			req.setNQCETB16_E_DT_FORZ(strDtFormaliz);
			req.setNQCETB16_E_NR_CNPJ_LOJI(strCNPJLoji);
						
			LegadoResult res = NQCETB16Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB16AreaDados> ret = decoder.parseRetorno(res, NQCETB16AreaDados.class, 83, 286);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String operacoesKM(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumTitulo, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException {
//NQAT2017 - NQCETB17
		String json = "";
		
		try {
			NQCETB17LegadoRequest req = new NQCETB17LegadoRequest();
			req.setNQCETB17_E_NM_PROG("NQAT2017");
			req.setNQCETB17_E_NM_AREA("NQAT2017");
			req.setNQCETB17_E_QT_TAMA_AREA(Long.valueOf("83"));
			req.setNQCETB17_E_SG_FCAO(strTpOperacao);
			req.setNQCETB17_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB17_E_CD_CLIE(strCodCliente);
			req.setNQCETB17_E_CD_USUA(strCodUser);
			req.setNQCETB17_E_DT_INICIO(strDtInicio);
			req.setNQCETB17_E_DT_FIM(strDtFinal);
			req.setNQCETB17_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB17_E_CD_TITU(strNumTitulo);
			req.setNQCETB17_E_NR_SEQU_OPER(strNumOper.isEmpty()? null : Long.valueOf(strNumOper));
			
			LegadoResult res = NQCETB17Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB17AreaDados> ret = decoder.parseRetorno(res, NQCETB17AreaDados.class, 83, 274);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String operacoesOX(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumProposta, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException {
//NQAT2018 - NQCETB18
		String json = "";
		
		try {
			NQCETB18LegadoRequest req = new NQCETB18LegadoRequest();
			req.setNQCETB18_E_NM_PROG("NQAT2018");
			req.setNQCETB18_E_NM_AREA("NQAT2018");
			req.setNQCETB18_E_QT_TAMA_AREA(Long.valueOf("82"));
			req.setNQCETB18_E_SG_FCAO(strTpOperacao);
			req.setNQCETB18_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB18_E_CD_CLIE(strCodCliente);
			req.setNQCETB18_E_CD_USUA(strCodUser);
			req.setNQCETB18_E_DT_INICIO(strDtInicio);
			req.setNQCETB18_E_DT_FIM(strDtFinal);
			req.setNQCETB18_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB18_E_NR_PROP(strNumProposta.isEmpty()? null : Long.valueOf(strNumProposta));
			req.setNQCETB18_E_NR_SEQU_OPER(strNumOper.isEmpty()? null : Long.valueOf(strNumOper));
			
			LegadoResult res = NQCETB18Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB18AreaDados> ret = decoder.parseRetorno(res, NQCETB18AreaDados.class, 83, 327);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String operacoesEZ(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumBoleto, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException {
//NQAT2019 - NQCETB19
		String json = "";
		
		try {
			NQCETB19LegadoRequest req = new NQCETB19LegadoRequest();
			req.setNQCETB19_E_NM_PROG("NQAT2019");
			req.setNQCETB19_E_NM_AREA("NQAT2019");
			req.setNQCETB19_E_QT_TAMA_AREA(Long.valueOf("92"));
			req.setNQCETB19_E_SG_FCAO(strTpOperacao);
			req.setNQCETB19_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB19_E_CD_CLIE(strCodCliente);
			req.setNQCETB19_E_CD_USUA(strCodUser);
			req.setNQCETB19_E_DT_INICIO(strDtInicio);
			req.setNQCETB19_E_DT_FIM(strDtFinal);
			req.setNQCETB19_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB19_E_NR_BOLT_OPER(strNumBoleto);
			req.setNQCETB19_E_NR_SEQU_OPER(strNumOper.isEmpty()? null : Long.valueOf(strNumOper));
			
			LegadoResult res = NQCETB19Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB19AreaDados> ret = decoder.parseRetorno(res, NQCETB19AreaDados.class, 83, 214);
			json =  new ObjectMapper().writeValueAsString(ret); 			
			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String operacoesAR(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumOperacao, String strTpOperacao, String strCodUser) throws BusinessException {
//NQAT2020 - NQCETB20
		String json = "";
		
		try {
			NQCETB20LegadoRequest req = new NQCETB20LegadoRequest();
	        req.setNQCETB20_E_NM_PROG("NQAT2020");
	        req.setNQCETB20_E_NM_AREA("NQAT2020");
	        req.setNQCETB20_E_QT_TAMA_AREA((long)89);
	        req.setNQCETB20_E_SG_FCAO(strTpOperacao);
	        req.setNQCETB20_E_CD_BANC_CLIE(strBanco);
	        req.setNQCETB20_E_CD_CLIE(strCodCliente);
	        req.setNQCETB20_E_CD_USUA(strCodUser);
	        req.setNQCETB20_E_DT_INICIO(strDtInicio);
	        req.setNQCETB20_E_DT_FIM(strDtFinal);
	        req.setNQCETB20_E_NR_SEQU_SIST(Long.valueOf(strCodSist));
	        req.setNQCETB20_E_NR_OPER(strNumOperacao);
	        req.setNQCETB20_E_NR_SEQU_OPER(Long.valueOf(strNumOperacao));
			
			LegadoResult res = NQCETB20Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB20AreaDados> ret = decoder.parseRetorno(res, NQCETB20AreaDados.class, 83, 248);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String operacoesGR(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException {
//NQAT2021 - NQCETB21
		String json = "";
		
		try {
			NQCETB21LegadoRequest req = new NQCETB21LegadoRequest();
			req.setNQCETB21_E_NM_PROG("NQAT2021");
			req.setNQCETB21_E_NM_AREA("NQAT2021");
			req.setNQCETB21_E_QT_TAMA_AREA(Long.valueOf("92"));
			req.setNQCETB21_E_SG_FCAO(strTpOperacao);
			req.setNQCETB21_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB21_E_CD_CLIE(strCodCliente);
			req.setNQCETB21_E_CD_USUA(strCodUser);
			req.setNQCETB21_E_DT_INICIO(strDtInicio);
			req.setNQCETB21_E_DT_FIM(strDtFinal);
			req.setNQCETB21_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB21_E_NR_CNTR(strNumContrato);
			req.setNQCETB21_E_NR_SEQU_OPER(strNumOper.isEmpty()? null : Long.valueOf(strNumOper));
			
			LegadoResult res = NQCETB21Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB21AreaDados> ret = decoder.parseRetorno(res, NQCETB21AreaDados.class, 83, 254);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String operacoesYZ(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException {
//NQAT2022 - NQCETB22
		String json = "";
		
		try {
			NQCETB22LegadoRequest req = new NQCETB22LegadoRequest();
			req.setNQCETB22_E_NM_PROG("NQAT2022");
			req.setNQCETB22_E_NM_AREA("NQAT2022");
			req.setNQCETB22_E_QT_TAMA_AREA(Long.valueOf("92"));
			req.setNQCETB22_E_SG_FCAO(strTpOperacao);
			req.setNQCETB22_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB22_E_CD_CLIE(strCodCliente);
			req.setNQCETB22_E_CD_USUA(strCodUser);
			req.setNQCETB22_E_DT_INICIO(strDtInicio);
			req.setNQCETB22_E_DT_FIM(strDtFinal);
			req.setNQCETB22_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB22_E_NR_CNTR(strNumContrato);
			req.setNQCETB22_E_NR_SEQU_OPER(strNumOper.isEmpty()? null : Long.valueOf(strNumOper));
			
			LegadoResult res = NQCETB22Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB22AreaDados> ret = decoder.parseRetorno(res, NQCETB22AreaDados.class, 83, 246);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String operacoesVC(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCtaDebito, String strNumProposta, String strNumApolice, String strNumOper,
			String strTpOperacao, String strCodUser) throws BusinessException {
//NQAT2023 - NQCETB23
		String json = "";
		
		try {
			NQCETB23LegadoRequest req = new NQCETB23LegadoRequest();
			req.setNQCETB23_E_NM_PROG("NQAT2023");
			req.setNQCETB23_E_NM_AREA("NQAT2023");
			req.setNQCETB23_E_QT_TAMA_AREA(Long.valueOf("134"));
			req.setNQCETB23_E_SG_FCAO(strTpOperacao);
			req.setNQCETB23_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB23_E_CD_CLIE(strCodCliente);
			req.setNQCETB23_E_CD_USUA(strCodUser);
			req.setNQCETB23_E_DT_INICIO(strDtInicio);
			req.setNQCETB23_E_DT_FIM(strDtFinal);
			req.setNQCETB23_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB23_E_CD_CNTA_DEBT(strNumCtaDebito);
			req.setNQCETB23_E_NR_APOL(strNumApolice);
			req.setNQCETB23_E_NR_PROP(strNumProposta);
			req.setNQCETB23_E_NR_SEQU_OPER(strNumOper.isEmpty()? null : Long.valueOf(strNumOper));
			
			LegadoResult res = NQCETB23Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB23AreaDados> ret = decoder.parseRetorno(res, NQCETB23AreaDados.class, 83, 247);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String operacoesIY(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCtaDebito, String strNumProposta, String strNumApolice, String strNumOper,
			String strTpOperacao, String strCodUser) throws BusinessException {
//NQAT2024 - NQCETB24
		String json = "";
		
		try {
			NQCETB24LegadoRequest req = new NQCETB24LegadoRequest();
			req.setNQCETB24_E_NM_PROG("NQAT2024");
			req.setNQCETB24_E_NM_AREA("NQAT2024");
			req.setNQCETB24_E_QT_TAMA_AREA(Long.valueOf("134"));
			req.setNQCETB24_E_SG_FCAO(strTpOperacao);
			req.setNQCETB24_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB24_E_CD_CLIE(strCodCliente);
			req.setNQCETB24_E_CD_USUA(strCodUser);
			req.setNQCETB24_E_DT_INICIO(strDtInicio);
			req.setNQCETB24_E_DT_FIM(strDtFinal);
			req.setNQCETB24_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB24_E_CD_CNTA_DEBT_SEGR(strNumCtaDebito);
			req.setNQCETB24_E_NR_APOL_SEGR(strNumApolice);
			req.setNQCETB24_E_NR_PROP_SEGR(strNumProposta);
			req.setNQCETB24_E_NR_SEQU_OPER(strNumOper.isEmpty()? null : Long.valueOf(strNumOper));
			
			LegadoResult res = NQCETB24Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB24AreaDados> ret = decoder.parseRetorno(res, NQCETB24AreaDados.class, 83, 269);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) {
		String json = "";
		return json;
	}

	public String fnAddCaracterCliente(String Vlr, String Tp, String Tam) {
		String json = "";
		return json;
	}

	public String dataAlta(String dtBaixa) {
		String json = "";
		return json;
	}

}
