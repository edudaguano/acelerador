package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name= "NQCETB07LegadoResponse")
public class NQCETB07LegadoResponse {
// -*-
//        01     NQCETB07-ENTRADA.                                         
//                                                                         
	@PsFieldString(name= "NQCETB07_E_NM_PROG", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_E_NM_PROG;//          05   NQCETB07-E-NM-PROG            PIC  X(008).                

//       *       NOME DO PROGRAMA CHAMADO                                  
//                                                                         
	@PsFieldString(name= "NQCETB07_E_NM_AREA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_E_NM_AREA;//          05   NQCETB07-E-NM-AREA            PIC  X(008).                

//       *       NOME DA AREA DE TS                                        
//                                                                         
	@PsFieldString(name= "NQCETB07_E_SG_FCAO", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_E_SG_FCAO;//          05   NQCETB07-E-SG-FCAO            PIC  X(002).                

//       *       FUNCAO A SER EXECUTADA                                    
//       *       C = CONSULTAR                                             
//       *       L = LISTAR                                                
//       *       I = INCLUIR                                               
//       *       A = ALTERAR                                               
//       *       E = EXCLUIR                                               
//                                                                         
	@PsFieldNumber(name= "NQCETB07_E_QT_TAMA_AREA", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long NQCETB07_E_QT_TAMA_AREA;//          05   NQCETB07-E-QT-TAMA-AREA       PIC  9(007).                

//       *       TAMANHO DA AREA DE TS                                     
//                                                                         
	@PsFieldString(name= "NQCETB07_E_CD_USUA_ULTI_ALTR", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_E_CD_USUA_ULTI_ALTR;//          05   NQCETB07-E-CD-USUA-ULTI-ALTR  PIC  X(008).                

//       *       CODIGO DO USUARIO                                         
//                                                                         
	@PsFieldNumber(name= "NQCETB07_E_NR_SEQU_SIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB07_E_NR_SEQU_SIST;//          05   NQCETB07-E-NR-SEQU-SIST       PIC  9(004).                

//       *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                         
	@PsFieldNumber(name= "NQCETB07_E_NR_SEQU_REGR", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB07_E_NR_SEQU_REGR;//          05   NQCETB07-E-NR-SEQU-REGR       PIC  9(004).                

//       *       NUMERO DE SEQUENCIA DA REGRA                              
//                                                                         
	@PsFieldString(name= "NQCETB07_E_TP_PERI", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_E_TP_PERI;//          05   NQCETB07-E-TP-PERI            PIC  X(001).                

//       *       TIPO DE PERIODO                                           
//                                                                         
	@PsFieldString(name= "NQCETB07_E_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_E_CD_PROD_ALTAIR;//          05   NQCETB07-E-CD-PROD-ALTAIR     PIC  X(002).                

//       *       CODIGO DO PRODUTO                                         
//                                                                         
	@PsFieldString(name= "NQCETB07_E_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_E_CD_SUBP_ALTAIR;//          05   NQCETB07-E-CD-SUBP-ALTAIR     PIC  X(004).                

//       *       CODIGO DO SUBPRODUTO                                      
//                                                                         
	@PsFieldString(name= "NQCETB07_E_IN_PEP", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_E_IN_PEP;//          05   NQCETB07-E-IN-PEP             PIC  X(001).                

//       *       INDICADOR CLIENTE PEP                                     
//                                                                         
	@PsFieldString(name= "NQCETB07_E_IN_FUNC", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_E_IN_FUNC;//          05   NQCETB07-E-IN-FUNC            PIC  X(001).                

//       *       INDICADOR DE CLIENTE FUNCIONARIO                          
//                                                                         
	@PsFieldString(name= "NQCETB07_E_TP_TRAN", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_E_TP_TRAN;//          05   NQCETB07-E-TP-TRAN            PIC  X(001).                

//       *       TIPO DE TRANSACAO                                         
//                                                                         
	@PsFieldNumber(name= "NQCETB07_E_QT_TRAN", decimal= 0, length= 9, signed= false, defaultValue="0")
	private Long NQCETB07_E_QT_TRAN;//          05   NQCETB07-E-QT-TRAN            PIC  9(009).                

//       *       QUANTIDADE DE TRANSACOES                                  
//                                                                         
	@PsFieldNumber(name= "NQCETB07_E_VL_PERC_FATU_REND", decimal= 3, length= 6, signed= false, defaultValue="0")
	private Double NQCETB07_E_VL_PERC_FATU_REND;//          05   NQCETB07-E-VL-PERC-FATU-REND  PIC  9(003)V99.             

//       *       VALOR DA PORCENTAGEM SOBRE FATURAMENTO / RENDA            
//                                                                         
	@PsFieldNumber(name= "NQCETB07_E_VL_TRAN", decimal= 3, length= 18, signed= false, defaultValue="0")
	private Double NQCETB07_E_VL_TRAN;//          05   NQCETB07-E-VL-TRAN            PIC  9(015)V99.             

//       *       VALOR DAS TRANSACOES                                      
//                                                                         
	@PsFieldString(name= "NQCETB07_E_CD_SITU", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_E_CD_SITU;//          05   NQCETB07-E-CD-SITU            PIC  X(001).                

//       *       CODIGO DA SITUACAO                                        
//                                                                         
//       *----------------------------------------------------------------*
//       *       AREA DE SAIDA                                             
//       *----------------------------------------------------------------*
//                                                                         
//        01     NQCETB07-SAIDA.                                           
//                                                                         
//       *       AREA DE MENSAGEM                                          
//                                                                         
	@PsFieldNumber(name= "NQCETB07_S_MENS_LEN", length= 4, binary= true, signed= true, decimal= 0)
	private Long NQCETB07_S_MENS_LEN;//         03    NQCETB07-S-MENS-LEN    COMP   PIC  S9(04) VALUE +83.      

//         03    NQCETB07-S-MENS.                                          
	@PsFieldNumber(name= "NQCETB07_S_RETORNO", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB07_S_RETORNO;//          05   NQCETB07-S-RETORNO            PIC  9(003) VALUE ZEROS.    

	@PsFieldString(name= "NQCETB07_S_MENSAGEM", length= 80, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_S_MENSAGEM;//          05   NQCETB07-S-MENSAGEM           PIC  X(080) VALUE SPACES.   

//                                                                         
//       *       AREA DE DADOS                                             
//                                                                         
	@PsFieldNumber(name= "NQCETB07_S_DATA_LEN", length= 4, binary= true, signed= true, decimal= 0)
	private Long NQCETB07_S_DATA_LEN;//         03    NQCETB07-S-DATA-LEN    COMP   PIC  S9(04) VALUE +86.      

//         03    NQCETB07-S-DATA.                                          
//                                                                         
	@PsFieldNumber(name= "NQCETB07_S_NR_SEQU_SIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB07_S_NR_SEQU_SIST;//          05   NQCETB07-S-NR-SEQU-SIST       PIC  9(004).                

//       *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                         
	@PsFieldString(name= "NQCETB07_S_SG_SIST", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_S_SG_SIST;//          05   NQCETB07-S-SG-SIST            PIC  X(002).                

//       *       SIGLA DO SISTEMA                                          
//                                                                         
	@PsFieldNumber(name= "NQCETB07_S_NR_SEQU_REGR", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB07_S_NR_SEQU_REGR;//          05   NQCETB07-S-NR-SEQU-REGR       PIC  9(004).                

//       *       NUMERO DE SEQUENCIA DA REGRA                              
//                                                                         
	@PsFieldString(name= "NQCETB07_S_TP_PERI", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_S_TP_PERI;//          05   NQCETB07-S-TP-PERI            PIC  X(001).                

//       *       TIPO DE PERIODO                                           
//                                                                         
	@PsFieldString(name= "NQCETB07_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_S_CD_PROD_ALTAIR;//          05   NQCETB07-S-CD-PROD-ALTAIR     PIC  X(002).                

//       *       CODIGO DO PRODUTO                                         
//                                                                         
	@PsFieldString(name= "NQCETB07_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_S_CD_SUBP_ALTAIR;//          05   NQCETB07-S-CD-SUBP-ALTAIR     PIC  X(004).                

//       *       CODIGO DO SUBPRODUTO                                      
//                                                                         
	@PsFieldString(name= "NQCETB07_S_IN_PEP", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_S_IN_PEP;//          05   NQCETB07-S-IN-PEP             PIC  X(001).                

//       *       INDICADOR DE CLIENTE PEP                                  
//                                                                         
	@PsFieldString(name= "NQCETB07_S_IN_FUNC", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_S_IN_FUNC;//          05   NQCETB07-S-IN-FUNC            PIC  X(001).                

//       *       INDICADOR DE CLIENTE FUNCIONARIO                          
//                                                                         
	@PsFieldString(name= "NQCETB07_S_TP_TRAN", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_S_TP_TRAN;//          05   NQCETB07-S-TP-TRAN            PIC  X(001).                

//       *       TIPO DE TRANSACAO                                         
//                                                                         
	@PsFieldNumber(name= "NQCETB07_S_QT_TRAN", decimal= 0, length= 9, signed= false, defaultValue="0")
	private Long NQCETB07_S_QT_TRAN;//          05   NQCETB07-S-QT-TRAN            PIC  9(009).                

//       *       QUANTIDADE DE TRANSACOES                                  
//                                                                         
	@PsFieldNumber(name= "NQCETB07_S_VL_PERC_FATU_REND", decimal= 3, length= 6, signed= false, defaultValue="0")
	private Double NQCETB07_S_VL_PERC_FATU_REND;//          05   NQCETB07-S-VL-PERC-FATU-REND  PIC  9(003)V99.             

//       *       VALOR DA PORCENTAGEM SOBRE FATURAMENTO / RENDA            
//                                                                         
	@PsFieldNumber(name= "NQCETB07_S_VL_TRAN", decimal= 3, length= 18, signed= false, defaultValue="0")
	private Double NQCETB07_S_VL_TRAN;//          05   NQCETB07-S-VL-TRAN            PIC  9(015)V99.             

//       *       VALOR DAS TRANSACOES                                      
//                                                                         
	@PsFieldString(name= "NQCETB07_S_CD_SITU", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_S_CD_SITU;//          05   NQCETB07-S-CD-SITU            PIC  X(001).                

//       *       CODIGO DA SITUACAO                                        
//                                                                         
	@PsFieldString(name= "NQCETB07_S_CD_USUA_ULTI_ALTR", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_S_CD_USUA_ULTI_ALTR;//          05   NQCETB07-S-CD-USUA-ULTI-ALTR  PIC  X(008).                

//       *       CODIGO DO USUARIO DA ULTIMA ALTERACAO                     
//                                                                         
	@PsFieldString(name= "NQCETB07_S_DH_ULTI_ALTR", length= 26, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB07_S_DH_ULTI_ALTR;//          05   NQCETB07-S-DH-ULTI-ALTR       PIC  X(026).                

//       *       DATA/HORA ULTIMA ALTERACAO                                
	public NQCETB07LegadoResponse() { }
	public NQCETB07LegadoResponse(String nqcetb07_e_nm_prog, String nqcetb07_e_nm_area, String nqcetb07_e_sg_fcao, Long nqcetb07_e_qt_tama_area, String nqcetb07_e_cd_usua_ulti_altr, Long nqcetb07_e_nr_sequ_sist, Long nqcetb07_e_nr_sequ_regr, String nqcetb07_e_tp_peri, String nqcetb07_e_cd_prod_altair, String nqcetb07_e_cd_subp_altair, String nqcetb07_e_in_pep, String nqcetb07_e_in_func, String nqcetb07_e_tp_tran, Long nqcetb07_e_qt_tran, Double nqcetb07_e_vl_perc_fatu_rend, Double nqcetb07_e_vl_tran, String nqcetb07_e_cd_situ, Long nqcetb07_s_nr_sequ_sist, String nqcetb07_s_sg_sist, Long nqcetb07_s_nr_sequ_regr, String nqcetb07_s_tp_peri, String nqcetb07_s_cd_prod_altair, String nqcetb07_s_cd_subp_altair, String nqcetb07_s_in_pep, String nqcetb07_s_in_func, String nqcetb07_s_tp_tran, Long nqcetb07_s_qt_tran, Double nqcetb07_s_vl_perc_fatu_rend, Double nqcetb07_s_vl_tran, String nqcetb07_s_cd_situ, String nqcetb07_s_cd_usua_ulti_altr, String nqcetb07_s_dh_ulti_altr) { 		this.NQCETB07_E_NM_PROG = nqcetb07_e_nm_prog;
		this.NQCETB07_E_NM_AREA = nqcetb07_e_nm_area;
		this.NQCETB07_E_SG_FCAO = nqcetb07_e_sg_fcao;
		this.NQCETB07_E_QT_TAMA_AREA = nqcetb07_e_qt_tama_area;
		this.NQCETB07_E_CD_USUA_ULTI_ALTR = nqcetb07_e_cd_usua_ulti_altr;
		this.NQCETB07_E_NR_SEQU_SIST = nqcetb07_e_nr_sequ_sist;
		this.NQCETB07_E_NR_SEQU_REGR = nqcetb07_e_nr_sequ_regr;
		this.NQCETB07_E_TP_PERI = nqcetb07_e_tp_peri;
		this.NQCETB07_E_CD_PROD_ALTAIR = nqcetb07_e_cd_prod_altair;
		this.NQCETB07_E_CD_SUBP_ALTAIR = nqcetb07_e_cd_subp_altair;
		this.NQCETB07_E_IN_PEP = nqcetb07_e_in_pep;
		this.NQCETB07_E_IN_FUNC = nqcetb07_e_in_func;
		this.NQCETB07_E_TP_TRAN = nqcetb07_e_tp_tran;
		this.NQCETB07_E_QT_TRAN = nqcetb07_e_qt_tran;
		this.NQCETB07_E_VL_PERC_FATU_REND = nqcetb07_e_vl_perc_fatu_rend;
		this.NQCETB07_E_VL_TRAN = nqcetb07_e_vl_tran;
		this.NQCETB07_E_CD_SITU = nqcetb07_e_cd_situ;
		/*this.NQCETB07_S_MENS_LEN = +83;
		this.NQCETB07_S_RETORNO = ZEROS;
		this.NQCETB07_S_MENSAGEM = SPACES;
		this.NQCETB07_S_DATA_LEN = +86;*/
		this.NQCETB07_S_NR_SEQU_SIST = nqcetb07_s_nr_sequ_sist;
		this.NQCETB07_S_SG_SIST = nqcetb07_s_sg_sist;
		this.NQCETB07_S_NR_SEQU_REGR = nqcetb07_s_nr_sequ_regr;
		this.NQCETB07_S_TP_PERI = nqcetb07_s_tp_peri;
		this.NQCETB07_S_CD_PROD_ALTAIR = nqcetb07_s_cd_prod_altair;
		this.NQCETB07_S_CD_SUBP_ALTAIR = nqcetb07_s_cd_subp_altair;
		this.NQCETB07_S_IN_PEP = nqcetb07_s_in_pep;
		this.NQCETB07_S_IN_FUNC = nqcetb07_s_in_func;
		this.NQCETB07_S_TP_TRAN = nqcetb07_s_tp_tran;
		this.NQCETB07_S_QT_TRAN = nqcetb07_s_qt_tran;
		this.NQCETB07_S_VL_PERC_FATU_REND = nqcetb07_s_vl_perc_fatu_rend;
		this.NQCETB07_S_VL_TRAN = nqcetb07_s_vl_tran;
		this.NQCETB07_S_CD_SITU = nqcetb07_s_cd_situ;
		this.NQCETB07_S_CD_USUA_ULTI_ALTR = nqcetb07_s_cd_usua_ulti_altr;
		this.NQCETB07_S_DH_ULTI_ALTR = nqcetb07_s_dh_ulti_altr; 
	}
	public String getNQCETB07_E_NM_PROG() { return this.NQCETB07_E_NM_PROG; }
	public String getNQCETB07_E_NM_AREA() { return this.NQCETB07_E_NM_AREA; }
	public String getNQCETB07_E_SG_FCAO() { return this.NQCETB07_E_SG_FCAO; }
	public Long getNQCETB07_E_QT_TAMA_AREA() { return this.NQCETB07_E_QT_TAMA_AREA; }
	public String getNQCETB07_E_CD_USUA_ULTI_ALTR() { return this.NQCETB07_E_CD_USUA_ULTI_ALTR; }
	public Long getNQCETB07_E_NR_SEQU_SIST() { return this.NQCETB07_E_NR_SEQU_SIST; }
	public Long getNQCETB07_E_NR_SEQU_REGR() { return this.NQCETB07_E_NR_SEQU_REGR; }
	public String getNQCETB07_E_TP_PERI() { return this.NQCETB07_E_TP_PERI; }
	public String getNQCETB07_E_CD_PROD_ALTAIR() { return this.NQCETB07_E_CD_PROD_ALTAIR; }
	public String getNQCETB07_E_CD_SUBP_ALTAIR() { return this.NQCETB07_E_CD_SUBP_ALTAIR; }
	public String getNQCETB07_E_IN_PEP() { return this.NQCETB07_E_IN_PEP; }
	public String getNQCETB07_E_IN_FUNC() { return this.NQCETB07_E_IN_FUNC; }
	public String getNQCETB07_E_TP_TRAN() { return this.NQCETB07_E_TP_TRAN; }
	public Long getNQCETB07_E_QT_TRAN() { return this.NQCETB07_E_QT_TRAN; }
	public Double getNQCETB07_E_VL_PERC_FATU_REND() { return this.NQCETB07_E_VL_PERC_FATU_REND; }
	public Double getNQCETB07_E_VL_TRAN() { return this.NQCETB07_E_VL_TRAN; }
	public String getNQCETB07_E_CD_SITU() { return this.NQCETB07_E_CD_SITU; }
	public Long getNQCETB07_S_MENS_LEN() { return this.NQCETB07_S_MENS_LEN; }
	public Long getNQCETB07_S_RETORNO() { return this.NQCETB07_S_RETORNO; }
	public String getNQCETB07_S_MENSAGEM() { return this.NQCETB07_S_MENSAGEM; }
	public Long getNQCETB07_S_DATA_LEN() { return this.NQCETB07_S_DATA_LEN; }
	public Long getNQCETB07_S_NR_SEQU_SIST() { return this.NQCETB07_S_NR_SEQU_SIST; }
	public String getNQCETB07_S_SG_SIST() { return this.NQCETB07_S_SG_SIST; }
	public Long getNQCETB07_S_NR_SEQU_REGR() { return this.NQCETB07_S_NR_SEQU_REGR; }
	public String getNQCETB07_S_TP_PERI() { return this.NQCETB07_S_TP_PERI; }
	public String getNQCETB07_S_CD_PROD_ALTAIR() { return this.NQCETB07_S_CD_PROD_ALTAIR; }
	public String getNQCETB07_S_CD_SUBP_ALTAIR() { return this.NQCETB07_S_CD_SUBP_ALTAIR; }
	public String getNQCETB07_S_IN_PEP() { return this.NQCETB07_S_IN_PEP; }
	public String getNQCETB07_S_IN_FUNC() { return this.NQCETB07_S_IN_FUNC; }
	public String getNQCETB07_S_TP_TRAN() { return this.NQCETB07_S_TP_TRAN; }
	public Long getNQCETB07_S_QT_TRAN() { return this.NQCETB07_S_QT_TRAN; }
	public Double getNQCETB07_S_VL_PERC_FATU_REND() { return this.NQCETB07_S_VL_PERC_FATU_REND; }
	public Double getNQCETB07_S_VL_TRAN() { return this.NQCETB07_S_VL_TRAN; }
	public String getNQCETB07_S_CD_SITU() { return this.NQCETB07_S_CD_SITU; }
	public String getNQCETB07_S_CD_USUA_ULTI_ALTR() { return this.NQCETB07_S_CD_USUA_ULTI_ALTR; }
	public String getNQCETB07_S_DH_ULTI_ALTR() { return this.NQCETB07_S_DH_ULTI_ALTR; }
	public void setNQCETB07_E_NM_PROG(String nqcetb07_e_nm_prog) { this.NQCETB07_E_NM_PROG = nqcetb07_e_nm_prog; }
	public void setNQCETB07_E_NM_AREA(String nqcetb07_e_nm_area) { this.NQCETB07_E_NM_AREA = nqcetb07_e_nm_area; }
	public void setNQCETB07_E_SG_FCAO(String nqcetb07_e_sg_fcao) { this.NQCETB07_E_SG_FCAO = nqcetb07_e_sg_fcao; }
	public void setNQCETB07_E_QT_TAMA_AREA(Long nqcetb07_e_qt_tama_area) { this.NQCETB07_E_QT_TAMA_AREA = nqcetb07_e_qt_tama_area; }
	public void setNQCETB07_E_CD_USUA_ULTI_ALTR(String nqcetb07_e_cd_usua_ulti_altr) { this.NQCETB07_E_CD_USUA_ULTI_ALTR = nqcetb07_e_cd_usua_ulti_altr; }
	public void setNQCETB07_E_NR_SEQU_SIST(Long nqcetb07_e_nr_sequ_sist) { this.NQCETB07_E_NR_SEQU_SIST = nqcetb07_e_nr_sequ_sist; }
	public void setNQCETB07_E_NR_SEQU_REGR(Long nqcetb07_e_nr_sequ_regr) { this.NQCETB07_E_NR_SEQU_REGR = nqcetb07_e_nr_sequ_regr; }
	public void setNQCETB07_E_TP_PERI(String nqcetb07_e_tp_peri) { this.NQCETB07_E_TP_PERI = nqcetb07_e_tp_peri; }
	public void setNQCETB07_E_CD_PROD_ALTAIR(String nqcetb07_e_cd_prod_altair) { this.NQCETB07_E_CD_PROD_ALTAIR = nqcetb07_e_cd_prod_altair; }
	public void setNQCETB07_E_CD_SUBP_ALTAIR(String nqcetb07_e_cd_subp_altair) { this.NQCETB07_E_CD_SUBP_ALTAIR = nqcetb07_e_cd_subp_altair; }
	public void setNQCETB07_E_IN_PEP(String nqcetb07_e_in_pep) { this.NQCETB07_E_IN_PEP = nqcetb07_e_in_pep; }
	public void setNQCETB07_E_IN_FUNC(String nqcetb07_e_in_func) { this.NQCETB07_E_IN_FUNC = nqcetb07_e_in_func; }
	public void setNQCETB07_E_TP_TRAN(String nqcetb07_e_tp_tran) { this.NQCETB07_E_TP_TRAN = nqcetb07_e_tp_tran; }
	public void setNQCETB07_E_QT_TRAN(Long nqcetb07_e_qt_tran) { this.NQCETB07_E_QT_TRAN = nqcetb07_e_qt_tran; }
	public void setNQCETB07_E_VL_PERC_FATU_REND(Double nqcetb07_e_vl_perc_fatu_rend) { this.NQCETB07_E_VL_PERC_FATU_REND = nqcetb07_e_vl_perc_fatu_rend; }
	public void setNQCETB07_E_VL_TRAN(Double nqcetb07_e_vl_tran) { this.NQCETB07_E_VL_TRAN = nqcetb07_e_vl_tran; }
	public void setNQCETB07_E_CD_SITU(String nqcetb07_e_cd_situ) { this.NQCETB07_E_CD_SITU = nqcetb07_e_cd_situ; }
	public void setNQCETB07_S_MENS_LEN(Long nqcetb07_s_mens_len) { this.NQCETB07_S_MENS_LEN = nqcetb07_s_mens_len; }
	public void setNQCETB07_S_RETORNO(Long nqcetb07_s_retorno) { this.NQCETB07_S_RETORNO = nqcetb07_s_retorno; }
	public void setNQCETB07_S_MENSAGEM(String nqcetb07_s_mensagem) { this.NQCETB07_S_MENSAGEM = nqcetb07_s_mensagem; }
	public void setNQCETB07_S_DATA_LEN(Long nqcetb07_s_data_len) { this.NQCETB07_S_DATA_LEN = nqcetb07_s_data_len; }
	public void setNQCETB07_S_NR_SEQU_SIST(Long nqcetb07_s_nr_sequ_sist) { this.NQCETB07_S_NR_SEQU_SIST = nqcetb07_s_nr_sequ_sist; }
	public void setNQCETB07_S_SG_SIST(String nqcetb07_s_sg_sist) { this.NQCETB07_S_SG_SIST = nqcetb07_s_sg_sist; }
	public void setNQCETB07_S_NR_SEQU_REGR(Long nqcetb07_s_nr_sequ_regr) { this.NQCETB07_S_NR_SEQU_REGR = nqcetb07_s_nr_sequ_regr; }
	public void setNQCETB07_S_TP_PERI(String nqcetb07_s_tp_peri) { this.NQCETB07_S_TP_PERI = nqcetb07_s_tp_peri; }
	public void setNQCETB07_S_CD_PROD_ALTAIR(String nqcetb07_s_cd_prod_altair) { this.NQCETB07_S_CD_PROD_ALTAIR = nqcetb07_s_cd_prod_altair; }
	public void setNQCETB07_S_CD_SUBP_ALTAIR(String nqcetb07_s_cd_subp_altair) { this.NQCETB07_S_CD_SUBP_ALTAIR = nqcetb07_s_cd_subp_altair; }
	public void setNQCETB07_S_IN_PEP(String nqcetb07_s_in_pep) { this.NQCETB07_S_IN_PEP = nqcetb07_s_in_pep; }
	public void setNQCETB07_S_IN_FUNC(String nqcetb07_s_in_func) { this.NQCETB07_S_IN_FUNC = nqcetb07_s_in_func; }
	public void setNQCETB07_S_TP_TRAN(String nqcetb07_s_tp_tran) { this.NQCETB07_S_TP_TRAN = nqcetb07_s_tp_tran; }
	public void setNQCETB07_S_QT_TRAN(Long nqcetb07_s_qt_tran) { this.NQCETB07_S_QT_TRAN = nqcetb07_s_qt_tran; }
	public void setNQCETB07_S_VL_PERC_FATU_REND(Double nqcetb07_s_vl_perc_fatu_rend) { this.NQCETB07_S_VL_PERC_FATU_REND = nqcetb07_s_vl_perc_fatu_rend; }
	public void setNQCETB07_S_VL_TRAN(Double nqcetb07_s_vl_tran) { this.NQCETB07_S_VL_TRAN = nqcetb07_s_vl_tran; }
	public void setNQCETB07_S_CD_SITU(String nqcetb07_s_cd_situ) { this.NQCETB07_S_CD_SITU = nqcetb07_s_cd_situ; }
	public void setNQCETB07_S_CD_USUA_ULTI_ALTR(String nqcetb07_s_cd_usua_ulti_altr) { this.NQCETB07_S_CD_USUA_ULTI_ALTR = nqcetb07_s_cd_usua_ulti_altr; }
	public void setNQCETB07_S_DH_ULTI_ALTR(String nqcetb07_s_dh_ulti_altr) { this.NQCETB07_S_DH_ULTI_ALTR = nqcetb07_s_dh_ulti_altr; }
}