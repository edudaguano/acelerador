package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name = "NQCETB23LegadoRequest")
public class NQCETB23LegadoRequest {

	// -*-
//  01     NQCETB23-ENTRADA.                                         
//                                                                   
	@PsFieldString(name = "NQCETB23_E_NM_PROG", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB23_E_NM_PROG;// 05 NQCETB23-E-NM-PROG PIC X(008).

// *       NOME DO PROGRAMA CHAMADO                                  
//                                                                   
	@PsFieldString(name = "NQCETB23_E_NM_AREA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB23_E_NM_AREA;// 05 NQCETB23-E-NM-AREA PIC X(008).

// *       NOME DA AREA DE TS                                        
//                                                                   
	@PsFieldString(name = "NQCETB23_E_SG_FCAO", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB23_E_SG_FCAO;// 05 NQCETB23-E-SG-FCAO PIC X(002).

// *       FUNCAO A SER EXECUTADA                                    
// *       L = LISTAR                                                
// *       C = CONSULTA                                              
//                                                                   
	@PsFieldNumber(name = "NQCETB23_E_QT_TAMA_AREA", decimal = 0, length = 7, signed = false, defaultValue = "0")
	private Long NQCETB23_E_QT_TAMA_AREA;// 05 NQCETB23-E-QT-TAMA-AREA PIC 9(007).

// *       TAMANHO DA AREA DE TS                                     
//                                                                   
	@PsFieldString(name = "NQCETB23_E_CD_USUA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB23_E_CD_USUA;// 05 NQCETB23-E-CD-USUA PIC X(008).

// *       CODIGO DO USUARIO                                         
//                                                                   
	@PsFieldNumber(name = "NQCETB23_E_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB23_E_NR_SEQU_SIST;// 05 NQCETB23-E-NR-SEQU-SIST PIC 9(004).

// *       NUMERO SEQUENCIAL DO SISTEMA                              
//                                                                   
	@PsFieldString(name = "NQCETB23_E_CD_BANC_CLIE", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB23_E_CD_BANC_CLIE;// 05 NQCETB23-E-CD-BANC-CLIE PIC X(004).

// *       CODIGO DO BANCO                                           
//                                                                   
	@PsFieldString(name = "NQCETB23_E_CD_CLIE", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB23_E_CD_CLIE;// 05 NQCETB23-E-CD-CLIE PIC X(008).

// *       CODIGO DO CLIENTE                                         
//                                                                   
	@PsFieldString(name = "NQCETB23_E_DT_INICIO", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB23_E_DT_INICIO;// 05 NQCETB23-E-DT-INICIO PIC X(010).

// *       DATA INICIO DO PERIODO                                    
//                                                                   
	@PsFieldString(name = "NQCETB23_E_DT_FIM", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB23_E_DT_FIM;// 05 NQCETB23-E-DT-FIM PIC X(010).

// *       DATA FIM DO PERIODO                                       
//                                                                   
	@PsFieldString(name = "NQCETB23_E_CD_CNTA_DEBT", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB23_E_CD_CNTA_DEBT;// 05 NQCETB23-E-CD-CNTA-DEBT PIC X(020).

// *       CODIGO DA CONTA DE DEBITO                                 
//                                                                   
	@PsFieldString(name = "NQCETB23_E_NR_PROP", length = 12, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB23_E_NR_PROP;// 05 NQCETB23-E-NR-PROP PIC X(012).

// *       NUMERO DA PROPOSTA                                        
//                                                                   
	@PsFieldString(name = "NQCETB23_E_NR_APOL", length = 30, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB23_E_NR_APOL;// 05 NQCETB23-E-NR-APOL PIC X(030).

// *       NUMERO DA APOLICE                                         
//                                                                   
	@PsFieldNumber(name = "NQCETB23_E_NR_SEQU_OPER", decimal = 0, length = 3, signed = false, defaultValue = "0")
	private Long NQCETB23_E_NR_SEQU_OPER;// 05 NQCETB23-E-NR-SEQU-OPER PIC 9(003).
                                                                 
	public NQCETB23LegadoRequest() {
	}

	public String getNQCETB23_E_NM_PROG() {
		return NQCETB23_E_NM_PROG;
	}

	public void setNQCETB23_E_NM_PROG(String nQCETB23_E_NM_PROG) {
		NQCETB23_E_NM_PROG = nQCETB23_E_NM_PROG;
	}

	public String getNQCETB23_E_NM_AREA() {
		return NQCETB23_E_NM_AREA;
	}

	public void setNQCETB23_E_NM_AREA(String nQCETB23_E_NM_AREA) {
		NQCETB23_E_NM_AREA = nQCETB23_E_NM_AREA;
	}

	public String getNQCETB23_E_SG_FCAO() {
		return NQCETB23_E_SG_FCAO;
	}

	public void setNQCETB23_E_SG_FCAO(String nQCETB23_E_SG_FCAO) {
		NQCETB23_E_SG_FCAO = nQCETB23_E_SG_FCAO;
	}

	public Long getNQCETB23_E_QT_TAMA_AREA() {
		return NQCETB23_E_QT_TAMA_AREA;
	}

	public void setNQCETB23_E_QT_TAMA_AREA(Long nQCETB23_E_QT_TAMA_AREA) {
		NQCETB23_E_QT_TAMA_AREA = nQCETB23_E_QT_TAMA_AREA;
	}

	public String getNQCETB23_E_CD_USUA() {
		return NQCETB23_E_CD_USUA;
	}

	public void setNQCETB23_E_CD_USUA(String nQCETB23_E_CD_USUA) {
		NQCETB23_E_CD_USUA = nQCETB23_E_CD_USUA;
	}

	public Long getNQCETB23_E_NR_SEQU_SIST() {
		return NQCETB23_E_NR_SEQU_SIST;
	}

	public void setNQCETB23_E_NR_SEQU_SIST(Long nQCETB23_E_NR_SEQU_SIST) {
		NQCETB23_E_NR_SEQU_SIST = nQCETB23_E_NR_SEQU_SIST;
	}

	public String getNQCETB23_E_CD_BANC_CLIE() {
		return NQCETB23_E_CD_BANC_CLIE;
	}

	public void setNQCETB23_E_CD_BANC_CLIE(String nQCETB23_E_CD_BANC_CLIE) {
		NQCETB23_E_CD_BANC_CLIE = nQCETB23_E_CD_BANC_CLIE;
	}

	public String getNQCETB23_E_CD_CLIE() {
		return NQCETB23_E_CD_CLIE;
	}

	public void setNQCETB23_E_CD_CLIE(String nQCETB23_E_CD_CLIE) {
		NQCETB23_E_CD_CLIE = nQCETB23_E_CD_CLIE;
	}

	public String getNQCETB23_E_DT_INICIO() {
		return NQCETB23_E_DT_INICIO;
	}

	public void setNQCETB23_E_DT_INICIO(String nQCETB23_E_DT_INICIO) {
		NQCETB23_E_DT_INICIO = nQCETB23_E_DT_INICIO;
	}

	public String getNQCETB23_E_DT_FIM() {
		return NQCETB23_E_DT_FIM;
	}

	public void setNQCETB23_E_DT_FIM(String nQCETB23_E_DT_FIM) {
		NQCETB23_E_DT_FIM = nQCETB23_E_DT_FIM;
	}

	public String getNQCETB23_E_CD_CNTA_DEBT() {
		return NQCETB23_E_CD_CNTA_DEBT;
	}

	public void setNQCETB23_E_CD_CNTA_DEBT(String nQCETB23_E_CD_CNTA_DEBT) {
		NQCETB23_E_CD_CNTA_DEBT = nQCETB23_E_CD_CNTA_DEBT;
	}

	public String getNQCETB23_E_NR_PROP() {
		return NQCETB23_E_NR_PROP;
	}

	public void setNQCETB23_E_NR_PROP(String nQCETB23_E_NR_PROP) {
		NQCETB23_E_NR_PROP = nQCETB23_E_NR_PROP;
	}

	public String getNQCETB23_E_NR_APOL() {
		return NQCETB23_E_NR_APOL;
	}

	public void setNQCETB23_E_NR_APOL(String nQCETB23_E_NR_APOL) {
		NQCETB23_E_NR_APOL = nQCETB23_E_NR_APOL;
	}

	public Long getNQCETB23_E_NR_SEQU_OPER() {
		return NQCETB23_E_NR_SEQU_OPER;
	}

	public void setNQCETB23_E_NR_SEQU_OPER(Long nQCETB23_E_NR_SEQU_OPER) {
		NQCETB23_E_NR_SEQU_OPER = nQCETB23_E_NR_SEQU_OPER;
	}
}