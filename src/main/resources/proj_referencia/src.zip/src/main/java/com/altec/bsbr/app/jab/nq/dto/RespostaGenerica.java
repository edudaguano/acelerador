package com.altec.bsbr.app.jab.nq.dto;

public class RespostaGenerica {
	
	private Object codigoRetorno;
	private Object erros;
	private Object formatos;
	private Object mensagem;
	
	public RespostaGenerica() {}

	public Object getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(Object codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public Object getErros() {
		return erros;
	}

	public void setErros(Object erros) {
		this.erros = erros;
	}

	public Object getFormatos() {
		return formatos;
	}

	public void setFormatos(Object formatos) {
		this.formatos = formatos;
	}

	public Object getMensagem() {
		return mensagem;
	}

	public void setMensagem(Object mensagem) {
		this.mensagem = mensagem;
	}	
	
}
