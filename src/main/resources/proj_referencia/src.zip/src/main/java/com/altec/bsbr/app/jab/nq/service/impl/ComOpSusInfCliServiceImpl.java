package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.ComOpSusInfCliDao;
import com.altec.bsbr.app.jab.nq.service.ComOpSusInfCliService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class ComOpSusInfCliServiceImpl implements ComOpSusInfCliService {
	private final Logger LOGGER = LoggerFactory.getLogger(ComOpSusInfCliServiceImpl.class);

	@Autowired
	private ComOpSusInfCliDao comOpSusInfCli;
	
	public String versao() throws BusinessException {
		return comOpSusInfCli.versao();
	}

	public String consultarAgencia(String strNUENTID, String strNUAGENC, String strNUCONTA, String strCOCLIEN)
			throws BusinessException {
		return comOpSusInfCli.consultarAgencia(strNUENTID, strNUAGENC, strNUCONTA, strCOCLIEN);
	}

	public String consultarSocio(String strPENUMPE) throws BusinessException {
		return comOpSusInfCli.consultarSocio(strPENUMPE);
	}

	public String consultarClientePJ(String strCODENT, String strTPDOCTO, String strNUDOCTO, String strCDALERT)
			throws BusinessException {
		return comOpSusInfCli.consultarClientePJ(strCODENT, strTPDOCTO, strNUDOCTO, strCDALERT);
	}

	public String consultarClientePF(String strTPDOCTO, String strNUDOCTO, String strCDENTID, String strCDALERT)
			throws BusinessException {
		return comOpSusInfCli.consultarClientePF(strTPDOCTO, strNUDOCTO, strCDENTID, strCDALERT);
	}

	public String consultarClientePE(String strCOENTID, String strTPDOCTO, String strNUDOCTO) throws BusinessException {
		return comOpSusInfCli.consultarClientePE(strCOENTID, strTPDOCTO, strNUDOCTO);
	}

	public String log(String strTexto) throws BusinessException {
		return comOpSusInfCli.log(strTexto);
	}
}