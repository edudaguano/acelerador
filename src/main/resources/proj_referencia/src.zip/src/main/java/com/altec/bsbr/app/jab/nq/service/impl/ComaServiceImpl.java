package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.ComaDao;
import com.altec.bsbr.app.jab.nq.service.ComaService;
import com.altec.bsbr.fw.BusinessException;

@Service 
public class ComaServiceImpl implements ComaService {

	private final Logger LOGGER = LoggerFactory.getLogger(ComaServiceImpl.class);

	@Autowired
	private ComaDao coma;

	public String fgNQAT7023(String programa,String segundoProg,String tamanho,String posicao,String banco,String codProd,String codigoErro,String  mensagemErro) throws BusinessException{ 
		return coma.fgNQAT7023(programa, segundoProg, tamanho, posicao, banco, codProd, codigoErro, mensagemErro);
	}
	public String fgNQAT6203(String programa,String segundoProg,String tamanho,String nuMatric,String nuBanco,String nuAgencia,String conta,String cliente,String pvs,String texto6,String tpUorg,String codigoErro,String  mensagemErro) throws BusinessException{ 
		return coma.fgNQAT6203(programa, segundoProg, tamanho, nuMatric, nuBanco, nuAgencia, conta, cliente, pvs, texto6, tpUorg, codigoErro,  mensagemErro);
	}
	public String fgNQAT6200(String programa,String segundoProg,String tamanho,String nuMatric,String nuBanco,String nuAgencia,String cliente,String conta,String codigoErro,String  mensagemErro) throws BusinessException{ 
		return coma.fgNQAT6200(programa, segundoProg, tamanho, nuMatric, nuBanco, nuAgencia, cliente, conta, codigoErro,  mensagemErro);
	}
	public String fgNQAT6202(String programa,String segundoProg,String tamanho,String nuMatric,String nuBanco,String nuAgencia,String cliente,String codigoErro,String  mensagemErro) throws BusinessException{ 
		return coma.fgNQAT6202(programa, segundoProg, tamanho, nuMatric, nuBanco, nuAgencia, cliente, codigoErro,  mensagemErro);
	}
}

