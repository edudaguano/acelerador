package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface PareceresACService {
	public String consultarRegistros(String strCodSist, String strBanco, String strCodCliente, String strDtOcorrenca,
			String strNotUPLD, String strRegra, String strIndParecer, String strPeriodo, String strCodUser) throws BusinessException;

	public String incluirPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorrenca,
			String strNotUPLD, String strRegra, String strIndParecer, String strPeriodo, String strTxtParecer,
			String strCodUser) throws BusinessException;

	public String alterarPareceres(String strCodSist,String strBanco,String strCodCliente,String strDtOcorrenca,String strNotUPLD,String strRegra,String strIndParecer,String strPeriodo,String strTxtParecer,String strCodUser) throws BusinessException;

	public String inicializarinputArea(String tNQ_NQAT2010_NQCETB10_Entrada) throws BusinessException;

	public String fnAddCaracter(String vlr, String tp, String tam) throws BusinessException;

	public String dataAlta(String dtBaixa) throws BusinessException; 
}
