package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.EnqSuspeitaService;
import com.altec.bsbr.app.jab.nq.service.EnqSuspeitaWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class EnqSuspeitaEndPoint extends SpringBeanAutowiringSupport implements EnqSuspeitaWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(EnqSuspeitaEndPoint.class);
	@Autowired
	private EnqSuspeitaService enqsuspeita;

	@WebMethod
	public String versao() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = enqsuspeita.versao();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String inserirEnquadramento(String strCDENTID, String strCDALERT, String strCDOREN1, String strCDENQ01,
			String strCDUSRES) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = enqsuspeita.inserirEnquadramento(strCDENTID, strCDALERT, strCDOREN1, strCDENQ01, strCDUSRES);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String listarOrgaoEnquadramento(String strCORGPAG) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = enqsuspeita.listarOrgaoEnquadramento(strCORGPAG);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarEnquadramento(String strCORGENQ, String strCOENPAG) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = enqsuspeita.consultarEnquadramento(strCORGENQ, strCOENPAG);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
}
