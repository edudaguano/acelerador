package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.RegrasACDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB07LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.AreaMensagem;
import com.altec.bsbr.app.jab.nq.legado.dto.response.FullAreaResponse;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB07AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB07LegadoResponse;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB20AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB30AreaDados;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB07MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class RegrasACDaoImpl implements RegrasACDao {
	private final Logger LOGGER = LoggerFactory.getLogger(RegrasACDaoImpl.class);

	@Autowired
	private JSONMapper jsonMapper;
	
	@Autowired
	private NQCETB07MessagingGateway NQCETB07Service;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String consultarRegras(String strCodSist, String strPeriodo, String strSituacao, String strCodUser) throws BusinessException {
		String json = "";
		try {
			NQCETB07LegadoRequest req = new NQCETB07LegadoRequest();
			req.setNQCETB07_E_SG_FCAO("L");
			req.setNQCETB07_E_CD_USUA_ULTI_ALTR(strCodUser);
			req.setNQCETB07_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB07_E_CD_SITU(strSituacao);
			req.setNQCETB07_E_TP_PERI(strPeriodo);	
			
			LegadoResult res = NQCETB07Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB07AreaDados> ret = decoder.parseRetorno(res, NQCETB07AreaDados.class, 83, 86);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String incluirRegras(String strCodSist, String strAtivo, String strCodUser, String strPeriodo,
			String strRegra, String strProduto, String strSubProduto, String StrPEP, String strFunc,
			String strTpTransacao, String strQtdTransacao, String strPercRenda, String strVlTransacao) throws BusinessException {
		String json = "";
 		
		Double vlrTr = Double.valueOf(strVlTransacao.replace(".", "").replace(",", "."));
		try {
			NQCETB07LegadoRequest req = new NQCETB07LegadoRequest();
			req.setNQCETB07_E_SG_FCAO("I");
			req.setNQCETB07_E_CD_USUA_ULTI_ALTR(strCodUser);
			req.setNQCETB07_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB07_E_CD_SITU(strAtivo);
			req.setNQCETB07_E_TP_PERI(strPeriodo);
			req.setNQCETB07_E_NR_SEQU_REGR(strRegra.isEmpty()? null : Long.valueOf(strRegra));
			req.setNQCETB07_E_CD_PROD_ALTAIR(strProduto);
			req.setNQCETB07_E_CD_SUBP_ALTAIR(strSubProduto);
			req.setNQCETB07_E_IN_PEP(StrPEP);
			req.setNQCETB07_E_IN_FUNC(strFunc);
			req.setNQCETB07_E_TP_TRAN(strTpTransacao);
			req.setNQCETB07_E_QT_TRAN(strQtdTransacao.isEmpty()? null : Long.valueOf(strQtdTransacao));
			req.setNQCETB07_E_VL_PERC_FATU_REND(strPercRenda.isEmpty()? null : Double.valueOf(strPercRenda));
			req.setNQCETB07_E_VL_TRAN(vlrTr / 100);
			
			LegadoResult res = NQCETB07Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB07AreaDados> ret = decoder.parseRetorno(res, NQCETB07AreaDados.class, 83, 86);
			json =  new ObjectMapper().writeValueAsString(ret);		
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String alterarRegras(String strCodSist, String strAtivo, String strCodUser, String strPeriodo,
			String strRegra, String strProduto, String strSubProduto, String StrPEP, String strFunc,
			String strTpTransacao, String strQtdTransacao, String strPercRenda, String strVlTransacao) throws BusinessException {
		String json = "";
		Double vlrTr = Double.valueOf(strVlTransacao.replace(".", "").replace(",", "."));
		try {
			NQCETB07LegadoRequest req = new NQCETB07LegadoRequest();
			req.setNQCETB07_E_SG_FCAO("A");
			req.setNQCETB07_E_CD_USUA_ULTI_ALTR(strCodUser);
			req.setNQCETB07_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB07_E_CD_SITU(strAtivo);
			req.setNQCETB07_E_TP_PERI(strPeriodo);
			req.setNQCETB07_E_NR_SEQU_REGR(strRegra.isEmpty()? null : Long.valueOf(strRegra));
			req.setNQCETB07_E_CD_PROD_ALTAIR(strProduto);
			req.setNQCETB07_E_CD_SUBP_ALTAIR(strSubProduto);
			req.setNQCETB07_E_IN_PEP(StrPEP);
			req.setNQCETB07_E_IN_FUNC(strFunc);
			req.setNQCETB07_E_TP_TRAN(strTpTransacao);
			req.setNQCETB07_E_QT_TRAN(strQtdTransacao.isEmpty()? null : Long.valueOf(strQtdTransacao));
			req.setNQCETB07_E_VL_PERC_FATU_REND(strPercRenda.isEmpty()? null : Double.valueOf(strPercRenda));
			req.setNQCETB07_E_VL_TRAN(vlrTr / 100);
			
			LegadoResult res = NQCETB07Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB07AreaDados> ret = decoder.parseRetorno(res, NQCETB07AreaDados.class, 83, 86);
			json =  new ObjectMapper().writeValueAsString(ret);		
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String inicializarinputArea(String tNQ_NQAT2007_NQCETB07_Entrada) {
		String json = "";
		return json;
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) {
		String json = "";
		return json;
	}
	
}
