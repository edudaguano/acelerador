package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@PsFormat(name = "NQCETB05LegadoRequest")
public class NQCETB05LegadoRequest {

/************************************************
*  Métodos deste programa 
* FUNCAO A SER EXECUTADA                                    
* C = CONSULTAR                                             
* L = LISTAR                                                
* I = INCLUIR                                               
* A = ALTERAR                                               
* E = EXCLUIR                                               
*************************************************/                                                                         

/*-------------------------------------------- CONSTRUTOR -------------------------------------------------*/

	public NQCETB05LegadoRequest() {
		super();
	}

/*-------------------------------------------- Request Area-------------------------------------------------*/	

	@PsFieldString(name = "NQCETB5E_NM_PROG", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5E_NM_PROG;// 05 NQCETB5E-NM-PROG PIC X(008).

	@PsFieldString(name = "NQCETB5E_NM_AREA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5E_NM_AREA;// 05 NQCETB5E-NM-AREA PIC X(008).

	@PsFieldString(name = "NQCETB5E_SG_FCAO", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5E_SG_FCAO;// 05 NQCETB5E-SG-FCAO PIC X(002).

	@PsFieldNumber(name = "NQCETB5E_QT_TAMA_AREA", decimal = 0, length = 7, signed = false, defaultValue = "0")
	private Long NQCETB5E_QT_TAMA_AREA;// 05 NQCETB5E-QT-TAMA-AREA PIC 9(007)V99.

	@PsFieldString(name = "NQCETB5E_CD_USUA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5E_CD_USUA;// 05 NQCETB5E-CD-USUA PIC X(008).

	@PsFieldNumber(name = "NQCETB5E_NR_SEQU_DOMI_OPER", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB5E_NR_SEQU_DOMI_OPER;// 05 NQCETB5E-NR-SEQU-DOMI-OPER PIC 9(004).

	@PsFieldString(name = "NQCETB5E_VL_PARM_DOMI_OPER", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5E_VL_PARM_DOMI_OPER;// 05 NQCETB5E-VL-PARM-DOMI-OPER PIC X(020).

	@PsFieldString(name = "NQCETB5E_DS_PARM_DOMI_OPER", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5E_DS_PARM_DOMI_OPER;// 05 NQCETB5E-DS-PARM-DOMI-OPER PIC X(040).

	@PsFieldString(name = "NQCETB5E_TP_USO_DOMI_OPER", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5E_TP_USO_DOMI_OPER;// 05 NQCETB5E-TP-USO-DOMI-OPER PIC X(002).

	@PsFieldString(name = "NQCETB5E_IN_DOMI_OPER_ATIV", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB5E_IN_DOMI_OPER_ATIV;// 05 NQCETB5E-IN-DOMI-OPER-ATIV PIC X(001).

	
/*-------------------------------------------- GETTER/SETTER-------------------------------------------------*/	
	public String getNQCETB5E_NM_PROG() {
		return NQCETB5E_NM_PROG;
	}

	public void setNQCETB5E_NM_PROG(String nQCETB5E_NM_PROG) {
		NQCETB5E_NM_PROG = nQCETB5E_NM_PROG;
	}

	public String getNQCETB5E_NM_AREA() {
		return NQCETB5E_NM_AREA;
	}

	public void setNQCETB5E_NM_AREA(String nQCETB5E_NM_AREA) {
		NQCETB5E_NM_AREA = nQCETB5E_NM_AREA;
	}

	public String getNQCETB5E_SG_FCAO() {
		return NQCETB5E_SG_FCAO;
	}

	public void setNQCETB5E_SG_FCAO(String nQCETB5E_SG_FCAO) {
		NQCETB5E_SG_FCAO = nQCETB5E_SG_FCAO;
	}

	public Long getNQCETB5E_QT_TAMA_AREA() {
		return NQCETB5E_QT_TAMA_AREA;
	}

	public void setNQCETB5E_QT_TAMA_AREA(Long nQCETB5E_QT_TAMA_AREA) {
		NQCETB5E_QT_TAMA_AREA = nQCETB5E_QT_TAMA_AREA;
	}

	public String getNQCETB5E_CD_USUA() {
		return NQCETB5E_CD_USUA;
	}

	public void setNQCETB5E_CD_USUA(String nQCETB5E_CD_USUA) {
		NQCETB5E_CD_USUA = nQCETB5E_CD_USUA;
	}

	public Long getNQCETB5E_NR_SEQU_DOMI_OPER() {
		return NQCETB5E_NR_SEQU_DOMI_OPER;
	}

	public void setNQCETB5E_NR_SEQU_DOMI_OPER(Long nQCETB5E_NR_SEQU_DOMI_OPER) {
		NQCETB5E_NR_SEQU_DOMI_OPER = nQCETB5E_NR_SEQU_DOMI_OPER;
	}

	public String getNQCETB5E_VL_PARM_DOMI_OPER() {
		return NQCETB5E_VL_PARM_DOMI_OPER;
	}

	public void setNQCETB5E_VL_PARM_DOMI_OPER(String nQCETB5E_VL_PARM_DOMI_OPER) {
		NQCETB5E_VL_PARM_DOMI_OPER = nQCETB5E_VL_PARM_DOMI_OPER;
	}

	public String getNQCETB5E_DS_PARM_DOMI_OPER() {
		return NQCETB5E_DS_PARM_DOMI_OPER;
	}

	public void setNQCETB5E_DS_PARM_DOMI_OPER(String nQCETB5E_DS_PARM_DOMI_OPER) {
		NQCETB5E_DS_PARM_DOMI_OPER = nQCETB5E_DS_PARM_DOMI_OPER;
	}

	public String getNQCETB5E_TP_USO_DOMI_OPER() {
		return NQCETB5E_TP_USO_DOMI_OPER;
	}

	public void setNQCETB5E_TP_USO_DOMI_OPER(String nQCETB5E_TP_USO_DOMI_OPER) {
		NQCETB5E_TP_USO_DOMI_OPER = nQCETB5E_TP_USO_DOMI_OPER;
	}

	public String getNQCETB5E_IN_DOMI_OPER_ATIV() {
		return NQCETB5E_IN_DOMI_OPER_ATIV;
	}

	public void setNQCETB5E_IN_DOMI_OPER_ATIV(String nQCETB5E_IN_DOMI_OPER_ATIV) {
		NQCETB5E_IN_DOMI_OPER_ATIV = nQCETB5E_IN_DOMI_OPER_ATIV;
	}

}