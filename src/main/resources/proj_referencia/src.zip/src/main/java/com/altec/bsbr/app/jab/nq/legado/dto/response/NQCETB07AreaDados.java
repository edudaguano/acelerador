package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name = "NQCETB07AreaDados")
public class NQCETB07AreaDados {

//       *       CODIGO DA SITUACAO                                        
//                                                                         
//       *----------------------------------------------------------------*
//       *       AREA DE SAIDA                                             
//       *----------------------------------------------------------------*
//                                                                         
//        01     NQCETB07-SAIDA.                                           
//                                                                         
//       *       AREA DE DADOS                                             
//                                                                         

//         03    NQCETB07-S-DATA.                                          
//                                                                         
	@PsFieldNumber(name = "NQCETB07_S_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB07_S_NR_SEQU_SIST;// 05 NQCETB07-S-NR-SEQU-SIST PIC 9(004).

//       *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                         
	@PsFieldString(name = "NQCETB07_S_SG_SIST", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB07_S_SG_SIST;// 05 NQCETB07-S-SG-SIST PIC X(002).

//       *       SIGLA DO SISTEMA                                          
//                                                                         
	@PsFieldNumber(name = "NQCETB07_S_NR_SEQU_REGR", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB07_S_NR_SEQU_REGR;// 05 NQCETB07-S-NR-SEQU-REGR PIC 9(004).

//       *       NUMERO DE SEQUENCIA DA REGRA                              
//                                                                         
	@PsFieldString(name = "NQCETB07_S_TP_PERI", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB07_S_TP_PERI;// 05 NQCETB07-S-TP-PERI PIC X(001).

//       *       TIPO DE PERIODO                                           
//                                                                         
	@PsFieldString(name = "NQCETB07_S_CD_PROD_ALTAIR", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB07_S_CD_PROD_ALTAIR;// 05 NQCETB07-S-CD-PROD-ALTAIR PIC X(002).

//       *       CODIGO DO PRODUTO                                         
//                                                                         
	@PsFieldString(name = "NQCETB07_S_CD_SUBP_ALTAIR", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB07_S_CD_SUBP_ALTAIR;// 05 NQCETB07-S-CD-SUBP-ALTAIR PIC X(004).

//       *       CODIGO DO SUBPRODUTO                                      
//                                                                         
	@PsFieldString(name = "NQCETB07_S_IN_PEP", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB07_S_IN_PEP;// 05 NQCETB07-S-IN-PEP PIC X(001).

//       *       INDICADOR DE CLIENTE PEP                                  
//                                                                         
	@PsFieldString(name = "NQCETB07_S_IN_FUNC", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB07_S_IN_FUNC;// 05 NQCETB07-S-IN-FUNC PIC X(001).

//       *       INDICADOR DE CLIENTE FUNCIONARIO                          
//                                                                         
	@PsFieldString(name = "NQCETB07_S_TP_TRAN", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB07_S_TP_TRAN;// 05 NQCETB07-S-TP-TRAN PIC X(001).

//       *       TIPO DE TRANSACAO                                         
//                                                                         
	@PsFieldNumber(name = "NQCETB07_S_QT_TRAN", decimal = 0, length = 9, signed = false, defaultValue = "0")
	private Long NQCETB07_S_QT_TRAN;// 05 NQCETB07-S-QT-TRAN PIC 9(009).

//       *       QUANTIDADE DE TRANSACOES                                  
//                                                                         
	@PsFieldNumber(name = "NQCETB07_S_VL_PERC_FATU_REND", decimal = 3, length = 5, signed = false, defaultValue = "0")
	private Double NQCETB07_S_VL_PERC_FATU_REND;// 05 NQCETB07-S-VL-PERC-FATU-REND PIC 9(003)V99.

//       *       VALOR DA PORCENTAGEM SOBRE FATURAMENTO / RENDA            
//                                                                         
	@PsFieldNumber(name = "NQCETB07_S_VL_TRAN", decimal = 3, length = 17, signed = false, defaultValue = "0")
	private Double NQCETB07_S_VL_TRAN;// 05 NQCETB07-S-VL-TRAN PIC 9(015)V99.

//       *       VALOR DAS TRANSACOES                                      
//                                                                         
	@PsFieldString(name = "NQCETB07_S_CD_SITU", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB07_S_CD_SITU;// 05 NQCETB07-S-CD-SITU PIC X(001).

//       *       CODIGO DA SITUACAO                                        
//                                                                         
	@PsFieldString(name = "NQCETB07_S_CD_USUA_ULTI_ALTR", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB07_S_CD_USUA_ULTI_ALTR;// 05 NQCETB07-S-CD-USUA-ULTI-ALTR PIC X(008).

//       *       CODIGO DO USUARIO DA ULTIMA ALTERACAO                     
//                                                                         
	@PsFieldString(name = "NQCETB07_S_DH_ULTI_ALTR", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB07_S_DH_ULTI_ALTR;// 05 NQCETB07-S-DH-ULTI-ALTR PIC X(026).

//       *       DATA/HORA ULTIMA ALTERACAO                                
	public NQCETB07AreaDados() {
	}


	public Long getNQCETB07_S_NR_SEQU_SIST() {
		return NQCETB07_S_NR_SEQU_SIST;
	}

	public void setNQCETB07_S_NR_SEQU_SIST(Long nQCETB07_S_NR_SEQU_SIST) {
		NQCETB07_S_NR_SEQU_SIST = nQCETB07_S_NR_SEQU_SIST;
	}

	public String getNQCETB07_S_SG_SIST() {
		return NQCETB07_S_SG_SIST;
	}

	public void setNQCETB07_S_SG_SIST(String nQCETB07_S_SG_SIST) {
		NQCETB07_S_SG_SIST = nQCETB07_S_SG_SIST;
	}

	public Long getNQCETB07_S_NR_SEQU_REGR() {
		return NQCETB07_S_NR_SEQU_REGR;
	}

	public void setNQCETB07_S_NR_SEQU_REGR(Long nQCETB07_S_NR_SEQU_REGR) {
		NQCETB07_S_NR_SEQU_REGR = nQCETB07_S_NR_SEQU_REGR;
	}

	public String getNQCETB07_S_TP_PERI() {
		return NQCETB07_S_TP_PERI;
	}

	public void setNQCETB07_S_TP_PERI(String nQCETB07_S_TP_PERI) {
		NQCETB07_S_TP_PERI = nQCETB07_S_TP_PERI;
	}

	public String getNQCETB07_S_CD_PROD_ALTAIR() {
		return NQCETB07_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB07_S_CD_PROD_ALTAIR(String nQCETB07_S_CD_PROD_ALTAIR) {
		NQCETB07_S_CD_PROD_ALTAIR = nQCETB07_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB07_S_CD_SUBP_ALTAIR() {
		return NQCETB07_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB07_S_CD_SUBP_ALTAIR(String nQCETB07_S_CD_SUBP_ALTAIR) {
		NQCETB07_S_CD_SUBP_ALTAIR = nQCETB07_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB07_S_IN_PEP() {
		return NQCETB07_S_IN_PEP;
	}

	public void setNQCETB07_S_IN_PEP(String nQCETB07_S_IN_PEP) {
		NQCETB07_S_IN_PEP = nQCETB07_S_IN_PEP;
	}

	public String getNQCETB07_S_IN_FUNC() {
		return NQCETB07_S_IN_FUNC;
	}

	public void setNQCETB07_S_IN_FUNC(String nQCETB07_S_IN_FUNC) {
		NQCETB07_S_IN_FUNC = nQCETB07_S_IN_FUNC;
	}

	public String getNQCETB07_S_TP_TRAN() {
		return NQCETB07_S_TP_TRAN;
	}

	public void setNQCETB07_S_TP_TRAN(String nQCETB07_S_TP_TRAN) {
		NQCETB07_S_TP_TRAN = nQCETB07_S_TP_TRAN;
	}

	public Long getNQCETB07_S_QT_TRAN() {
		return NQCETB07_S_QT_TRAN;
	}

	public void setNQCETB07_S_QT_TRAN(Long nQCETB07_S_QT_TRAN) {
		NQCETB07_S_QT_TRAN = nQCETB07_S_QT_TRAN;
	}

	public Double getNQCETB07_S_VL_PERC_FATU_REND() {
		return NQCETB07_S_VL_PERC_FATU_REND;
	}

	public void setNQCETB07_S_VL_PERC_FATU_REND(Double nQCETB07_S_VL_PERC_FATU_REND) {
		NQCETB07_S_VL_PERC_FATU_REND = nQCETB07_S_VL_PERC_FATU_REND;
	}

	public Double getNQCETB07_S_VL_TRAN() {
		return NQCETB07_S_VL_TRAN;
	}

	public void setNQCETB07_S_VL_TRAN(Double nQCETB07_S_VL_TRAN) {
		NQCETB07_S_VL_TRAN = nQCETB07_S_VL_TRAN;
	}

	public String getNQCETB07_S_CD_SITU() {
		return NQCETB07_S_CD_SITU;
	}

	public void setNQCETB07_S_CD_SITU(String nQCETB07_S_CD_SITU) {
		NQCETB07_S_CD_SITU = nQCETB07_S_CD_SITU;
	}

	public String getNQCETB07_S_CD_USUA_ULTI_ALTR() {
		return NQCETB07_S_CD_USUA_ULTI_ALTR;
	}

	public void setNQCETB07_S_CD_USUA_ULTI_ALTR(String nQCETB07_S_CD_USUA_ULTI_ALTR) {
		NQCETB07_S_CD_USUA_ULTI_ALTR = nQCETB07_S_CD_USUA_ULTI_ALTR;
	}

	public String getNQCETB07_S_DH_ULTI_ALTR() {
		return NQCETB07_S_DH_ULTI_ALTR;
	}

	public void setNQCETB07_S_DH_ULTI_ALTR(String nQCETB07_S_DH_ULTI_ALTR) {
		NQCETB07_S_DH_ULTI_ALTR = nQCETB07_S_DH_ULTI_ALTR;
	}


}