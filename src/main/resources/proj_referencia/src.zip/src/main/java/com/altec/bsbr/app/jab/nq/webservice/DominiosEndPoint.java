package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.DominiosService;
import com.altec.bsbr.app.jab.nq.service.DominiosWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class DominiosEndPoint extends SpringBeanAutowiringSupport implements DominiosWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(DominiosEndPoint.class);
	@Autowired
	private DominiosService dominios;

	@WebMethod
	public String listarDominio(String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = dominios.listarDominio(strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarDominio(String strCodDom, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = dominios.consultarDominio(strCodDom, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirDominio(String strVlrDom, String strDesDom, String strTpUsuDom, String strIndDomAtv,
			String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = dominios.incluirDominio(strVlrDom, strDesDom, strTpUsuDom, strIndDomAtv, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarDominio(String strCodDom, String strVlrDom, String strDesDom, String strTpUsuDom,
			String strIndDomAtv, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = dominios.alterarDominio(strCodDom, strVlrDom, strDesDom, strTpUsuDom, strIndDomAtv, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String excluirDominio(String strCodDom, String strCodUser) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = dominios.excluirDominio(strCodDom, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String inicializarinputArea(String tNQ_NQAT2005_NQCETB05_ENTRADA) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = dominios.inicializarinputArea(tNQ_NQAT2005_NQCETB05_ENTRADA);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = dominios.fnAddCaracter(Vlr, Tp, Tam);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

}
