package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.altec.bsbr.app.jab.nq.dao.ComaDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCE7023LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.AreaMensagem;
import com.altec.bsbr.app.jab.nq.legado.dto.response.FullAreaResponse;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCE7023AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB02AreaDados;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCE7023MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository 
public class ComaDaoImpl  implements ComaDao { 

	private final Logger LOGGER = LoggerFactory.getLogger(ComaDaoImpl.class); 

	@Autowired
	private NQCE7023MessagingGateway NQCE7023service;
	
	public String fgNQAT7023(String programa,String segundoProg,String tamanho,String posicao,String banco,String codProd,String codigoErro,String mensagemErro) {
		escreveLog("NQAT7023 - NQCE7023 - NQZM");
		String json = "";
		try {
			NQCE7023LegadoRequest req = new NQCE7023LegadoRequest();

			/* MOCK
			 * req.setNQCE7023_PROG_CALLED("NQAT7023");
			req.setNQCE7023_NOMEDATS("NQAT7023");
			req.setNQCE7023_COMMAREA_LEN(39l);
			req.setNQCE7023_FUNCAO("1");
			req.setNQCE7023_CINSTIT(Long.valueOf("379"));*/

			req.setNQCE7023_PROG_CALLED(programa);
			req.setNQCE7023_NOMEDATS(segundoProg);
			req.setNQCE7023_COMMAREA_LEN(Long.valueOf(tamanho));
			req.setNQCE7023_FUNCAO(posicao);
			req.setNQCE7023_CINSTIT(Long.valueOf(banco));
			
			LegadoResult res = NQCE7023service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCE7023AreaDados> ret = decoder.parseRetorno(res, NQCE7023AreaDados.class, 83, 290);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			escreveLog(e.getMessage());
		}
		
		return json; 
	}

	public String fgNQAT6203(String programa,String segundoProg,String tamanho,String nuMatric,String nuBanco,String nuAgencia,String conta,String cliente,String pvs,String texto6,String tpUorg,String codigoErro,String mensagemErro) {
		return mensagemErro; 
	}

	public String fgNQAT6200(String programa,String segundoProg,String tamanho,String nuMatric,String nuBanco,String nuAgencia,String cliente,String conta,String codigoErro,String mensagemErro) {
		return mensagemErro; 
	}

	public String fgNQAT6202(String programa,String segundoProg,String tamanho,String nuMatric,String nuBanco,String nuAgencia,String cliente,String codigoErro,String mensagemErro) {
		return mensagemErro; 
	}
	
	public void escreveLog(String sTexto){
		LOGGER.info(sTexto);
	}

	public NQCE7023MessagingGateway getNQCE7023service() {
		return NQCE7023service;
	}

/*---------------------------------------- GETTER/SETTER -----------------------------------*/
	
	public void setNQCE7023service(NQCE7023MessagingGateway nQCE7023service) {
		NQCE7023service = nQCE7023service;
	}

	public Logger getLOGGER() {
		return LOGGER;
	}
	
}

