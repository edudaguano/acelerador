package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name = "NQCETB29LegadoRequest")
public class NQCETB29LegadoRequest {
// -*-                                                                        
//        01     NQCETB29-ENTRADA.                                         
//                                                                         
	@PsFieldString(name = "NQCETB29_E_NM_PROG", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_E_NM_PROG;// 05 NQCETB29-E-NM-PROG PIC X(008).

//       *       NOME DO PROGRAMA CHAMADO                                  
//                                                                         
	@PsFieldString(name = "NQCETB29_E_NM_AREA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_E_NM_AREA;// 05 NQCETB29-E-NM-AREA PIC X(008).

//       *       NOME DA AREA DE TS                                        
//                                                                         
	@PsFieldString(name = "NQCETB29_E_SG_FCAO", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_E_SG_FCAO;// 05 NQCETB29-E-SG-FCAO PIC X(002).

//       *       FUNCAO A SER EXECUTADA                                    
//       *       L = LISTAR                                                
//                                                                         
	@PsFieldNumber(name = "NQCETB29_E_QT_TAMA_AREA", decimal = 0, length = 7, signed = false, defaultValue = "0")
	private Long NQCETB29_E_QT_TAMA_AREA;// 05 NQCETB29-E-QT-TAMA-AREA PIC 9(007).

//       *       TAMANHO DA AREA DE TS                                     
//                                                                         
	@PsFieldString(name = "NQCETB29_E_CD_USUA_ULTI_ALTR", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_E_CD_USUA_ULTI_ALTR;// 05 NQCETB29-E-CD-USUA-ULTI-ALTR PIC X(008).

//       *       CODIGO DO USUARIO                                         
//                                                                         
	@PsFieldNumber(name = "NQCETB29_E_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB29_E_NR_SEQU_SIST;// 05 NQCETB29-E-NR-SEQU-SIST PIC 9(004).

//       *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                         
	@PsFieldString(name = "NQCETB29_E_DT_OCOR", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB29_E_DT_OCOR;// 05 NQCETB29-E-DT-OCOR PIC X(010).

	public String getNQCETB29_E_NM_PROG() {
		return NQCETB29_E_NM_PROG;
	}

	public void setNQCETB29_E_NM_PROG(String nQCETB29_E_NM_PROG) {
		NQCETB29_E_NM_PROG = nQCETB29_E_NM_PROG;
	}

	public String getNQCETB29_E_NM_AREA() {
		return NQCETB29_E_NM_AREA;
	}

	public void setNQCETB29_E_NM_AREA(String nQCETB29_E_NM_AREA) {
		NQCETB29_E_NM_AREA = nQCETB29_E_NM_AREA;
	}

	public String getNQCETB29_E_SG_FCAO() {
		return NQCETB29_E_SG_FCAO;
	}

	public void setNQCETB29_E_SG_FCAO(String nQCETB29_E_SG_FCAO) {
		NQCETB29_E_SG_FCAO = nQCETB29_E_SG_FCAO;
	}

	public Long getNQCETB29_E_QT_TAMA_AREA() {
		return NQCETB29_E_QT_TAMA_AREA;
	}

	public void setNQCETB29_E_QT_TAMA_AREA(Long nQCETB29_E_QT_TAMA_AREA) {
		NQCETB29_E_QT_TAMA_AREA = nQCETB29_E_QT_TAMA_AREA;
	}

	public String getNQCETB29_E_CD_USUA_ULTI_ALTR() {
		return NQCETB29_E_CD_USUA_ULTI_ALTR;
	}

	public void setNQCETB29_E_CD_USUA_ULTI_ALTR(String nQCETB29_E_CD_USUA_ULTI_ALTR) {
		NQCETB29_E_CD_USUA_ULTI_ALTR = nQCETB29_E_CD_USUA_ULTI_ALTR;
	}

	public Long getNQCETB29_E_NR_SEQU_SIST() {
		return NQCETB29_E_NR_SEQU_SIST;
	}

	public void setNQCETB29_E_NR_SEQU_SIST(Long nQCETB29_E_NR_SEQU_SIST) {
		NQCETB29_E_NR_SEQU_SIST = nQCETB29_E_NR_SEQU_SIST;
	}

	public String getNQCETB29_E_DT_OCOR() {
		return NQCETB29_E_DT_OCOR;
	}

	public void setNQCETB29_E_DT_OCOR(String nQCETB29_E_DT_OCOR) {
		NQCETB29_E_DT_OCOR = nQCETB29_E_DT_OCOR;
	}

//       *       DATA DA OCORRENCIA                                        

	
}