package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.AlertaCliCCPoupDao;
import com.altec.bsbr.app.jab.nq.service.AlertaCliCCPoupService;
import com.altec.bsbr.fw.BusinessException;


@Service
public class AlertaCliCCPoupServiceImpl implements AlertaCliCCPoupService {
	private final Logger LOGGER = LoggerFactory.getLogger(AlertaCliCCPoupServiceImpl.class);

	@Autowired
	private AlertaCliCCPoupDao alertacliccpoup;

	public String versao() throws BusinessException {
		return alertacliccpoup.versao();
	}

	public String consultarCenario(String strCODENTI, String strCODALER, String strCODCENA) throws BusinessException {
		return alertacliccpoup.consultarCenario(strCODENTI, strCODALER, strCODCENA);
	}

	public String consultarDadoProduto(String strCDENTI, String strCDALER, String strCDCENA, String strCDDTINT,
			String strCDPROD, String strNUCNTR) throws BusinessException {
		return alertacliccpoup.consultarDadoProduto(strCDENTI, strCDALER, strCDCENA, strCDDTINT, strCDPROD, strNUCNTR);
	}

	public String consultarClientePJ(String strCOENTID, String strCOALER) throws BusinessException {
		return alertacliccpoup.consultarClientePJ(strCOENTID, strCOALER);
	}

	public String consultarClientePF(String strCOENTID, String strCOALER) throws BusinessException {
		return alertacliccpoup.consultarClientePF(strCOENTID, strCOALER);
	}

	public String consultarOperacao(String strCDENTID, String strCDALERT, String strCDCENAR, String strCDDETIN,
			String strCDDOCOP, String strNUCNTR) throws BusinessException {
		return alertacliccpoup.consultarOperacao(strCDENTID, strCDALERT, strCDCENAR, strCDDETIN, strCDDOCOP, strNUCNTR);
	}
}
