package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0250")
public class NQS0250 {
@PsFieldString(name="NUMDOCO", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUMDOCO;
@PsFieldString(name="CDOPERA", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDOPERA;
@PsFieldString(name="DSOPER1", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSOPER1;
@PsFieldString(name="DSOPER2", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSOPER2;
@PsFieldString(name="DSOPER3", length=55, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSOPER3;
@PsFieldString(name="DTOPERA", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTOPERA;
@PsFieldString(name="TPOPERA", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPOPERA;
@PsFieldString(name="ICSINOP", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICSINOP;
@PsFieldNumber(name="VLOPERA", length=15, decimal=2, defaultValue = "0" )
private double VLOPERA;
@PsFieldString(name="ICCONPA", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICCONPA;
@PsFieldString(name="DSFIOP1", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSFIOP1;
@PsFieldString(name="DSFIOP2", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSFIOP2;
@PsFieldString(name="DSFIOP3", length=55, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSFIOP3;
@PsFieldString(name="NUCNTR", length=32, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUCNTR;

public String getNUMDOCO() {
 return NUMDOCO;
}
public void setNUMDOCO(String NUMDOCO) {
 this.NUMDOCO = NUMDOCO;
}

public String getCDOPERA() {
 return CDOPERA;
}
public void setCDOPERA(String CDOPERA) {
 this.CDOPERA = CDOPERA;
}

public String getDSOPER1() {
 return DSOPER1;
}
public void setDSOPER1(String DSOPER1) {
 this.DSOPER1 = DSOPER1;
}

public String getDSOPER2() {
 return DSOPER2;
}
public void setDSOPER2(String DSOPER2) {
 this.DSOPER2 = DSOPER2;
}

public String getDSOPER3() {
 return DSOPER3;
}
public void setDSOPER3(String DSOPER3) {
 this.DSOPER3 = DSOPER3;
}

public String getDTOPERA() {
 return DTOPERA;
}
public void setDTOPERA(String DTOPERA) {
 this.DTOPERA = DTOPERA;
}

public String getTPOPERA() {
 return TPOPERA;
}
public void setTPOPERA(String TPOPERA) {
 this.TPOPERA = TPOPERA;
}

public String getICSINOP() {
 return ICSINOP;
}
public void setICSINOP(String ICSINOP) {
 this.ICSINOP = ICSINOP;
}
public double getVLOPERA() {
 return VLOPERA;
}
public void setVLOPERA(double vLOPERA) {
VLOPERA = vLOPERA;
}
public String getICCONPA() {
 return ICCONPA;
}
public void setICCONPA(String ICCONPA) {
 this.ICCONPA = ICCONPA;
}

public String getDSFIOP1() {
 return DSFIOP1;
}
public void setDSFIOP1(String DSFIOP1) {
 this.DSFIOP1 = DSFIOP1;
}

public String getDSFIOP2() {
 return DSFIOP2;
}
public void setDSFIOP2(String DSFIOP2) {
 this.DSFIOP2 = DSFIOP2;
}

public String getDSFIOP3() {
 return DSFIOP3;
}
public void setDSFIOP3(String DSFIOP3) {
 this.DSFIOP3 = DSFIOP3;
}

public String getNUCNTR() {
 return NUCNTR;
}
public void setNUCNTR(String NUCNTR) {
 this.NUCNTR = NUCNTR;
}


}
