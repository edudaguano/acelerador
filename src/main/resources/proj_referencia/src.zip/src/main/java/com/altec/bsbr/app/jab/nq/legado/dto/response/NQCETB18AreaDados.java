package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB18AreaDados")
public class NQCETB18AreaDados {

	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*
	@PsFieldString(name= "NQCETB18_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_CD_BANC_CLIE;//          05   NQCETB18-S-CD-BANC-CLIE       PIC  X(004).                
	
	//*       CODIGO DO BANCO                                           
	//
	@PsFieldString(name= "NQCETB18_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_CD_CLIE;//          05   NQCETB18-S-CD-CLIE            PIC  X(008).                
	
	//*       CODIGO DO CLIENTE                                         
	//
	@PsFieldString(name= "NQCETB18_S_DT_MOVI", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_DT_MOVI;//          05   NQCETB18-S-DT-MOVI            PIC  X(010).                
	
	//*       DATA DO MOVIMENTO                                         
	//
	@PsFieldNumber(name= "NQCETB18_S_NR_PROP", decimal= 0, length= 10, signed= false, defaultValue="0")
	private Long NQCETB18_S_NR_PROP;//          05   NQCETB18-S-NR-PROP            PIC  9(010).                
	
	//*       NUMERO DA PROPOSTA                                        
	//
	@PsFieldString(name= "NQCETB18_S_DT_INIC_PLAN", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_DT_INIC_PLAN;//          05   NQCETB18-S-DT-INIC-PLAN       PIC  X(010).                
	
	//*       DATA INICIO DO PLANO                                      
	//
	@PsFieldString(name= "NQCETB18_S_CD_PROD", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_CD_PROD;//          05   NQCETB18-S-CD-PROD            PIC  X(002).                
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name= "NQCETB18_S_TP_PROD", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_TP_PROD;//          05   NQCETB18-S-TP-PROD            PIC  X(004).                
	
	//*       TIPO DE PRODUTO                                           
	//
	@PsFieldNumber(name= "NQCETB18_S_VL_RECB_CNTR", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB18_S_VL_RECB_CNTR;//          05   NQCETB18-S-VL-RECB-CNTR       PIC S9(015)V99.             
	
	//*       VALOR RECEBIDO DO CONTRATO                                
	//
	@PsFieldNumber(name= "NQCETB18_S_VL_RECB_APOR", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB18_S_VL_RECB_APOR;//          05   NQCETB18-S-VL-RECB-APOR       PIC S9(015)V99.             
	
	//*       VALOR RECEBIDO DO APORTE                                  
	//
	@PsFieldNumber(name= "NQCETB18_S_VL_RECB_PRTB", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB18_S_VL_RECB_PRTB;//          05   NQCETB18-S-VL-RECB-PRTB       PIC S9(015)V99.             
	
	//*       VALOR RECEBIDO DA PORTABILIDADE                           
	//
	@PsFieldNumber(name= "NQCETB18_S_VL_RESG_PRTB", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB18_S_VL_RESG_PRTB;//          05   NQCETB18-S-VL-RESG-PRTB       PIC S9(015)V99.             
	
	//*       VALOR RESGATADO DA PORTABILIDADE                          
	//
	@PsFieldNumber(name= "NQCETB18_S_VL_RESG_CNTR", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB18_S_VL_RESG_CNTR;//          05   NQCETB18-S-VL-RESG-CNTR       PIC S9(015)V99.             
	
	//*       VALOR RESGATADO DO CONTRATO                               
	//
	@PsFieldNumber(name= "NQCETB18_S_VL_DEVO", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB18_S_VL_DEVO;//          05   NQCETB18-S-VL-DEVO            PIC S9(015)V99.             
	
	//*       VALOR DEVOLVIDO                                           
	//
	@PsFieldString(name= "NQCETB18_S_TP_FORM_PGTO", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_TP_FORM_PGTO;//          05   NQCETB18-S-TP-FORM-PGTO       PIC  X(001).                
	
	//*       TIPO DE FORMA DE PAGAMENTO                                
	//
	@PsFieldString(name= "NQCETB18_S_TP_FORM_RESG", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_TP_FORM_RESG;//          05   NQCETB18-S-TP-FORM-RESG       PIC  X(001).                
	
	//*       TIPO DE FORMA DE RESGATE                                  
	//
	@PsFieldString(name= "NQCETB18_S_DT_PGTO", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_DT_PGTO;//          05   NQCETB18-S-DT-PGTO            PIC  X(010).                
	
	//*       DATA DE PAGAMENTO                                         
	//
	@PsFieldString(name= "NQCETB18_S_DT_RESG", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_DT_RESG;//          05   NQCETB18-S-DT-RESG            PIC  X(010).                
	
	//*       DATA DE RESGATE                                           
	//
	@PsFieldNumber(name= "NQCETB18_S_VL_RESG_TOTL_RELT", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB18_S_VL_RESG_TOTL_RELT;//          05   NQCETB18-S-VL-RESG-TOTL-RELT  PIC S9(015)V99.             
	
	//*       VALOR RESGATE TOTAL NA DATA DO RELATORIO PREVIDENCIA      
	//
	@PsFieldString(name= "NQCETB18_S_CD_CNTA_DEBT", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_CD_CNTA_DEBT;//          05   NQCETB18-S-CD-CNTA-DEBT       PIC  X(020).                
	
	//*       CODIGO DA CONTA PARA DEBITO                               
	//
	@PsFieldNumber(name= "NQCETB18_S_VL_BOLT_PAGO", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB18_S_VL_BOLT_PAGO;//          05   NQCETB18-S-VL-BOLT-PAGO       PIC S9(015)V99.             
	
	//*       VALOR DO BOLETO PAGO / PRINCIPAL                          
	//
	@PsFieldString(name= "NQCETB18_S_TP_TRAN_PRVD_PRIV", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_TP_TRAN_PRVD_PRIV;//          05   NQCETB18-S-TP-TRAN-PRVD-PRIV  PIC  X(001).                
	
	//*       TIPO DE TRANSACAO DA PREVIDENCIA PRIVADA                  
	//
	@PsFieldString(name= "NQCETB18_S_CD_BANC_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_CD_BANC_CNTR;//          05   NQCETB18-S-CD-BANC-CNTR       PIC  X(004).                
	
	//*       CODIGO DO BANCO DO CONTRATO                               
	//
	@PsFieldString(name= "NQCETB18_S_CD_AGEN_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_CD_AGEN_CNTR;//          05   NQCETB18-S-CD-AGEN-CNTR       PIC  X(004).                
	
	//*       CODIGO DA AGENCIA DO CONTRATO                             
	//
	@PsFieldString(name= "NQCETB18_S_NR_CNTR_A", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_NR_CNTR_A;//          05   NQCETB18-S-NR-CNTR-A          PIC  X(020).                
	
	//*       NUMERO DO CONTRATO ALTAIR                                 
	//
	@PsFieldString(name= "NQCETB18_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_CD_PROD_ALTAIR;//          05   NQCETB18-S-CD-PROD-ALTAIR     PIC  X(002).                
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name= "NQCETB18_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_CD_SUBP_ALTAIR;//          05   NQCETB18-S-CD-SUBP-ALTAIR     PIC  X(004).                
	
	//*       CODIGO DO SUBPRODUTO                                      
	//
	@PsFieldString(name= "NQCETB18_S_CD_MOED", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_CD_MOED;//          05   NQCETB18-S-CD-MOED            PIC  X(003).                
	
	//*       CODIGO DA MOEDA                                           
	//
	@PsFieldNumber(name= "NQCETB18_S_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB18_S_NR_SEQU_OPER;//          05   NQCETB18-S-NR-SEQU-OPER       PIC  9(003).                
	
	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	@PsFieldString(name= "NQCETB18_S_CD_IDEF_OPER", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_CD_IDEF_OPER;//          05   NQCETB18-S-CD-IDEF-OPER       PIC  X(020).                
	
	//*       CODIGO DA IDENTIFICACAO DA OPERACAO                       
	//
	@PsFieldString(name= "NQCETB18_S_NM_CLIE", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_S_NM_CLIE;//     05   NQCETB18-S-NM-CLIE            PIC  X(040).                


	public String getNQCETB18_S_CD_BANC_CLIE() {
		return NQCETB18_S_CD_BANC_CLIE;
	}

	public void setNQCETB18_S_CD_BANC_CLIE(String nQCETB18_S_CD_BANC_CLIE) {
		NQCETB18_S_CD_BANC_CLIE = nQCETB18_S_CD_BANC_CLIE;
	}

	public String getNQCETB18_S_CD_CLIE() {
		return NQCETB18_S_CD_CLIE;
	}

	public void setNQCETB18_S_CD_CLIE(String nQCETB18_S_CD_CLIE) {
		NQCETB18_S_CD_CLIE = nQCETB18_S_CD_CLIE;
	}

	public String getNQCETB18_S_DT_MOVI() {
		return NQCETB18_S_DT_MOVI;
	}

	public void setNQCETB18_S_DT_MOVI(String nQCETB18_S_DT_MOVI) {
		NQCETB18_S_DT_MOVI = nQCETB18_S_DT_MOVI;
	}

	public Long getNQCETB18_S_NR_PROP() {
		return NQCETB18_S_NR_PROP;
	}

	public void setNQCETB18_S_NR_PROP(Long nQCETB18_S_NR_PROP) {
		NQCETB18_S_NR_PROP = nQCETB18_S_NR_PROP;
	}

	public String getNQCETB18_S_DT_INIC_PLAN() {
		return NQCETB18_S_DT_INIC_PLAN;
	}

	public void setNQCETB18_S_DT_INIC_PLAN(String nQCETB18_S_DT_INIC_PLAN) {
		NQCETB18_S_DT_INIC_PLAN = nQCETB18_S_DT_INIC_PLAN;
	}

	public String getNQCETB18_S_CD_PROD() {
		return NQCETB18_S_CD_PROD;
	}

	public void setNQCETB18_S_CD_PROD(String nQCETB18_S_CD_PROD) {
		NQCETB18_S_CD_PROD = nQCETB18_S_CD_PROD;
	}

	public String getNQCETB18_S_TP_PROD() {
		return NQCETB18_S_TP_PROD;
	}

	public void setNQCETB18_S_TP_PROD(String nQCETB18_S_TP_PROD) {
		NQCETB18_S_TP_PROD = nQCETB18_S_TP_PROD;
	}

	public Double getNQCETB18_S_VL_RECB_CNTR() {
		return NQCETB18_S_VL_RECB_CNTR;
	}

	public void setNQCETB18_S_VL_RECB_CNTR(Double nQCETB18_S_VL_RECB_CNTR) {
		NQCETB18_S_VL_RECB_CNTR = nQCETB18_S_VL_RECB_CNTR;
	}

	public Double getNQCETB18_S_VL_RECB_APOR() {
		return NQCETB18_S_VL_RECB_APOR;
	}

	public void setNQCETB18_S_VL_RECB_APOR(Double nQCETB18_S_VL_RECB_APOR) {
		NQCETB18_S_VL_RECB_APOR = nQCETB18_S_VL_RECB_APOR;
	}

	public Double getNQCETB18_S_VL_RECB_PRTB() {
		return NQCETB18_S_VL_RECB_PRTB;
	}

	public void setNQCETB18_S_VL_RECB_PRTB(Double nQCETB18_S_VL_RECB_PRTB) {
		NQCETB18_S_VL_RECB_PRTB = nQCETB18_S_VL_RECB_PRTB;
	}

	public Double getNQCETB18_S_VL_RESG_PRTB() {
		return NQCETB18_S_VL_RESG_PRTB;
	}

	public void setNQCETB18_S_VL_RESG_PRTB(Double nQCETB18_S_VL_RESG_PRTB) {
		NQCETB18_S_VL_RESG_PRTB = nQCETB18_S_VL_RESG_PRTB;
	}

	public Double getNQCETB18_S_VL_RESG_CNTR() {
		return NQCETB18_S_VL_RESG_CNTR;
	}

	public void setNQCETB18_S_VL_RESG_CNTR(Double nQCETB18_S_VL_RESG_CNTR) {
		NQCETB18_S_VL_RESG_CNTR = nQCETB18_S_VL_RESG_CNTR;
	}

	public Double getNQCETB18_S_VL_DEVO() {
		return NQCETB18_S_VL_DEVO;
	}

	public void setNQCETB18_S_VL_DEVO(Double nQCETB18_S_VL_DEVO) {
		NQCETB18_S_VL_DEVO = nQCETB18_S_VL_DEVO;
	}

	public String getNQCETB18_S_TP_FORM_PGTO() {
		return NQCETB18_S_TP_FORM_PGTO;
	}

	public void setNQCETB18_S_TP_FORM_PGTO(String nQCETB18_S_TP_FORM_PGTO) {
		NQCETB18_S_TP_FORM_PGTO = nQCETB18_S_TP_FORM_PGTO;
	}

	public String getNQCETB18_S_TP_FORM_RESG() {
		return NQCETB18_S_TP_FORM_RESG;
	}

	public void setNQCETB18_S_TP_FORM_RESG(String nQCETB18_S_TP_FORM_RESG) {
		NQCETB18_S_TP_FORM_RESG = nQCETB18_S_TP_FORM_RESG;
	}

	public String getNQCETB18_S_DT_PGTO() {
		return NQCETB18_S_DT_PGTO;
	}

	public void setNQCETB18_S_DT_PGTO(String nQCETB18_S_DT_PGTO) {
		NQCETB18_S_DT_PGTO = nQCETB18_S_DT_PGTO;
	}

	public String getNQCETB18_S_DT_RESG() {
		return NQCETB18_S_DT_RESG;
	}

	public void setNQCETB18_S_DT_RESG(String nQCETB18_S_DT_RESG) {
		NQCETB18_S_DT_RESG = nQCETB18_S_DT_RESG;
	}

	public Double getNQCETB18_S_VL_RESG_TOTL_RELT() {
		return NQCETB18_S_VL_RESG_TOTL_RELT;
	}

	public void setNQCETB18_S_VL_RESG_TOTL_RELT(Double nQCETB18_S_VL_RESG_TOTL_RELT) {
		NQCETB18_S_VL_RESG_TOTL_RELT = nQCETB18_S_VL_RESG_TOTL_RELT;
	}

	public String getNQCETB18_S_CD_CNTA_DEBT() {
		return NQCETB18_S_CD_CNTA_DEBT;
	}

	public void setNQCETB18_S_CD_CNTA_DEBT(String nQCETB18_S_CD_CNTA_DEBT) {
		NQCETB18_S_CD_CNTA_DEBT = nQCETB18_S_CD_CNTA_DEBT;
	}

	public Double getNQCETB18_S_VL_BOLT_PAGO() {
		return NQCETB18_S_VL_BOLT_PAGO;
	}

	public void setNQCETB18_S_VL_BOLT_PAGO(Double nQCETB18_S_VL_BOLT_PAGO) {
		NQCETB18_S_VL_BOLT_PAGO = nQCETB18_S_VL_BOLT_PAGO;
	}

	public String getNQCETB18_S_TP_TRAN_PRVD_PRIV() {
		return NQCETB18_S_TP_TRAN_PRVD_PRIV;
	}

	public void setNQCETB18_S_TP_TRAN_PRVD_PRIV(String nQCETB18_S_TP_TRAN_PRVD_PRIV) {
		NQCETB18_S_TP_TRAN_PRVD_PRIV = nQCETB18_S_TP_TRAN_PRVD_PRIV;
	}

	public String getNQCETB18_S_CD_BANC_CNTR() {
		return NQCETB18_S_CD_BANC_CNTR;
	}

	public void setNQCETB18_S_CD_BANC_CNTR(String nQCETB18_S_CD_BANC_CNTR) {
		NQCETB18_S_CD_BANC_CNTR = nQCETB18_S_CD_BANC_CNTR;
	}

	public String getNQCETB18_S_CD_AGEN_CNTR() {
		return NQCETB18_S_CD_AGEN_CNTR;
	}

	public void setNQCETB18_S_CD_AGEN_CNTR(String nQCETB18_S_CD_AGEN_CNTR) {
		NQCETB18_S_CD_AGEN_CNTR = nQCETB18_S_CD_AGEN_CNTR;
	}

	public String getNQCETB18_S_NR_CNTR_A() {
		return NQCETB18_S_NR_CNTR_A;
	}

	public void setNQCETB18_S_NR_CNTR_A(String nQCETB18_S_NR_CNTR_A) {
		NQCETB18_S_NR_CNTR_A = nQCETB18_S_NR_CNTR_A;
	}

	public String getNQCETB18_S_CD_PROD_ALTAIR() {
		return NQCETB18_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB18_S_CD_PROD_ALTAIR(String nQCETB18_S_CD_PROD_ALTAIR) {
		NQCETB18_S_CD_PROD_ALTAIR = nQCETB18_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB18_S_CD_SUBP_ALTAIR() {
		return NQCETB18_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB18_S_CD_SUBP_ALTAIR(String nQCETB18_S_CD_SUBP_ALTAIR) {
		NQCETB18_S_CD_SUBP_ALTAIR = nQCETB18_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB18_S_CD_MOED() {
		return NQCETB18_S_CD_MOED;
	}

	public void setNQCETB18_S_CD_MOED(String nQCETB18_S_CD_MOED) {
		NQCETB18_S_CD_MOED = nQCETB18_S_CD_MOED;
	}

	public Long getNQCETB18_S_NR_SEQU_OPER() {
		return NQCETB18_S_NR_SEQU_OPER;
	}

	public void setNQCETB18_S_NR_SEQU_OPER(Long nQCETB18_S_NR_SEQU_OPER) {
		NQCETB18_S_NR_SEQU_OPER = nQCETB18_S_NR_SEQU_OPER;
	}

	public String getNQCETB18_S_CD_IDEF_OPER() {
		return NQCETB18_S_CD_IDEF_OPER;
	}

	public void setNQCETB18_S_CD_IDEF_OPER(String nQCETB18_S_CD_IDEF_OPER) {
		NQCETB18_S_CD_IDEF_OPER = nQCETB18_S_CD_IDEF_OPER;
	}

	public String getNQCETB18_S_NM_CLIE() {
		return NQCETB18_S_NM_CLIE;
	}

	public void setNQCETB18_S_NM_CLIE(String nQCETB18_S_NM_CLIE) {
		NQCETB18_S_NM_CLIE = nQCETB18_S_NM_CLIE;
	}
	
	//*       NOME DO CLIENTE                                           
	//
	
	
}