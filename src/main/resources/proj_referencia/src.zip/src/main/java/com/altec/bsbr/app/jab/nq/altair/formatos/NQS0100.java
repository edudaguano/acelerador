package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0100")
public class NQS0100 {
@PsFieldNumber(name="NUMATRI", length=11, defaultValue = "0" )
private Long NUMATRI;
@PsFieldString(name="NOFUNCI", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUNCI;
@PsFieldString(name="DSCARGO", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCARGO;
public Long getNUMATRI() {
 return NUMATRI;
}
public void setNUMATRI(Long nUMATRI) {
NUMATRI = nUMATRI;
}
public String getNOFUNCI() {
 return NOFUNCI;
}
public void setNOFUNCI(String NOFUNCI) {
 this.NOFUNCI = NOFUNCI;
}

public String getDSCARGO() {
 return DSCARGO;
}
public void setDSCARGO(String DSCARGO) {
 this.DSCARGO = DSCARGO;
}


}
