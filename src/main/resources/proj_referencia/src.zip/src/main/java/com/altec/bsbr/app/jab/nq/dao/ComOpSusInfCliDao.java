package com.altec.bsbr.app.jab.nq.dao;

public interface ComOpSusInfCliDao {
	public String versao();

	public String consultarAgencia(String strNUENTID, String strNUAGENC, String strNUCONTA, String strCOCLIEN);

	public String consultarSocio(String strPENUMPE);

	public String consultarClientePJ(String strCODENT, String strTPDOCTO, String strNUDOCTO, String strCDALERT);

	public String consultarClientePF(String strTPDOCTO, String strNUDOCTO, String strCDENTID, String strCDALERT);

	public String consultarClientePE(String strCOENTID, String strTPDOCTO, String strNUDOCTO);

	public String log(String strTexto); 
}
