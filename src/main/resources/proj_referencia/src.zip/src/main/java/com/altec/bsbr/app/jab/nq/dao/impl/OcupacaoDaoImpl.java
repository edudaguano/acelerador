package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.HistoricoDao;
import com.altec.bsbr.app.jab.nq.dao.OcupacaoDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCE7035LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCE7035LegadoResponse;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

//BACKEND SEM FONTE
@Repository
public class OcupacaoDaoImpl implements OcupacaoDao {

	private final Logger LOGGER = LoggerFactory.getLogger(OcupacaoDaoImpl.class);

	@Autowired
 	private JSONMapper jsonMapper;

	@Override
	public String consOcupCadastradas(String intBanco, String intPeriodicidade) {
		// TODO: Não foi identificado qual transação é utilizado nesse metodo
		return null;
	}

	@Override
	public String recuperaDados(String intOcupacao) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String incluirOcupacao(String intBanco, String intPeriod, String intCodOcup, String strDescOcup,
			String strUserId) {
		// TODO: Não foi identificado qual transação é utilizado nesse metodo
		return null;
	}

	@Override
	public String consultarBancoProdPeriod() {
		// TODO: Não foi identificado qual transação é utilizado nesse metodo
		return null;
	}

	@Override
	public String exclusaoOcupacao(String intBanco, String intPeriod, String intCodOcup, String strUsuario) {
		// TODO: Não foi identificado qual transação é utilizado nesse metodo
		return null;
	} 

}
