package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface ParamProdutoService {
	public String versao() throws BusinessException;

	public String listaProduto(String strSIGLA, String strNUSEQ, String strDETINTE, String strNOMEPRO,
			String strIDORDPA) throws BusinessException;

	public String alteraProduto(String strSGSISOR, String strSQSISOR, String strCDDETIN, String strDHFILTR,
			String strTPOPER, String strICMONIT, String strVLMINPR, String strCDUSRES) throws BusinessException;

	public String listaAlteracaoParametro(String strCOSIGLA, String strNUSEQSI, String strCODETIN, String strCOOPINT,
			String strIDORDPG) throws BusinessException;
}
