package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB08")
public class NQCETB08LegadoRequest {
	
// -*-NQCETB08
//         01     NQCETB08-ENTRADA.                                         
//                                                                          
	@PsFieldString(name= "NQCETB08_E_NM_PROG", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_E_NM_PROG;//           05   NQCETB08-E-NM-PROG            PIC  X(008).                

//        *       NOME DO PROGRAMA CHAMADO                                  
//                                                                          
	@PsFieldString(name= "NQCETB08_E_NM_AREA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_E_NM_AREA;//           05   NQCETB08-E-NM-AREA            PIC  X(008).                

//        *       NOME DA AREA DE TS                                        
//                                                                          
	@PsFieldString(name= "NQCETB08_E_SG_FCAO", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_E_SG_FCAO;//           05   NQCETB08-E-SG-FCAO            PIC  X(002).                

//        *       FUNCAO A SER EXECUTADA                                    
//        *       C = CONSULTAR                                             
//                                                                          
	@PsFieldNumber(name= "NQCETB08_E_QT_TAMA_AREA", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long NQCETB08_E_QT_TAMA_AREA;//           05   NQCETB08-E-QT-TAMA-AREA       PIC  9(007).                

//        *       TAMANHO DA AREA DE TS                                     
//                                                                          
	@PsFieldString(name= "NQCETB08_E_CD_USUA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_E_CD_USUA;//           05   NQCETB08-E-CD-USUA            PIC  X(008).                

//        *       CODIGO DO USUARIO                                         
//                                                                          
	@PsFieldString(name= "NQCETB08_E_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_E_CD_BANC_CLIE;//           05   NQCETB08-E-CD-BANC-CLIE       PIC  X(004).                

//        *       CODIGO DO BANCO                                           
//                                                                          
	@PsFieldString(name= "NQCETB08_E_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_E_CD_CLIE;//           05   NQCETB08-E-CD-CLIE            PIC  X(008).                

//        *       CODIGO DO CLIENTE                                         
//                                                                          
//         01     NQCETB08-SAIDA.                                           
//                                                                          
//        *       AREA DE MENSAGEM                                          
//                                                                          
	@PsFieldNumber(name= "NQCETB08_S_MENS_LEN", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long NQCETB08_S_MENS_LEN;//          03    NQCETB08-S-MENS-LEN    COMP   PIC  S9(04) VALUE +83.      

//          03    NQCETB08-S-MENS.                                          
	@PsFieldNumber(name= "NQCETB08_S_RETORNO", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB08_S_RETORNO;//           05   NQCETB08-S-RETORNO            PIC  9(003) VALUE ZEROS.    

	@PsFieldString(name= "NQCETB08_S_MENSAGEM", length= 80, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_MENSAGEM;//           05   NQCETB08-S-MENSAGEM           PIC  X(080) VALUE SPACES.   

//                                                                          
//        *       AREA DE DADOS                                             
//                                                                          
	@PsFieldNumber(name= "NQCETB08_S_DATA_LEN", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long NQCETB08_S_DATA_LEN;//          03    NQCETB08-S-DATA-LEN    COMP   PIC  S9(04) VALUE +235.     

//          03    NQCETB08-S-DATA.                                          
//                                                                          
	@PsFieldString(name= "NQCETB08_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_CD_BANC_CLIE;//           05   NQCETB08-S-CD-BANC-CLIE       PIC  X(004).                

//        *       CODIGO DO BANCO                                           
//                                                                          
	@PsFieldString(name= "NQCETB08_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_CD_CLIE;//           05   NQCETB08-S-CD-CLIE            PIC  X(008).                

//        *       CODIGO DO CLIENTE                                         
//                                                                          
	@PsFieldString(name= "NQCETB08_S_NM_CLIE", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_NM_CLIE;//           05   NQCETB08-S-NM-CLIE            PIC  X(040).                

//        *       NOME DO CLIENTE                                           
//                                                                          
	@PsFieldString(name= "NQCETB08_S_TP_PESS_CLIE", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_TP_PESS_CLIE;//           05   NQCETB08-S-TP-PESS-CLIE       PIC  X(001).                

//        *       TIPO DE PESSOA                                            
//                                                                          
	@PsFieldString(name= "NQCETB08_S_NR_CPF_CNPJ", length= 15, paddingAlign= PsAlign.LEFT, paddingChar= '0')
	private String NQCETB08_S_NR_CPF_CNPJ;//           05   NQCETB08-S-NR-CPF-CNPJ        PIC  X(015).                

//        *       CODIGO DO CPF / CNPJ                                      
//                                                                          
	@PsFieldString(name= "NQCETB08_S_CD_ATVD_OCUP", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_CD_ATVD_OCUP;//           05   NQCETB08-S-CD-ATVD-OCUP       PIC  X(010).                

//        *       CODIGO DA ATIVIDADE / OCUPACAO                            
//                                                                          
	@PsFieldString(name= "NQCETB08_S_DT_NASC_FNDA", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_DT_NASC_FNDA;//           05   NQCETB08-S-DT-NASC-FNDA       PIC  X(010).                

//        *       DATA DE NASCIMENTO / FUNDACAO                             
//                                                                          
	@PsFieldString(name= "NQCETB08_S_NM_CIDA_CLIE", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_NM_CIDA_CLIE;//           05   NQCETB08-S-NM-CIDA-CLIE       PIC  X(020).                

//        *       NOME DA CIDADE                                            
//                                                                          
	@PsFieldString(name= "NQCETB08_S_CD_UF_CLIE", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_CD_UF_CLIE;//           05   NQCETB08-S-CD-UF-CLIE         PIC  X(002).                

//        *       CODIGO DA UF                                              
//                                                                          
	@PsFieldNumber(name= "NQCETB08_S_VL_FATU_REND", decimal= 2, length= 17, signed= true, defaultValue="0")
	private Double NQCETB08_S_VL_FATU_REND;//           05   NQCETB08-S-VL-FATU-REND       PIC  9(015)V99.             

//        *       VALOR DA RENDA / FATURAMENTO                              
//                                                                          
	@PsFieldString(name= "NQCETB08_S_DT_FATU_REND", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_DT_FATU_REND;//           05   NQCETB08-S-DT-FATU-REND       PIC  X(010).                

//        *       DATA DA RENDA / FATURAMENTO                               
//                                                                          
	@PsFieldString(name= "NQCETB08_S_NM_GRUP_ECON", length= 25, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_NM_GRUP_ECON;//           05   NQCETB08-S-NM-GRUP-ECON       PIC  X(025).                

//        *       NOME DO GRUPO ECONOMICO                                   
//                                                                          
	@PsFieldString(name= "NQCETB08_S_CD_SEGM", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_CD_SEGM;//           05   NQCETB08-S-CD-SEGM            PIC  X(004).                

//        *       CODIGO DO SEGMENTO                                        
//                                                                          
	@PsFieldString(name= "NQCETB08_S_NR_MATR_GERE_COME", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_NR_MATR_GERE_COME;//           05   NQCETB08-S-NR-MATR-GERE-COME  PIC  X(008).                

//        *       NUMERO DA MATRICULA DO GERENTE                            
//                                                                          
	@PsFieldString(name= "NQCETB08_S_NM_GERENTE", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_NM_GERENTE;//           05   NQCETB08-S-NM-GERENTE         PIC  X(040).                

//        *       NOME DO GERENTE                                           
//                                                                          
	@PsFieldString(name= "NQCETB08_S_CD_RSTR", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_CD_RSTR;//           05   NQCETB08-S-CD-RSTR            PIC  X(001).                

//        *       CODIGO DE RESTRICAO                                       
//                                                                          
	@PsFieldString(name= "NQCETB08_S_DS_RSTR", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB08_S_DS_RSTR;//           05   NQCETB08-S-DS-RSTR            PIC  X(020).                

//        *       DESCRICAO DA RESTRICAO                                    
	public NQCETB08LegadoRequest() { }
	public NQCETB08LegadoRequest(String nqcetb08_e_nm_prog, String nqcetb08_e_nm_area, String nqcetb08_e_sg_fcao, Long nqcetb08_e_qt_tama_area, String nqcetb08_e_cd_usua, String nqcetb08_e_cd_banc_clie, String nqcetb08_e_cd_clie, String nqcetb08_s_cd_banc_clie, String nqcetb08_s_cd_clie, String nqcetb08_s_nm_clie, String nqcetb08_s_tp_pess_clie, String nqcetb08_s_nr_cpf_cnpj, String nqcetb08_s_cd_atvd_ocup, String nqcetb08_s_dt_nasc_fnda, String nqcetb08_s_nm_cida_clie, String nqcetb08_s_cd_uf_clie, Double nqcetb08_s_vl_fatu_rend, String nqcetb08_s_dt_fatu_rend, String nqcetb08_s_nm_grup_econ, String nqcetb08_s_cd_segm, String nqcetb08_s_nr_matr_gere_come, String nqcetb08_s_nm_gerente, String nqcetb08_s_cd_rstr, String nqcetb08_s_ds_rstr) { 		this.NQCETB08_E_NM_PROG = nqcetb08_e_nm_prog;
		this.NQCETB08_E_NM_AREA = nqcetb08_e_nm_area;
		this.NQCETB08_E_SG_FCAO = nqcetb08_e_sg_fcao;
		this.NQCETB08_E_QT_TAMA_AREA = nqcetb08_e_qt_tama_area;
		this.NQCETB08_E_CD_USUA = nqcetb08_e_cd_usua;
		this.NQCETB08_E_CD_BANC_CLIE = nqcetb08_e_cd_banc_clie;
		this.NQCETB08_E_CD_CLIE = nqcetb08_e_cd_clie;
		/*this.NQCETB08_S_MENS_LEN = +83;
		this.NQCETB08_S_RETORNO = ZEROS;
		this.NQCETB08_S_MENSAGEM = SPACES;
		this.NQCETB08_S_DATA_LEN = +235;*/
		this.NQCETB08_S_CD_BANC_CLIE = nqcetb08_s_cd_banc_clie;
		this.NQCETB08_S_CD_CLIE = nqcetb08_s_cd_clie;
		this.NQCETB08_S_NM_CLIE = nqcetb08_s_nm_clie;
		this.NQCETB08_S_TP_PESS_CLIE = nqcetb08_s_tp_pess_clie;
		this.NQCETB08_S_NR_CPF_CNPJ = nqcetb08_s_nr_cpf_cnpj;
		this.NQCETB08_S_CD_ATVD_OCUP = nqcetb08_s_cd_atvd_ocup;
		this.NQCETB08_S_DT_NASC_FNDA = nqcetb08_s_dt_nasc_fnda;
		this.NQCETB08_S_NM_CIDA_CLIE = nqcetb08_s_nm_cida_clie;
		this.NQCETB08_S_CD_UF_CLIE = nqcetb08_s_cd_uf_clie;
		this.NQCETB08_S_VL_FATU_REND = nqcetb08_s_vl_fatu_rend;
		this.NQCETB08_S_DT_FATU_REND = nqcetb08_s_dt_fatu_rend;
		this.NQCETB08_S_NM_GRUP_ECON = nqcetb08_s_nm_grup_econ;
		this.NQCETB08_S_CD_SEGM = nqcetb08_s_cd_segm;
		this.NQCETB08_S_NR_MATR_GERE_COME = nqcetb08_s_nr_matr_gere_come;
		this.NQCETB08_S_NM_GERENTE = nqcetb08_s_nm_gerente;
		this.NQCETB08_S_CD_RSTR = nqcetb08_s_cd_rstr;
		this.NQCETB08_S_DS_RSTR = nqcetb08_s_ds_rstr; 
	}
	public String getNQCETB08_E_NM_PROG() { return this.NQCETB08_E_NM_PROG; }
	public String getNQCETB08_E_NM_AREA() { return this.NQCETB08_E_NM_AREA; }
	public String getNQCETB08_E_SG_FCAO() { return this.NQCETB08_E_SG_FCAO; }
	public Long getNQCETB08_E_QT_TAMA_AREA() { return this.NQCETB08_E_QT_TAMA_AREA; }
	public String getNQCETB08_E_CD_USUA() { return this.NQCETB08_E_CD_USUA; }
	public String getNQCETB08_E_CD_BANC_CLIE() { return this.NQCETB08_E_CD_BANC_CLIE; }
	public String getNQCETB08_E_CD_CLIE() { return this.NQCETB08_E_CD_CLIE; }
	public Long getNQCETB08_S_MENS_LEN() { return this.NQCETB08_S_MENS_LEN; }
	public Long getNQCETB08_S_RETORNO() { return this.NQCETB08_S_RETORNO; }
	public String getNQCETB08_S_MENSAGEM() { return this.NQCETB08_S_MENSAGEM; }
	public Long getNQCETB08_S_DATA_LEN() { return this.NQCETB08_S_DATA_LEN; }
	public String getNQCETB08_S_CD_BANC_CLIE() { return this.NQCETB08_S_CD_BANC_CLIE; }
	public String getNQCETB08_S_CD_CLIE() { return this.NQCETB08_S_CD_CLIE; }
	public String getNQCETB08_S_NM_CLIE() { return this.NQCETB08_S_NM_CLIE; }
	public String getNQCETB08_S_TP_PESS_CLIE() { return this.NQCETB08_S_TP_PESS_CLIE; }
	public String getNQCETB08_S_NR_CPF_CNPJ() { return this.NQCETB08_S_NR_CPF_CNPJ; }
	public String getNQCETB08_S_CD_ATVD_OCUP() { return this.NQCETB08_S_CD_ATVD_OCUP; }
	public String getNQCETB08_S_DT_NASC_FNDA() { return this.NQCETB08_S_DT_NASC_FNDA; }
	public String getNQCETB08_S_NM_CIDA_CLIE() { return this.NQCETB08_S_NM_CIDA_CLIE; }
	public String getNQCETB08_S_CD_UF_CLIE() { return this.NQCETB08_S_CD_UF_CLIE; }
	public Double getNQCETB08_S_VL_FATU_REND() { return this.NQCETB08_S_VL_FATU_REND; }
	public String getNQCETB08_S_DT_FATU_REND() { return this.NQCETB08_S_DT_FATU_REND; }
	public String getNQCETB08_S_NM_GRUP_ECON() { return this.NQCETB08_S_NM_GRUP_ECON; }
	public String getNQCETB08_S_CD_SEGM() { return this.NQCETB08_S_CD_SEGM; }
	public String getNQCETB08_S_NR_MATR_GERE_COME() { return this.NQCETB08_S_NR_MATR_GERE_COME; }
	public String getNQCETB08_S_NM_GERENTE() { return this.NQCETB08_S_NM_GERENTE; }
	public String getNQCETB08_S_CD_RSTR() { return this.NQCETB08_S_CD_RSTR; }
	public String getNQCETB08_S_DS_RSTR() { return this.NQCETB08_S_DS_RSTR; }
	public void setNQCETB08_E_NM_PROG(String nqcetb08_e_nm_prog) { this.NQCETB08_E_NM_PROG = nqcetb08_e_nm_prog; }
	public void setNQCETB08_E_NM_AREA(String nqcetb08_e_nm_area) { this.NQCETB08_E_NM_AREA = nqcetb08_e_nm_area; }
	public void setNQCETB08_E_SG_FCAO(String nqcetb08_e_sg_fcao) { this.NQCETB08_E_SG_FCAO = nqcetb08_e_sg_fcao; }
	public void setNQCETB08_E_QT_TAMA_AREA(Long nqcetb08_e_qt_tama_area) { this.NQCETB08_E_QT_TAMA_AREA = nqcetb08_e_qt_tama_area; }
	public void setNQCETB08_E_CD_USUA(String nqcetb08_e_cd_usua) { this.NQCETB08_E_CD_USUA = nqcetb08_e_cd_usua; }
	public void setNQCETB08_E_CD_BANC_CLIE(String nqcetb08_e_cd_banc_clie) { this.NQCETB08_E_CD_BANC_CLIE = nqcetb08_e_cd_banc_clie; }
	public void setNQCETB08_E_CD_CLIE(String nqcetb08_e_cd_clie) { this.NQCETB08_E_CD_CLIE = nqcetb08_e_cd_clie; }
	public void setNQCETB08_S_MENS_LEN(Long nqcetb08_s_mens_len) { this.NQCETB08_S_MENS_LEN = nqcetb08_s_mens_len; }
	public void setNQCETB08_S_RETORNO(Long nqcetb08_s_retorno) { this.NQCETB08_S_RETORNO = nqcetb08_s_retorno; }
	public void setNQCETB08_S_MENSAGEM(String nqcetb08_s_mensagem) { this.NQCETB08_S_MENSAGEM = nqcetb08_s_mensagem; }
	public void setNQCETB08_S_DATA_LEN(Long nqcetb08_s_data_len) { this.NQCETB08_S_DATA_LEN = nqcetb08_s_data_len; }
	public void setNQCETB08_S_CD_BANC_CLIE(String nqcetb08_s_cd_banc_clie) { this.NQCETB08_S_CD_BANC_CLIE = nqcetb08_s_cd_banc_clie; }
	public void setNQCETB08_S_CD_CLIE(String nqcetb08_s_cd_clie) { this.NQCETB08_S_CD_CLIE = nqcetb08_s_cd_clie; }
	public void setNQCETB08_S_NM_CLIE(String nqcetb08_s_nm_clie) { this.NQCETB08_S_NM_CLIE = nqcetb08_s_nm_clie; }
	public void setNQCETB08_S_TP_PESS_CLIE(String nqcetb08_s_tp_pess_clie) { this.NQCETB08_S_TP_PESS_CLIE = nqcetb08_s_tp_pess_clie; }
	public void setNQCETB08_S_NR_CPF_CNPJ(String nqcetb08_s_nr_cpf_cnpj) { this.NQCETB08_S_NR_CPF_CNPJ = nqcetb08_s_nr_cpf_cnpj; }
	public void setNQCETB08_S_CD_ATVD_OCUP(String nqcetb08_s_cd_atvd_ocup) { this.NQCETB08_S_CD_ATVD_OCUP = nqcetb08_s_cd_atvd_ocup; }
	public void setNQCETB08_S_DT_NASC_FNDA(String nqcetb08_s_dt_nasc_fnda) { this.NQCETB08_S_DT_NASC_FNDA = nqcetb08_s_dt_nasc_fnda; }
	public void setNQCETB08_S_NM_CIDA_CLIE(String nqcetb08_s_nm_cida_clie) { this.NQCETB08_S_NM_CIDA_CLIE = nqcetb08_s_nm_cida_clie; }
	public void setNQCETB08_S_CD_UF_CLIE(String nqcetb08_s_cd_uf_clie) { this.NQCETB08_S_CD_UF_CLIE = nqcetb08_s_cd_uf_clie; }
	public void setNQCETB08_S_VL_FATU_REND(Double nqcetb08_s_vl_fatu_rend) { this.NQCETB08_S_VL_FATU_REND = nqcetb08_s_vl_fatu_rend; }
	public void setNQCETB08_S_DT_FATU_REND(String nqcetb08_s_dt_fatu_rend) { this.NQCETB08_S_DT_FATU_REND = nqcetb08_s_dt_fatu_rend; }
	public void setNQCETB08_S_NM_GRUP_ECON(String nqcetb08_s_nm_grup_econ) { this.NQCETB08_S_NM_GRUP_ECON = nqcetb08_s_nm_grup_econ; }
	public void setNQCETB08_S_CD_SEGM(String nqcetb08_s_cd_segm) { this.NQCETB08_S_CD_SEGM = nqcetb08_s_cd_segm; }
	public void setNQCETB08_S_NR_MATR_GERE_COME(String nqcetb08_s_nr_matr_gere_come) { this.NQCETB08_S_NR_MATR_GERE_COME = nqcetb08_s_nr_matr_gere_come; }
	public void setNQCETB08_S_NM_GERENTE(String nqcetb08_s_nm_gerente) { this.NQCETB08_S_NM_GERENTE = nqcetb08_s_nm_gerente; }
	public void setNQCETB08_S_CD_RSTR(String nqcetb08_s_cd_rstr) { this.NQCETB08_S_CD_RSTR = nqcetb08_s_cd_rstr; }
	public void setNQCETB08_S_DS_RSTR(String nqcetb08_s_ds_rstr) { this.NQCETB08_S_DS_RSTR = nqcetb08_s_ds_rstr; }
	
}