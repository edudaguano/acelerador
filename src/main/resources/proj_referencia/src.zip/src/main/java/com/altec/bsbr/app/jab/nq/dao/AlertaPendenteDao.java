package com.altec.bsbr.app.jab.nq.dao;

public interface AlertaPendenteDao {
	public String versao();

	public String consultarAlerta(String strCOENTID, String strTPUNIOR, String strCDUNIOR, String strCOALERP,
			String strDTQUEST, String strDTGERPA, String strIDORDPA);
}
