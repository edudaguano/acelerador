package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.AlertaCliDdsCtpDao;
import com.altec.bsbr.app.jab.nq.service.AlertaCliDdsCtpService;
import com.altec.bsbr.fw.BusinessException;


@Service
public class AlertaCliDdsCtpServiceImpl implements AlertaCliDdsCtpService {
	private final Logger LOGGER = LoggerFactory.getLogger(AlertaCliDdsCtpServiceImpl.class);

	@Autowired
	private AlertaCliDdsCtpDao alertacliddsctp;

	public String versao() throws BusinessException {
		return alertacliddsctp.versao();
	}

	public String consultarContraparte(String strCOENTID, String strCOALERT, String strCDCENAR, String strCDDETIN,
			String strCDOCOPE, String strNUCNTR) throws BusinessException {
		return alertacliddsctp.consultarContraparte(strCOENTID, strCOALERT, strCDCENAR, strCDDETIN, strCDOCOPE, strNUCNTR);
	}
}
