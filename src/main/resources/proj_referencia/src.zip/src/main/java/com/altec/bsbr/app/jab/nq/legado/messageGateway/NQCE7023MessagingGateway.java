package com.altec.bsbr.app.jab.nq.legado.messageGateway;

import java.util.List;

import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCE7023LegadoRequest;
import com.altec.bsbr.fw.jms.legado.LegadoException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;

public interface NQCE7023MessagingGateway {
	
	LegadoResult sendMessageLegado(NQCE7023LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageMultiLegado(NQCE7023LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageListLegado(List<NQCE7023LegadoRequest> arg0) throws LegadoException;
	
}