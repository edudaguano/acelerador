package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.ParamAuditoriaDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB06LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB06AreaDados;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB06MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ParamAuditoriaDaoImpl implements ParamAuditoriaDao {
	private final Logger LOGGER = LoggerFactory.getLogger(ParamAuditoriaDaoImpl.class);

	@Autowired
	private JSONMapper jsonMapper;
	
	@Autowired
	private NQCETB06MessagingGateway NQCETB06Service;
	
	public String listarParametro(String strCodSist, String strCodUser) throws BusinessException {
		String json = "";
		try {
			NQCETB06LegadoRequest req = new NQCETB06LegadoRequest();
			req.setNQCETB6E_SG_FCAO("L");
			req.setNQCETB6E_CD_USUA(strCodUser);
			req.setNQCETB6E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
						
			LegadoResult res = NQCETB06Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB06AreaDados> ret = decoder.parseRetorno(res, NQCETB06AreaDados.class, 83, 329);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String consultarParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodUser) throws BusinessException {
		String json = "";
		try {
			NQCETB06LegadoRequest req = new NQCETB06LegadoRequest();
			req.setNQCETB6E_SG_FCAO("C");
			req.setNQCETB6E_CD_USUA(strCodUser);
			req.setNQCETB6E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB6E_NR_SEQU_CAPO_SIST(strCodCamp.isEmpty()? null : Long.valueOf(strCodCamp));
			req.setNQCETB6E_NR_SEQU_PARM_FILT(strCodParam.isEmpty()? null : Long.valueOf(strCodParam));
			
			LegadoResult res = NQCETB06Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB06AreaDados> ret = decoder.parseRetorno(res, NQCETB06AreaDados.class, 83, 329);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String incluirParametro(String strCodSist, String strCodCamp, String strCodDomin, String strCntd1,
			String strCntd2, String strCodList, String strDesc, String strCodUser, String strDtIncAlt, String strAtivo) throws BusinessException {
		String json = "";
		try {
			NQCETB06LegadoRequest req = new NQCETB06LegadoRequest();
			req.setNQCETB6E_SG_FCAO("I");
			req.setNQCETB6E_CD_USUA(strCodUser);
			req.setNQCETB6E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB6E_NR_SEQU_CAPO_SIST(strCodCamp.isEmpty()? null : Long.valueOf(strCodCamp));
			req.setNQCETB6E_NR_SEQU_DOMI_OPER(strCodDomin.isEmpty()? null : Long.valueOf(strCodDomin));
			req.setNQCETB6E_TX_CNTD_INIC_PARM(strCntd1);
			req.setNQCETB6E_TX_CNTD_FINA_PARM(strCntd2);
			req.setNQCETB6E_NR_SEQU_LIST(strCodList.isEmpty()? null : Long.valueOf(strCodList));
			req.setNQCETB6E_DS_PARM(strDesc);
			req.setNQCETB6E_IN_PARM_ATIV(strAtivo);
			req.setNQCETB6E_CD_USUA_INCL_PARM(strCodUser);
			req.setNQCETB6E_DH_INCL_PARM(new Date().toString()); //TODO: verificar formatacao Data
			
			LegadoResult res = NQCETB06Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB06AreaDados> ret = decoder.parseRetorno(res, NQCETB06AreaDados.class, 83, 329);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String alterarParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodDomin,
			String strCntd1, String strCntd2, String strCodList, String strDesc, String strCodUser, String strDtIncAlt,
			String strAtivo) throws BusinessException {
		String json = "";
		try {
			NQCETB06LegadoRequest req = new NQCETB06LegadoRequest();
			req.setNQCETB6E_SG_FCAO("A");
			req.setNQCETB6E_CD_USUA(strCodUser);
			req.setNQCETB6E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB6E_NR_SEQU_CAPO_SIST(strCodCamp.isEmpty()? null : Long.valueOf(strCodCamp));
			req.setNQCETB6E_NR_SEQU_PARM_FILT(strCodParam.isEmpty()? null : Long.valueOf(strCodParam));
			req.setNQCETB6E_NR_SEQU_DOMI_OPER(strCodDomin.isEmpty()? null : Long.valueOf(strCodDomin));
			req.setNQCETB6E_TX_CNTD_INIC_PARM(strCntd1);
			req.setNQCETB6E_TX_CNTD_FINA_PARM(strCntd2);
			req.setNQCETB6E_NR_SEQU_LIST(strCodList.isEmpty()? null : Long.valueOf(strCodList));
			req.setNQCETB6E_DS_PARM(strDesc);
			req.setNQCETB6E_IN_PARM_ATIV(strAtivo);
			req.setNQCETB6E_CD_USUA_ALTR_PARM(strCodUser);
			req.setNQCETB6E_DH_ALTR_PARM(new Date().toString()); //TODO: verificar formatacao Data
			
			LegadoResult res = NQCETB06Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB06AreaDados> ret = decoder.parseRetorno(res, NQCETB06AreaDados.class, 83, 329);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String excluirParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodUser) throws BusinessException {
		String json = "";
		try {
			NQCETB06LegadoRequest req = new NQCETB06LegadoRequest();
			req.setNQCETB6E_SG_FCAO("E");
			req.setNQCETB6E_CD_USUA(strCodUser);
			req.setNQCETB6E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB6E_NR_SEQU_CAPO_SIST(strCodCamp.isEmpty()? null : Long.valueOf(strCodCamp));
			req.setNQCETB6E_NR_SEQU_PARM_FILT(strCodParam.isEmpty()? null : Long.valueOf(strCodParam));
			
			LegadoResult res = NQCETB06Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB06AreaDados> ret = decoder.parseRetorno(res, NQCETB06AreaDados.class, 83, 329);
			json =  new ObjectMapper().writeValueAsString(ret); 
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String inicializarinputArea(String TNQ_NQAT2006_NQCETB06_INPUT_AREA) {
		String json = "";
		return json;
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) {
		String json = "";
		return json;
	}

}
