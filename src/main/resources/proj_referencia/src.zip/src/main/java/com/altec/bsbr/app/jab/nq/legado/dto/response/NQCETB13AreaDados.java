package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB13AreaDados")
public class NQCETB13AreaDados {

	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*
	//
	//01     NQCETB13-SAIDA.                                           
		
	//03    NQCETB13-S-DATA.                                          
	//
	@PsFieldString(name = "NQCETB13_S_CD_BANC_CLIE", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_CD_BANC_CLIE;// 05 NQCETB13-S-CD-BANC-CLIE PIC X(004).
	
	//*       CODIGO DO BANCO                                           
	//
	@PsFieldString(name = "NQCETB13_S_CD_CLIE", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_CD_CLIE;// 05 NQCETB13-S-CD-CLIE PIC X(008).
	
	//*       CODIGO DO CLIENTE                                         
	//
	@PsFieldString(name = "NQCETB13_S_DT_MOVI", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_DT_MOVI;// 05 NQCETB13-S-DT-MOVI PIC X(010).
	
	//*       DATA DO MOVIMENTO                                         
	//
	@PsFieldString(name = "NQCETB13_S_NR_CNTR", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_NR_CNTR;// 05 NQCETB13-S-NR-CNTR PIC X(020).
	
	//*       NUMERO DO CONTRATO                                        
	//
	@PsFieldString(name = "NQCETB13_S_CD_CNTA_OPER", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_CD_CNTA_OPER;// 05 NQCETB13-S-CD-CNTA-OPER PIC X(020).
	
	//*       CODIGO DA CONTA DE OPERACAO                               
	//
	@PsFieldString(name = "NQCETB13_S_DT_FORZ", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_DT_FORZ;// 05 NQCETB13-S-DT-FORZ PIC X(010).
	
	//*       DATA DE FORMALIZACAO                                      
	//
	@PsFieldString(name = "NQCETB13_S_DT_INIC_VIGE", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_DT_INIC_VIGE;// 05 NQCETB13-S-DT-INIC-VIGE PIC X(010).
	
	//*       DATA DE INICIO DA VIGENCIA                                
	//
	@PsFieldString(name = "NQCETB13_S_DT_FIM_VIGE", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_DT_FIM_VIGE;// 05 NQCETB13-S-DT-FIM-VIGE PIC X(010).
	
	//*       DATA DE INICIO DA VIGENCIA                                
	//
	@PsFieldString(name = "NQCETB13_S_DT_LIQU", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_DT_LIQU;// 05 NQCETB13-S-DT-LIQU PIC X(010).
	
	//*       DATA DA LIQUIDACAO                                        
	//
	@PsFieldNumber(name = "NQCETB13_S_VL_CNTR", decimal = 3, length = 18, signed = true, defaultValue = "0")
	private Double NQCETB13_S_VL_CNTR;// 05 NQCETB13-S-VL-CNTR PIC S9(015)V99.
	
	//*       VALOR DO CONTRATO                                         
	//
	@PsFieldNumber(name = "NQCETB13_S_VL_LIQU", decimal = 3, length = 18, signed = true, defaultValue = "0")
	private Double NQCETB13_S_VL_LIQU;// 05 NQCETB13-S-VL-LIQU PIC S9(015)V99.
	
	//*       VALOR DA LIQUIDACAO                                       
	//
	@PsFieldString(name = "NQCETB13_S_NR_CNPJ_FORN", length = 15, paddingAlign = PsAlign.LEFT, paddingChar = '0')
	private String NQCETB13_S_NR_CNPJ_FORN;// 05 NQCETB13-S-NR-CNPJ-FORN PIC 9(015).
	
	//*       NUMERO DO CNPJ DO FORNECEDOR                              
	//
	@PsFieldString(name = "NQCETB13_S_CD_CNTA_FORN", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_CD_CNTA_FORN;// 05 NQCETB13-S-CD-CNTA-FORN PIC X(020).
	
	//*       CODIGO DA CONTA DO FORNECEDOR                             
	//
	@PsFieldString(name = "NQCETB13_S_TP_FORM_PGTO", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_TP_FORM_PGTO;// 05 NQCETB13-S-TP-FORM-PGTO PIC X(001).
	
	//*       TIPO DE FORMA DE PAGAMENTO                                
	//
	@PsFieldString(name = "NQCETB13_S_TP_TRAN", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_TP_TRAN;// 05 NQCETB13-S-TP-TRAN PIC X(001).
	
	//*       TIPO DE TRANSACAO                                         
	//
	@PsFieldString(name = "NQCETB13_S_CD_BANC_CNTR", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_CD_BANC_CNTR;// 05 NQCETB13-S-CD-BANC-CNTR PIC X(004).
	
	//*       CODIGO DO BANCO DO CONTRATO                               
	//
	@PsFieldString(name = "NQCETB13_S_CD_AGEN_CNTR", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_CD_AGEN_CNTR;// 05 NQCETB13-S-CD-AGEN-CNTR PIC X(004).
	
	//*       CODIGO DA AGENCIA DO CONTRATO                             
	//
	@PsFieldString(name = "NQCETB13_S_NR_CNTR_A", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_NR_CNTR_A;// 05 NQCETB13-S-NR-CNTR-A PIC X(020).
	
	//*       NUMERO DO CONTRATO ALTAIR                                 
	//
	@PsFieldString(name = "NQCETB13_S_CD_PROD_ALTAIR", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_CD_PROD_ALTAIR;// 05 NQCETB13-S-CD-PROD-ALTAIR PIC X(002).
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name = "NQCETB13_S_CD_SUBP_ALTAIR", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_CD_SUBP_ALTAIR;// 05 NQCETB13-S-CD-SUBP-ALTAIR PIC X(004).
	
	//*       CODIGO DO SUBPRODUTO                                      
	//
	@PsFieldString(name = "NQCETB13_S_CD_MOED", length = 3, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_CD_MOED;// 05 NQCETB13-S-CD-MOED PIC X(003).
	
	//*       CODIGO DA MOEDA                                           
	//
	@PsFieldNumber(name = "NQCETB13_S_NR_SEQU_OPER", decimal = 0, length = 3, signed = false, defaultValue = "0")
	private Long NQCETB13_S_NR_SEQU_OPER;// 05 NQCETB13-S-NR-SEQU-OPER PIC 9(003).
	
	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	@PsFieldString(name = "NQCETB13_S_CD_IDEF_OPER", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_CD_IDEF_OPER;// 05 NQCETB13-S-CD-IDEF-OPER PIC X(020).
	
	//*       CODIGO DA IDENTIFICACAO DA OPERACAO                       
	//
	@PsFieldString(name = "NQCETB13_S_NM_CLIE", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB13_S_NM_CLIE;// 05 NQCETB13-S-NM-CLIE PIC X(040).

	public String getNQCETB13_S_CD_BANC_CLIE() {
		return NQCETB13_S_CD_BANC_CLIE;
	}

	public void setNQCETB13_S_CD_BANC_CLIE(String nQCETB13_S_CD_BANC_CLIE) {
		NQCETB13_S_CD_BANC_CLIE = nQCETB13_S_CD_BANC_CLIE;
	}

	public String getNQCETB13_S_CD_CLIE() {
		return NQCETB13_S_CD_CLIE;
	}

	public void setNQCETB13_S_CD_CLIE(String nQCETB13_S_CD_CLIE) {
		NQCETB13_S_CD_CLIE = nQCETB13_S_CD_CLIE;
	}

	public String getNQCETB13_S_DT_MOVI() {
		return NQCETB13_S_DT_MOVI;
	}

	public void setNQCETB13_S_DT_MOVI(String nQCETB13_S_DT_MOVI) {
		NQCETB13_S_DT_MOVI = nQCETB13_S_DT_MOVI;
	}

	public String getNQCETB13_S_NR_CNTR() {
		return NQCETB13_S_NR_CNTR;
	}

	public void setNQCETB13_S_NR_CNTR(String nQCETB13_S_NR_CNTR) {
		NQCETB13_S_NR_CNTR = nQCETB13_S_NR_CNTR;
	}

	public String getNQCETB13_S_CD_CNTA_OPER() {
		return NQCETB13_S_CD_CNTA_OPER;
	}

	public void setNQCETB13_S_CD_CNTA_OPER(String nQCETB13_S_CD_CNTA_OPER) {
		NQCETB13_S_CD_CNTA_OPER = nQCETB13_S_CD_CNTA_OPER;
	}

	public String getNQCETB13_S_DT_FORZ() {
		return NQCETB13_S_DT_FORZ;
	}

	public void setNQCETB13_S_DT_FORZ(String nQCETB13_S_DT_FORZ) {
		NQCETB13_S_DT_FORZ = nQCETB13_S_DT_FORZ;
	}

	public String getNQCETB13_S_DT_INIC_VIGE() {
		return NQCETB13_S_DT_INIC_VIGE;
	}

	public void setNQCETB13_S_DT_INIC_VIGE(String nQCETB13_S_DT_INIC_VIGE) {
		NQCETB13_S_DT_INIC_VIGE = nQCETB13_S_DT_INIC_VIGE;
	}

	public String getNQCETB13_S_DT_FIM_VIGE() {
		return NQCETB13_S_DT_FIM_VIGE;
	}

	public void setNQCETB13_S_DT_FIM_VIGE(String nQCETB13_S_DT_FIM_VIGE) {
		NQCETB13_S_DT_FIM_VIGE = nQCETB13_S_DT_FIM_VIGE;
	}

	public String getNQCETB13_S_DT_LIQU() {
		return NQCETB13_S_DT_LIQU;
	}

	public void setNQCETB13_S_DT_LIQU(String nQCETB13_S_DT_LIQU) {
		NQCETB13_S_DT_LIQU = nQCETB13_S_DT_LIQU;
	}

	public Double getNQCETB13_S_VL_CNTR() {
		return NQCETB13_S_VL_CNTR;
	}

	public void setNQCETB13_S_VL_CNTR(Double nQCETB13_S_VL_CNTR) {
		NQCETB13_S_VL_CNTR = nQCETB13_S_VL_CNTR;
	}

	public Double getNQCETB13_S_VL_LIQU() {
		return NQCETB13_S_VL_LIQU;
	}

	public void setNQCETB13_S_VL_LIQU(Double nQCETB13_S_VL_LIQU) {
		NQCETB13_S_VL_LIQU = nQCETB13_S_VL_LIQU;
	}

	public String getNQCETB13_S_NR_CNPJ_FORN() {
		return NQCETB13_S_NR_CNPJ_FORN;
	}

	public void setNQCETB13_S_NR_CNPJ_FORN(String nQCETB13_S_NR_CNPJ_FORN) {
		NQCETB13_S_NR_CNPJ_FORN = nQCETB13_S_NR_CNPJ_FORN;
	}

	public String getNQCETB13_S_CD_CNTA_FORN() {
		return NQCETB13_S_CD_CNTA_FORN;
	}

	public void setNQCETB13_S_CD_CNTA_FORN(String nQCETB13_S_CD_CNTA_FORN) {
		NQCETB13_S_CD_CNTA_FORN = nQCETB13_S_CD_CNTA_FORN;
	}

	public String getNQCETB13_S_TP_FORM_PGTO() {
		return NQCETB13_S_TP_FORM_PGTO;
	}

	public void setNQCETB13_S_TP_FORM_PGTO(String nQCETB13_S_TP_FORM_PGTO) {
		NQCETB13_S_TP_FORM_PGTO = nQCETB13_S_TP_FORM_PGTO;
	}

	public String getNQCETB13_S_TP_TRAN() {
		return NQCETB13_S_TP_TRAN;
	}

	public void setNQCETB13_S_TP_TRAN(String nQCETB13_S_TP_TRAN) {
		NQCETB13_S_TP_TRAN = nQCETB13_S_TP_TRAN;
	}

	public String getNQCETB13_S_CD_BANC_CNTR() {
		return NQCETB13_S_CD_BANC_CNTR;
	}

	public void setNQCETB13_S_CD_BANC_CNTR(String nQCETB13_S_CD_BANC_CNTR) {
		NQCETB13_S_CD_BANC_CNTR = nQCETB13_S_CD_BANC_CNTR;
	}

	public String getNQCETB13_S_CD_AGEN_CNTR() {
		return NQCETB13_S_CD_AGEN_CNTR;
	}

	public void setNQCETB13_S_CD_AGEN_CNTR(String nQCETB13_S_CD_AGEN_CNTR) {
		NQCETB13_S_CD_AGEN_CNTR = nQCETB13_S_CD_AGEN_CNTR;
	}

	public String getNQCETB13_S_NR_CNTR_A() {
		return NQCETB13_S_NR_CNTR_A;
	}

	public void setNQCETB13_S_NR_CNTR_A(String nQCETB13_S_NR_CNTR_A) {
		NQCETB13_S_NR_CNTR_A = nQCETB13_S_NR_CNTR_A;
	}

	public String getNQCETB13_S_CD_PROD_ALTAIR() {
		return NQCETB13_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB13_S_CD_PROD_ALTAIR(String nQCETB13_S_CD_PROD_ALTAIR) {
		NQCETB13_S_CD_PROD_ALTAIR = nQCETB13_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB13_S_CD_SUBP_ALTAIR() {
		return NQCETB13_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB13_S_CD_SUBP_ALTAIR(String nQCETB13_S_CD_SUBP_ALTAIR) {
		NQCETB13_S_CD_SUBP_ALTAIR = nQCETB13_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB13_S_CD_MOED() {
		return NQCETB13_S_CD_MOED;
	}

	public void setNQCETB13_S_CD_MOED(String nQCETB13_S_CD_MOED) {
		NQCETB13_S_CD_MOED = nQCETB13_S_CD_MOED;
	}

	public Long getNQCETB13_S_NR_SEQU_OPER() {
		return NQCETB13_S_NR_SEQU_OPER;
	}

	public void setNQCETB13_S_NR_SEQU_OPER(Long nQCETB13_S_NR_SEQU_OPER) {
		NQCETB13_S_NR_SEQU_OPER = nQCETB13_S_NR_SEQU_OPER;
	}

	public String getNQCETB13_S_CD_IDEF_OPER() {
		return NQCETB13_S_CD_IDEF_OPER;
	}

	public void setNQCETB13_S_CD_IDEF_OPER(String nQCETB13_S_CD_IDEF_OPER) {
		NQCETB13_S_CD_IDEF_OPER = nQCETB13_S_CD_IDEF_OPER;
	}

	public String getNQCETB13_S_NM_CLIE() {
		return NQCETB13_S_NM_CLIE;
	}

	public void setNQCETB13_S_NM_CLIE(String nQCETB13_S_NM_CLIE) {
		NQCETB13_S_NM_CLIE = nQCETB13_S_NM_CLIE;
	}
	
	//*       NOME DO CLIENTE                                           
	//
	
	
}