package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.FiltrosACService;
import com.altec.bsbr.app.jab.nq.service.FiltrosACWebService;
import com.altec.bsbr.app.jab.nq.service.HistoricoService;
import com.altec.bsbr.app.jab.nq.service.HistoricoWebService;
import com.altec.bsbr.app.jab.nq.service.OcupacaoService;
import com.altec.bsbr.app.jab.nq.service.OcupacaoWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class OcupacaoEndPoint extends SpringBeanAutowiringSupport implements OcupacaoWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(OcupacaoEndPoint.class);
	@Autowired
	private OcupacaoService ocupacao;

	@WebMethod
	public String consOcupCadastradas(String intBanco, String intPeriodicidade) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = ocupacao.consOcupCadastradas(intBanco, intPeriodicidade);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String recuperaDados(String intOcupacao) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = ocupacao.recuperaDados(intOcupacao);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirOcupacao(String intBanco, String intPeriod, String intCodOcup, String strDescOcup,
			String strUserId) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = ocupacao.incluirOcupacao(intBanco, intPeriod, intCodOcup, strDescOcup, strUserId);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarBancoProdPeriod() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = ocupacao.consultarBancoProdPeriod();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String exclusaoOcupacao(String intBanco, String intPeriod, String intCodOcup, String strUsuario)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = ocupacao.exclusaoOcupacao(intBanco, intPeriod, intCodOcup, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

}
