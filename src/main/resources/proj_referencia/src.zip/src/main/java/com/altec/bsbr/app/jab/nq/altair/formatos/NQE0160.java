package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0160")
public class NQE0160 {
@PsFieldString(name="SGSISOR", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SGSISOR;
@PsFieldNumber(name="SQSISOR", length=2, defaultValue = "0" )
private Integer SQSISOR;
@PsFieldString(name="CDDETIN", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDDETIN;
@PsFieldString(name="DHFILTR", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DHFILTR;
@PsFieldString(name="TPOPER", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPOPER;
@PsFieldString(name="ICMONIT", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMONIT;
@PsFieldNumber(name="VLMINPR", length=15, decimal=2, defaultValue = "0" )
private double VLMINPR;
@PsFieldString(name="CDUSRES", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDUSRES;

public String getSGSISOR() {
 return SGSISOR;
}
public void setSGSISOR(String SGSISOR) {
 this.SGSISOR = SGSISOR;
}
public Integer getSQSISOR() {
 return SQSISOR;
}
public void setSQSISOR(Integer sQSISOR) {
SQSISOR = sQSISOR;
}
public String getCDDETIN() {
 return CDDETIN;
}
public void setCDDETIN(String CDDETIN) {
 this.CDDETIN = CDDETIN;
}

public String getDHFILTR() {
 return DHFILTR;
}
public void setDHFILTR(String DHFILTR) {
 this.DHFILTR = DHFILTR;
}

public String getTPOPER() {
 return TPOPER;
}
public void setTPOPER(String TPOPER) {
 this.TPOPER = TPOPER;
}

public String getICMONIT() {
 return ICMONIT;
}
public void setICMONIT(String ICMONIT) {
 this.ICMONIT = ICMONIT;
}
public double getVLMINPR() {
 return VLMINPR;
}
public void setVLMINPR(double vLMINPR) {
VLMINPR = vLMINPR;
}
public String getCDUSRES() {
 return CDUSRES;
}
public void setCDUSRES(String CDUSRES) {
 this.CDUSRES = CDUSRES;
}


}
