package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0090")
public class NQS0090 {
@PsFieldNumber(name="COENTID", length=4, defaultValue = "0" )
private Integer COENTID;
@PsFieldString(name="COALERT", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALERT;
@PsFieldNumber(name="NUSEQUE", length=3, defaultValue = "0" )
private Integer NUSEQUE;
@PsFieldString(name="DTCOMIT", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTCOMIT;
@PsFieldNumber(name="COPAREC", length=2, defaultValue = "0" )
private Integer COPAREC;
@PsFieldString(name="TXTPAR1", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPAR1;
@PsFieldString(name="TXTPAR2", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPAR2;
@PsFieldString(name="TXTPAR3", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPAR3;
@PsFieldString(name="TXTPAR4", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPAR4;
@PsFieldString(name="TXTPAR5", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPAR5;
@PsFieldString(name="TXTPAR6", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPAR6;
@PsFieldString(name="TXTPAR7", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPAR7;
@PsFieldString(name="TXTPAR8", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPAR8;
@PsFieldString(name="TXTPAR9", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPAR9;
@PsFieldString(name="TXTPA10", length=100, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TXTPA10;
public Integer getCOENTID() {
 return COENTID;
}
public void setCOENTID(Integer cOENTID) {
COENTID = cOENTID;
}
public String getCOALERT() {
 return COALERT;
}
public void setCOALERT(String COALERT) {
 this.COALERT = COALERT;
}
public Integer getNUSEQUE() {
 return NUSEQUE;
}
public void setNUSEQUE(Integer nUSEQUE) {
NUSEQUE = nUSEQUE;
}
public String getDTCOMIT() {
 return DTCOMIT;
}
public void setDTCOMIT(String DTCOMIT) {
 this.DTCOMIT = DTCOMIT;
}
public Integer getCOPAREC() {
 return COPAREC;
}
public void setCOPAREC(Integer cOPAREC) {
COPAREC = cOPAREC;
}
public String getTXTPAR1() {
 return TXTPAR1;
}
public void setTXTPAR1(String TXTPAR1) {
 this.TXTPAR1 = TXTPAR1;
}

public String getTXTPAR2() {
 return TXTPAR2;
}
public void setTXTPAR2(String TXTPAR2) {
 this.TXTPAR2 = TXTPAR2;
}

public String getTXTPAR3() {
 return TXTPAR3;
}
public void setTXTPAR3(String TXTPAR3) {
 this.TXTPAR3 = TXTPAR3;
}

public String getTXTPAR4() {
 return TXTPAR4;
}
public void setTXTPAR4(String TXTPAR4) {
 this.TXTPAR4 = TXTPAR4;
}

public String getTXTPAR5() {
 return TXTPAR5;
}
public void setTXTPAR5(String TXTPAR5) {
 this.TXTPAR5 = TXTPAR5;
}

public String getTXTPAR6() {
 return TXTPAR6;
}
public void setTXTPAR6(String TXTPAR6) {
 this.TXTPAR6 = TXTPAR6;
}

public String getTXTPAR7() {
 return TXTPAR7;
}
public void setTXTPAR7(String TXTPAR7) {
 this.TXTPAR7 = TXTPAR7;
}

public String getTXTPAR8() {
 return TXTPAR8;
}
public void setTXTPAR8(String TXTPAR8) {
 this.TXTPAR8 = TXTPAR8;
}

public String getTXTPAR9() {
 return TXTPAR9;
}
public void setTXTPAR9(String TXTPAR9) {
 this.TXTPAR9 = TXTPAR9;
}

public String getTXTPA10() {
 return TXTPA10;
}
public void setTXTPA10(String TXTPA10) {
 this.TXTPA10 = TXTPA10;
}


}
