package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE6200LegadoRequest {
	/*
// -*-NQCE6200
//         01      RECEIVE-COMMAREA.                                                                                              
	@FixedLenghtField(position = 572, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_PGM_CHAMADA;//                 03  COMM-PGM-CHAMADA      PIC  X(008).                   

	@FixedLenghtField(position = 573, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOMEDATS;//                 03  COMM-NOMEDATS         PIC  X(010).                   

	@FixedLenghtField(position = 574, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_TAM_COMM;//                 03  COMM-TAM-COMM         PIC  9(007).                   

	@FixedLenghtField(position = 575, lenght = 9, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_MATRICULA;//                 03  COMM-MATRICULA        PIC  9(009).                   

	@FixedLenghtField(position = 576, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CINSTIT;//                 03  COMM-CINSTIT          PIC  9(003).                   

	@FixedLenghtField(position = 577, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CODAGENC;//                 03  COMM-CODAGENC         PIC  9(004).                   

//  INDRA1*        03  COMM-CCLI             PIC  9(010).                   
	@FixedLenghtField(position = 578, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 03;//  INDRA1         03  COMM-CCLI             PIC  X(008).                   

	@FixedLenghtField(position = 579, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 03;//  INDRA1         03  COMM-FILLER           PIC  X(002).                   

	@FixedLenghtField(position = 580, lenght = 10, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_NUMCONTA;//                 03  COMM-NUMCONTA         PIC  9(010).                                                                                 

//         01      SEND-AREA.                                                                                                          
	@FixedLenghtField(position = 581, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN;//                 03  TS01-MENS-LEN         PIC S9(004) COMP VALUE +83.    

//                 03  TS01-AREA-MENSAGEM.                                  
	@FixedLenghtField(position = 582, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO;//                     05  TS01-RETORNO      PIC  9(003) VALUE ZEROS.       

	@FixedLenghtField(position = 583, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM;//                     05  TS01-MENSAGEM     PIC  X(080) VALUE SPACES.                                                                      

	@FixedLenghtField(position = 584, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 03;//  PJ0004         03  TS02-MENS-LEN         PIC S9(004) COMP VALUE +310.   

//                 03  TS02-AREA-DETALHE.                                   
	@FixedLenghtField(position = 585, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NOME_AGENCIA;//                     05 TS02-NOME-AGENCIA  PIC  X(050).                   

	@FixedLenghtField(position = 586, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NOME_REDE;//                     05 TS02-NOME-REDE     PIC  X(050).                   

	@FixedLenghtField(position = 587, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NOME_CLI;//                     05 TS02-NOME-CLI      PIC  X(050).                   

	@FixedLenghtField(position = 588, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_DTABER_CC;//                     05 TS02-DTABER-CC     PIC  9(008).                   

	@FixedLenghtField(position = 589, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_RAMO_ATIV;//                     05 TS02-RAMO-ATIV     PIC  X(050).                   

	@FixedLenghtField(position = 590, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_TPPESSOA;//                     05 TS02-TPPESSOA      PIC  X(001).                   

	@FixedLenghtField(position = 591, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_DATA_VIS;//                     05 TS02-DATA-VIS      PIC  9(008).                   

	@FixedLenghtField(position = 592, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_DATA_REF;//                     05 TS02-DATA-REF      PIC  9(008).                   

	@FixedLenghtField(position = 593, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 05;//  PJ0004             05 TS02-COD-SEG       PIC  9(005).                   

	@FixedLenghtField(position = 594, lenght = 15, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_SEGMENTO;//                     05 TS02-SEGMENTO      PIC  X(015).                   

	@FixedLenghtField(position = 595, lenght = 15, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_VLR_RENFAT;//                     05 TS02-VLR-RENFAT    PIC  X(015).                   

	@FixedLenghtField(position = 596, lenght = 20, paddingAlign = Align.LEFT, paddingChar = '0')
	private String TS02_CPFCNPJ;//                     05 TS02-CPFCNPJ       PIC  X(020).                   

	@FixedLenghtField(position = 597, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 05;//  PJ0004             05 TS02-CARTEIRA      PIC  X(015).                   

	@FixedLenghtField(position = 598, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 05;//  PJ0004             05 TS02-GERENTE       PIC  X(015).                   

	public NQCE6200LegadoRequest() { }
	public NQCE6200LegadoRequest(String comm_pgm_chamada, String comm_nomedats, Long comm_tam_comm, Long comm_matricula, Long comm_cinstit, Long comm_codagenc, String 03, String 03, Long comm_numconta, String ts02_nome_agencia, String ts02_nome_rede, String ts02_nome_cli, Long ts02_dtaber_cc, String ts02_ramo_ativ, String ts02_tppessoa, Long ts02_data_vis, Long ts02_data_ref, Long 05, String ts02_segmento, String ts02_vlr_renfat, String ts02_cpfcnpj, String 05, String 05) { 		this.COMM_PGM_CHAMADA = comm_pgm_chamada;
		this.COMM_NOMEDATS = comm_nomedats;
		this.COMM_TAM_COMM = comm_tam_comm;
		this.COMM_MATRICULA = comm_matricula;
		this.COMM_CINSTIT = comm_cinstit;
		this.COMM_CODAGENC = comm_codagenc;
		this.03 = 03;
		this.03 = 03;
		this.COMM_NUMCONTA = comm_numconta;
		this.TS01_MENS_LEN = +83;
		this.TS01_RETORNO = ZEROS;
		this.TS01_MENSAGEM = SPACES;
		this.03 = +310;
		this.TS02_NOME_AGENCIA = ts02_nome_agencia;
		this.TS02_NOME_REDE = ts02_nome_rede;
		this.TS02_NOME_CLI = ts02_nome_cli;
		this.TS02_DTABER_CC = ts02_dtaber_cc;
		this.TS02_RAMO_ATIV = ts02_ramo_ativ;
		this.TS02_TPPESSOA = ts02_tppessoa;
		this.TS02_DATA_VIS = ts02_data_vis;
		this.TS02_DATA_REF = ts02_data_ref;
		this.05 = 05;
		this.TS02_SEGMENTO = ts02_segmento;
		this.TS02_VLR_RENFAT = ts02_vlr_renfat;
		this.TS02_CPFCNPJ = ts02_cpfcnpj;
		this.05 = 05;
		this.05 = 05; 
	}
	public String getCOMM_PGM_CHAMADA() { return this.COMM_PGM_CHAMADA; }
	public String getCOMM_NOMEDATS() { return this.COMM_NOMEDATS; }
	public Long getCOMM_TAM_COMM() { return this.COMM_TAM_COMM; }
	public Long getCOMM_MATRICULA() { return this.COMM_MATRICULA; }
	public Long getCOMM_CINSTIT() { return this.COMM_CINSTIT; }
	public Long getCOMM_CODAGENC() { return this.COMM_CODAGENC; }
	public String get03() { return this.03; }
	public String get03() { return this.03; }
	public Long getCOMM_NUMCONTA() { return this.COMM_NUMCONTA; }
	public Long getTS01_MENS_LEN() { return this.TS01_MENS_LEN; }
	public Long getTS01_RETORNO() { return this.TS01_RETORNO; }
	public String getTS01_MENSAGEM() { return this.TS01_MENSAGEM; }
	public Long get03() { return this.03; }
	public String getTS02_NOME_AGENCIA() { return this.TS02_NOME_AGENCIA; }
	public String getTS02_NOME_REDE() { return this.TS02_NOME_REDE; }
	public String getTS02_NOME_CLI() { return this.TS02_NOME_CLI; }
	public Long getTS02_DTABER_CC() { return this.TS02_DTABER_CC; }
	public String getTS02_RAMO_ATIV() { return this.TS02_RAMO_ATIV; }
	public String getTS02_TPPESSOA() { return this.TS02_TPPESSOA; }
	public Long getTS02_DATA_VIS() { return this.TS02_DATA_VIS; }
	public Long getTS02_DATA_REF() { return this.TS02_DATA_REF; }
	public Long get05() { return this.05; }
	public String getTS02_SEGMENTO() { return this.TS02_SEGMENTO; }
	public String getTS02_VLR_RENFAT() { return this.TS02_VLR_RENFAT; }
	public String getTS02_CPFCNPJ() { return this.TS02_CPFCNPJ; }
	public String get05() { return this.05; }
	public String get05() { return this.05; }
	public void setCOMM_PGM_CHAMADA(String comm_pgm_chamada) { this.COMM_PGM_CHAMADA = comm_pgm_chamada; }
	public void setCOMM_NOMEDATS(String comm_nomedats) { this.COMM_NOMEDATS = comm_nomedats; }
	public void setCOMM_TAM_COMM(Long comm_tam_comm) { this.COMM_TAM_COMM = comm_tam_comm; }
	public void setCOMM_MATRICULA(Long comm_matricula) { this.COMM_MATRICULA = comm_matricula; }
	public void setCOMM_CINSTIT(Long comm_cinstit) { this.COMM_CINSTIT = comm_cinstit; }
	public void setCOMM_CODAGENC(Long comm_codagenc) { this.COMM_CODAGENC = comm_codagenc; }
	public void set03(String 03) { this.03 = 03; }
	public void set03(String 03) { this.03 = 03; }
	public void setCOMM_NUMCONTA(Long comm_numconta) { this.COMM_NUMCONTA = comm_numconta; }
	public void setTS01_MENS_LEN(Long ts01_mens_len) { this.TS01_MENS_LEN = ts01_mens_len; }
	public void setTS01_RETORNO(Long ts01_retorno) { this.TS01_RETORNO = ts01_retorno; }
	public void setTS01_MENSAGEM(String ts01_mensagem) { this.TS01_MENSAGEM = ts01_mensagem; }
	public void set03(Long 03) { this.03 = 03; }
	public void setTS02_NOME_AGENCIA(String ts02_nome_agencia) { this.TS02_NOME_AGENCIA = ts02_nome_agencia; }
	public void setTS02_NOME_REDE(String ts02_nome_rede) { this.TS02_NOME_REDE = ts02_nome_rede; }
	public void setTS02_NOME_CLI(String ts02_nome_cli) { this.TS02_NOME_CLI = ts02_nome_cli; }
	public void setTS02_DTABER_CC(Long ts02_dtaber_cc) { this.TS02_DTABER_CC = ts02_dtaber_cc; }
	public void setTS02_RAMO_ATIV(String ts02_ramo_ativ) { this.TS02_RAMO_ATIV = ts02_ramo_ativ; }
	public void setTS02_TPPESSOA(String ts02_tppessoa) { this.TS02_TPPESSOA = ts02_tppessoa; }
	public void setTS02_DATA_VIS(Long ts02_data_vis) { this.TS02_DATA_VIS = ts02_data_vis; }
	public void setTS02_DATA_REF(Long ts02_data_ref) { this.TS02_DATA_REF = ts02_data_ref; }
	public void set05(Long 05) { this.05 = 05; }
	public void setTS02_SEGMENTO(String ts02_segmento) { this.TS02_SEGMENTO = ts02_segmento; }
	public void setTS02_VLR_RENFAT(String ts02_vlr_renfat) { this.TS02_VLR_RENFAT = ts02_vlr_renfat; }
	public void setTS02_CPFCNPJ(String ts02_cpfcnpj) { this.TS02_CPFCNPJ = ts02_cpfcnpj; }
	public void set05(String 05) { this.05 = 05; }
	public void set05(String 05) { this.05 = 05; }
	*/
}