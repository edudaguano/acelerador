package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.OcupacaoDao;
import com.altec.bsbr.app.jab.nq.service.OcupacaoService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class OcupacaoServiceImpl implements OcupacaoService {
	private final Logger LOGGER = LoggerFactory.getLogger(OcupacaoServiceImpl.class);
	@Autowired
	private OcupacaoDao ocupacao;
	
	@Override
	public String consOcupCadastradas(String intBanco, String intPeriodicidade) throws BusinessException {
		return ocupacao.consOcupCadastradas(intBanco, intPeriodicidade);
	}
	
	@Override
	public String recuperaDados(String intOcupacao) throws BusinessException {
		return ocupacao.recuperaDados(intOcupacao);
	}
	
	@Override
	public String incluirOcupacao(String intBanco, String intPeriod, String intCodOcup, String strDescOcup,
			String strUserId) throws BusinessException {
		return ocupacao.incluirOcupacao(intBanco, intPeriod, intCodOcup, strDescOcup, strUserId);
	}
	
	@Override
	public String consultarBancoProdPeriod() throws BusinessException {
		return ocupacao.consultarBancoProdPeriod();
	}
	
	@Override
	public String exclusaoOcupacao(String intBanco, String intPeriod, String intCodOcup, String strUsuario)
			throws BusinessException {
		return ocupacao.exclusaoOcupacao(intBanco, intPeriod, intCodOcup, strUsuario);
	}
	
}
