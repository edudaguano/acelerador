package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name= "NQCETB18LegadoRequest")
public class NQCETB18LegadoRequest {
// -*-
//        01     NQCETB18-ENTRADA.                                         
//                                                                         
	@PsFieldString(name= "NQCETB18_E_NM_PROG", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_E_NM_PROG;//          05   NQCETB18-E-NM-PROG            PIC  X(008).                

//       *       NOME DO PROGRAMA CHAMADO                                  
//                                                                         
	@PsFieldString(name= "NQCETB18_E_NM_AREA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_E_NM_AREA;//          05   NQCETB18-E-NM-AREA            PIC  X(008).                

//       *       NOME DA AREA DE TS                                        
//                                                                         
	@PsFieldString(name= "NQCETB18_E_SG_FCAO", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_E_SG_FCAO;//          05   NQCETB18-E-SG-FCAO            PIC  X(002).                

//       *       FUNCAO A SER EXECUTADA                                    
//       *       L = LISTAR                                                
//       *       C = CONSULTA                                              
//                                                                         
	@PsFieldNumber(name= "NQCETB18_E_QT_TAMA_AREA", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long NQCETB18_E_QT_TAMA_AREA;//          05   NQCETB18-E-QT-TAMA-AREA       PIC  9(007).                

//       *       TAMANHO DA AREA DE TS                                     
//                                                                         
	@PsFieldString(name= "NQCETB18_E_CD_USUA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_E_CD_USUA;//          05   NQCETB18-E-CD-USUA            PIC  X(008).                

//       *       CODIGO DO USUARIO                                         
//                                                                         
	@PsFieldNumber(name= "NQCETB18_E_NR_SEQU_SIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB18_E_NR_SEQU_SIST;//          05   NQCETB18-E-NR-SEQU-SIST       PIC  9(004).                

//       *       NUMERO SEQUENCIAL DO SISTEMA                              
//                                                                         
	@PsFieldString(name= "NQCETB18_E_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_E_CD_BANC_CLIE;//          05   NQCETB18-E-CD-BANC-CLIE       PIC  X(004).                

//       *       CODIGO DO BANCO                                           
//                                                                         
	@PsFieldString(name= "NQCETB18_E_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_E_CD_CLIE;//          05   NQCETB18-E-CD-CLIE            PIC  X(008).                

//       *       CODIGO DO CLIENTE                                         
//                                                                         
	@PsFieldString(name= "NQCETB18_E_DT_INICIO", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_E_DT_INICIO;//          05   NQCETB18-E-DT-INICIO          PIC  X(010).                

//       *       DATA INICIO DO PERIODO                                    
//                                                                         
	@PsFieldString(name= "NQCETB18_E_DT_FIM", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB18_E_DT_FIM;//          05   NQCETB18-E-DT-FIM             PIC  X(010).                

//       *       DATA FIM DO PERIODO                                       
//                                                                         
	@PsFieldNumber(name= "NQCETB18_E_NR_PROP", decimal= 0, length= 10, signed= false, defaultValue="0")
	private Long NQCETB18_E_NR_PROP;//          05   NQCETB18-E-NR-PROP            PIC  9(010).                

//       *       NUMERO DA PROPOSTA                                        
//                                                                         
	@PsFieldNumber(name= "NQCETB18_E_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB18_E_NR_SEQU_OPER;//          05   NQCETB18-E-NR-SEQU-OPER       PIC  9(003).                
                                                                         
	public NQCETB18LegadoRequest() { }

	public String getNQCETB18_E_NM_PROG() {
		return NQCETB18_E_NM_PROG;
	}

	public void setNQCETB18_E_NM_PROG(String nQCETB18_E_NM_PROG) {
		NQCETB18_E_NM_PROG = nQCETB18_E_NM_PROG;
	}

	public String getNQCETB18_E_NM_AREA() {
		return NQCETB18_E_NM_AREA;
	}

	public void setNQCETB18_E_NM_AREA(String nQCETB18_E_NM_AREA) {
		NQCETB18_E_NM_AREA = nQCETB18_E_NM_AREA;
	}

	public String getNQCETB18_E_SG_FCAO() {
		return NQCETB18_E_SG_FCAO;
	}

	public void setNQCETB18_E_SG_FCAO(String nQCETB18_E_SG_FCAO) {
		NQCETB18_E_SG_FCAO = nQCETB18_E_SG_FCAO;
	}

	public Long getNQCETB18_E_QT_TAMA_AREA() {
		return NQCETB18_E_QT_TAMA_AREA;
	}

	public void setNQCETB18_E_QT_TAMA_AREA(Long nQCETB18_E_QT_TAMA_AREA) {
		NQCETB18_E_QT_TAMA_AREA = nQCETB18_E_QT_TAMA_AREA;
	}

	public String getNQCETB18_E_CD_USUA() {
		return NQCETB18_E_CD_USUA;
	}

	public void setNQCETB18_E_CD_USUA(String nQCETB18_E_CD_USUA) {
		NQCETB18_E_CD_USUA = nQCETB18_E_CD_USUA;
	}

	public Long getNQCETB18_E_NR_SEQU_SIST() {
		return NQCETB18_E_NR_SEQU_SIST;
	}

	public void setNQCETB18_E_NR_SEQU_SIST(Long nQCETB18_E_NR_SEQU_SIST) {
		NQCETB18_E_NR_SEQU_SIST = nQCETB18_E_NR_SEQU_SIST;
	}

	public String getNQCETB18_E_CD_BANC_CLIE() {
		return NQCETB18_E_CD_BANC_CLIE;
	}

	public void setNQCETB18_E_CD_BANC_CLIE(String nQCETB18_E_CD_BANC_CLIE) {
		NQCETB18_E_CD_BANC_CLIE = nQCETB18_E_CD_BANC_CLIE;
	}

	public String getNQCETB18_E_CD_CLIE() {
		return NQCETB18_E_CD_CLIE;
	}

	public void setNQCETB18_E_CD_CLIE(String nQCETB18_E_CD_CLIE) {
		NQCETB18_E_CD_CLIE = nQCETB18_E_CD_CLIE;
	}

	public String getNQCETB18_E_DT_INICIO() {
		return NQCETB18_E_DT_INICIO;
	}

	public void setNQCETB18_E_DT_INICIO(String nQCETB18_E_DT_INICIO) {
		NQCETB18_E_DT_INICIO = nQCETB18_E_DT_INICIO;
	}

	public String getNQCETB18_E_DT_FIM() {
		return NQCETB18_E_DT_FIM;
	}

	public void setNQCETB18_E_DT_FIM(String nQCETB18_E_DT_FIM) {
		NQCETB18_E_DT_FIM = nQCETB18_E_DT_FIM;
	}

	public Long getNQCETB18_E_NR_PROP() {
		return NQCETB18_E_NR_PROP;
	}

	public void setNQCETB18_E_NR_PROP(Long nQCETB18_E_NR_PROP) {
		NQCETB18_E_NR_PROP = nQCETB18_E_NR_PROP;
	}

	public Long getNQCETB18_E_NR_SEQU_OPER() {
		return NQCETB18_E_NR_SEQU_OPER;
	}

	public void setNQCETB18_E_NR_SEQU_OPER(Long nQCETB18_E_NR_SEQU_OPER) {
		NQCETB18_E_NR_SEQU_OPER = nQCETB18_E_NR_SEQU_OPER;
	}


}