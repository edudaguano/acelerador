package com.altec.bsbr.app.jab.nq.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0050;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0050;
import com.altec.bsbr.app.jab.nq.dao.ComunicNormalDao;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ComunicNormalDaoImpl implements ComunicNormalDao {
	private final Logger LOGGER = LoggerFactory.getLogger(ComunicNormalDaoImpl.class);

	@Autowired
	private AltairService altairService;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String versao() {
		return "";
	}

	public String enviaMensagem(String strCDENTID, String strCDAGENC, String strCDALERT, String strCDUNIOR,
			String strTPUNIOR, String strTXPAR01, String strTXPAR02, String strTXPAR03, String strTXPAR04,
			String strTXPAR05, String strTXPAR06, String strTXPAR07, String strTXPAR08, String strTXPAR09,
			String strTXPAR10, String strTPPAREC, String strDTCOMIT, String strCDUSRES, String strNUSEQUE,
			String strTPCHAMA) {
		NQE0050 request = new NQE0050();
		request.setCDENTID(strCDENTID);
		request.setCDAGENC(strCDAGENC);
		request.setCDALERT(strCDALERT);
		request.setCDUNIOR(strCDUNIOR.isEmpty()? null : Integer.valueOf(strCDUNIOR));
		request.setTPUNIOR(strTPUNIOR.isEmpty()? null : Integer.valueOf(strTPUNIOR));
		request.setTXPAR01(strTXPAR01);
		request.setTXPAR02(strTXPAR02);
		request.setTXPAR03(strTXPAR03);
		request.setTXPAR04(strTXPAR04);
		request.setTXPAR05(strTXPAR05);
		request.setTXPAR06(strTXPAR06);
		request.setTXPAR07(strTXPAR07);
		request.setTXPAR08(strTXPAR08);
		request.setTXPAR09(strTXPAR09);
		request.setTXPAR10(strTXPAR10);
		request.setTPPAREC(strTPPAREC.isEmpty()? null : Integer.valueOf(strTPPAREC));
		request.setDTCOMIT(strDTCOMIT);
		request.setCDUSRES(strCDUSRES);
		request.setNUSEQUE(strNUSEQUE.isEmpty()? null : Integer.valueOf(strNUSEQUE));
		request.setTPCHAMA(strTPCHAMA);
		
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQA7", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0050.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

}
