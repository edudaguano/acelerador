package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface AnaliseACService {
	public String consultarAnalises(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser, String strFuncao) throws BusinessException;

	public String listarPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser) throws BusinessException;

	public String listarClientes(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser) throws BusinessException;

	public String fnAddCaracter(String vlr, String tp, String tam) throws BusinessException;

	public String dataAlta(String dtBaixa) throws BusinessException;
}
