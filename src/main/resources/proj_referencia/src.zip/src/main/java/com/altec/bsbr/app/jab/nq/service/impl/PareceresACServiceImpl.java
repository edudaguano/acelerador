package com.altec.bsbr.app.jab.nq.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.app.jab.nq.dao.PareceresACDao;
import com.altec.bsbr.app.jab.nq.service.PareceresACService;


@Service
public class PareceresACServiceImpl implements PareceresACService {
	
	private final Logger LOGGER = LoggerFactory.getLogger(PareceresACServiceImpl.class);
	
	@Autowired
	private PareceresACDao pareceresac;

	@Override
	public String consultarRegistros(String strCodSist, String strBanco, String strCodCliente, String strDtOcorrenca,
			String strNotUPLD, String strRegra, String strIndParecer, String strPeriodo, String strCodUser) throws BusinessException {
		System.out.println("consulta service");
		return pareceresac.consultarRegistros(strCodSist, strBanco, strCodCliente, strDtOcorrenca, strNotUPLD, strRegra,
				strIndParecer, strPeriodo, strCodUser);
	}

	@Override
	public String incluirPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorrenca,
			String strNotUPLD, String strRegra, String strIndParecer, String strPeriodo, String strTxtParecer,
			String strCodUser) throws BusinessException {
		return pareceresac.incluirPareceres(strCodSist, strBanco, strCodCliente, strDtOcorrenca, strNotUPLD, strRegra,
				strIndParecer, strPeriodo, strTxtParecer, strCodUser);
	}

	@Override
	public String alterarPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorrenca,
			String strNotUPLD, String strRegra, String strIndParecer, String strPeriodo, String strTxtParecer,
			String strCodUser) throws BusinessException {
		return pareceresac.alterarPareceres(strCodSist, strBanco, strCodCliente, strDtOcorrenca, strNotUPLD, strRegra,
				strIndParecer, strPeriodo, strTxtParecer, strCodUser);
	}

	@Override
	public String inicializarinputArea(String tNQ_NQAT2010_NQCETB10_Entrada) throws BusinessException{ 
		return pareceresac.inicializarinputArea(tNQ_NQAT2010_NQCETB10_Entrada);
	}

	@Override
	public String fnAddCaracter(String vlr, String tp, String tam) throws BusinessException{ 
		return pareceresac.fnAddCaracter(vlr, tp,  tam);
	}
	
	@Override
	public String dataAlta(String dtBaixa) throws BusinessException{ 
		return pareceresac.dataAlta(dtBaixa);
	}
}
