package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name= "NQCE6016")
public class NQCE6016LegadoRequest {
	/*
// -*-NQCE6016
//         01      RECEIVE-COMMAREA.                                        
	@PsFieldString(name= "COMM_PGM_CHAMADA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String COMM_PGM_CHAMADA;//                 03  COMM-PGM-CHAMADA      PIC  X(008).                   

	@PsFieldString(name= "COMM_NOMEDATS", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String COMM_NOMEDATS;//                 03  COMM-NOMEDATS         PIC  X(010).                   

	@PsFieldNumber(name= "COMM_TAM_COMM", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long COMM_TAM_COMM;//                 03  COMM-TAM-COMM         PIC  9(007).                   

	@PsFieldNumber(name= "03", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long 03;//  NB2612         03  COMM-CODAGENC         PIC  9(004).                   

	@PsFieldNumber(name= "COMM_MATRICULA", decimal= 0, length= 9, signed= false, defaultValue="0")
	private Long COMM_MATRICULA;//                 03  COMM-MATRICULA        PIC  9(009).                   

	@PsFieldNumber(name= "COMM_CINSTIT", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long COMM_CINSTIT;//                 03  COMM-CINSTIT          PIC  9(003).                   

	@PsFieldNumber(name= "03", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long 03;//  PJ0004         03  COMM-CCLI             PIC  9(010).                   

	@PsFieldNumber(name= "COMM_DATAMOVI", decimal= 0, length= 8, signed= false, defaultValue="0")
	private Long COMM_DATAMOVI;//                 03  COMM-DATAMOVI         PIC  9(008).                   

//         01      SEND-AREA.                                               
	@PsFieldNumber(name= "TS01_MENS_LEN", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long TS01_MENS_LEN;//                 03  TS01-MENS-LEN         PIC S9(004) COMP VALUE +83.    

//                 03  TS01-AREA-MENSAGEM.                                  
	@PsFieldNumber(name= "TS01_RETORNO", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long TS01_RETORNO;//                     05  TS01-RETORNO      PIC  9(003) VALUE ZEROS.       

	@PsFieldString(name= "TS01_MENSAGEM", length= 80, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String TS01_MENSAGEM;//                     05  TS01-MENSAGEM     PIC  X(080) VALUE SPACES.                                                                    

	@PsFieldNumber(name= "03", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long 03;//  PJ0004         03  TS02-MENS-LEN         PIC S9(004) COMP VALUE +150.   

//                 03  TS02-AREA-DETALHE.                                   
	@PsFieldNumber(name= "TS02_CINSTIT", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long TS02_CINSTIT;//                     05 TS02-CINSTIT       PIC  9(003).                   

	@PsFieldNumber(name= "TS02_CODAGENC", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long TS02_CODAGENC;//                     05 TS02-CODAGENC      PIC  9(004).                   

	@PsFieldNumber(name= "TS02_CPROD", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long TS02_CPROD;//                     05 TS02-CPROD         PIC  9(004).                   

	@PsFieldNumber(name= "TS02_NUMCONTA", decimal= 0, length= 10, signed= false, defaultValue="0")
	private Long TS02_NUMCONTA;//                     05 TS02-NUMCONTA      PIC  9(010).                   

	@PsFieldNumber(name= "TS02_DATAMOVI", decimal= 0, length= 8, signed= false, defaultValue="0")
	private Long TS02_DATAMOVI;//                     05 TS02-DATAMOVI      PIC  9(008).                   

	@PsFieldNumber(name= "TS02_CSEQUE", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long TS02_CSEQUE;//                     05 TS02-CSEQUE        PIC  9(003).                   

	@PsFieldNumber(name= "TS02_HISTORIC", decimal= 0, length= 5, signed= false, defaultValue="0")
	private Long TS02_HISTORIC;//                     05 TS02-HISTORIC      PIC  9(005).                   

	@PsFieldNumber(name= "TS02_NUMDOCUM", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long TS02_NUMDOCUM;//                     05 TS02-NUMDOCUM      PIC  9(007).                   

	@PsFieldString(name= "TS02_CGCCPF", length= 15, paddingAlign= PsAlign.LEFT, paddingChar= '0')
	private String TS02_CGCCPF;//                     05 TS02-CGCCPF        PIC  9(015).                   

	@PsFieldNumber(name= "TS02_TIPOPESS", decimal= 0, length= 1, signed= false, defaultValue="0")
	private Long TS02_TIPOPESS;//                     05 TS02-TIPOPESS      PIC  9(001).                   

	@PsFieldString(name= "TS02_NCLI", length= 35, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String TS02_NCLI;//                     05 TS02-NCLI          PIC  X(035).                   

	@PsFieldNumber(name= "TS02_VALORLAN", decimal= 2, length= 13, signed= true, defaultValue="0")
	private Double TS02_VALORLAN;//                     05 TS02-VALORLAN      PIC  9(011)V99.                

	@PsFieldNumber(name= "TS02_CCLI", decimal= 0, length= 10, signed= false, defaultValue="0")
	private Long TS02_CCLI;//                     05 TS02-CCLI          PIC  9(010).                   

	@PsFieldNumber(name= "TS02_SITMOVIM", decimal= 0, length= 1, signed= false, defaultValue="0")
	private Long TS02_SITMOVIM;//                     05 TS02-SITMOVIM      PIC  9(001).                   

	@PsFieldString(name= "TS02_USERID", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String TS02_USERID;//                     05 TS02-USERID        PIC  X(008).                   

	@PsFieldNumber(name= "TS02_DATAJUST", decimal= 0, length= 8, signed= false, defaultValue="0")
	private Long TS02_DATAJUST;//                     05 TS02-DATAJUST      PIC  9(008).                   

	@PsFieldNumber(name= "TS02_HORAJUST", decimal= 0, length= 6, signed= false, defaultValue="0")
	private Long TS02_HORAJUST;//                     05 TS02-HORAJUST      PIC  9(006).                   

	@PsFieldString(name= "TS02_PEND", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String TS02_PEND;//                     05 TS02-PEND          PIC  X(001).                   

	@PsFieldString(name= "TS02_TPISEN", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String TS02_TPISEN;//                     05 TS02-TPISEN        PIC  X(001).                   

	@PsFieldString(name= "TS02_POSTO", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String TS02_POSTO;//                     05 TS02-POSTO         PIC  X(002).                   

	@PsFieldNumber(name= "TS02_TPCONTA", decimal= 0, length= 5, signed= false, defaultValue="0")
	private Long TS02_TPCONTA;//                     05 TS02-TPCONTA       PIC  9(005).                   

	public NQCE6016LegadoRequest() { }
	public NQCE6016LegadoRequest(String comm_pgm_chamada, String comm_nomedats, Long comm_tam_comm, Long 03, Long comm_matricula, Long comm_cinstit, Long 03, Long comm_datamovi, Long ts02_cinstit, Long ts02_codagenc, Long ts02_cprod, Long ts02_numconta, Long ts02_datamovi, Long ts02_cseque, Long ts02_historic, Long ts02_numdocum, String ts02_cgccpf, Long ts02_tipopess, String ts02_ncli, Double ts02_valorlan, Long ts02_ccli, Long ts02_sitmovim, String ts02_userid, Long ts02_datajust, Long ts02_horajust, String ts02_pend, String ts02_tpisen, String ts02_posto, Long ts02_tpconta) { 		this.COMM_PGM_CHAMADA = comm_pgm_chamada;
		this.COMM_NOMEDATS = comm_nomedats;
		this.COMM_TAM_COMM = comm_tam_comm;
		this.03 = 03;
		this.COMM_MATRICULA = comm_matricula;
		this.COMM_CINSTIT = comm_cinstit;
		this.03 = 03;
		this.COMM_DATAMOVI = comm_datamovi;
		this.TS01_MENS_LEN = +83;
		this.TS01_RETORNO = ZEROS;
		this.TS01_MENSAGEM = SPACES;
		this.03 = +150;
		this.TS02_CINSTIT = ts02_cinstit;
		this.TS02_CODAGENC = ts02_codagenc;
		this.TS02_CPROD = ts02_cprod;
		this.TS02_NUMCONTA = ts02_numconta;
		this.TS02_DATAMOVI = ts02_datamovi;
		this.TS02_CSEQUE = ts02_cseque;
		this.TS02_HISTORIC = ts02_historic;
		this.TS02_NUMDOCUM = ts02_numdocum;
		this.TS02_CGCCPF = ts02_cgccpf;
		this.TS02_TIPOPESS = ts02_tipopess;
		this.TS02_NCLI = ts02_ncli;
		this.TS02_VALORLAN = ts02_valorlan;
		this.TS02_CCLI = ts02_ccli;
		this.TS02_SITMOVIM = ts02_sitmovim;
		this.TS02_USERID = ts02_userid;
		this.TS02_DATAJUST = ts02_datajust;
		this.TS02_HORAJUST = ts02_horajust;
		this.TS02_PEND = ts02_pend;
		this.TS02_TPISEN = ts02_tpisen;
		this.TS02_POSTO = ts02_posto;
		this.TS02_TPCONTA = ts02_tpconta; 
	}
	public String getCOMM_PGM_CHAMADA() { return this.COMM_PGM_CHAMADA; }
	public String getCOMM_NOMEDATS() { return this.COMM_NOMEDATS; }
	public Long getCOMM_TAM_COMM() { return this.COMM_TAM_COMM; }
	public Long get03() { return this.03; }
	public Long getCOMM_MATRICULA() { return this.COMM_MATRICULA; }
	public Long getCOMM_CINSTIT() { return this.COMM_CINSTIT; }
	public Long get03() { return this.03; }
	public Long getCOMM_DATAMOVI() { return this.COMM_DATAMOVI; }
	public Long getTS01_MENS_LEN() { return this.TS01_MENS_LEN; }
	public Long getTS01_RETORNO() { return this.TS01_RETORNO; }
	public String getTS01_MENSAGEM() { return this.TS01_MENSAGEM; }
	public Long get03() { return this.03; }
	public Long getTS02_CINSTIT() { return this.TS02_CINSTIT; }
	public Long getTS02_CODAGENC() { return this.TS02_CODAGENC; }
	public Long getTS02_CPROD() { return this.TS02_CPROD; }
	public Long getTS02_NUMCONTA() { return this.TS02_NUMCONTA; }
	public Long getTS02_DATAMOVI() { return this.TS02_DATAMOVI; }
	public Long getTS02_CSEQUE() { return this.TS02_CSEQUE; }
	public Long getTS02_HISTORIC() { return this.TS02_HISTORIC; }
	public Long getTS02_NUMDOCUM() { return this.TS02_NUMDOCUM; }
	public String getTS02_CGCCPF() { return this.TS02_CGCCPF; }
	public Long getTS02_TIPOPESS() { return this.TS02_TIPOPESS; }
	public String getTS02_NCLI() { return this.TS02_NCLI; }
	public Double getTS02_VALORLAN() { return this.TS02_VALORLAN; }
	public Long getTS02_CCLI() { return this.TS02_CCLI; }
	public Long getTS02_SITMOVIM() { return this.TS02_SITMOVIM; }
	public String getTS02_USERID() { return this.TS02_USERID; }
	public Long getTS02_DATAJUST() { return this.TS02_DATAJUST; }
	public Long getTS02_HORAJUST() { return this.TS02_HORAJUST; }
	public String getTS02_PEND() { return this.TS02_PEND; }
	public String getTS02_TPISEN() { return this.TS02_TPISEN; }
	public String getTS02_POSTO() { return this.TS02_POSTO; }
	public Long getTS02_TPCONTA() { return this.TS02_TPCONTA; }
	public void setCOMM_PGM_CHAMADA(String comm_pgm_chamada) { this.COMM_PGM_CHAMADA = comm_pgm_chamada; }
	public void setCOMM_NOMEDATS(String comm_nomedats) { this.COMM_NOMEDATS = comm_nomedats; }
	public void setCOMM_TAM_COMM(Long comm_tam_comm) { this.COMM_TAM_COMM = comm_tam_comm; }
	public void set03(Long 03) { this.03 = 03; }
	public void setCOMM_MATRICULA(Long comm_matricula) { this.COMM_MATRICULA = comm_matricula; }
	public void setCOMM_CINSTIT(Long comm_cinstit) { this.COMM_CINSTIT = comm_cinstit; }
	public void set03(Long 03) { this.03 = 03; }
	public void setCOMM_DATAMOVI(Long comm_datamovi) { this.COMM_DATAMOVI = comm_datamovi; }
	public void setTS01_MENS_LEN(Long ts01_mens_len) { this.TS01_MENS_LEN = ts01_mens_len; }
	public void setTS01_RETORNO(Long ts01_retorno) { this.TS01_RETORNO = ts01_retorno; }
	public void setTS01_MENSAGEM(String ts01_mensagem) { this.TS01_MENSAGEM = ts01_mensagem; }
	public void set03(Long 03) { this.03 = 03; }
	public void setTS02_CINSTIT(Long ts02_cinstit) { this.TS02_CINSTIT = ts02_cinstit; }
	public void setTS02_CODAGENC(Long ts02_codagenc) { this.TS02_CODAGENC = ts02_codagenc; }
	public void setTS02_CPROD(Long ts02_cprod) { this.TS02_CPROD = ts02_cprod; }
	public void setTS02_NUMCONTA(Long ts02_numconta) { this.TS02_NUMCONTA = ts02_numconta; }
	public void setTS02_DATAMOVI(Long ts02_datamovi) { this.TS02_DATAMOVI = ts02_datamovi; }
	public void setTS02_CSEQUE(Long ts02_cseque) { this.TS02_CSEQUE = ts02_cseque; }
	public void setTS02_HISTORIC(Long ts02_historic) { this.TS02_HISTORIC = ts02_historic; }
	public void setTS02_NUMDOCUM(Long ts02_numdocum) { this.TS02_NUMDOCUM = ts02_numdocum; }
	public void setTS02_CGCCPF(String ts02_cgccpf) { this.TS02_CGCCPF = ts02_cgccpf; }
	public void setTS02_TIPOPESS(Long ts02_tipopess) { this.TS02_TIPOPESS = ts02_tipopess; }
	public void setTS02_NCLI(String ts02_ncli) { this.TS02_NCLI = ts02_ncli; }
	public void setTS02_VALORLAN(Double ts02_valorlan) { this.TS02_VALORLAN = ts02_valorlan; }
	public void setTS02_CCLI(Long ts02_ccli) { this.TS02_CCLI = ts02_ccli; }
	public void setTS02_SITMOVIM(Long ts02_sitmovim) { this.TS02_SITMOVIM = ts02_sitmovim; }
	public void setTS02_USERID(String ts02_userid) { this.TS02_USERID = ts02_userid; }
	public void setTS02_DATAJUST(Long ts02_datajust) { this.TS02_DATAJUST = ts02_datajust; }
	public void setTS02_HORAJUST(Long ts02_horajust) { this.TS02_HORAJUST = ts02_horajust; }
	public void setTS02_PEND(String ts02_pend) { this.TS02_PEND = ts02_pend; }
	public void setTS02_TPISEN(String ts02_tpisen) { this.TS02_TPISEN = ts02_tpisen; }
	public void setTS02_POSTO(String ts02_posto) { this.TS02_POSTO = ts02_posto; }
	public void setTS02_TPCONTA(Long ts02_tpconta) { this.TS02_TPCONTA = ts02_tpconta; }
	*/
}