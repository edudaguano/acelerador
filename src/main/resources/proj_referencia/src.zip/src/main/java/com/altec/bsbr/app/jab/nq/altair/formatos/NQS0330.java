package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0330")
public class NQS0330 {
@PsFieldNumber(name="NUMAT01", length=11, defaultValue = "0" )
private Long NUMAT01;
@PsFieldString(name="NOFUN01", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN01;
@PsFieldString(name="DSCAR01", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR01;
@PsFieldNumber(name="NUMAT02", length=11, defaultValue = "0" )
private Long NUMAT02;
@PsFieldString(name="NOFUN02", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN02;
@PsFieldString(name="DSCAR02", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR02;
@PsFieldNumber(name="NUMAT03", length=11, defaultValue = "0" )
private Long NUMAT03;
@PsFieldString(name="NOFUN03", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN03;
@PsFieldString(name="DSCAR03", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR03;
@PsFieldNumber(name="NUMAT04", length=11, defaultValue = "0" )
private Long NUMAT04;
@PsFieldString(name="NOFUN04", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN04;
@PsFieldString(name="DSCAR04", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR04;
@PsFieldNumber(name="NUMAT05", length=11, defaultValue = "0" )
private Long NUMAT05;
@PsFieldString(name="NOFUN05", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN05;
@PsFieldString(name="DSCAR05", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR05;
@PsFieldNumber(name="NUMAT06", length=11, defaultValue = "0" )
private Long NUMAT06;
@PsFieldString(name="NOFUN06", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN06;
@PsFieldString(name="DSCAR06", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR06;
@PsFieldNumber(name="NUMAT07", length=11, defaultValue = "0" )
private Long NUMAT07;
@PsFieldString(name="NOFUN07", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN07;
@PsFieldString(name="DSCAR07", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR07;
@PsFieldNumber(name="NUMAT08", length=11, defaultValue = "0" )
private Long NUMAT08;
@PsFieldString(name="NOFUN08", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN08;
@PsFieldString(name="DSCAR08", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR08;
@PsFieldNumber(name="NUMAT09", length=11, defaultValue = "0" )
private Long NUMAT09;
@PsFieldString(name="NOFUN09", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN09;
@PsFieldString(name="DSCAR09", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR09;
@PsFieldNumber(name="NUMAT10", length=11, defaultValue = "0" )
private Long NUMAT10;
@PsFieldString(name="NOFUN10", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN10;
@PsFieldString(name="DSCAR10", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR10;
@PsFieldNumber(name="NUMAT11", length=11, defaultValue = "0" )
private Long NUMAT11;
@PsFieldString(name="NOFUN11", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN11;
@PsFieldString(name="DSCAR11", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR11;
@PsFieldNumber(name="NUMAT12", length=11, defaultValue = "0" )
private Long NUMAT12;
@PsFieldString(name="NOFUN12", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN12;
@PsFieldString(name="DSCAR12", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR12;
@PsFieldNumber(name="NUMAT13", length=11, defaultValue = "0" )
private Long NUMAT13;
@PsFieldString(name="NOFUN13", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN13;
@PsFieldString(name="DSCAR13", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR13;
@PsFieldNumber(name="NUMAT14", length=11, defaultValue = "0" )
private Long NUMAT14;
@PsFieldString(name="NOFUN14", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN14;
@PsFieldString(name="DSCAR14", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR14;
@PsFieldNumber(name="NUMAT15", length=11, defaultValue = "0" )
private Long NUMAT15;
@PsFieldString(name="NOFUN15", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN15;
@PsFieldString(name="DSCAR15", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR15;
@PsFieldNumber(name="NUMAT16", length=11, defaultValue = "0" )
private Long NUMAT16;
@PsFieldString(name="NOFUN16", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN16;
@PsFieldString(name="DSCAR16", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR16;
@PsFieldNumber(name="NUMAT17", length=11, defaultValue = "0" )
private Long NUMAT17;
@PsFieldString(name="NOFUN17", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN17;
@PsFieldString(name="DSCAR17", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR17;
@PsFieldNumber(name="NUMAT18", length=11, defaultValue = "0" )
private Long NUMAT18;
@PsFieldString(name="NOFUN18", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN18;
@PsFieldString(name="DSCAR18", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR18;
@PsFieldNumber(name="NUMAT19", length=11, defaultValue = "0" )
private Long NUMAT19;
@PsFieldString(name="NOFUN19", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN19;
@PsFieldString(name="DSCAR19", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR19;
@PsFieldNumber(name="NUMAT20", length=11, defaultValue = "0" )
private Long NUMAT20;
@PsFieldString(name="NOFUN20", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOFUN20;
@PsFieldString(name="DSCAR20", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCAR20;
public Long getNUMAT01() {
 return NUMAT01;
}
public void setNUMAT01(Long nUMAT01) {
NUMAT01 = nUMAT01;
}
public String getNOFUN01() {
 return NOFUN01;
}
public void setNOFUN01(String NOFUN01) {
 this.NOFUN01 = NOFUN01;
}

public String getDSCAR01() {
 return DSCAR01;
}
public void setDSCAR01(String DSCAR01) {
 this.DSCAR01 = DSCAR01;
}
public Long getNUMAT02() {
 return NUMAT02;
}
public void setNUMAT02(Long nUMAT02) {
NUMAT02 = nUMAT02;
}
public String getNOFUN02() {
 return NOFUN02;
}
public void setNOFUN02(String NOFUN02) {
 this.NOFUN02 = NOFUN02;
}

public String getDSCAR02() {
 return DSCAR02;
}
public void setDSCAR02(String DSCAR02) {
 this.DSCAR02 = DSCAR02;
}
public Long getNUMAT03() {
 return NUMAT03;
}
public void setNUMAT03(Long nUMAT03) {
NUMAT03 = nUMAT03;
}
public String getNOFUN03() {
 return NOFUN03;
}
public void setNOFUN03(String NOFUN03) {
 this.NOFUN03 = NOFUN03;
}

public String getDSCAR03() {
 return DSCAR03;
}
public void setDSCAR03(String DSCAR03) {
 this.DSCAR03 = DSCAR03;
}
public Long getNUMAT04() {
 return NUMAT04;
}
public void setNUMAT04(Long nUMAT04) {
NUMAT04 = nUMAT04;
}
public String getNOFUN04() {
 return NOFUN04;
}
public void setNOFUN04(String NOFUN04) {
 this.NOFUN04 = NOFUN04;
}

public String getDSCAR04() {
 return DSCAR04;
}
public void setDSCAR04(String DSCAR04) {
 this.DSCAR04 = DSCAR04;
}
public Long getNUMAT05() {
 return NUMAT05;
}
public void setNUMAT05(Long nUMAT05) {
NUMAT05 = nUMAT05;
}
public String getNOFUN05() {
 return NOFUN05;
}
public void setNOFUN05(String NOFUN05) {
 this.NOFUN05 = NOFUN05;
}

public String getDSCAR05() {
 return DSCAR05;
}
public void setDSCAR05(String DSCAR05) {
 this.DSCAR05 = DSCAR05;
}
public Long getNUMAT06() {
 return NUMAT06;
}
public void setNUMAT06(Long nUMAT06) {
NUMAT06 = nUMAT06;
}
public String getNOFUN06() {
 return NOFUN06;
}
public void setNOFUN06(String NOFUN06) {
 this.NOFUN06 = NOFUN06;
}

public String getDSCAR06() {
 return DSCAR06;
}
public void setDSCAR06(String DSCAR06) {
 this.DSCAR06 = DSCAR06;
}
public Long getNUMAT07() {
 return NUMAT07;
}
public void setNUMAT07(Long nUMAT07) {
NUMAT07 = nUMAT07;
}
public String getNOFUN07() {
 return NOFUN07;
}
public void setNOFUN07(String NOFUN07) {
 this.NOFUN07 = NOFUN07;
}

public String getDSCAR07() {
 return DSCAR07;
}
public void setDSCAR07(String DSCAR07) {
 this.DSCAR07 = DSCAR07;
}
public Long getNUMAT08() {
 return NUMAT08;
}
public void setNUMAT08(Long nUMAT08) {
NUMAT08 = nUMAT08;
}
public String getNOFUN08() {
 return NOFUN08;
}
public void setNOFUN08(String NOFUN08) {
 this.NOFUN08 = NOFUN08;
}

public String getDSCAR08() {
 return DSCAR08;
}
public void setDSCAR08(String DSCAR08) {
 this.DSCAR08 = DSCAR08;
}
public Long getNUMAT09() {
 return NUMAT09;
}
public void setNUMAT09(Long nUMAT09) {
NUMAT09 = nUMAT09;
}
public String getNOFUN09() {
 return NOFUN09;
}
public void setNOFUN09(String NOFUN09) {
 this.NOFUN09 = NOFUN09;
}

public String getDSCAR09() {
 return DSCAR09;
}
public void setDSCAR09(String DSCAR09) {
 this.DSCAR09 = DSCAR09;
}
public Long getNUMAT10() {
 return NUMAT10;
}
public void setNUMAT10(Long nUMAT10) {
NUMAT10 = nUMAT10;
}
public String getNOFUN10() {
 return NOFUN10;
}
public void setNOFUN10(String NOFUN10) {
 this.NOFUN10 = NOFUN10;
}

public String getDSCAR10() {
 return DSCAR10;
}
public void setDSCAR10(String DSCAR10) {
 this.DSCAR10 = DSCAR10;
}
public Long getNUMAT11() {
 return NUMAT11;
}
public void setNUMAT11(Long nUMAT11) {
NUMAT11 = nUMAT11;
}
public String getNOFUN11() {
 return NOFUN11;
}
public void setNOFUN11(String NOFUN11) {
 this.NOFUN11 = NOFUN11;
}

public String getDSCAR11() {
 return DSCAR11;
}
public void setDSCAR11(String DSCAR11) {
 this.DSCAR11 = DSCAR11;
}
public Long getNUMAT12() {
 return NUMAT12;
}
public void setNUMAT12(Long nUMAT12) {
NUMAT12 = nUMAT12;
}
public String getNOFUN12() {
 return NOFUN12;
}
public void setNOFUN12(String NOFUN12) {
 this.NOFUN12 = NOFUN12;
}

public String getDSCAR12() {
 return DSCAR12;
}
public void setDSCAR12(String DSCAR12) {
 this.DSCAR12 = DSCAR12;
}
public Long getNUMAT13() {
 return NUMAT13;
}
public void setNUMAT13(Long nUMAT13) {
NUMAT13 = nUMAT13;
}
public String getNOFUN13() {
 return NOFUN13;
}
public void setNOFUN13(String NOFUN13) {
 this.NOFUN13 = NOFUN13;
}

public String getDSCAR13() {
 return DSCAR13;
}
public void setDSCAR13(String DSCAR13) {
 this.DSCAR13 = DSCAR13;
}
public Long getNUMAT14() {
 return NUMAT14;
}
public void setNUMAT14(Long nUMAT14) {
NUMAT14 = nUMAT14;
}
public String getNOFUN14() {
 return NOFUN14;
}
public void setNOFUN14(String NOFUN14) {
 this.NOFUN14 = NOFUN14;
}

public String getDSCAR14() {
 return DSCAR14;
}
public void setDSCAR14(String DSCAR14) {
 this.DSCAR14 = DSCAR14;
}
public Long getNUMAT15() {
 return NUMAT15;
}
public void setNUMAT15(Long nUMAT15) {
NUMAT15 = nUMAT15;
}
public String getNOFUN15() {
 return NOFUN15;
}
public void setNOFUN15(String NOFUN15) {
 this.NOFUN15 = NOFUN15;
}

public String getDSCAR15() {
 return DSCAR15;
}
public void setDSCAR15(String DSCAR15) {
 this.DSCAR15 = DSCAR15;
}
public Long getNUMAT16() {
 return NUMAT16;
}
public void setNUMAT16(Long nUMAT16) {
NUMAT16 = nUMAT16;
}
public String getNOFUN16() {
 return NOFUN16;
}
public void setNOFUN16(String NOFUN16) {
 this.NOFUN16 = NOFUN16;
}

public String getDSCAR16() {
 return DSCAR16;
}
public void setDSCAR16(String DSCAR16) {
 this.DSCAR16 = DSCAR16;
}
public Long getNUMAT17() {
 return NUMAT17;
}
public void setNUMAT17(Long nUMAT17) {
NUMAT17 = nUMAT17;
}
public String getNOFUN17() {
 return NOFUN17;
}
public void setNOFUN17(String NOFUN17) {
 this.NOFUN17 = NOFUN17;
}

public String getDSCAR17() {
 return DSCAR17;
}
public void setDSCAR17(String DSCAR17) {
 this.DSCAR17 = DSCAR17;
}
public Long getNUMAT18() {
 return NUMAT18;
}
public void setNUMAT18(Long nUMAT18) {
NUMAT18 = nUMAT18;
}
public String getNOFUN18() {
 return NOFUN18;
}
public void setNOFUN18(String NOFUN18) {
 this.NOFUN18 = NOFUN18;
}

public String getDSCAR18() {
 return DSCAR18;
}
public void setDSCAR18(String DSCAR18) {
 this.DSCAR18 = DSCAR18;
}
public Long getNUMAT19() {
 return NUMAT19;
}
public void setNUMAT19(Long nUMAT19) {
NUMAT19 = nUMAT19;
}
public String getNOFUN19() {
 return NOFUN19;
}
public void setNOFUN19(String NOFUN19) {
 this.NOFUN19 = NOFUN19;
}

public String getDSCAR19() {
 return DSCAR19;
}
public void setDSCAR19(String DSCAR19) {
 this.DSCAR19 = DSCAR19;
}
public Long getNUMAT20() {
 return NUMAT20;
}
public void setNUMAT20(Long nUMAT20) {
NUMAT20 = nUMAT20;
}
public String getNOFUN20() {
 return NOFUN20;
}
public void setNOFUN20(String NOFUN20) {
 this.NOFUN20 = NOFUN20;
}

public String getDSCAR20() {
 return DSCAR20;
}
public void setDSCAR20(String DSCAR20) {
 this.DSCAR20 = DSCAR20;
}


}
