package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0240")
public class NQS0240 {
@PsFieldString(name="CODCENP", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODCENP;
@PsFieldString(name="CDCEN01", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN01;
@PsFieldString(name="DSCEN01", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN01;
@PsFieldString(name="CDCEN02", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN02;
@PsFieldString(name="DSCEN02", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN02;
@PsFieldString(name="CDCEN03", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN03;
@PsFieldString(name="DSCEN03", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN03;
@PsFieldString(name="CDCEN04", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN04;
@PsFieldString(name="DSCEN04", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN04;
@PsFieldString(name="CDCEN05", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN05;
@PsFieldString(name="DSCEN05", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN05;
@PsFieldString(name="CDCEN06", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN06;
@PsFieldString(name="DSCEN06", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN06;
@PsFieldString(name="CDCEN07", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN07;
@PsFieldString(name="DSCEN07", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN07;
@PsFieldString(name="CDCEN08", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN08;
@PsFieldString(name="DSCEN08", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN08;
@PsFieldString(name="CDCEN09", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN09;
@PsFieldString(name="DSCEN09", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN09;
@PsFieldString(name="CDCEN10", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN10;
@PsFieldString(name="DSCEN10", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN10;
@PsFieldString(name="CDCEN11", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN11;
@PsFieldString(name="DSCEN11", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN11;
@PsFieldString(name="CDCEN12", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN12;
@PsFieldString(name="DSCEN12", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN12;
@PsFieldString(name="CDCEN13", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN13;
@PsFieldString(name="DSCEN13", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN13;
@PsFieldString(name="CDCEN14", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN14;
@PsFieldString(name="DSCEN14", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN14;
@PsFieldString(name="CDCEN15", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN15;
@PsFieldString(name="DSCEN15", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN15;
@PsFieldString(name="CDCEN16", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN16;
@PsFieldString(name="DSCEN16", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN16;
@PsFieldString(name="CDCEN17", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN17;
@PsFieldString(name="DSCEN17", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN17;
@PsFieldString(name="CDCEN18", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN18;
@PsFieldString(name="DSCEN18", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN18;
@PsFieldString(name="CDCEN19", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN19;
@PsFieldString(name="DSCEN19", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN19;
@PsFieldString(name="CDCEN20", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCEN20;
@PsFieldString(name="DSCEN20", length=50, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSCEN20;

public String getCODCENP() {
 return CODCENP;
}
public void setCODCENP(String CODCENP) {
 this.CODCENP = CODCENP;
}

public String getCDCEN01() {
 return CDCEN01;
}
public void setCDCEN01(String CDCEN01) {
 this.CDCEN01 = CDCEN01;
}

public String getDSCEN01() {
 return DSCEN01;
}
public void setDSCEN01(String DSCEN01) {
 this.DSCEN01 = DSCEN01;
}

public String getCDCEN02() {
 return CDCEN02;
}
public void setCDCEN02(String CDCEN02) {
 this.CDCEN02 = CDCEN02;
}

public String getDSCEN02() {
 return DSCEN02;
}
public void setDSCEN02(String DSCEN02) {
 this.DSCEN02 = DSCEN02;
}

public String getCDCEN03() {
 return CDCEN03;
}
public void setCDCEN03(String CDCEN03) {
 this.CDCEN03 = CDCEN03;
}

public String getDSCEN03() {
 return DSCEN03;
}
public void setDSCEN03(String DSCEN03) {
 this.DSCEN03 = DSCEN03;
}

public String getCDCEN04() {
 return CDCEN04;
}
public void setCDCEN04(String CDCEN04) {
 this.CDCEN04 = CDCEN04;
}

public String getDSCEN04() {
 return DSCEN04;
}
public void setDSCEN04(String DSCEN04) {
 this.DSCEN04 = DSCEN04;
}

public String getCDCEN05() {
 return CDCEN05;
}
public void setCDCEN05(String CDCEN05) {
 this.CDCEN05 = CDCEN05;
}

public String getDSCEN05() {
 return DSCEN05;
}
public void setDSCEN05(String DSCEN05) {
 this.DSCEN05 = DSCEN05;
}

public String getCDCEN06() {
 return CDCEN06;
}
public void setCDCEN06(String CDCEN06) {
 this.CDCEN06 = CDCEN06;
}

public String getDSCEN06() {
 return DSCEN06;
}
public void setDSCEN06(String DSCEN06) {
 this.DSCEN06 = DSCEN06;
}

public String getCDCEN07() {
 return CDCEN07;
}
public void setCDCEN07(String CDCEN07) {
 this.CDCEN07 = CDCEN07;
}

public String getDSCEN07() {
 return DSCEN07;
}
public void setDSCEN07(String DSCEN07) {
 this.DSCEN07 = DSCEN07;
}

public String getCDCEN08() {
 return CDCEN08;
}
public void setCDCEN08(String CDCEN08) {
 this.CDCEN08 = CDCEN08;
}

public String getDSCEN08() {
 return DSCEN08;
}
public void setDSCEN08(String DSCEN08) {
 this.DSCEN08 = DSCEN08;
}

public String getCDCEN09() {
 return CDCEN09;
}
public void setCDCEN09(String CDCEN09) {
 this.CDCEN09 = CDCEN09;
}

public String getDSCEN09() {
 return DSCEN09;
}
public void setDSCEN09(String DSCEN09) {
 this.DSCEN09 = DSCEN09;
}

public String getCDCEN10() {
 return CDCEN10;
}
public void setCDCEN10(String CDCEN10) {
 this.CDCEN10 = CDCEN10;
}

public String getDSCEN10() {
 return DSCEN10;
}
public void setDSCEN10(String DSCEN10) {
 this.DSCEN10 = DSCEN10;
}

public String getCDCEN11() {
 return CDCEN11;
}
public void setCDCEN11(String CDCEN11) {
 this.CDCEN11 = CDCEN11;
}

public String getDSCEN11() {
 return DSCEN11;
}
public void setDSCEN11(String DSCEN11) {
 this.DSCEN11 = DSCEN11;
}

public String getCDCEN12() {
 return CDCEN12;
}
public void setCDCEN12(String CDCEN12) {
 this.CDCEN12 = CDCEN12;
}

public String getDSCEN12() {
 return DSCEN12;
}
public void setDSCEN12(String DSCEN12) {
 this.DSCEN12 = DSCEN12;
}

public String getCDCEN13() {
 return CDCEN13;
}
public void setCDCEN13(String CDCEN13) {
 this.CDCEN13 = CDCEN13;
}

public String getDSCEN13() {
 return DSCEN13;
}
public void setDSCEN13(String DSCEN13) {
 this.DSCEN13 = DSCEN13;
}

public String getCDCEN14() {
 return CDCEN14;
}
public void setCDCEN14(String CDCEN14) {
 this.CDCEN14 = CDCEN14;
}

public String getDSCEN14() {
 return DSCEN14;
}
public void setDSCEN14(String DSCEN14) {
 this.DSCEN14 = DSCEN14;
}

public String getCDCEN15() {
 return CDCEN15;
}
public void setCDCEN15(String CDCEN15) {
 this.CDCEN15 = CDCEN15;
}

public String getDSCEN15() {
 return DSCEN15;
}
public void setDSCEN15(String DSCEN15) {
 this.DSCEN15 = DSCEN15;
}

public String getCDCEN16() {
 return CDCEN16;
}
public void setCDCEN16(String CDCEN16) {
 this.CDCEN16 = CDCEN16;
}

public String getDSCEN16() {
 return DSCEN16;
}
public void setDSCEN16(String DSCEN16) {
 this.DSCEN16 = DSCEN16;
}

public String getCDCEN17() {
 return CDCEN17;
}
public void setCDCEN17(String CDCEN17) {
 this.CDCEN17 = CDCEN17;
}

public String getDSCEN17() {
 return DSCEN17;
}
public void setDSCEN17(String DSCEN17) {
 this.DSCEN17 = DSCEN17;
}

public String getCDCEN18() {
 return CDCEN18;
}
public void setCDCEN18(String CDCEN18) {
 this.CDCEN18 = CDCEN18;
}

public String getDSCEN18() {
 return DSCEN18;
}
public void setDSCEN18(String DSCEN18) {
 this.DSCEN18 = DSCEN18;
}

public String getCDCEN19() {
 return CDCEN19;
}
public void setCDCEN19(String CDCEN19) {
 this.CDCEN19 = CDCEN19;
}

public String getDSCEN19() {
 return DSCEN19;
}
public void setDSCEN19(String DSCEN19) {
 this.DSCEN19 = DSCEN19;
}

public String getCDCEN20() {
 return CDCEN20;
}
public void setCDCEN20(String CDCEN20) {
 this.CDCEN20 = CDCEN20;
}

public String getDSCEN20() {
 return DSCEN20;
}
public void setDSCEN20(String DSCEN20) {
 this.DSCEN20 = DSCEN20;
}


}
