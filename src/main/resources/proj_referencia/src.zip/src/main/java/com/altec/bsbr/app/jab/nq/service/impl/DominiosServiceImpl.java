package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.DominiosDao;
import com.altec.bsbr.app.jab.nq.service.DominiosService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class DominiosServiceImpl implements DominiosService {
	private final Logger LOGGER = LoggerFactory.getLogger(DominiosServiceImpl.class);
	
	@Autowired
	private DominiosDao dominios;

	public String listarDominio(String strCodUser) throws BusinessException {
		return dominios.listarDominio(strCodUser);
	}

	public String consultarDominio(String strCodDom, String strCodUser) throws BusinessException {
		return dominios.consultarDominio(strCodDom, strCodUser);
	}

	public String incluirDominio(String strVlrDom, String strDesDom, String strTpUsuDom, String strIndDomAtv,
			String strCodUser) throws BusinessException {
		return dominios.incluirDominio(strVlrDom, strDesDom, strTpUsuDom, strIndDomAtv, strCodUser);
	}

	public String alterarDominio(String strCodDom, String strVlrDom, String strDesDom, String strTpUsuDom,
			String strIndDomAtv, String strCodUser) throws BusinessException {
		return dominios.alterarDominio(strCodDom, strVlrDom, strDesDom, strTpUsuDom, strIndDomAtv, strCodUser);
	}

	public String excluirDominio(String strCodDom, String strCodUser) throws BusinessException {
		return dominios.excluirDominio(strCodDom, strCodUser);
	}

	public String inicializarinputArea(String tNQ_NQAT2005_NQCETB05_ENTRADA) throws BusinessException {
		return dominios.inicializarinputArea(tNQ_NQAT2005_NQCETB05_ENTRADA);
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws BusinessException {
		return dominios.fnAddCaracter(Vlr, Tp, Tam);
	}
}
