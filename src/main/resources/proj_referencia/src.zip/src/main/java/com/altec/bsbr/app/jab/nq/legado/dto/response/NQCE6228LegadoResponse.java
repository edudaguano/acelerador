package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE6228LegadoResponse {
	/*
// -*-NQCE6228
//         01      RECEIVE-COMMAREA.                                        
	@FixedLenghtField(position = 808, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_PGM_CHAMADA;//                 03  COMM-PGM-CHAMADA      PIC  X(008).                   

	@FixedLenghtField(position = 809, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOMEDATS;//                 03  COMM-NOMEDATS         PIC  X(010).                   

	@FixedLenghtField(position = 810, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_TAM_COMM;//                 03  COMM-TAM-COMM         PIC  9(007).                   

//         01      SEND-AREA.                                               
	@FixedLenghtField(position = 811, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN;//                 03  TS01-MENS-LEN         PIC S9(004) COMP VALUE +83.    

//                 03  TS01-AREA-MENSAGEM.                                  
	@FixedLenghtField(position = 812, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO;//                     05  TS01-RETORNO      PIC  9(003) VALUE ZEROS.       

	@FixedLenghtField(position = 813, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM;//                     05  TS01-MENSAGEM     PIC  X(080) VALUE SPACES.                                                                      

	@FixedLenghtField(position = 814, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_MENS_LEN;//                 03  TS02-MENS-LEN         PIC S9(004) COMP VALUE +18.    

//                 03  TS02-AREA-DETALHE.                                   
	@FixedLenghtField(position = 815, lenght = 3, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_SEGMTO;//                     07 TS02-SEGMTO    PIC  X(003).                       

	@FixedLenghtField(position = 816, lenght = 15, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_DESCRSEG;//                     07 TS02-DESCRSEG  PIC  X(015).                       

	public NQCE6228LegadoResponse() { }
	public NQCE6228LegadoResponse(String comm_pgm_chamada, String comm_nomedats, Long comm_tam_comm, String ts02_segmto, String ts02_descrseg) { 		this.COMM_PGM_CHAMADA = comm_pgm_chamada;
		this.COMM_NOMEDATS = comm_nomedats;
		this.COMM_TAM_COMM = comm_tam_comm;
		this.TS01_MENS_LEN = +83;
		this.TS01_RETORNO = ZEROS;
		this.TS01_MENSAGEM = SPACES;
		this.TS02_MENS_LEN = +18;
		this.TS02_SEGMTO = ts02_segmto;
		this.TS02_DESCRSEG = ts02_descrseg; 
	}
	public String getCOMM_PGM_CHAMADA() { return this.COMM_PGM_CHAMADA; }
	public String getCOMM_NOMEDATS() { return this.COMM_NOMEDATS; }
	public Long getCOMM_TAM_COMM() { return this.COMM_TAM_COMM; }
	public Long getTS01_MENS_LEN() { return this.TS01_MENS_LEN; }
	public Long getTS01_RETORNO() { return this.TS01_RETORNO; }
	public String getTS01_MENSAGEM() { return this.TS01_MENSAGEM; }
	public Long getTS02_MENS_LEN() { return this.TS02_MENS_LEN; }
	public String getTS02_SEGMTO() { return this.TS02_SEGMTO; }
	public String getTS02_DESCRSEG() { return this.TS02_DESCRSEG; }
	public void setCOMM_PGM_CHAMADA(String comm_pgm_chamada) { this.COMM_PGM_CHAMADA = comm_pgm_chamada; }
	public void setCOMM_NOMEDATS(String comm_nomedats) { this.COMM_NOMEDATS = comm_nomedats; }
	public void setCOMM_TAM_COMM(Long comm_tam_comm) { this.COMM_TAM_COMM = comm_tam_comm; }
	public void setTS01_MENS_LEN(Long ts01_mens_len) { this.TS01_MENS_LEN = ts01_mens_len; }
	public void setTS01_RETORNO(Long ts01_retorno) { this.TS01_RETORNO = ts01_retorno; }
	public void setTS01_MENSAGEM(String ts01_mensagem) { this.TS01_MENSAGEM = ts01_mensagem; }
	public void setTS02_MENS_LEN(Long ts02_mens_len) { this.TS02_MENS_LEN = ts02_mens_len; }
	public void setTS02_SEGMTO(String ts02_segmto) { this.TS02_SEGMTO = ts02_segmto; }
	public void setTS02_DESCRSEG(String ts02_descrseg) { this.TS02_DESCRSEG = ts02_descrseg; }
	*/
}