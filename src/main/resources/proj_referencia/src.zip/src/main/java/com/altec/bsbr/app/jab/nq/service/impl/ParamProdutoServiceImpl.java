package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.ParamProdutoDao;
import com.altec.bsbr.app.jab.nq.service.ParamProdutoService;
import com.altec.bsbr.fw.BusinessException;


@Service
public class ParamProdutoServiceImpl implements ParamProdutoService {
	private final Logger LOGGER = LoggerFactory.getLogger(ParamProdutoServiceImpl.class);
	@Autowired
	private ParamProdutoDao paramProduto;

	public String versao() throws BusinessException {
		return paramProduto.versao();
	}

	public String listaProduto(String strSIGLA, String strNUSEQ, String strDETINTE, String strNOMEPRO,
			String strIDORDPA) throws BusinessException {
		return paramProduto.listaProduto(strSIGLA, strNUSEQ, strDETINTE, strNOMEPRO, strIDORDPA);
	}

	public String alteraProduto(String strSGSISOR, String strSQSISOR, String strCDDETIN, String strDHFILTR,
			String strTPOPER, String strICMONIT, String strVLMINPR, String strCDUSRES) throws BusinessException {
		return paramProduto.alteraProduto(strSGSISOR, strSQSISOR, strCDDETIN, strDHFILTR, strTPOPER, strICMONIT,
				strVLMINPR, strCDUSRES);
	}

	public String listaAlteracaoParametro(String strCOSIGLA, String strNUSEQSI, String strCODETIN, String strCOOPINT,
			String strIDORDPG) throws BusinessException {
		return paramProduto.listaAlteracaoParametro(strCOSIGLA, strNUSEQSI, strCODETIN, strCOOPINT, strIDORDPG);
	}
}
