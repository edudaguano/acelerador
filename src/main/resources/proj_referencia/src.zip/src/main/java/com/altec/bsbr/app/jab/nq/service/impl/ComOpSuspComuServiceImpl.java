package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.ComOpSuspComuDao;
import com.altec.bsbr.app.jab.nq.service.ComOpSuspComuService;
import com.altec.bsbr.fw.BusinessException;


@Service
public class ComOpSuspComuServiceImpl implements ComOpSuspComuService {
	private final Logger LOGGER = LoggerFactory.getLogger(ComOpSuspComuServiceImpl.class);
	@Autowired
	private ComOpSuspComuDao comOpSuspComu;

	public String versao() throws BusinessException {
		return comOpSuspComu.versao();
	}

	public String salvaComunicacao(String strCOENTID, String strCODAGEN, String strTPUNIOR, String strNUNIORG,
			String strNUCONTA, String strNUPENUM, String strTPDOCTO, String strNUDOCTO, String strNOPESSO,
			String strCOSEGPR, String strCOSEGSE, String strCOAREAT, String strTCOPROF, String strVLRENDA,
			String strDTRENDA, String strCOTPREN, String strVLPATRI, String strDTPATRI, String strICCEP,
			String strNOEMPRE, String strCOATIVI, String strCOATCNA, String strCOTPCOR, String strVLFATAN,
			String strDTFATAN, String strTXPARA1, String strTXPARA2, String strTXPARA3, String strTXPARA4,
			String strTXPARA5, String strTXPARA6, String strTXPARA7, String strTXPARA8, String strTXPARA9,
			String strTXPAR10, String strNOCONJU, String strICORREN, String strCDUSRES, String strICIMPED)
			throws BusinessException {
		return comOpSuspComu.salvaComunicacao(strCOENTID, strCODAGEN, strTPUNIOR, strNUNIORG, strNUCONTA, strNUPENUM,
				strTPDOCTO, strNUDOCTO, strNOPESSO, strCOSEGPR, strCOSEGSE, strCOAREAT, strTCOPROF, strVLRENDA,
				strDTRENDA, strCOTPREN, strVLPATRI, strDTPATRI, strICCEP, strNOEMPRE, strCOATIVI, strCOATCNA,
				strCOTPCOR, strVLFATAN, strDTFATAN, strTXPARA1, strTXPARA2, strTXPARA3, strTXPARA4, strTXPARA5,
				strTXPARA6, strTXPARA7, strTXPARA8, strTXPARA9, strTXPAR10, strNOCONJU, strICORREN, strCDUSRES,
				strICIMPED);
	}
}
