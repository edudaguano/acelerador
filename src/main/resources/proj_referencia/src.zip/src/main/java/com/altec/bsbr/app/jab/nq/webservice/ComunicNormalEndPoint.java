package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.ComunicNormalService;
import com.altec.bsbr.app.jab.nq.service.ComunicNormalWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class ComunicNormalEndPoint extends SpringBeanAutowiringSupport implements ComunicNormalWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(ComunicNormalEndPoint.class);
	@Autowired
	private ComunicNormalService comunicNormal;

	@WebMethod
	public String versao() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = comunicNormal.versao();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String enviaMensagem(String strCDENTID, String strCDAGENC, String strCDALERT, String strCDUNIOR,
			String strTPUNIOR, String strTXPAR01, String strTXPAR02, String strTXPAR03, String strTXPAR04,
			String strTXPAR05, String strTXPAR06, String strTXPAR07, String strTXPAR08, String strTXPAR09,
			String strTXPAR10, String strTPPAREC, String strDTCOMIT, String strCDUSRES, String strNUSEQUE,
			String strTPCHAMA) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = comunicNormal.enviaMensagem(strCDENTID, strCDAGENC, strCDALERT, strCDUNIOR, strTPUNIOR,
					strTXPAR01, strTXPAR02, strTXPAR03, strTXPAR04, strTXPAR05, strTXPAR06, strTXPAR07, strTXPAR08,
					strTXPAR09, strTXPAR10, strTPPAREC, strDTCOMIT, strCDUSRES, strNUSEQUE, strTPCHAMA);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
}
