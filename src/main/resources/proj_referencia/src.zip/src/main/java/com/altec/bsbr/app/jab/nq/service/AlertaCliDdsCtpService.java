package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface AlertaCliDdsCtpService {
	public String versao() throws BusinessException;

	public String consultarContraparte(String strCOENTID, String strCOALERT, String strCDCENAR, String strCDDETIN,
			String strCDOCOPE, String strNUCNTR) throws BusinessException;
}
