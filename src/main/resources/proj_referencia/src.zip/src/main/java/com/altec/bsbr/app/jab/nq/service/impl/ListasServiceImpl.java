package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.ListasDao;
import com.altec.bsbr.app.jab.nq.service.ListasService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class ListasServiceImpl implements ListasService {
	private final Logger LOGGER = LoggerFactory.getLogger(ListasServiceImpl.class);
	
	@Autowired
	private ListasDao listas;

	public String listarLista(String strCodSist, String strCodUser) throws BusinessException {
		return listas.listarLista(strCodSist, strCodUser);
	}

	public String consultarLista(String strCodSist, String strCodList, String strCodUser) throws BusinessException {
		return listas.consultarLista(strCodSist, strCodList, strCodUser);
	}

	public String incluirLista(String strCodSist, String strCodCamp, String strDsList, String strListAtiv,
			String strCodUser) throws BusinessException {
		return listas.incluirLista(strCodSist, strCodCamp, strDsList, strListAtiv, strCodUser);
	}

	public String alterarLista(String strCodSist, String strCodList, String strCodCamp, String strDsList,
			String strListAtiv, String strCodUser) throws BusinessException {
		return listas.alterarLista(strCodSist, strCodList, strCodCamp, strDsList, strListAtiv, strCodUser);
	}

	public String excluirLista(String strCodSist, String strCodList, String strCodUser) throws BusinessException {
		return listas.excluirLista(strCodSist, strCodList, strCodUser);
	}

	public String inicializarinputArea(String tNQ_NQAT2003_NQCETB03_ENTRADA) throws BusinessException {
		return listas.inicializarinputArea(tNQ_NQAT2003_NQCETB03_ENTRADA);
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws BusinessException {
		return listas.fnAddCaracter(Vlr, Tp, Tam);
	}
	
}
