package com.altec.bsbr.app.jab.nq.dao;

public interface AnaliseACDao {
	public String consultarAnalises(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser, String strFuncao);

	public String listarPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser);

	public String listarClientes(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser);

	public String fnAddCaracter(String vlr, String tp, String tam);

	public String dataAlta(String dtBaixa);
}
