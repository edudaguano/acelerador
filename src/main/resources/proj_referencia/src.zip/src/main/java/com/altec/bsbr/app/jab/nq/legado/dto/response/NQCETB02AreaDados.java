package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name = "NQCETB02AreaDados")
public class NQCETB02AreaDados {

	//*       INDICADOR DE CAMPO ATIVO                                  
	//
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*
	//
	//01     NQCETB02-SAIDA.                                           
	
	//03    NQCETB2S-MENS.                                            
//	@PsFieldNumber(name = "NQCETB2S_RETORNO", decimal = 0, length = 3, signed = false, defaultValue = "0")
//	private Long NQCETB2S_RETORNO;// 05 NQCETB2S-RETORNO PIC 9(003) VALUE ZEROS.
//	
//	@PsFieldString(name = "NQCETB2S_MENSAGEM", length = 80, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
//	private String NQCETB2S_MENSAGEM;// 05 NQCETB2S-MENSAGEM PIC X(080) VALUE SPACES.
//	
//	//
//	//*       AREA DE DADOS                                             
//	//
//	@PsFieldNumber(name = "NQCETB2S_DATA_LEN", length = 4, binary = true, signed = true, decimal = 0)
//	private Long NQCETB2S_DATA_LEN;// 03 NQCETB2S-DATA-LEN COMP PIC S9(04) VALUE +59.
	
	//03    NQCETB2S-DATA.                                            
	@PsFieldNumber(name = "NQCETB2S_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB2S_NR_SEQU_SIST;// 05 NQCETB2S-NR-SEQU-SIST PIC 9(004).
	
	//*       NUMERO DE SEQUENCIA DO SISTEMA                            
	//
	@PsFieldNumber(name = "NQCETB2S_NR_SEQU_CAPO", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB2S_NR_SEQU_CAPO;// 05 NQCETB2S-NR-SEQU-CAPO PIC 9(004).
	
	//*       NUMERO DE SEQUENCIA DO CAMPO DO SISTEMA                   
	//
	@PsFieldString(name = "NQCETB2S_DS_CAPO", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB2S_DS_CAPO;// 05 NQCETB2S-DS-CAPO PIC X(040).
	
	//*       DESCRICAO DO CAMPO DO SISTEMA                             
	//
	@PsFieldString(name = "NQCETB2S_TP_CAPO", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB2S_TP_CAPO;// 05 NQCETB2S-TP-CAPO PIC X(002).
	
	//*       TIPO DE CAMPO DO SISTEMA                                  
	//
	@PsFieldNumber(name = "NQCETB2S_QT_TAMA_CAPO", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB2S_QT_TAMA_CAPO;// 05 NQCETB2S-QT-TAMA-CAPO PIC 9(004).
	
	//*       TAMANHO DO CAMPO DO SISTEMA                               
	//
	@PsFieldNumber(name = "NQCETB2S_VL_INIC_FILT_CAPO", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB2S_VL_INIC_FILT_CAPO;// 05 NQCETB2S-VL-INIC-FILT-CAPO PIC 9(004).
	
	//*       POSICAO INICIAL DO CAMPO NO ARQUIVO                       
	//
	@PsFieldString(name = "NQCETB2S_IN_CAPO_ATIV", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB2S_IN_CAPO_ATIV;// 05 NQCETB2S-IN-CAPO-ATIV PIC X(001).


	public Long getNQCETB2S_NR_SEQU_SIST() {
		return NQCETB2S_NR_SEQU_SIST;
	}

	public void setNQCETB2S_NR_SEQU_SIST(Long nQCETB2S_NR_SEQU_SIST) {
		NQCETB2S_NR_SEQU_SIST = nQCETB2S_NR_SEQU_SIST;
	}

	public Long getNQCETB2S_NR_SEQU_CAPO() {
		return NQCETB2S_NR_SEQU_CAPO;
	}

	public void setNQCETB2S_NR_SEQU_CAPO(Long nQCETB2S_NR_SEQU_CAPO) {
		NQCETB2S_NR_SEQU_CAPO = nQCETB2S_NR_SEQU_CAPO;
	}

	public String getNQCETB2S_DS_CAPO() {
		return NQCETB2S_DS_CAPO;
	}

	public void setNQCETB2S_DS_CAPO(String nQCETB2S_DS_CAPO) {
		NQCETB2S_DS_CAPO = nQCETB2S_DS_CAPO;
	}

	public String getNQCETB2S_TP_CAPO() {
		return NQCETB2S_TP_CAPO;
	}

	public void setNQCETB2S_TP_CAPO(String nQCETB2S_TP_CAPO) {
		NQCETB2S_TP_CAPO = nQCETB2S_TP_CAPO;
	}

	public Long getNQCETB2S_QT_TAMA_CAPO() {
		return NQCETB2S_QT_TAMA_CAPO;
	}

	public void setNQCETB2S_QT_TAMA_CAPO(Long nQCETB2S_QT_TAMA_CAPO) {
		NQCETB2S_QT_TAMA_CAPO = nQCETB2S_QT_TAMA_CAPO;
	}

	public Long getNQCETB2S_VL_INIC_FILT_CAPO() {
		return NQCETB2S_VL_INIC_FILT_CAPO;
	}

	public void setNQCETB2S_VL_INIC_FILT_CAPO(Long nQCETB2S_VL_INIC_FILT_CAPO) {
		NQCETB2S_VL_INIC_FILT_CAPO = nQCETB2S_VL_INIC_FILT_CAPO;
	}

	public String getNQCETB2S_IN_CAPO_ATIV() {
		return NQCETB2S_IN_CAPO_ATIV;
	}

	public void setNQCETB2S_IN_CAPO_ATIV(String nQCETB2S_IN_CAPO_ATIV) {
		NQCETB2S_IN_CAPO_ATIV = nQCETB2S_IN_CAPO_ATIV;
	}
		
}