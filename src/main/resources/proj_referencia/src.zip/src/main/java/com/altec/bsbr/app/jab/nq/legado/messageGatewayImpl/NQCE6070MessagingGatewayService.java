/*
package com.altec.bsbr.app.jab.nq.legado.messageGatewayImpl;
import javax.jms.JMSException;
import javax.jms.Queue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nqce.legado.dto.request.NQCE6070LegadoRequest;
import com.altec.bsbr.app.jab.nqce.legado.dto.request.NQCE6070LegadoResponse;
import com.altec.bsbr.app.jab.nqce.legado.dto.request.NQCE6070MessagingGateway;
import com.altec.bsbr.app.jab.nqce.legado.AbstractLegadoMessassingGatewayImpl;
import com.altec.bsbr.fw.jms.legado.LegadoUser;
@Service
public class NQCE6070MessagingGatewayService extends AbstractLegadoMessassingGatewayImpl<NQCE6070LegadoRequest> implements NQCE6070MessagingGateway {

	@Autowired
	@Qualifier("requestQueueLegado")
	private Queue requestQueue;

	@Autowired
	@Qualifier("responseQueueLegado")
	private Queue responseQueue;

	@Autowired
	@Qualifier("jmsConnectionFactoryLegado")
	private ConnectionFactory connectionFactory;

	@Autowired
	@Qualifier("requestMultiQueueLegado")
	private Queue requestMultiQueue;

	@Autowired
	@Qualifier("responseMultiQueueLegado")
	private Queue responseMultiQueue;

	public Class<?> getReplyFormat() {
		return NQCE6070LegadoResponse.class;
	}

	@Override
	public void setUser(LegadoUser u) {
		super.setLegadoUser(u);
	}

	@Override
	public ConnectionFactory getConnectionFactory() {
		return this.connectionFactory;
	}

	@Override
	protected String getIdCanal() {
		return "";
	}

	@Override
	protected String getIdTransacao() {
		return "NQCE6070";
	}

	@Override
	protected String getNivelLog() {
		return "00";
	}

	@Override
	protected String getReplyToQClte() {
		try {
			String{} queueSplit = responseMultiQueue.getQueueName().split(Pattern.quote("///")); // queue:///<fila>
		} catch (JMSException e) {
			e.printStackTrace();
			return "";
		}
	}

	@Override
	public Queue getRequestMultiQueue() {
		return requestMultiQueue;
	}

	@Override
	public Queue getResponseMultiQueue() {
		return responseMultiQueue;
	}	

	@Override
	public Queue getRequestQueue() {
		return requestQueue;
	}

	@Override
	public Queue getResponseQueue() {
		return responseQueue;
	}		

	@Override
	protected String getTipoMensagem() {
		return "R";
	}

	@Override
	protected String getTipoMensaje() {
		return "R";
	}

	@Override
	protected String getTipoProcesso() {
		return " ";
	}

	@Override
	protected int getPosicaoTsEntrada() {
		return 0;
	}

	@Override
	protected int getPosicaoTsRetorno() {
		return 2;
	}
}
*/