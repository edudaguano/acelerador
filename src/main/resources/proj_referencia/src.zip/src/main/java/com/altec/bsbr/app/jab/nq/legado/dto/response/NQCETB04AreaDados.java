package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name = "NQCETB04AreaDados")
public class NQCETB04AreaDados {
	
	//03    NQCETB4S-DATA.                                            
	@PsFieldNumber(name = "NQCETB4S_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB4S_NR_SEQU_SIST;// 05 NQCETB4S-NR-SEQU-SIST PIC 9(004).
	
	//*       NUMERO DE SEQUENCIA DO SISTEMA                            
	//
	@PsFieldNumber(name = "NQCETB4S_NR_SEQU_LIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB4S_NR_SEQU_LIST;// 05 NQCETB4S-NR-SEQU-LIST PIC 9(004).
	
	//*       NUMERO DE SEQUENCIA DA LISTA                              
	//
	@PsFieldNumber(name = "NQCETB4S_NR_SEQU_CNTD", decimal = 0, length = 5, signed = false, defaultValue = "0")
	private Long NQCETB4S_NR_SEQU_CNTD;// 05 NQCETB4S-NR-SEQU-CNTD PIC 9(005).
	
	//*       NUMERO DE SEQUENCIA DO CONTEUDO                           
	//
	@PsFieldString(name = "NQCETB4S_TX_CNTD", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4S_TX_CNTD;// 05 NQCETB4S-TX-CNTD PIC X(040).
	
	//*       TEXTO DO CONTEUDO                                         
	//
	@PsFieldString(name = "NQCETB4S_DS_CNTD", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4S_DS_CNTD;// 05 NQCETB4S-DS-CNTD PIC X(040).
	
	//*       DESCRICAO DO CONTEUDO                                     
	//
	@PsFieldString(name = "NQCETB4S_CD_USUA_INCL_CNTD", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4S_CD_USUA_INCL_CNTD;// 05 NQCETB4S-CD-USUA-INCL-CNTD PIC X(008).
	
	//*       CODIGO DO USUARIO QUE INCLUIU O CONTEUDO                  
	//
	@PsFieldString(name = "NQCETB4S_DH_INCL_CNTD", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4S_DH_INCL_CNTD;// 05 NQCETB4S-DH-INCL-CNTD PIC X(026).
	
	//*       DATA/HORA DE INCLUSAO DO CONTEUDO                         
	//
	@PsFieldString(name = "NQCETB4S_CD_USUA_ALTR_CNTD", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4S_CD_USUA_ALTR_CNTD;// 05 NQCETB4S-CD-USUA-ALTR-CNTD PIC X(008).
	
	//*       CODIGO DO USUARIO QUE ALTEROU O CONTEUDO                  
	//
	@PsFieldString(name = "NQCETB4S_DH_ALTR_CNTD", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4S_DH_ALTR_CNTD;// 05 NQCETB4S-DH-ALTR-CNTD PIC X(026).
	
	//*       DATA/HORA DE ALTERACAO DO CONTEUDO                        
	//
	@PsFieldString(name = "NQCETB4S_IN_CNTD_ATIV", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB4S_IN_CNTD_ATIV;// 05 NQCETB4S-IN-CNTD-ATIV PIC X(001).

	public Long getNQCETB4S_NR_SEQU_SIST() {
		return NQCETB4S_NR_SEQU_SIST;
	}

	public void setNQCETB4S_NR_SEQU_SIST(Long nQCETB4S_NR_SEQU_SIST) {
		NQCETB4S_NR_SEQU_SIST = nQCETB4S_NR_SEQU_SIST;
	}

	public Long getNQCETB4S_NR_SEQU_LIST() {
		return NQCETB4S_NR_SEQU_LIST;
	}

	public void setNQCETB4S_NR_SEQU_LIST(Long nQCETB4S_NR_SEQU_LIST) {
		NQCETB4S_NR_SEQU_LIST = nQCETB4S_NR_SEQU_LIST;
	}

	public Long getNQCETB4S_NR_SEQU_CNTD() {
		return NQCETB4S_NR_SEQU_CNTD;
	}

	public void setNQCETB4S_NR_SEQU_CNTD(Long nQCETB4S_NR_SEQU_CNTD) {
		NQCETB4S_NR_SEQU_CNTD = nQCETB4S_NR_SEQU_CNTD;
	}

	public String getNQCETB4S_TX_CNTD() {
		return NQCETB4S_TX_CNTD;
	}

	public void setNQCETB4S_TX_CNTD(String nQCETB4S_TX_CNTD) {
		NQCETB4S_TX_CNTD = nQCETB4S_TX_CNTD;
	}

	public String getNQCETB4S_DS_CNTD() {
		return NQCETB4S_DS_CNTD;
	}

	public void setNQCETB4S_DS_CNTD(String nQCETB4S_DS_CNTD) {
		NQCETB4S_DS_CNTD = nQCETB4S_DS_CNTD;
	}

	public String getNQCETB4S_CD_USUA_INCL_CNTD() {
		return NQCETB4S_CD_USUA_INCL_CNTD;
	}

	public void setNQCETB4S_CD_USUA_INCL_CNTD(String nQCETB4S_CD_USUA_INCL_CNTD) {
		NQCETB4S_CD_USUA_INCL_CNTD = nQCETB4S_CD_USUA_INCL_CNTD;
	}

	public String getNQCETB4S_DH_INCL_CNTD() {
		return NQCETB4S_DH_INCL_CNTD;
	}

	public void setNQCETB4S_DH_INCL_CNTD(String nQCETB4S_DH_INCL_CNTD) {
		NQCETB4S_DH_INCL_CNTD = nQCETB4S_DH_INCL_CNTD;
	}

	public String getNQCETB4S_CD_USUA_ALTR_CNTD() {
		return NQCETB4S_CD_USUA_ALTR_CNTD;
	}

	public void setNQCETB4S_CD_USUA_ALTR_CNTD(String nQCETB4S_CD_USUA_ALTR_CNTD) {
		NQCETB4S_CD_USUA_ALTR_CNTD = nQCETB4S_CD_USUA_ALTR_CNTD;
	}

	public String getNQCETB4S_DH_ALTR_CNTD() {
		return NQCETB4S_DH_ALTR_CNTD;
	}

	public void setNQCETB4S_DH_ALTR_CNTD(String nQCETB4S_DH_ALTR_CNTD) {
		NQCETB4S_DH_ALTR_CNTD = nQCETB4S_DH_ALTR_CNTD;
	}

	public String getNQCETB4S_IN_CNTD_ATIV() {
		return NQCETB4S_IN_CNTD_ATIV;
	}

	public void setNQCETB4S_IN_CNTD_ATIV(String nQCETB4S_IN_CNTD_ATIV) {
		NQCETB4S_IN_CNTD_ATIV = nQCETB4S_IN_CNTD_ATIV;
	}
	
	//*       INDICADOR DE CONTEUDO ATIVO 
	
	
}