package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name= "NQCETB12AreaDados")
public class NQCETB12AreaDados {
	
//    03    NQCETB12-S-DATA.                                          
//                                                                    
	@PsFieldString(name= "NQCETB12_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_CD_BANC_CLIE;//     05   NQCETB12-S-CD-BANC-CLIE       PIC  X(004).                

//  *       CODIGO DO BANCO                                           
//                                                                    
	@PsFieldString(name= "NQCETB12_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_CD_CLIE;//     05   NQCETB12-S-CD-CLIE            PIC  X(008).                

//  *       CODIGO DO CLIENTE                                         
//                                                                    
	@PsFieldString(name= "NQCETB12_S_NR_CNTR", length= 12, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_NR_CNTR;//     05   NQCETB12-S-NR-CNTR            PIC  X(012).                

//  *       NUMERO DO CONTRATO                                        
//                                                                    
	@PsFieldString(name= "NQCETB12_S_CD_PROD", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_CD_PROD;//     05   NQCETB12-S-CD-PROD            PIC  X(002).                

//  *       CODIGO DO PRODUTO                                         
//                                                                    
	@PsFieldString(name= "NQCETB12_S_CD_SUBP", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_CD_SUBP;//     05   NQCETB12-S-CD-SUBP            PIC  X(004).                

//  *       CODIGO DO SUBPRODUTO                                      
//                                                                    
	@PsFieldString(name= "NQCETB12_S_DT_INIC_RELA", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_DT_INIC_RELA;//     05   NQCETB12-S-DT-INIC-RELA       PIC  X(010).                

//  *       DATA DE INICIO DE RELACIONAMENTO                          
//                                                                    
	@PsFieldString(name= "NQCETB12_S_DT_INIC_CNTR_PROD", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_DT_INIC_CNTR_PROD;//     05   NQCETB12-S-DT-INIC-CNTR-PROD  PIC  X(010).                

//  *       DATA DE INICIO DA CONTRATACAO                             
//                                                                    
	@PsFieldString(name= "NQCETB12_S_DT_VENC_CNTR_PROD", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB12_S_DT_VENC_CNTR_PROD;//     05   NQCETB12-S-DT-VENC-CNTR-PROD  PIC  X(010).                

//  *       DATA DE VENCIMENTO DA CONTRATACAO                         
	public NQCETB12AreaDados() { }

	public String getNQCETB12_S_CD_BANC_CLIE() {
		return NQCETB12_S_CD_BANC_CLIE;
	}

	public void setNQCETB12_S_CD_BANC_CLIE(String nQCETB12_S_CD_BANC_CLIE) {
		NQCETB12_S_CD_BANC_CLIE = nQCETB12_S_CD_BANC_CLIE;
	}

	public String getNQCETB12_S_CD_CLIE() {
		return NQCETB12_S_CD_CLIE;
	}

	public void setNQCETB12_S_CD_CLIE(String nQCETB12_S_CD_CLIE) {
		NQCETB12_S_CD_CLIE = nQCETB12_S_CD_CLIE;
	}

	public String getNQCETB12_S_NR_CNTR() {
		return NQCETB12_S_NR_CNTR;
	}

	public void setNQCETB12_S_NR_CNTR(String nQCETB12_S_NR_CNTR) {
		NQCETB12_S_NR_CNTR = nQCETB12_S_NR_CNTR;
	}

	public String getNQCETB12_S_CD_PROD() {
		return NQCETB12_S_CD_PROD;
	}

	public void setNQCETB12_S_CD_PROD(String nQCETB12_S_CD_PROD) {
		NQCETB12_S_CD_PROD = nQCETB12_S_CD_PROD;
	}

	public String getNQCETB12_S_CD_SUBP() {
		return NQCETB12_S_CD_SUBP;
	}

	public void setNQCETB12_S_CD_SUBP(String nQCETB12_S_CD_SUBP) {
		NQCETB12_S_CD_SUBP = nQCETB12_S_CD_SUBP;
	}

	public String getNQCETB12_S_DT_INIC_RELA() {
		return NQCETB12_S_DT_INIC_RELA;
	}

	public void setNQCETB12_S_DT_INIC_RELA(String nQCETB12_S_DT_INIC_RELA) {
		NQCETB12_S_DT_INIC_RELA = nQCETB12_S_DT_INIC_RELA;
	}

	public String getNQCETB12_S_DT_INIC_CNTR_PROD() {
		return NQCETB12_S_DT_INIC_CNTR_PROD;
	}

	public void setNQCETB12_S_DT_INIC_CNTR_PROD(String nQCETB12_S_DT_INIC_CNTR_PROD) {
		NQCETB12_S_DT_INIC_CNTR_PROD = nQCETB12_S_DT_INIC_CNTR_PROD;
	}

	public String getNQCETB12_S_DT_VENC_CNTR_PROD() {
		return NQCETB12_S_DT_VENC_CNTR_PROD;
	}

	public void setNQCETB12_S_DT_VENC_CNTR_PROD(String nQCETB12_S_DT_VENC_CNTR_PROD) {
		NQCETB12_S_DT_VENC_CNTR_PROD = nQCETB12_S_DT_VENC_CNTR_PROD;
	}
	
	
	
}