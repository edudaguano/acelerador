package com.altec.bsbr.app.jab.nq.dao;

public interface ParamMonitorDao {
	public String versao();

	public String listaTipoMovimentoMonitorado(String strCOSIGLA, String strNUSEQSI, String strCODETIN,
			String strCOOPINT, String strNOOPEIN, String strIDORDPA);

	public String incluirTipoMovimentoMonitorado(String strCOSIGLA, String strNUSEQSI, String strCODETIN,
			String strCOOPINT, String strNOOPEIN, String strICMONIT, String strTPOPERA, String strDTHROPE,
			String strCDUSRES, String strTPMANUT);

	public String montarComboProduto(String strCOPRSPR);
}
