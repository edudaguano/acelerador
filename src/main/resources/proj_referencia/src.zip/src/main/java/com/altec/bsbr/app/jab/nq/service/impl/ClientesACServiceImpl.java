package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.ClientesACDao;
import com.altec.bsbr.app.jab.nq.service.ClientesACService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class ClientesACServiceImpl implements ClientesACService {
	private final Logger LOGGER = LoggerFactory.getLogger(ClientesACServiceImpl.class);

	@Autowired
	private ClientesACDao clientesAC;

	public String consultarClientes(String strBanco, String strCliente, String StrUsuario) throws BusinessException {
		return clientesAC.consultarClientes(strBanco, strCliente, StrUsuario);
	}

	public String listarClientes(String strBanco, String strCliente, String StrUsuario) throws BusinessException {
		return clientesAC.listarClientes(strBanco, strCliente, StrUsuario);
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws BusinessException {
		return clientesAC.fnAddCaracter(Vlr, Tp, Tam);
	}
}
