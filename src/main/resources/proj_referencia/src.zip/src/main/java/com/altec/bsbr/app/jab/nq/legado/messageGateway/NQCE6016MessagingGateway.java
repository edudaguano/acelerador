package com.altec.bsbr.app.jab.nq.legado.messageGateway;

import java.util.List;

import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCE6016LegadoRequest;
import com.altec.bsbr.fw.jms.legado.LegadoException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;

public interface NQCE6016MessagingGateway {
	
	LegadoResult sendMessageLegado(NQCE6016LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageMultiLegado(NQCE6016LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageListLegado(List<NQCE6016LegadoRequest> arg0) throws LegadoException;

}