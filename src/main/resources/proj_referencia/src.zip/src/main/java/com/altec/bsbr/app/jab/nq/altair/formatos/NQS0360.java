package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0360")
public class NQS0360 {
@PsFieldString(name="COSIGLA", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COSIGLA;
@PsFieldNumber(name="NUSEQSI", length=2, defaultValue = "0" )
private Integer NUSEQSI;
@PsFieldString(name="CODETIN", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODETIN;
@PsFieldString(name="COOPINT", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COOPINT;
@PsFieldString(name="SGSIORI", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SGSIORI;
@PsFieldNumber(name="NUSEQSO", length=2, defaultValue = "0" )
private Integer NUSEQSO;
@PsFieldString(name="CDDETIN", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDDETIN;
@PsFieldString(name="CDOPINT", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDOPINT;
@PsFieldString(name="DHFOPIN", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DHFOPIN;
@PsFieldString(name="TPMANUT", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPMANUT;
@PsFieldString(name="DSDETIN", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSDETIN;
@PsFieldNumber(name="VLMONDE", length=15, decimal=2, defaultValue = "0" )
private double VLMONDE;
@PsFieldNumber(name="VLMONPA", length=15, decimal=2, defaultValue = "0" )
private double VLMONPA;
@PsFieldString(name="DSOPER", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSOPER;
@PsFieldString(name="ICMONIT", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMONIT;
@PsFieldString(name="IDSOLIC", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String IDSOLIC;

public String getCOSIGLA() {
 return COSIGLA;
}
public void setCOSIGLA(String COSIGLA) {
 this.COSIGLA = COSIGLA;
}
public Integer getNUSEQSI() {
 return NUSEQSI;
}
public void setNUSEQSI(Integer nUSEQSI) {
NUSEQSI = nUSEQSI;
}
public String getCODETIN() {
 return CODETIN;
}
public void setCODETIN(String CODETIN) {
 this.CODETIN = CODETIN;
}

public String getCOOPINT() {
 return COOPINT;
}
public void setCOOPINT(String COOPINT) {
 this.COOPINT = COOPINT;
}

public String getSGSIORI() {
 return SGSIORI;
}
public void setSGSIORI(String SGSIORI) {
 this.SGSIORI = SGSIORI;
}
public Integer getNUSEQSO() {
 return NUSEQSO;
}
public void setNUSEQSO(Integer nUSEQSO) {
NUSEQSO = nUSEQSO;
}
public String getCDDETIN() {
 return CDDETIN;
}
public void setCDDETIN(String CDDETIN) {
 this.CDDETIN = CDDETIN;
}

public String getCDOPINT() {
 return CDOPINT;
}
public void setCDOPINT(String CDOPINT) {
 this.CDOPINT = CDOPINT;
}

public String getDHFOPIN() {
 return DHFOPIN;
}
public void setDHFOPIN(String DHFOPIN) {
 this.DHFOPIN = DHFOPIN;
}

public String getTPMANUT() {
 return TPMANUT;
}
public void setTPMANUT(String TPMANUT) {
 this.TPMANUT = TPMANUT;
}

public String getDSDETIN() {
 return DSDETIN;
}
public void setDSDETIN(String DSDETIN) {
 this.DSDETIN = DSDETIN;
}
public double getVLMONDE() {
 return VLMONDE;
}
public void setVLMONDE(double vLMONDE) {
VLMONDE = vLMONDE;
}public double getVLMONPA() {
 return VLMONPA;
}
public void setVLMONPA(double vLMONPA) {
VLMONPA = vLMONPA;
}
public String getDSOPER() {
 return DSOPER;
}
public void setDSOPER(String DSOPER) {
 this.DSOPER = DSOPER;
}

public String getICMONIT() {
 return ICMONIT;
}
public void setICMONIT(String ICMONIT) {
 this.ICMONIT = ICMONIT;
}

public String getIDSOLIC() {
 return IDSOLIC;
}
public void setIDSOLIC(String IDSOLIC) {
 this.IDSOLIC = IDSOLIC;
}


}
