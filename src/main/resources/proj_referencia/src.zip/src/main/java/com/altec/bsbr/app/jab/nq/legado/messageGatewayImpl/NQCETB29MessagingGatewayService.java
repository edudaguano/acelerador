package com.altec.bsbr.app.jab.nq.legado.messageGatewayImpl;

import javax.jms.ConnectionFactory;
import javax.jms.Queue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB29LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.FullAreaResponse;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB29MessagingGateway;
import com.altec.bsbr.fw.jms.legado.AbstractLegadoMessagingGatewayImpl;
import com.altec.bsbr.fw.jms.legado.LegadoUser;

@Service
public class NQCETB29MessagingGatewayService extends AbstractLegadoMessagingGatewayImpl<NQCETB29LegadoRequest> implements NQCETB29MessagingGateway {

	@Autowired
	@Qualifier("requestQueueLegado")
	private Queue requestQueue;

	@Autowired
	@Qualifier("responseQueueLegado")
	private Queue responseQueue;

	@Autowired
	@Qualifier("requestMultiQueueLegado")
	private Queue requestMultQueue;

	@Autowired
	@Qualifier("responseMultiQueueLegado")
	private Queue responseMultQueue;
	
	@Autowired
	@Qualifier("jmsConnectionFactoryLegado")
	private ConnectionFactory connectionFactory;
	
	@Autowired
    @Qualifier("legadoUserName")
    private LegadoUser legadoUser;

	public Class<?> getReplyFormat() {
		return FullAreaResponse.class;
	}

	@Override
	public void setUser(LegadoUser u) {
		super.setLegadoUser(u);
	}

	@Override
	public ConnectionFactory getConnectionFactory() {
		return this.connectionFactory;
	}

	@Override
	protected String getIdCanal() {
		return "   ";
	}

	@Override
	protected String getIdTransacao() {
		return "NQY4";
	}
	
	@Override
	protected String getPrograma() {
		return "DRAT0384";
	}

	@Override
	protected String getNivelLog() {
		return "00";
	}

	@Override
	protected String getReplyToQClte() {
		return "NQ.QL.ANSWER.LEGADO.MULT";
	}

	@Override
	public Queue getRequestMultQueue() {
		return requestMultQueue;
	}

	@Override
	public Queue getResponseMultQueue() {
		return responseMultQueue;
	}

	@Override
	public Queue getRequestQueue() {
		return requestQueue;
	}

	@Override
	public Queue getResponseQueue() {
		return responseQueue;
	}

	@Override
	protected String getTipoMensagem() {
		return "";
	}

	@Override
	protected String getTipoMensaje() {
		return "R";
	}

	@Override
	protected String getTipoProcesso() {
		return " ";
	}

	@Override
	protected int getPosicaoTsEntrada() {
		return 0;
	}

	@Override
	protected int getPosicaoTsRetorno() {
		return 9;
	}
}
