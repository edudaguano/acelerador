package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE6049LegadoResponse {
	/*
//  -*-NQCE6049
//         01  RECEIVE-COMMAREA.                                                                                                      
	@FixedLenghtField(position = 260, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_PGM_CHAMADA;//                 03  COMM-PGM-CHAMADA      PIC  X(008).                   

	@FixedLenghtField(position = 261, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOMEDATS;//                 03  COMM-NOMEDATS         PIC  X(010).                   

	@FixedLenghtField(position = 262, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_TAM_COMM;//                 03  COMM-TAM-COMM         PIC  9(007).                   

	@FixedLenghtField(position = 263, lenght = 9, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_MATRICULA;//                 03  COMM-MATRICULA        PIC  9(009).                   

	@FixedLenghtField(position = 264, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CINSTIT;//                 03  COMM-CINSTIT          PIC  9(003).                   

	@FixedLenghtField(position = 265, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CODAGENC;//                 03  COMM-CODAGENC         PIC  9(004).                   

	@FixedLenghtField(position = 266, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 03;//  PJ0004         03  COMM-CCLI             PIC  9(010).                                                                               

//         01      SEND-AREA.                                                                                                        
	@FixedLenghtField(position = 267, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN;//                 03  TS01-MENS-LEN         PIC S9(004) COMP VALUE +83.    

//                 03  TS01-AREA-MENSAGEM.                                  
	@FixedLenghtField(position = 268, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO;//                     05  TS01-RETORNO      PIC  9(003) VALUE ZEROS.       

	@FixedLenghtField(position = 269, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM;//                     05  TS01-MENSAGEM     PIC  X(080) VALUE SPACES.                                                                  

	@FixedLenghtField(position = 270, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_MENS_LEN;//                 03  TS02-MENS-LEN         PIC S9(004) COMP VALUE +121.   

//                 03  TS02-AREA-DETALHE.                                   
	@FixedLenghtField(position = 271, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NOME_AGENCIA;//                     05 TS02-NOME-AGENCIA  PIC  X(050).                   

	@FixedLenghtField(position = 272, lenght = 30, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NCLI;//                     05 TS02-NCLI          PIC  X(030).                   

	@FixedLenghtField(position = 273, lenght = 10, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_CCLI;//                     05 TS02-CCLI          PIC  9(010).                   

	@FixedLenghtField(position = 274, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_DTCOMUNI;//                     05 TS02-DTCOMUNI      PIC  9(008).                   

	@FixedLenghtField(position = 275, lenght = 5, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_UNIDCOMU;//                     05 TS02-UNIDCOMU      PIC  9(005).                   

	@FixedLenghtField(position = 276, lenght = 15, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_SITUACAO;//                     05 TS02-SITUACAO      PIC  X(015).                   

	@FixedLenghtField(position = 277, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_TP_UOR;//                     05 TS02-TP-UOR        PIC  9(003).                   

	public NQCE6049LegadoResponse() { }
	public NQCE6049LegadoResponse(String comm_pgm_chamada, String comm_nomedats, Long comm_tam_comm, Long comm_matricula, Long comm_cinstit, Long comm_codagenc, Long 03, String ts02_nome_agencia, String ts02_ncli, Long ts02_ccli, Long ts02_dtcomuni, Long ts02_unidcomu, String ts02_situacao, Long ts02_tp_uor) { 		this.COMM_PGM_CHAMADA = comm_pgm_chamada;
		this.COMM_NOMEDATS = comm_nomedats;
		this.COMM_TAM_COMM = comm_tam_comm;
		this.COMM_MATRICULA = comm_matricula;
		this.COMM_CINSTIT = comm_cinstit;
		this.COMM_CODAGENC = comm_codagenc;
		this.03 = 03;
		this.TS01_MENS_LEN = +83;
		this.TS01_RETORNO = ZEROS;
		this.TS01_MENSAGEM = SPACES;
		this.TS02_MENS_LEN = +121;
		this.TS02_NOME_AGENCIA = ts02_nome_agencia;
		this.TS02_NCLI = ts02_ncli;
		this.TS02_CCLI = ts02_ccli;
		this.TS02_DTCOMUNI = ts02_dtcomuni;
		this.TS02_UNIDCOMU = ts02_unidcomu;
		this.TS02_SITUACAO = ts02_situacao;
		this.TS02_TP_UOR = ts02_tp_uor; 
	}
	public String getCOMM_PGM_CHAMADA() { return this.COMM_PGM_CHAMADA; }
	public String getCOMM_NOMEDATS() { return this.COMM_NOMEDATS; }
	public Long getCOMM_TAM_COMM() { return this.COMM_TAM_COMM; }
	public Long getCOMM_MATRICULA() { return this.COMM_MATRICULA; }
	public Long getCOMM_CINSTIT() { return this.COMM_CINSTIT; }
	public Long getCOMM_CODAGENC() { return this.COMM_CODAGENC; }
	public Long get03() { return this.03; }
	public Long getTS01_MENS_LEN() { return this.TS01_MENS_LEN; }
	public Long getTS01_RETORNO() { return this.TS01_RETORNO; }
	public String getTS01_MENSAGEM() { return this.TS01_MENSAGEM; }
	public Long getTS02_MENS_LEN() { return this.TS02_MENS_LEN; }
	public String getTS02_NOME_AGENCIA() { return this.TS02_NOME_AGENCIA; }
	public String getTS02_NCLI() { return this.TS02_NCLI; }
	public Long getTS02_CCLI() { return this.TS02_CCLI; }
	public Long getTS02_DTCOMUNI() { return this.TS02_DTCOMUNI; }
	public Long getTS02_UNIDCOMU() { return this.TS02_UNIDCOMU; }
	public String getTS02_SITUACAO() { return this.TS02_SITUACAO; }
	public Long getTS02_TP_UOR() { return this.TS02_TP_UOR; }
	public void setCOMM_PGM_CHAMADA(String comm_pgm_chamada) { this.COMM_PGM_CHAMADA = comm_pgm_chamada; }
	public void setCOMM_NOMEDATS(String comm_nomedats) { this.COMM_NOMEDATS = comm_nomedats; }
	public void setCOMM_TAM_COMM(Long comm_tam_comm) { this.COMM_TAM_COMM = comm_tam_comm; }
	public void setCOMM_MATRICULA(Long comm_matricula) { this.COMM_MATRICULA = comm_matricula; }
	public void setCOMM_CINSTIT(Long comm_cinstit) { this.COMM_CINSTIT = comm_cinstit; }
	public void setCOMM_CODAGENC(Long comm_codagenc) { this.COMM_CODAGENC = comm_codagenc; }
	public void set03(Long 03) { this.03 = 03; }
	public void setTS01_MENS_LEN(Long ts01_mens_len) { this.TS01_MENS_LEN = ts01_mens_len; }
	public void setTS01_RETORNO(Long ts01_retorno) { this.TS01_RETORNO = ts01_retorno; }
	public void setTS01_MENSAGEM(String ts01_mensagem) { this.TS01_MENSAGEM = ts01_mensagem; }
	public void setTS02_MENS_LEN(Long ts02_mens_len) { this.TS02_MENS_LEN = ts02_mens_len; }
	public void setTS02_NOME_AGENCIA(String ts02_nome_agencia) { this.TS02_NOME_AGENCIA = ts02_nome_agencia; }
	public void setTS02_NCLI(String ts02_ncli) { this.TS02_NCLI = ts02_ncli; }
	public void setTS02_CCLI(Long ts02_ccli) { this.TS02_CCLI = ts02_ccli; }
	public void setTS02_DTCOMUNI(Long ts02_dtcomuni) { this.TS02_DTCOMUNI = ts02_dtcomuni; }
	public void setTS02_UNIDCOMU(Long ts02_unidcomu) { this.TS02_UNIDCOMU = ts02_unidcomu; }
	public void setTS02_SITUACAO(String ts02_situacao) { this.TS02_SITUACAO = ts02_situacao; }
	public void setTS02_TP_UOR(Long ts02_tp_uor) { this.TS02_TP_UOR = ts02_tp_uor; }
	*/
}