package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB23AreaDados")
public class NQCETB23AreaDados {
	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*
	@PsFieldString(name= "NQCETB23_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_BANC_CLIE;//          05   NQCETB23-S-CD-BANC-CLIE       PIC  X(004).                
	
	//*       CODIGO DO BANCO                                           
	//
	@PsFieldString(name= "NQCETB23_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_CLIE;//          05   NQCETB23-S-CD-CLIE            PIC  X(008).                
	
	//*       CODIGO DO CLIENTE                                         
	//
	@PsFieldString(name= "NQCETB23_S_DT_MOVI", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_DT_MOVI;//          05   NQCETB23-S-DT-MOVI            PIC  X(010).                
	
	//*       DATA DO MOVIMENTO                                         
	//
	@PsFieldString(name= "NQCETB23_S_CD_CNTA_DEBT", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_CNTA_DEBT;//          05   NQCETB23-S-CD-CNTA-DEBT       PIC  X(020).                
	
	//*       CODIGO DA CONTA DE DEBITO                                 
	//
	@PsFieldString(name= "NQCETB23_S_NR_PROP", length= 12, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_NR_PROP;//          05   NQCETB23-S-NR-PROP            PIC  X(012).                
	
	//*       NUMERO DA PROPOSTA                                        
	//
	@PsFieldString(name= "NQCETB23_S_NR_APOL", length= 30, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_NR_APOL;//          05   NQCETB23-S-NR-APOL            PIC  X(030).                
	
	//*       NUMERO DA APOLICE                                         
	//
	@PsFieldString(name= "NQCETB23_S_CD_PROD", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_PROD;//          05   NQCETB23-S-CD-PROD            PIC  X(002).                
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name= "NQCETB23_S_CD_RAMO_SEGR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_RAMO_SEGR;//          05   NQCETB23-S-CD-RAMO-SEGR       PIC  X(004).                
	
	//*       CODIGO DO RAMO DO SEGURO                                  
	//
	@PsFieldString(name= "NQCETB23_S_CD_FORM_PGTO", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_FORM_PGTO;//          05   NQCETB23-S-CD-FORM-PGTO       PIC  X(002).                
	
	//*       CODIGO DA FORMA DE PAGAMENTO                              
	//
	@PsFieldNumber(name= "NQCETB23_S_VL_IS", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB23_S_VL_IS;//          05   NQCETB23-S-VL-IS              PIC S9(015)V99.             
	
	//*       VALOR DA IMPORTANCIA SEGURADA                             
	//
	@PsFieldString(name= "NQCETB23_S_DT_FORZ", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_DT_FORZ;//          05   NQCETB23-S-DT-FORZ            PIC  X(010).                
	
	//*       DATA DA FORMALIZACAO                                      
	//
	@PsFieldString(name= "NQCETB23_S_CD_CNAL_VEND", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_CNAL_VEND;//          05   NQCETB23-S-CD-CNAL-VEND       PIC  X(003).                
	
	//*       CODIGO DO CANAL DE VENDA                                  
	//
	@PsFieldString(name= "NQCETB23_S_CD_SEGD", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_SEGD;//          05   NQCETB23-S-CD-SEGD            PIC  X(004).                
	
	//*       CODIGO DA SEGURADORA                                      
	//
	@PsFieldString(name= "NQCETB23_S_TP_TRAN", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_TP_TRAN;//          05   NQCETB23-S-TP-TRAN            PIC  X(001).                
	
	//*       TIPO DE TRANSACAO                                         
	//
	@PsFieldString(name= "NQCETB23_S_CD_BANC_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_BANC_CNTR;//          05   NQCETB23-S-CD-BANC-CNTR       PIC  X(004).                
	
	//*       CODIGO DO BANCO DO CONTRATO                               
	//
	@PsFieldString(name= "NQCETB23_S_CD_AGEN_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_AGEN_CNTR;//          05   NQCETB23-S-CD-AGEN-CNTR       PIC  X(004).                
	
	//*       CODIGO DA AGENCIA DO CONTRATO                             
	//
	@PsFieldString(name= "NQCETB23_S_NR_CNTR_A", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_NR_CNTR_A;//          05   NQCETB23-S-NR-CNTR-A          PIC  X(020).                
	
	//*       NUMERO DO CONTRATO ALTAIR                                 
	//
	@PsFieldString(name= "NQCETB23_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_PROD_ALTAIR;//          05   NQCETB23-S-CD-PROD-ALTAIR     PIC  X(002).                
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name= "NQCETB23_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_SUBP_ALTAIR;//          05   NQCETB23-S-CD-SUBP-ALTAIR     PIC  X(004).                
	
	//*       CODIGO DO SUBPRODUTO                                      
	//
	@PsFieldString(name= "NQCETB23_S_CD_MOED", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_MOED;//          05   NQCETB23-S-CD-MOED            PIC  X(003).                
	
	//*       CODIGO DA MOEDA                                           
	//
	@PsFieldNumber(name= "NQCETB23_S_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB23_S_NR_SEQU_OPER;//          05   NQCETB23-S-NR-SEQU-OPER       PIC  9(003).                
	
	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	@PsFieldString(name= "NQCETB23_S_CD_IDEF_OPER", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_CD_IDEF_OPER;//          05   NQCETB23-S-CD-IDEF-OPER       PIC  X(020).                
	
	//*       CODIGO DA IDENTIFICACAO DA OPERACAO                       
	//
	@PsFieldNumber(name= "NQCETB23_S_VL_MOVI_OPER", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB23_S_VL_MOVI_OPER;//         05   NQCETB23-S-VL-MOVI-OPER       PIC S9(015)V99.             
	
	//*       VALOR DO MOVIMENTO DA OPERACAO                            
	//
	@PsFieldString(name= "NQCETB23_S_TP_MOVI_OPER", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_TP_MOVI_OPER;//         05   NQCETB23-S-TP-MOVI-OPER       PIC  X(003).                
	
	//*       TIPO DO MOVIMENTO DA OPERACAO                             
	//
	@PsFieldString(name= "NQCETB23_S_NM_CLIE", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB23_S_NM_CLIE;//         05   NQCETB23-S-NM-CLIE            PIC  X(040).                

	public String getNQCETB23_S_CD_BANC_CLIE() {
		return NQCETB23_S_CD_BANC_CLIE;
	}

	public void setNQCETB23_S_CD_BANC_CLIE(String nQCETB23_S_CD_BANC_CLIE) {
		NQCETB23_S_CD_BANC_CLIE = nQCETB23_S_CD_BANC_CLIE;
	}

	public String getNQCETB23_S_CD_CLIE() {
		return NQCETB23_S_CD_CLIE;
	}

	public void setNQCETB23_S_CD_CLIE(String nQCETB23_S_CD_CLIE) {
		NQCETB23_S_CD_CLIE = nQCETB23_S_CD_CLIE;
	}

	public String getNQCETB23_S_DT_MOVI() {
		return NQCETB23_S_DT_MOVI;
	}

	public void setNQCETB23_S_DT_MOVI(String nQCETB23_S_DT_MOVI) {
		NQCETB23_S_DT_MOVI = nQCETB23_S_DT_MOVI;
	}

	public String getNQCETB23_S_CD_CNTA_DEBT() {
		return NQCETB23_S_CD_CNTA_DEBT;
	}

	public void setNQCETB23_S_CD_CNTA_DEBT(String nQCETB23_S_CD_CNTA_DEBT) {
		NQCETB23_S_CD_CNTA_DEBT = nQCETB23_S_CD_CNTA_DEBT;
	}

	public String getNQCETB23_S_NR_PROP() {
		return NQCETB23_S_NR_PROP;
	}

	public void setNQCETB23_S_NR_PROP(String nQCETB23_S_NR_PROP) {
		NQCETB23_S_NR_PROP = nQCETB23_S_NR_PROP;
	}

	public String getNQCETB23_S_NR_APOL() {
		return NQCETB23_S_NR_APOL;
	}

	public void setNQCETB23_S_NR_APOL(String nQCETB23_S_NR_APOL) {
		NQCETB23_S_NR_APOL = nQCETB23_S_NR_APOL;
	}

	public String getNQCETB23_S_CD_PROD() {
		return NQCETB23_S_CD_PROD;
	}

	public void setNQCETB23_S_CD_PROD(String nQCETB23_S_CD_PROD) {
		NQCETB23_S_CD_PROD = nQCETB23_S_CD_PROD;
	}

	public String getNQCETB23_S_CD_RAMO_SEGR() {
		return NQCETB23_S_CD_RAMO_SEGR;
	}

	public void setNQCETB23_S_CD_RAMO_SEGR(String nQCETB23_S_CD_RAMO_SEGR) {
		NQCETB23_S_CD_RAMO_SEGR = nQCETB23_S_CD_RAMO_SEGR;
	}

	public String getNQCETB23_S_CD_FORM_PGTO() {
		return NQCETB23_S_CD_FORM_PGTO;
	}

	public void setNQCETB23_S_CD_FORM_PGTO(String nQCETB23_S_CD_FORM_PGTO) {
		NQCETB23_S_CD_FORM_PGTO = nQCETB23_S_CD_FORM_PGTO;
	}

	public Double getNQCETB23_S_VL_IS() {
		return NQCETB23_S_VL_IS;
	}

	public void setNQCETB23_S_VL_IS(Double nQCETB23_S_VL_IS) {
		NQCETB23_S_VL_IS = nQCETB23_S_VL_IS;
	}

	public String getNQCETB23_S_DT_FORZ() {
		return NQCETB23_S_DT_FORZ;
	}

	public void setNQCETB23_S_DT_FORZ(String nQCETB23_S_DT_FORZ) {
		NQCETB23_S_DT_FORZ = nQCETB23_S_DT_FORZ;
	}

	public String getNQCETB23_S_CD_CNAL_VEND() {
		return NQCETB23_S_CD_CNAL_VEND;
	}

	public void setNQCETB23_S_CD_CNAL_VEND(String nQCETB23_S_CD_CNAL_VEND) {
		NQCETB23_S_CD_CNAL_VEND = nQCETB23_S_CD_CNAL_VEND;
	}

	public String getNQCETB23_S_CD_SEGD() {
		return NQCETB23_S_CD_SEGD;
	}

	public void setNQCETB23_S_CD_SEGD(String nQCETB23_S_CD_SEGD) {
		NQCETB23_S_CD_SEGD = nQCETB23_S_CD_SEGD;
	}

	public String getNQCETB23_S_TP_TRAN() {
		return NQCETB23_S_TP_TRAN;
	}

	public void setNQCETB23_S_TP_TRAN(String nQCETB23_S_TP_TRAN) {
		NQCETB23_S_TP_TRAN = nQCETB23_S_TP_TRAN;
	}

	public String getNQCETB23_S_CD_BANC_CNTR() {
		return NQCETB23_S_CD_BANC_CNTR;
	}

	public void setNQCETB23_S_CD_BANC_CNTR(String nQCETB23_S_CD_BANC_CNTR) {
		NQCETB23_S_CD_BANC_CNTR = nQCETB23_S_CD_BANC_CNTR;
	}

	public String getNQCETB23_S_CD_AGEN_CNTR() {
		return NQCETB23_S_CD_AGEN_CNTR;
	}

	public void setNQCETB23_S_CD_AGEN_CNTR(String nQCETB23_S_CD_AGEN_CNTR) {
		NQCETB23_S_CD_AGEN_CNTR = nQCETB23_S_CD_AGEN_CNTR;
	}

	public String getNQCETB23_S_NR_CNTR_A() {
		return NQCETB23_S_NR_CNTR_A;
	}

	public void setNQCETB23_S_NR_CNTR_A(String nQCETB23_S_NR_CNTR_A) {
		NQCETB23_S_NR_CNTR_A = nQCETB23_S_NR_CNTR_A;
	}

	public String getNQCETB23_S_CD_PROD_ALTAIR() {
		return NQCETB23_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB23_S_CD_PROD_ALTAIR(String nQCETB23_S_CD_PROD_ALTAIR) {
		NQCETB23_S_CD_PROD_ALTAIR = nQCETB23_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB23_S_CD_SUBP_ALTAIR() {
		return NQCETB23_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB23_S_CD_SUBP_ALTAIR(String nQCETB23_S_CD_SUBP_ALTAIR) {
		NQCETB23_S_CD_SUBP_ALTAIR = nQCETB23_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB23_S_CD_MOED() {
		return NQCETB23_S_CD_MOED;
	}

	public void setNQCETB23_S_CD_MOED(String nQCETB23_S_CD_MOED) {
		NQCETB23_S_CD_MOED = nQCETB23_S_CD_MOED;
	}

	public Long getNQCETB23_S_NR_SEQU_OPER() {
		return NQCETB23_S_NR_SEQU_OPER;
	}

	public void setNQCETB23_S_NR_SEQU_OPER(Long nQCETB23_S_NR_SEQU_OPER) {
		NQCETB23_S_NR_SEQU_OPER = nQCETB23_S_NR_SEQU_OPER;
	}

	public String getNQCETB23_S_CD_IDEF_OPER() {
		return NQCETB23_S_CD_IDEF_OPER;
	}

	public void setNQCETB23_S_CD_IDEF_OPER(String nQCETB23_S_CD_IDEF_OPER) {
		NQCETB23_S_CD_IDEF_OPER = nQCETB23_S_CD_IDEF_OPER;
	}

	public Double getNQCETB23_S_VL_MOVI_OPER() {
		return NQCETB23_S_VL_MOVI_OPER;
	}

	public void setNQCETB23_S_VL_MOVI_OPER(Double nQCETB23_S_VL_MOVI_OPER) {
		NQCETB23_S_VL_MOVI_OPER = nQCETB23_S_VL_MOVI_OPER;
	}

	public String getNQCETB23_S_TP_MOVI_OPER() {
		return NQCETB23_S_TP_MOVI_OPER;
	}

	public void setNQCETB23_S_TP_MOVI_OPER(String nQCETB23_S_TP_MOVI_OPER) {
		NQCETB23_S_TP_MOVI_OPER = nQCETB23_S_TP_MOVI_OPER;
	}

	public String getNQCETB23_S_NM_CLIE() {
		return NQCETB23_S_NM_CLIE;
	}

	public void setNQCETB23_S_NM_CLIE(String nQCETB23_S_NM_CLIE) {
		NQCETB23_S_NM_CLIE = nQCETB23_S_NM_CLIE;
	}
	
	//*       NOME DO CLIENTE                                           
	//
	
	
}