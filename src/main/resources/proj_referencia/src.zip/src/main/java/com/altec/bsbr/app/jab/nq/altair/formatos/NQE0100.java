package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0100")
public class NQE0100 {
@PsFieldNumber(name="NUMATRI", length=11, defaultValue = "0" )
private Long NUMATRI;
public Long getNUMATRI() {
 return NUMATRI;
}
public void setNUMATRI(Long nUMATRI) {
NUMATRI = nUMATRI;
}

}
