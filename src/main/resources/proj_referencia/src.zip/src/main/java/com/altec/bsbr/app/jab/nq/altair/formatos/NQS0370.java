package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0370")
public class NQS0370 {
@PsFieldString(name="SGSISOR", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SGSISOR;
@PsFieldNumber(name="NRSQSIS", length=2, defaultValue = "0" )
private Integer NRSQSIS;
@PsFieldString(name="CDDETIF", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDDETIF;
@PsFieldString(name="NMDETIF", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NMDETIF;

public String getSGSISOR() {
 return SGSISOR;
}
public void setSGSISOR(String SGSISOR) {
 this.SGSISOR = SGSISOR;
}
public Integer getNRSQSIS() {
 return NRSQSIS;
}
public void setNRSQSIS(Integer nRSQSIS) {
NRSQSIS = nRSQSIS;
}
public String getCDDETIF() {
 return CDDETIF;
}
public void setCDDETIF(String CDDETIF) {
 this.CDDETIF = CDDETIF;
}

public String getNMDETIF() {
 return NMDETIF;
}
public void setNMDETIF(String NMDETIF) {
 this.NMDETIF = NMDETIF;
}


}
