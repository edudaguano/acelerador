package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "LDAOPSU")
public class LDAOPSULegadoResponse {
	/*
//  -*-LDAOPSU
//        01          OPSU-REG.                                            
//            05      OPSU-CHVIDENT.                                       
	@PsFieldNumber(name= "OPSU_CINSTIT", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long OPSU_CINSTIT;//                10  OPSU-CINSTIT        PIC 9(03)       COMP-3.          

	@PsFieldNumber(name= "OPSU_CODAGENC", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long OPSU_CODAGENC;//                10  OPSU-CODAGENC       PIC 9(04)       COMP-3.          

	@PsFieldNumber(name= "OPSU_CPROD", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long OPSU_CPROD;//                10  OPSU-CPROD          PIC 9(04)       COMP-3.          

	@PsFieldNumber(name= "OPSU_NUMCONTA", decimal= 0, length= 10, signed= false, defaultValue="0")
	private Long OPSU_NUMCONTA;//                10  OPSU-NUMCONTA       PIC 9(10)       COMP-3.          

	@PsFieldNumber(name= "OPSU_DATAMOVI", decimal= 0, length= 8, signed= false, defaultValue="0")
	private Long OPSU_DATAMOVI;//                10  OPSU-DATAMOVI       PIC 9(08)       COMP-3.          

	@PsFieldNumber(name= "OPSU_CSEQUE", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long OPSU_CSEQUE;//                10  OPSU-CSEQUE         PIC 9(03)       COMP-3.          

	@PsFieldNumber(name= "OPSU_HISTORIC", decimal= 0, length= 5, signed= false, defaultValue="0")
	private Long OPSU_HISTORIC;//            05      OPSU-HISTORIC       PIC 9(05)       COMP-3.          

	@PsFieldNumber(name= "OPSU_NUMDOCUM", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long OPSU_NUMDOCUM;//            05      OPSU-NUMDOCUM       PIC 9(07)       COMP-3.          

	@PsFieldString(name= "OPSU_CGCCPF", length= 15, paddingAlign= Align.LEFT, paddingChar= '0')
	private String OPSU_CGCCPF;//            05      OPSU-CGCCPF         PIC 9(15)       COMP-3.          

	@PsFieldString(name= "OPSU_TIPOPESS", length= 1, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String OPSU_TIPOPESS;//            05      OPSU-TIPOPESS       PIC X(01).                       

	@PsFieldString(name= "OPSU_NCLI", length= 35, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String OPSU_NCLI;//            05      OPSU-NCLI           PIC X(35).                       

	@PsFieldNumber(name= "OPSU_VALORLAN", decimal= 2, length= 13, signed= true, defaultValue="0")
	private Double OPSU_VALORLAN;//            05      OPSU-VALORLAN       PIC 9(11)V9(02) COMP-3.          

	@PsFieldNumber(name= "OPSU_CCLI", decimal= 0, length= 10, signed= false, defaultValue="0")
	private Long OPSU_CCLI;//            05      OPSU-CCLI           PIC 9(10)       COMP-3.          

	@PsFieldString(name= "OPSU_SITMOVIM", length= 1, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String OPSU_SITMOVIM;//            05      OPSU-SITMOVIM       PIC X(01).                       

	@PsFieldString(name= "OPSU_USERID", length= 9, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String OPSU_USERID;//            05      OPSU-USERID         PIC X(09).                       

	@PsFieldNumber(name= "OPSU_DATAJUST", decimal= 0, length= 8, signed= false, defaultValue="0")
	private Long OPSU_DATAJUST;//            05      OPSU-DATAJUST       PIC 9(08)       COMP-3.          

	@PsFieldNumber(name= "OPSU_HORAJUST", decimal= 0, length= 6, signed= false, defaultValue="0")
	private Long OPSU_HORAJUST;//            05      OPSU-HORAJUST       PIC 9(06)       COMP-3.          

	@PsFieldString(name= "OPSU_PEND", length= 1, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String OPSU_PEND;//            05      OPSU-PEND           PIC X(01).                       

	@PsFieldString(name= "OPSU_TPISEN", length= 1, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String OPSU_TPISEN;//            05      OPSU-TPISEN         PIC X(01).                       

	@PsFieldString(name= "OPSU_POSTO", length= 2, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String OPSU_POSTO;//            05      OPSU-POSTO          PIC X(02).                       

	@PsFieldNumber(name= "OPSU_TPCONTA", decimal= 0, length= 5, signed= false, defaultValue="0")
	private Long OPSU_TPCONTA;//            05      OPSU-TPCONTA        PIC 9(05)       COMP-3.          

//            05      OPSU-CHVIDENT1.                                      
	@PsFieldNumber(name= "OPSU_CINSTIT1", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long OPSU_CINSTIT1;//                10  OPSU-CINSTIT1       PIC 9(03)       COMP-3.          

	@PsFieldNumber(name= "OPSU_CODAGENC1", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long OPSU_CODAGENC1;//                10  OPSU-CODAGENC1      PIC 9(04)       COMP-3.          

	@PsFieldNumber(name= "OPSU_DATAMOVI1", decimal= 0, length= 8, signed= false, defaultValue="0")
	private Long OPSU_DATAMOVI1;//                10  OPSU-DATAMOVI1      PIC 9(08)       COMP-3.          

	@PsFieldString(name= "OPSU_TPAPLIC", length= 3, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String OPSU_TPAPLIC;//            05      OPSU-TPAPLIC        PIC X(03).                       

	@PsFieldNumber(name= "OPSU_NUMOPER", decimal= 0, length= 9, signed= false, defaultValue="0")
	private Long OPSU_NUMOPER;//            05      OPSU-NUMOPER        PIC 9(09)       COMP-3.          

	@PsFieldNumber(name= "OPSU_QTDELAN", decimal= 0, length= 5, signed= false, defaultValue="0")
	private Long OPSU_QTDELAN;//            05      OPSU-QTDELAN        PIC 9(05)       COMP-3.          

	@PsFieldString(name= "OPSU_TPHIST", length= 3, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String OPSU_TPHIST;//            05      OPSU-TPHIST         PIC X(03).                       

//            05      OPSU-CHVIDENT2.                                      
	@PsFieldNumber(name= "OPSU_CINSTIT2", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long OPSU_CINSTIT2;//                10  OPSU-CINSTIT2       PIC 9(03)       COMP-3.          

	@PsFieldNumber(name= "OPSU_CODAGENC2", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long OPSU_CODAGENC2;//                10  OPSU-CODAGENC2      PIC 9(04)       COMP-3.          

	@PsFieldNumber(name= "OPSU_CCLI2", decimal= 0, length= 10, signed= false, defaultValue="0")
	private Long OPSU_CCLI2;//                10  OPSU-CCLI2          PIC 9(10)       COMP-3.          

	@PsFieldString(name= "OPSU_INDESP", length= 1, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String OPSU_INDESP;//            05      OPSU-INDESP         PIC X(01).                       

	@PsFieldString(name= "OPSU_TIPOLAN", length= 1, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String OPSU_TIPOLAN;//            05      OPSU-TIPOLAN        PIC X(01).                       

	@PsFieldNumber(name= "05", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long 05;// PJ0004     05      OPSU-DATAINIP       PIC 9(08).                       

	@PsFieldNumber(name= "05", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long 05;// PJ0004     05      OPSU-PERFIL         PIC 9(02).                       

// PJ0004     05      OPSU-CHVIDENT3.                                      
	@PsFieldNumber(name= "10", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long 10;// PJ0004         10  OPSU-CINSTIT3       PIC 9(03)       COMP-3.          

	@PsFieldNumber(name= "10", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long 10;// PJ0004         10  OPSU-CCLI3          PIC 9(10)       COMP-3.          

	@PsFieldNumber(name= "10", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long 10;// PJ0004         10  OPSU-DATAMOVI3      PIC 9(08)       COMP-3.          

	@PsFieldNumber(name= "10", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long 10;// PJ0004         10  OPSU-CODAGENC3      PIC 9(04)       COMP-3.          

// ML8303     05    OPSU-CHVIDENT4.                                        
	@PsFieldString(name= "10", length= 0, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String 10;// ML8303         10  OPSU-CODGRUPO4      PIC X(01).                       

	@PsFieldString(name= "10", length= 0, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String 10;// ML8303         10  OPSU-TIPOPV4        PIC X(01).                       

	@PsFieldString(name= "10", length= 0, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String 10;// ML8303         10  OPSU-SITMOVIM4      PIC X(01).                       

	@PsFieldNumber(name= "10", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long 10;// ML8303         10  OPSU-CINSTIT4       PIC 9(03)       COMP-3.          

	@PsFieldNumber(name= "10", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long 10;// ML8303         10  OPSU-DATAMOVI4      PIC 9(08)       COMP-3.          

	@PsFieldNumber(name= "10", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long 10;// ML8303         10  OPSU-CODAGENC4      PIC 9(04)       COMP-3.          

	@PsFieldString(name= "05", length= 0, paddingAlign= Align.LEFT, paddingChar= ' ')
	private String 05;// JL0403     05      FILLER              PIC X(13).                       

	public LDAOPSULegadoResponse() { }
	public LDAOPSULegadoResponse(Long opsu_cinstit, Long opsu_codagenc, Long opsu_cprod, Long opsu_numconta, Long opsu_datamovi, Long opsu_cseque, Long opsu_historic, Long opsu_numdocum, String opsu_cgccpf, String opsu_tipopess, String opsu_ncli, Double opsu_valorlan, Long opsu_ccli, String opsu_sitmovim, String opsu_userid, Long opsu_datajust, Long opsu_horajust, String opsu_pend, String opsu_tpisen, String opsu_posto, Long opsu_tpconta, Long opsu_cinstit1, Long opsu_codagenc1, Long opsu_datamovi1, String opsu_tpaplic, Long opsu_numoper, Long opsu_qtdelan, String opsu_tphist, Long opsu_cinstit2, Long opsu_codagenc2, Long opsu_ccli2, String opsu_indesp, String opsu_tipolan, Long 05, Long 05, Long 10, Long 10, Long 10, Long 10, String 10, String 10, String 10, Long 10, Long 10, Long 10, String 05) { 		this.OPSU_CINSTIT = opsu_cinstit;
		this.OPSU_CODAGENC = opsu_codagenc;
		this.OPSU_CPROD = opsu_cprod;
		this.OPSU_NUMCONTA = opsu_numconta;
		this.OPSU_DATAMOVI = opsu_datamovi;
		this.OPSU_CSEQUE = opsu_cseque;
		this.OPSU_HISTORIC = opsu_historic;
		this.OPSU_NUMDOCUM = opsu_numdocum;
		this.OPSU_CGCCPF = opsu_cgccpf;
		this.OPSU_TIPOPESS = opsu_tipopess;
		this.OPSU_NCLI = opsu_ncli;
		this.OPSU_VALORLAN = opsu_valorlan;
		this.OPSU_CCLI = opsu_ccli;
		this.OPSU_SITMOVIM = opsu_sitmovim;
		this.OPSU_USERID = opsu_userid;
		this.OPSU_DATAJUST = opsu_datajust;
		this.OPSU_HORAJUST = opsu_horajust;
		this.OPSU_PEND = opsu_pend;
		this.OPSU_TPISEN = opsu_tpisen;
		this.OPSU_POSTO = opsu_posto;
		this.OPSU_TPCONTA = opsu_tpconta;
		this.OPSU_CINSTIT1 = opsu_cinstit1;
		this.OPSU_CODAGENC1 = opsu_codagenc1;
		this.OPSU_DATAMOVI1 = opsu_datamovi1;
		this.OPSU_TPAPLIC = opsu_tpaplic;
		this.OPSU_NUMOPER = opsu_numoper;
		this.OPSU_QTDELAN = opsu_qtdelan;
		this.OPSU_TPHIST = opsu_tphist;
		this.OPSU_CINSTIT2 = opsu_cinstit2;
		this.OPSU_CODAGENC2 = opsu_codagenc2;
		this.OPSU_CCLI2 = opsu_ccli2;
		this.OPSU_INDESP = opsu_indesp;
		this.OPSU_TIPOLAN = opsu_tipolan;
		this.05 = 05;
		this.05 = 05;
		this.10 = 10;
		this.10 = 10;
		this.10 = 10;
		this.10 = 10;
		this.10 = 10;
		this.10 = 10;
		this.10 = 10;
		this.10 = 10;
		this.10 = 10;
		this.10 = 10;
		this.05 = 05; 
	}
	public Long getOPSU_CINSTIT() { return this.OPSU_CINSTIT; }
	public Long getOPSU_CODAGENC() { return this.OPSU_CODAGENC; }
	public Long getOPSU_CPROD() { return this.OPSU_CPROD; }
	public Long getOPSU_NUMCONTA() { return this.OPSU_NUMCONTA; }
	public Long getOPSU_DATAMOVI() { return this.OPSU_DATAMOVI; }
	public Long getOPSU_CSEQUE() { return this.OPSU_CSEQUE; }
	public Long getOPSU_HISTORIC() { return this.OPSU_HISTORIC; }
	public Long getOPSU_NUMDOCUM() { return this.OPSU_NUMDOCUM; }
	public String getOPSU_CGCCPF() { return this.OPSU_CGCCPF; }
	public String getOPSU_TIPOPESS() { return this.OPSU_TIPOPESS; }
	public String getOPSU_NCLI() { return this.OPSU_NCLI; }
	public Double getOPSU_VALORLAN() { return this.OPSU_VALORLAN; }
	public Long getOPSU_CCLI() { return this.OPSU_CCLI; }
	public String getOPSU_SITMOVIM() { return this.OPSU_SITMOVIM; }
	public String getOPSU_USERID() { return this.OPSU_USERID; }
	public Long getOPSU_DATAJUST() { return this.OPSU_DATAJUST; }
	public Long getOPSU_HORAJUST() { return this.OPSU_HORAJUST; }
	public String getOPSU_PEND() { return this.OPSU_PEND; }
	public String getOPSU_TPISEN() { return this.OPSU_TPISEN; }
	public String getOPSU_POSTO() { return this.OPSU_POSTO; }
	public Long getOPSU_TPCONTA() { return this.OPSU_TPCONTA; }
	public Long getOPSU_CINSTIT1() { return this.OPSU_CINSTIT1; }
	public Long getOPSU_CODAGENC1() { return this.OPSU_CODAGENC1; }
	public Long getOPSU_DATAMOVI1() { return this.OPSU_DATAMOVI1; }
	public String getOPSU_TPAPLIC() { return this.OPSU_TPAPLIC; }
	public Long getOPSU_NUMOPER() { return this.OPSU_NUMOPER; }
	public Long getOPSU_QTDELAN() { return this.OPSU_QTDELAN; }
	public String getOPSU_TPHIST() { return this.OPSU_TPHIST; }
	public Long getOPSU_CINSTIT2() { return this.OPSU_CINSTIT2; }
	public Long getOPSU_CODAGENC2() { return this.OPSU_CODAGENC2; }
	public Long getOPSU_CCLI2() { return this.OPSU_CCLI2; }
	public String getOPSU_INDESP() { return this.OPSU_INDESP; }
	public String getOPSU_TIPOLAN() { return this.OPSU_TIPOLAN; }
	public Long get05() { return this.05; }
	public Long get05() { return this.05; }
	public Long get10() { return this.10; }
	public Long get10() { return this.10; }
	public Long get10() { return this.10; }
	public Long get10() { return this.10; }
	public String get10() { return this.10; }
	public String get10() { return this.10; }
	public String get10() { return this.10; }
	public Long get10() { return this.10; }
	public Long get10() { return this.10; }
	public Long get10() { return this.10; }
	public String get05() { return this.05; }
	public void setOPSU_CINSTIT(Long opsu_cinstit) { this.OPSU_CINSTIT = opsu_cinstit; }
	public void setOPSU_CODAGENC(Long opsu_codagenc) { this.OPSU_CODAGENC = opsu_codagenc; }
	public void setOPSU_CPROD(Long opsu_cprod) { this.OPSU_CPROD = opsu_cprod; }
	public void setOPSU_NUMCONTA(Long opsu_numconta) { this.OPSU_NUMCONTA = opsu_numconta; }
	public void setOPSU_DATAMOVI(Long opsu_datamovi) { this.OPSU_DATAMOVI = opsu_datamovi; }
	public void setOPSU_CSEQUE(Long opsu_cseque) { this.OPSU_CSEQUE = opsu_cseque; }
	public void setOPSU_HISTORIC(Long opsu_historic) { this.OPSU_HISTORIC = opsu_historic; }
	public void setOPSU_NUMDOCUM(Long opsu_numdocum) { this.OPSU_NUMDOCUM = opsu_numdocum; }
	public void setOPSU_CGCCPF(String opsu_cgccpf) { this.OPSU_CGCCPF = opsu_cgccpf; }
	public void setOPSU_TIPOPESS(String opsu_tipopess) { this.OPSU_TIPOPESS = opsu_tipopess; }
	public void setOPSU_NCLI(String opsu_ncli) { this.OPSU_NCLI = opsu_ncli; }
	public void setOPSU_VALORLAN(Double opsu_valorlan) { this.OPSU_VALORLAN = opsu_valorlan; }
	public void setOPSU_CCLI(Long opsu_ccli) { this.OPSU_CCLI = opsu_ccli; }
	public void setOPSU_SITMOVIM(String opsu_sitmovim) { this.OPSU_SITMOVIM = opsu_sitmovim; }
	public void setOPSU_USERID(String opsu_userid) { this.OPSU_USERID = opsu_userid; }
	public void setOPSU_DATAJUST(Long opsu_datajust) { this.OPSU_DATAJUST = opsu_datajust; }
	public void setOPSU_HORAJUST(Long opsu_horajust) { this.OPSU_HORAJUST = opsu_horajust; }
	public void setOPSU_PEND(String opsu_pend) { this.OPSU_PEND = opsu_pend; }
	public void setOPSU_TPISEN(String opsu_tpisen) { this.OPSU_TPISEN = opsu_tpisen; }
	public void setOPSU_POSTO(String opsu_posto) { this.OPSU_POSTO = opsu_posto; }
	public void setOPSU_TPCONTA(Long opsu_tpconta) { this.OPSU_TPCONTA = opsu_tpconta; }
	public void setOPSU_CINSTIT1(Long opsu_cinstit1) { this.OPSU_CINSTIT1 = opsu_cinstit1; }
	public void setOPSU_CODAGENC1(Long opsu_codagenc1) { this.OPSU_CODAGENC1 = opsu_codagenc1; }
	public void setOPSU_DATAMOVI1(Long opsu_datamovi1) { this.OPSU_DATAMOVI1 = opsu_datamovi1; }
	public void setOPSU_TPAPLIC(String opsu_tpaplic) { this.OPSU_TPAPLIC = opsu_tpaplic; }
	public void setOPSU_NUMOPER(Long opsu_numoper) { this.OPSU_NUMOPER = opsu_numoper; }
	public void setOPSU_QTDELAN(Long opsu_qtdelan) { this.OPSU_QTDELAN = opsu_qtdelan; }
	public void setOPSU_TPHIST(String opsu_tphist) { this.OPSU_TPHIST = opsu_tphist; }
	public void setOPSU_CINSTIT2(Long opsu_cinstit2) { this.OPSU_CINSTIT2 = opsu_cinstit2; }
	public void setOPSU_CODAGENC2(Long opsu_codagenc2) { this.OPSU_CODAGENC2 = opsu_codagenc2; }
	public void setOPSU_CCLI2(Long opsu_ccli2) { this.OPSU_CCLI2 = opsu_ccli2; }
	public void setOPSU_INDESP(String opsu_indesp) { this.OPSU_INDESP = opsu_indesp; }
	public void setOPSU_TIPOLAN(String opsu_tipolan) { this.OPSU_TIPOLAN = opsu_tipolan; }
	public void set05(Long 05) { this.05 = 05; }
	public void set05(Long 05) { this.05 = 05; }
	public void set10(Long 10) { this.10 = 10; }
	public void set10(Long 10) { this.10 = 10; }
	public void set10(Long 10) { this.10 = 10; }
	public void set10(Long 10) { this.10 = 10; }
	public void set10(String 10) { this.10 = 10; }
	public void set10(String 10) { this.10 = 10; }
	public void set10(String 10) { this.10 = 10; }
	public void set10(Long 10) { this.10 = 10; }
	public void set10(Long 10) { this.10 = 10; }
	public void set10(Long 10) { this.10 = 10; }
	public void set05(String 05) { this.05 = 05; }
	*/
}