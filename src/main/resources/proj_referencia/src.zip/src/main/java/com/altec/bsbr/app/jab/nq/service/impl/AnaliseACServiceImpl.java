package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.AnaliseACDao;
import com.altec.bsbr.app.jab.nq.service.AnaliseACService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class AnaliseACServiceImpl implements AnaliseACService {
	private final Logger LOGGER = LoggerFactory.getLogger(AnaliseACServiceImpl.class);
	@Autowired
	private AnaliseACDao analiseac;

	public String consultarAnalises(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser, String strFuncao) throws BusinessException {
		return analiseac.consultarAnalises(strCodSist, strBanco, strCodCliente, strDtOcorr, strNotUPLD, strParOper,
				strParGer, strParUPLD, strRegra, strPeriodo, strCodUser, strFuncao);
	}

	public String listarPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser) throws BusinessException {
		return analiseac.listarPareceres(strCodSist, strBanco, strCodCliente, strDtOcorr, strNotUPLD, strParOper,
				strParGer, strParUPLD, strRegra, strPeriodo, strCodUser);
	}

	public String listarClientes(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser) throws BusinessException {
		return analiseac.listarClientes(strCodSist, strBanco, strCodCliente, strDtOcorr, strNotUPLD, strParOper,
				strParGer, strParUPLD, strRegra, strPeriodo, strCodUser);
	}

	public String fnAddCaracter(String vlr, String tp, String tam) throws BusinessException {
		return analiseac.fnAddCaracter(vlr, tp, tam);
	}

	public String dataAlta(String dtBaixa) throws BusinessException {
		return analiseac.dataAlta(dtBaixa);
	}
}
