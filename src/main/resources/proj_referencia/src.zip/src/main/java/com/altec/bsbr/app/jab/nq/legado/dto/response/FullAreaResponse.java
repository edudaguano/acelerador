package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

/*
 * O conector não faz parser quando há formatos diferentes de resposta. 
 * Para isto, utilizamos um DTO intermediário que captura a string e depois quebramos campo a campo.
 */

@PsFormat(name = "FullArea")
public class FullAreaResponse {

	@PsFieldString(name = "RETORNO", length = 500, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String retorno;

	public String getRetorno() {
		return retorno;
	}

	public void setRetorno(String retorno) {
		this.retorno = retorno;
	}
	
	
}
