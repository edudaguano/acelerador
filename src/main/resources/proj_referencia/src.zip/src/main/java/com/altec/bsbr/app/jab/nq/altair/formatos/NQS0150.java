package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0150")
public class NQS0150 {
@PsFieldString(name="SIGLA01", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SIGLA01;
@PsFieldNumber(name="NUMSE01", length=2, defaultValue = "0" )
private Integer NUMSE01;
@PsFieldString(name="CODET01", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODET01;
@PsFieldString(name="NOMEP01", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOMEP01;
@PsFieldNumber(name="VLRMI01", length=17, decimal=2, defaultValue = "0" )
private double VLRMI01;
@PsFieldString(name="TSFIL01", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TSFIL01;
@PsFieldString(name="ICMON01", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMON01;
@PsFieldString(name="SIGLA02", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SIGLA02;
@PsFieldNumber(name="NUMSE02", length=2, defaultValue = "0" )
private Integer NUMSE02;
@PsFieldString(name="CODET02", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODET02;
@PsFieldString(name="NOMEP02", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOMEP02;
@PsFieldNumber(name="VLRMI02", length=17, decimal=2, defaultValue = "0" )
private double VLRMI02;
@PsFieldString(name="TSFIL02", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TSFIL02;
@PsFieldString(name="ICMON02", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMON02;
@PsFieldString(name="SIGLA03", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SIGLA03;
@PsFieldNumber(name="NUMSE03", length=2, defaultValue = "0" )
private Integer NUMSE03;
@PsFieldString(name="CODET03", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODET03;
@PsFieldString(name="NOMEP03", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOMEP03;
@PsFieldNumber(name="VLRMI03", length=17, decimal=2, defaultValue = "0" )
private double VLRMI03;
@PsFieldString(name="TSFIL03", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TSFIL03;
@PsFieldString(name="ICMON03", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMON03;
@PsFieldString(name="SIGLA04", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SIGLA04;
@PsFieldNumber(name="NUMSE04", length=2, defaultValue = "0" )
private Integer NUMSE04;
@PsFieldString(name="CODET04", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODET04;
@PsFieldString(name="NOMEP04", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOMEP04;
@PsFieldNumber(name="VLRMI04", length=17, decimal=2, defaultValue = "0" )
private double VLRMI04;
@PsFieldString(name="TSFIL04", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TSFIL04;
@PsFieldString(name="ICMON04", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMON04;
@PsFieldString(name="SIGLA05", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SIGLA05;
@PsFieldNumber(name="NUMSE05", length=2, defaultValue = "0" )
private Integer NUMSE05;
@PsFieldString(name="CODET05", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODET05;
@PsFieldString(name="NOMEP05", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOMEP05;
@PsFieldNumber(name="VLRMI05", length=17, decimal=2, defaultValue = "0" )
private double VLRMI05;
@PsFieldString(name="TSFIL05", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TSFIL05;
@PsFieldString(name="ICMON05", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMON05;
@PsFieldString(name="SIGLA06", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SIGLA06;
@PsFieldNumber(name="NUMSE06", length=2, defaultValue = "0" )
private Integer NUMSE06;
@PsFieldString(name="CODET06", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODET06;
@PsFieldString(name="NOMEP06", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOMEP06;
@PsFieldNumber(name="VLRMI06", length=17, decimal=2, defaultValue = "0" )
private double VLRMI06;
@PsFieldString(name="TSFIL06", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TSFIL06;
@PsFieldString(name="ICMON06", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMON06;
@PsFieldString(name="SIGLA07", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SIGLA07;
@PsFieldNumber(name="NUMSE07", length=2, defaultValue = "0" )
private Integer NUMSE07;
@PsFieldString(name="CODET07", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODET07;
@PsFieldString(name="NOMEP07", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOMEP07;
@PsFieldNumber(name="VLRMI07", length=17, decimal=2, defaultValue = "0" )
private double VLRMI07;
@PsFieldString(name="TSFIL07", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TSFIL07;
@PsFieldString(name="ICMON07", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMON07;
@PsFieldString(name="SIGLA08", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SIGLA08;
@PsFieldNumber(name="NUMSE08", length=2, defaultValue = "0" )
private Integer NUMSE08;
@PsFieldString(name="CODET08", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODET08;
@PsFieldString(name="NOMEP08", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOMEP08;
@PsFieldNumber(name="VLRMI08", length=17, decimal=2, defaultValue = "0" )
private double VLRMI08;
@PsFieldString(name="TSFIL08", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TSFIL08;
@PsFieldString(name="ICMON08", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMON08;
@PsFieldString(name="SIGLA09", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String SIGLA09;
@PsFieldNumber(name="NUMSE09", length=2, defaultValue = "0" )
private Integer NUMSE09;
@PsFieldString(name="CODET09", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODET09;
@PsFieldString(name="NOMEP09", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOMEP09;
@PsFieldNumber(name="VLRMI09", length=17, decimal=2, defaultValue = "0" )
private double VLRMI09;
@PsFieldString(name="TSFIL09", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TSFIL09;
@PsFieldString(name="ICMON09", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMON09;
@PsFieldString(name="INDPAGS", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String INDPAGS;

public String getSIGLA01() {
 return SIGLA01;
}
public void setSIGLA01(String SIGLA01) {
 this.SIGLA01 = SIGLA01;
}
public Integer getNUMSE01() {
 return NUMSE01;
}
public void setNUMSE01(Integer nUMSE01) {
NUMSE01 = nUMSE01;
}
public String getCODET01() {
 return CODET01;
}
public void setCODET01(String CODET01) {
 this.CODET01 = CODET01;
}

public String getNOMEP01() {
 return NOMEP01;
}
public void setNOMEP01(String NOMEP01) {
 this.NOMEP01 = NOMEP01;
}
public double getVLRMI01() {
 return VLRMI01;
}
public void setVLRMI01(double vLRMI01) {
VLRMI01 = vLRMI01;
}
public String getTSFIL01() {
 return TSFIL01;
}
public void setTSFIL01(String TSFIL01) {
 this.TSFIL01 = TSFIL01;
}

public String getICMON01() {
 return ICMON01;
}
public void setICMON01(String ICMON01) {
 this.ICMON01 = ICMON01;
}

public String getSIGLA02() {
 return SIGLA02;
}
public void setSIGLA02(String SIGLA02) {
 this.SIGLA02 = SIGLA02;
}
public Integer getNUMSE02() {
 return NUMSE02;
}
public void setNUMSE02(Integer nUMSE02) {
NUMSE02 = nUMSE02;
}
public String getCODET02() {
 return CODET02;
}
public void setCODET02(String CODET02) {
 this.CODET02 = CODET02;
}

public String getNOMEP02() {
 return NOMEP02;
}
public void setNOMEP02(String NOMEP02) {
 this.NOMEP02 = NOMEP02;
}
public double getVLRMI02() {
 return VLRMI02;
}
public void setVLRMI02(double vLRMI02) {
VLRMI02 = vLRMI02;
}
public String getTSFIL02() {
 return TSFIL02;
}
public void setTSFIL02(String TSFIL02) {
 this.TSFIL02 = TSFIL02;
}

public String getICMON02() {
 return ICMON02;
}
public void setICMON02(String ICMON02) {
 this.ICMON02 = ICMON02;
}

public String getSIGLA03() {
 return SIGLA03;
}
public void setSIGLA03(String SIGLA03) {
 this.SIGLA03 = SIGLA03;
}
public Integer getNUMSE03() {
 return NUMSE03;
}
public void setNUMSE03(Integer nUMSE03) {
NUMSE03 = nUMSE03;
}
public String getCODET03() {
 return CODET03;
}
public void setCODET03(String CODET03) {
 this.CODET03 = CODET03;
}

public String getNOMEP03() {
 return NOMEP03;
}
public void setNOMEP03(String NOMEP03) {
 this.NOMEP03 = NOMEP03;
}
public double getVLRMI03() {
 return VLRMI03;
}
public void setVLRMI03(double vLRMI03) {
VLRMI03 = vLRMI03;
}
public String getTSFIL03() {
 return TSFIL03;
}
public void setTSFIL03(String TSFIL03) {
 this.TSFIL03 = TSFIL03;
}

public String getICMON03() {
 return ICMON03;
}
public void setICMON03(String ICMON03) {
 this.ICMON03 = ICMON03;
}

public String getSIGLA04() {
 return SIGLA04;
}
public void setSIGLA04(String SIGLA04) {
 this.SIGLA04 = SIGLA04;
}
public Integer getNUMSE04() {
 return NUMSE04;
}
public void setNUMSE04(Integer nUMSE04) {
NUMSE04 = nUMSE04;
}
public String getCODET04() {
 return CODET04;
}
public void setCODET04(String CODET04) {
 this.CODET04 = CODET04;
}

public String getNOMEP04() {
 return NOMEP04;
}
public void setNOMEP04(String NOMEP04) {
 this.NOMEP04 = NOMEP04;
}
public double getVLRMI04() {
 return VLRMI04;
}
public void setVLRMI04(double vLRMI04) {
VLRMI04 = vLRMI04;
}
public String getTSFIL04() {
 return TSFIL04;
}
public void setTSFIL04(String TSFIL04) {
 this.TSFIL04 = TSFIL04;
}

public String getICMON04() {
 return ICMON04;
}
public void setICMON04(String ICMON04) {
 this.ICMON04 = ICMON04;
}

public String getSIGLA05() {
 return SIGLA05;
}
public void setSIGLA05(String SIGLA05) {
 this.SIGLA05 = SIGLA05;
}
public Integer getNUMSE05() {
 return NUMSE05;
}
public void setNUMSE05(Integer nUMSE05) {
NUMSE05 = nUMSE05;
}
public String getCODET05() {
 return CODET05;
}
public void setCODET05(String CODET05) {
 this.CODET05 = CODET05;
}

public String getNOMEP05() {
 return NOMEP05;
}
public void setNOMEP05(String NOMEP05) {
 this.NOMEP05 = NOMEP05;
}
public double getVLRMI05() {
 return VLRMI05;
}
public void setVLRMI05(double vLRMI05) {
VLRMI05 = vLRMI05;
}
public String getTSFIL05() {
 return TSFIL05;
}
public void setTSFIL05(String TSFIL05) {
 this.TSFIL05 = TSFIL05;
}

public String getICMON05() {
 return ICMON05;
}
public void setICMON05(String ICMON05) {
 this.ICMON05 = ICMON05;
}

public String getSIGLA06() {
 return SIGLA06;
}
public void setSIGLA06(String SIGLA06) {
 this.SIGLA06 = SIGLA06;
}
public Integer getNUMSE06() {
 return NUMSE06;
}
public void setNUMSE06(Integer nUMSE06) {
NUMSE06 = nUMSE06;
}
public String getCODET06() {
 return CODET06;
}
public void setCODET06(String CODET06) {
 this.CODET06 = CODET06;
}

public String getNOMEP06() {
 return NOMEP06;
}
public void setNOMEP06(String NOMEP06) {
 this.NOMEP06 = NOMEP06;
}
public double getVLRMI06() {
 return VLRMI06;
}
public void setVLRMI06(double vLRMI06) {
VLRMI06 = vLRMI06;
}
public String getTSFIL06() {
 return TSFIL06;
}
public void setTSFIL06(String TSFIL06) {
 this.TSFIL06 = TSFIL06;
}

public String getICMON06() {
 return ICMON06;
}
public void setICMON06(String ICMON06) {
 this.ICMON06 = ICMON06;
}

public String getSIGLA07() {
 return SIGLA07;
}
public void setSIGLA07(String SIGLA07) {
 this.SIGLA07 = SIGLA07;
}
public Integer getNUMSE07() {
 return NUMSE07;
}
public void setNUMSE07(Integer nUMSE07) {
NUMSE07 = nUMSE07;
}
public String getCODET07() {
 return CODET07;
}
public void setCODET07(String CODET07) {
 this.CODET07 = CODET07;
}

public String getNOMEP07() {
 return NOMEP07;
}
public void setNOMEP07(String NOMEP07) {
 this.NOMEP07 = NOMEP07;
}
public double getVLRMI07() {
 return VLRMI07;
}
public void setVLRMI07(double vLRMI07) {
VLRMI07 = vLRMI07;
}
public String getTSFIL07() {
 return TSFIL07;
}
public void setTSFIL07(String TSFIL07) {
 this.TSFIL07 = TSFIL07;
}

public String getICMON07() {
 return ICMON07;
}
public void setICMON07(String ICMON07) {
 this.ICMON07 = ICMON07;
}

public String getSIGLA08() {
 return SIGLA08;
}
public void setSIGLA08(String SIGLA08) {
 this.SIGLA08 = SIGLA08;
}
public Integer getNUMSE08() {
 return NUMSE08;
}
public void setNUMSE08(Integer nUMSE08) {
NUMSE08 = nUMSE08;
}
public String getCODET08() {
 return CODET08;
}
public void setCODET08(String CODET08) {
 this.CODET08 = CODET08;
}

public String getNOMEP08() {
 return NOMEP08;
}
public void setNOMEP08(String NOMEP08) {
 this.NOMEP08 = NOMEP08;
}
public double getVLRMI08() {
 return VLRMI08;
}
public void setVLRMI08(double vLRMI08) {
VLRMI08 = vLRMI08;
}
public String getTSFIL08() {
 return TSFIL08;
}
public void setTSFIL08(String TSFIL08) {
 this.TSFIL08 = TSFIL08;
}

public String getICMON08() {
 return ICMON08;
}
public void setICMON08(String ICMON08) {
 this.ICMON08 = ICMON08;
}

public String getSIGLA09() {
 return SIGLA09;
}
public void setSIGLA09(String SIGLA09) {
 this.SIGLA09 = SIGLA09;
}
public Integer getNUMSE09() {
 return NUMSE09;
}
public void setNUMSE09(Integer nUMSE09) {
NUMSE09 = nUMSE09;
}
public String getCODET09() {
 return CODET09;
}
public void setCODET09(String CODET09) {
 this.CODET09 = CODET09;
}

public String getNOMEP09() {
 return NOMEP09;
}
public void setNOMEP09(String NOMEP09) {
 this.NOMEP09 = NOMEP09;
}
public double getVLRMI09() {
 return VLRMI09;
}
public void setVLRMI09(double vLRMI09) {
VLRMI09 = vLRMI09;
}
public String getTSFIL09() {
 return TSFIL09;
}
public void setTSFIL09(String TSFIL09) {
 this.TSFIL09 = TSFIL09;
}

public String getICMON09() {
 return ICMON09;
}
public void setICMON09(String ICMON09) {
 this.ICMON09 = ICMON09;
}

public String getINDPAGS() {
 return INDPAGS;
}
public void setINDPAGS(String INDPAGS) {
 this.INDPAGS = INDPAGS;
}


}
