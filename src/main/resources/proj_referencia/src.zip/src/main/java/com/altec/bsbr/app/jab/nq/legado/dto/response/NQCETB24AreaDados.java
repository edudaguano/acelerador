package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name = "NQCETB24AreaDados")
public class NQCETB24AreaDados {

	// * NUMERO SEQUENCIAL DA OPERACAO
//  
//*----------------------------------------------------------------*
//*       AREA DE SAIDA                                             
//*----------------------------------------------------------------*
//  
	@PsFieldString(name = "NQCETB24_S_CD_BANC_CLIE", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_CD_BANC_CLIE;// 05 NQCETB24-S-CD-BANC-CLIE PIC X(004).

//*       CODIGO DO BANCO                                           
//  
	@PsFieldString(name = "NQCETB24_S_CD_CLIE", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_CD_CLIE;// 05 NQCETB24-S-CD-CLIE PIC X(008).

//*       CODIGO DO CLIENTE                                         
//  
	@PsFieldString(name = "NQCETB24_S_DT_MOVI", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_DT_MOVI;// 05 NQCETB24-S-DT-MOVI PIC X(010).

//*       DATA DO MOVIMENTO                                         
//  
	@PsFieldString(name = "NQCETB24_S_CD_CNTA_DEBT_SEGR", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_CD_CNTA_DEBT_SEGR;// 05 NQCETB24-S-CD-CNTA-DEBT-SEGR PIC X(020).

//*       CODIGO DA CONTA DE DEBITO                                 
//  
	@PsFieldString(name = "NQCETB24_S_NR_PROP_SEGR", length = 12, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_NR_PROP_SEGR;// 05 NQCETB24-S-NR-PROP-SEGR PIC X(012).

//*       NUMERO DA PROPOSTA                                        
//  
	@PsFieldString(name = "NQCETB24_S_NR_APOL_SEGR", length = 30, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_NR_APOL_SEGR;// 05 NQCETB24-S-NR-APOL-SEGR PIC X(030).

//*       NUMERO DA APOLICE                                         
//  
	@PsFieldNumber(name = "NQCETB24_S_VL_PREM_PAGO", decimal = 3, length = 18, signed = true, defaultValue = "0")
	private Double NQCETB24_S_VL_PREM_PAGO;// 05 NQCETB24-S-VL-PREM-PAGO PIC S9(015)V99.

//*       VALOR DO PREMIO PAGO                                      
//  
	@PsFieldNumber(name = "NQCETB24_S_VL_PREM_DEVO", decimal = 3, length = 18, signed = true, defaultValue = "0")
	private Double NQCETB24_S_VL_PREM_DEVO;// 05 NQCETB24-S-VL-PREM-DEVO PIC S9(015)V99.

//*       VALOR DO PREMIO DEVOLVIDO                                 
//  
	@PsFieldNumber(name = "NQCETB24_S_VL_PGTO", decimal = 3, length = 18, signed = true, defaultValue = "0")
	private Double NQCETB24_S_VL_PGTO;// 05 NQCETB24-S-VL-PGTO PIC S9(015)V99.

//*       VALOR DO PAGAMENTO                                        
//  
	@PsFieldString(name = "NQCETB24_S_DT_PGTO", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_DT_PGTO;// 05 NQCETB24-S-DT-PGTO PIC X(010).

//*       DATA DO PAGAMENTO                                         
//  
	@PsFieldString(name = "NQCETB24_S_TP_DE_SINI", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_TP_DE_SINI;// 05 NQCETB24-S-TP-DE-SINI PIC X(002).

//*       TIPO DE SINISTRO                                          
//  
	@PsFieldString(name = "NQCETB24_S_NR_BENF", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_NR_BENF;// 05 NQCETB24-S-NR-BENF PIC X(020).

//*       NUMERO DO BENEFICIARIO                                    
//  
	@PsFieldString(name = "NQCETB24_S_TP_FORM_PGTO", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_TP_FORM_PGTO;// 05 NQCETB24-S-TP-FORM-PGTO PIC X(001).

//*       TIPO DA FORMA DE PAGAMENTO                                
//  
	@PsFieldString(name = "NQCETB24_S_TP_TRAN", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_TP_TRAN;// 05 NQCETB24-S-TP-TRAN PIC X(001).

//*       TIPO DE TRANSACAO                                         
//  
	@PsFieldString(name = "NQCETB24_S_CD_BANC_CNTR", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_CD_BANC_CNTR;// 05 NQCETB24-S-CD-BANC-CNTR PIC X(004).

//*       CODIGO DO BANCO DO CONTRATO                               
//  
	@PsFieldString(name = "NQCETB24_S_CD_AGEN_CNTR", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_CD_AGEN_CNTR;// 05 NQCETB24-S-CD-AGEN-CNTR PIC X(004).

//*       CODIGO DA AGENCIA DO CONTRATO                             
//  
	@PsFieldString(name = "NQCETB24_S_NR_CNTR_A", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_NR_CNTR_A;// 05 NQCETB24-S-NR-CNTR-A PIC X(020).

//*       NUMERO DO CONTRATO ALTAIR                                 
//  
	@PsFieldString(name = "NQCETB24_S_CD_PROD_ALTAIR", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_CD_PROD_ALTAIR;// 05 NQCETB24-S-CD-PROD-ALTAIR PIC X(002).

//*       CODIGO DO PRODUTO                                         
//  
	@PsFieldString(name = "NQCETB24_S_CD_SUBP_ALTAIR", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_CD_SUBP_ALTAIR;// 05 NQCETB24-S-CD-SUBP-ALTAIR PIC X(004).

//*       CODIGO DO SUBPRODUTO                                      
//  
	@PsFieldString(name = "NQCETB24_S_CD_MOED", length = 3, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_CD_MOED;// 05 NQCETB24-S-CD-MOED PIC X(003).

//*       CODIGO DA MOEDA                                           
//  
	@PsFieldNumber(name = "NQCETB24_S_NR_SEQU_OPER", decimal = 0, length = 3, signed = false, defaultValue = "0")
	private Long NQCETB24_S_NR_SEQU_OPER;// 05 NQCETB24-S-NR-SEQU-OPER PIC 9(003).

//*       NUMERO SEQUENCIAL DA OPERACAO                             
//  
	@PsFieldString(name = "NQCETB24_S_CD_IDEF_OPER", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_CD_IDEF_OPER;// 05 NQCETB24-S-CD-IDEF-OPER PIC X(020).

//*       CODIGO DA IDENTIFICACAO DA OPERACAO                       
//  
	@PsFieldString(name = "NQCETB24_S_NM_CLIE", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB24_S_NM_CLIE;// 05 NQCETB24-S-NM-CLIE PIC X(040).

	public String getNQCETB24_S_CD_BANC_CLIE() {
		return NQCETB24_S_CD_BANC_CLIE;
	}

	public void setNQCETB24_S_CD_BANC_CLIE(String nQCETB24_S_CD_BANC_CLIE) {
		NQCETB24_S_CD_BANC_CLIE = nQCETB24_S_CD_BANC_CLIE;
	}

	public String getNQCETB24_S_CD_CLIE() {
		return NQCETB24_S_CD_CLIE;
	}

	public void setNQCETB24_S_CD_CLIE(String nQCETB24_S_CD_CLIE) {
		NQCETB24_S_CD_CLIE = nQCETB24_S_CD_CLIE;
	}

	public String getNQCETB24_S_DT_MOVI() {
		return NQCETB24_S_DT_MOVI;
	}

	public void setNQCETB24_S_DT_MOVI(String nQCETB24_S_DT_MOVI) {
		NQCETB24_S_DT_MOVI = nQCETB24_S_DT_MOVI;
	}

	public String getNQCETB24_S_CD_CNTA_DEBT_SEGR() {
		return NQCETB24_S_CD_CNTA_DEBT_SEGR;
	}

	public void setNQCETB24_S_CD_CNTA_DEBT_SEGR(String nQCETB24_S_CD_CNTA_DEBT_SEGR) {
		NQCETB24_S_CD_CNTA_DEBT_SEGR = nQCETB24_S_CD_CNTA_DEBT_SEGR;
	}

	public String getNQCETB24_S_NR_PROP_SEGR() {
		return NQCETB24_S_NR_PROP_SEGR;
	}

	public void setNQCETB24_S_NR_PROP_SEGR(String nQCETB24_S_NR_PROP_SEGR) {
		NQCETB24_S_NR_PROP_SEGR = nQCETB24_S_NR_PROP_SEGR;
	}

	public String getNQCETB24_S_NR_APOL_SEGR() {
		return NQCETB24_S_NR_APOL_SEGR;
	}

	public void setNQCETB24_S_NR_APOL_SEGR(String nQCETB24_S_NR_APOL_SEGR) {
		NQCETB24_S_NR_APOL_SEGR = nQCETB24_S_NR_APOL_SEGR;
	}

	public Double getNQCETB24_S_VL_PREM_PAGO() {
		return NQCETB24_S_VL_PREM_PAGO;
	}

	public void setNQCETB24_S_VL_PREM_PAGO(Double nQCETB24_S_VL_PREM_PAGO) {
		NQCETB24_S_VL_PREM_PAGO = nQCETB24_S_VL_PREM_PAGO;
	}

	public Double getNQCETB24_S_VL_PREM_DEVO() {
		return NQCETB24_S_VL_PREM_DEVO;
	}

	public void setNQCETB24_S_VL_PREM_DEVO(Double nQCETB24_S_VL_PREM_DEVO) {
		NQCETB24_S_VL_PREM_DEVO = nQCETB24_S_VL_PREM_DEVO;
	}

	public Double getNQCETB24_S_VL_PGTO() {
		return NQCETB24_S_VL_PGTO;
	}

	public void setNQCETB24_S_VL_PGTO(Double nQCETB24_S_VL_PGTO) {
		NQCETB24_S_VL_PGTO = nQCETB24_S_VL_PGTO;
	}

	public String getNQCETB24_S_DT_PGTO() {
		return NQCETB24_S_DT_PGTO;
	}

	public void setNQCETB24_S_DT_PGTO(String nQCETB24_S_DT_PGTO) {
		NQCETB24_S_DT_PGTO = nQCETB24_S_DT_PGTO;
	}

	public String getNQCETB24_S_TP_DE_SINI() {
		return NQCETB24_S_TP_DE_SINI;
	}

	public void setNQCETB24_S_TP_DE_SINI(String nQCETB24_S_TP_DE_SINI) {
		NQCETB24_S_TP_DE_SINI = nQCETB24_S_TP_DE_SINI;
	}

	public String getNQCETB24_S_NR_BENF() {
		return NQCETB24_S_NR_BENF;
	}

	public void setNQCETB24_S_NR_BENF(String nQCETB24_S_NR_BENF) {
		NQCETB24_S_NR_BENF = nQCETB24_S_NR_BENF;
	}

	public String getNQCETB24_S_TP_FORM_PGTO() {
		return NQCETB24_S_TP_FORM_PGTO;
	}

	public void setNQCETB24_S_TP_FORM_PGTO(String nQCETB24_S_TP_FORM_PGTO) {
		NQCETB24_S_TP_FORM_PGTO = nQCETB24_S_TP_FORM_PGTO;
	}

	public String getNQCETB24_S_TP_TRAN() {
		return NQCETB24_S_TP_TRAN;
	}

	public void setNQCETB24_S_TP_TRAN(String nQCETB24_S_TP_TRAN) {
		NQCETB24_S_TP_TRAN = nQCETB24_S_TP_TRAN;
	}

	public String getNQCETB24_S_CD_BANC_CNTR() {
		return NQCETB24_S_CD_BANC_CNTR;
	}

	public void setNQCETB24_S_CD_BANC_CNTR(String nQCETB24_S_CD_BANC_CNTR) {
		NQCETB24_S_CD_BANC_CNTR = nQCETB24_S_CD_BANC_CNTR;
	}

	public String getNQCETB24_S_CD_AGEN_CNTR() {
		return NQCETB24_S_CD_AGEN_CNTR;
	}

	public void setNQCETB24_S_CD_AGEN_CNTR(String nQCETB24_S_CD_AGEN_CNTR) {
		NQCETB24_S_CD_AGEN_CNTR = nQCETB24_S_CD_AGEN_CNTR;
	}

	public String getNQCETB24_S_NR_CNTR_A() {
		return NQCETB24_S_NR_CNTR_A;
	}

	public void setNQCETB24_S_NR_CNTR_A(String nQCETB24_S_NR_CNTR_A) {
		NQCETB24_S_NR_CNTR_A = nQCETB24_S_NR_CNTR_A;
	}

	public String getNQCETB24_S_CD_PROD_ALTAIR() {
		return NQCETB24_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB24_S_CD_PROD_ALTAIR(String nQCETB24_S_CD_PROD_ALTAIR) {
		NQCETB24_S_CD_PROD_ALTAIR = nQCETB24_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB24_S_CD_SUBP_ALTAIR() {
		return NQCETB24_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB24_S_CD_SUBP_ALTAIR(String nQCETB24_S_CD_SUBP_ALTAIR) {
		NQCETB24_S_CD_SUBP_ALTAIR = nQCETB24_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB24_S_CD_MOED() {
		return NQCETB24_S_CD_MOED;
	}

	public void setNQCETB24_S_CD_MOED(String nQCETB24_S_CD_MOED) {
		NQCETB24_S_CD_MOED = nQCETB24_S_CD_MOED;
	}

	public Long getNQCETB24_S_NR_SEQU_OPER() {
		return NQCETB24_S_NR_SEQU_OPER;
	}

	public void setNQCETB24_S_NR_SEQU_OPER(Long nQCETB24_S_NR_SEQU_OPER) {
		NQCETB24_S_NR_SEQU_OPER = nQCETB24_S_NR_SEQU_OPER;
	}

	public String getNQCETB24_S_CD_IDEF_OPER() {
		return NQCETB24_S_CD_IDEF_OPER;
	}

	public void setNQCETB24_S_CD_IDEF_OPER(String nQCETB24_S_CD_IDEF_OPER) {
		NQCETB24_S_CD_IDEF_OPER = nQCETB24_S_CD_IDEF_OPER;
	}

	public String getNQCETB24_S_NM_CLIE() {
		return NQCETB24_S_NM_CLIE;
	}

	public void setNQCETB24_S_NM_CLIE(String nQCETB24_S_NM_CLIE) {
		NQCETB24_S_NM_CLIE = nQCETB24_S_NM_CLIE;
	}

//*       NOME DO CLIENTE                                           	
}