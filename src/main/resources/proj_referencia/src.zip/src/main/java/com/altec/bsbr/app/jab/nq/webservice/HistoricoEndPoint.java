package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.FiltrosACService;
import com.altec.bsbr.app.jab.nq.service.FiltrosACWebService;
import com.altec.bsbr.app.jab.nq.service.HistoricoService;
import com.altec.bsbr.app.jab.nq.service.HistoricoWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class HistoricoEndPoint extends SpringBeanAutowiringSupport implements HistoricoWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(HistoricoEndPoint.class);
	@Autowired
	private HistoricoService historico;

	@WebMethod
	public String recuperaDadosAlt(String intConceito1, String intConceito2) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = historico.recuperaDadosAlt(intConceito1, intConceito2);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
	
	@WebMethod
	public String recuperaDadosInc(String intHistorico, String intAgrupamento, String intConceito1, String intConceito2) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = historico.recuperaDadosInc(intHistorico, intAgrupamento, intConceito1, intConceito2);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	};

	@WebMethod
	public String consultarLista(String intOpcao, String intBanco, String intProduto, String intPeriodicidade) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = historico.consultarLista(intOpcao, intBanco, intProduto, intPeriodicidade);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	};

	@WebMethod
	public String consultarBancoProdPeriod() throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = historico.consultarBancoProdPeriod();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	};

	@WebMethod
	public String IncluirHistorico(String intOpcao, String intBanco, String intPeriodicidade, String intProduto,
			String intCodHist, String intHistorico, String strUsuario, String strDescricao, String strConceito1,
			String strConceito2) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = historico.IncluirHistorico(intOpcao, intBanco, intPeriodicidade, intProduto, intCodHist, intHistorico, strUsuario, strDescricao, strConceito1, strConceito2);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	};

	@WebMethod
	public String AlterarHistorico(String intOpcao, String intBanco, String intPeriodicidade, String intProduto,
			String intCodHist, String intHistorico, String strUsuario, String strDescricao, String strConceito1, String strConceito2) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = historico.AlterarHistorico(intOpcao, intBanco, intPeriodicidade, intProduto, intCodHist, intHistorico, strUsuario, strDescricao, strConceito1, strConceito2);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	};

	@WebMethod
	public String ExclusaoItem(String intOpcao, String intBanco, String intProduto, String intPeriodicidade,
			String intCodHist, String intHistorico, String strUsuario) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = historico.ExclusaoItem(intOpcao, intBanco, intProduto, intPeriodicidade, intCodHist, intHistorico, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	};


}
