package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface EnqSuspeitaService {
	public String versao() throws BusinessException;

	public String inserirEnquadramento(String strCDENTID, String strCDALERT, String strCDOREN1, String strCDENQ01,
			String strCDUSRES) throws BusinessException;

	public String listarOrgaoEnquadramento(String strCORGPAG) throws BusinessException;

	public String consultarEnquadramento(String strCORGENQ, String strCOENPAG) throws BusinessException;
}
