package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.ParamProdutoService;
import com.altec.bsbr.app.jab.nq.service.ParamProdutoWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class ParamProdutoEndPoint extends SpringBeanAutowiringSupport implements ParamProdutoWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(ParamProdutoEndPoint.class);
	@Autowired
	private ParamProdutoService paramProduto;

	@WebMethod
	public String versao() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramProduto.versao();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String listaProduto(String strSIGLA, String strNUSEQ, String strDETINTE, String strNOMEPRO,
			String strIDORDPA) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramProduto.listaProduto(strSIGLA, strNUSEQ, strDETINTE, strNOMEPRO, strIDORDPA);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alteraProduto(String strSGSISOR, String strSQSISOR, String strCDDETIN, String strDHFILTR,
			String strTPOPER, String strICMONIT, String strVLMINPR, String strCDUSRES) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramProduto.alteraProduto(strSGSISOR, strSQSISOR, strCDDETIN, strDHFILTR, strTPOPER, strICMONIT,
					strVLMINPR, strCDUSRES);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String listaAlteracaoParametro(String strCOSIGLA, String strNUSEQSI, String strCODETIN, String strCOOPINT,
			String strIDORDPG) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramProduto.listaAlteracaoParametro(strCOSIGLA, strNUSEQSI, strCODETIN, strCOOPINT, strIDORDPG);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
}
