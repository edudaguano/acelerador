package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE6201LegadoRequest {
	/*
// -*-NQCE6201
//         01      RECEIVE-COMMAREA.                                        
	@FixedLenghtField(position = 721, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_PGM_CHAMADA;//                 03  COMM-PGM-CHAMADA      PIC  X(008).                   

	@FixedLenghtField(position = 722, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOMEDATS;//                 03  COMM-NOMEDATS         PIC  X(010).                   

	@FixedLenghtField(position = 723, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_TAM_COMM;//                 03  COMM-TAM-COMM         PIC  9(007).                   

	@FixedLenghtField(position = 724, lenght = 9, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_MATRICULA;//                 03  COMM-MATRICULA        PIC  9(009).                   

	@FixedLenghtField(position = 725, lenght = 15, paddingAlign = Align.LEFT, paddingChar = '0')
	private String COMM_CNPJCPF;//                 03  COMM-CNPJCPF          PIC  9(015).                   

	@FixedLenghtField(position = 726, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_TPPESS;//                 03  COMM-TPPESS           PIC  X(001).                   

//         01      SEND-AREA.                                               
	@FixedLenghtField(position = 727, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN;//                 03  TS01-MENS-LEN         PIC S9(004) COMP VALUE +83.    

//                 03  TS01-AREA-MENSAGEM.                                  
	@FixedLenghtField(position = 728, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO;//                     05  TS01-RETORNO      PIC  9(003) VALUE ZEROS.       

	@FixedLenghtField(position = 729, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM;//                     05  TS01-MENSAGEM     PIC  X(080) VALUE SPACES.                                                                       

	@FixedLenghtField(position = 730, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_MENS_LEN;//                 03  TS02-MENS-LEN         PIC S9(004) COMP VALUE +74.    

//                 03  TS02-AREA-NQCE6201.                                  
	@FixedLenghtField(position = 731, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NOME;//                     05 TS02-NOME          PIC  X(050).                   

	@FixedLenghtField(position = 732, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_TIPOPESS;//                     05 TS02-TIPOPESS      PIC  X(001).                   

	@FixedLenghtField(position = 733, lenght = 20, paddingAlign = Align.LEFT, paddingChar = '0')
	private String TS02_CNPJCPF;//                     05 TS02-CNPJCPF       PIC  X(020).                   

	@FixedLenghtField(position = 734, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_MOTIVO;//                     05 TS02-MOTIVO        PIC  9(003).                   

	public NQCE6201LegadoRequest() { }
	public NQCE6201LegadoRequest(String comm_pgm_chamada, String comm_nomedats, Long comm_tam_comm, Long comm_matricula, String comm_cnpjcpf, String comm_tppess, String ts02_nome, String ts02_tipopess, String ts02_cnpjcpf, Long ts02_motivo) { 		this.COMM_PGM_CHAMADA = comm_pgm_chamada;
		this.COMM_NOMEDATS = comm_nomedats;
		this.COMM_TAM_COMM = comm_tam_comm;
		this.COMM_MATRICULA = comm_matricula;
		this.COMM_CNPJCPF = comm_cnpjcpf;
		this.COMM_TPPESS = comm_tppess;
		this.TS01_MENS_LEN = +83;
		this.TS01_RETORNO = ZEROS;
		this.TS01_MENSAGEM = SPACES;
		this.TS02_MENS_LEN = +74;
		this.TS02_NOME = ts02_nome;
		this.TS02_TIPOPESS = ts02_tipopess;
		this.TS02_CNPJCPF = ts02_cnpjcpf;
		this.TS02_MOTIVO = ts02_motivo; 
	}
	public String getCOMM_PGM_CHAMADA() { return this.COMM_PGM_CHAMADA; }
	public String getCOMM_NOMEDATS() { return this.COMM_NOMEDATS; }
	public Long getCOMM_TAM_COMM() { return this.COMM_TAM_COMM; }
	public Long getCOMM_MATRICULA() { return this.COMM_MATRICULA; }
	public String getCOMM_CNPJCPF() { return this.COMM_CNPJCPF; }
	public String getCOMM_TPPESS() { return this.COMM_TPPESS; }
	public Long getTS01_MENS_LEN() { return this.TS01_MENS_LEN; }
	public Long getTS01_RETORNO() { return this.TS01_RETORNO; }
	public String getTS01_MENSAGEM() { return this.TS01_MENSAGEM; }
	public Long getTS02_MENS_LEN() { return this.TS02_MENS_LEN; }
	public String getTS02_NOME() { return this.TS02_NOME; }
	public String getTS02_TIPOPESS() { return this.TS02_TIPOPESS; }
	public String getTS02_CNPJCPF() { return this.TS02_CNPJCPF; }
	public Long getTS02_MOTIVO() { return this.TS02_MOTIVO; }
	public void setCOMM_PGM_CHAMADA(String comm_pgm_chamada) { this.COMM_PGM_CHAMADA = comm_pgm_chamada; }
	public void setCOMM_NOMEDATS(String comm_nomedats) { this.COMM_NOMEDATS = comm_nomedats; }
	public void setCOMM_TAM_COMM(Long comm_tam_comm) { this.COMM_TAM_COMM = comm_tam_comm; }
	public void setCOMM_MATRICULA(Long comm_matricula) { this.COMM_MATRICULA = comm_matricula; }
	public void setCOMM_CNPJCPF(String comm_cnpjcpf) { this.COMM_CNPJCPF = comm_cnpjcpf; }
	public void setCOMM_TPPESS(String comm_tppess) { this.COMM_TPPESS = comm_tppess; }
	public void setTS01_MENS_LEN(Long ts01_mens_len) { this.TS01_MENS_LEN = ts01_mens_len; }
	public void setTS01_RETORNO(Long ts01_retorno) { this.TS01_RETORNO = ts01_retorno; }
	public void setTS01_MENSAGEM(String ts01_mensagem) { this.TS01_MENSAGEM = ts01_mensagem; }
	public void setTS02_MENS_LEN(Long ts02_mens_len) { this.TS02_MENS_LEN = ts02_mens_len; }
	public void setTS02_NOME(String ts02_nome) { this.TS02_NOME = ts02_nome; }
	public void setTS02_TIPOPESS(String ts02_tipopess) { this.TS02_TIPOPESS = ts02_tipopess; }
	public void setTS02_CNPJCPF(String ts02_cnpjcpf) { this.TS02_CNPJCPF = ts02_cnpjcpf; }
	public void setTS02_MOTIVO(Long ts02_motivo) { this.TS02_MOTIVO = ts02_motivo; }
	*/
}