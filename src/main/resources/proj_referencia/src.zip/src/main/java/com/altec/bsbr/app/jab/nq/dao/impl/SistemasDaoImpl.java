package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.SistemasDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB01LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.AreaMensagem;
import com.altec.bsbr.app.jab.nq.legado.dto.response.FullAreaResponse;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB01AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB03AreaDados;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB01MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class SistemasDaoImpl implements SistemasDao {
	private final Logger LOGGER = LoggerFactory.getLogger(SistemasDaoImpl.class);
	
	@Autowired
 	private JSONMapper jsonMapper;
	
	@Autowired
	private NQCETB01MessagingGateway NQCETB01Service;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}
	
	public String listarSistema(String strCodUser) throws BusinessException {		
		String json = "";
		try {
			NQCETB01LegadoRequest req = new NQCETB01LegadoRequest();
			req.setNQCETB1E_SG_FCAO("L");
			req.setNQCETB1E_CD_USUA(strCodUser);
						
			LegadoResult res = NQCETB01Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB01AreaDados> ret = decoder.parseRetorno(res, NQCETB01AreaDados.class, 83, 93);
			json =  new ObjectMapper().writeValueAsString(ret);			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String consultarSistema(String codigoSistema, String codigoUsuario) throws BusinessException {
		String json = "";		
		try {			
			NQCETB01LegadoRequest req = new NQCETB01LegadoRequest();
			req.setNQCETB1E_SG_FCAO("C");
			req.setNQCETB1E_CD_USUA(codigoUsuario);
			req.setNQCETB1E_NR_SEQU_SIST(codigoSistema.isEmpty() ? null : Long.valueOf(codigoSistema));
			
			LegadoResult res = NQCETB01Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB01AreaDados> ret = decoder.parseRetorno(res, NQCETB01AreaDados.class, 83, 93);
			json =  new ObjectMapper().writeValueAsString(ret);			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String incluirSistema(String strCodSist, String strSigla, String strNmFuncao, String strDesc,
			String strAtivo, String strCodUser) throws BusinessException {			
		String json = "";		
		try {
			NQCETB01LegadoRequest req = new NQCETB01LegadoRequest();
			req.setNQCETB1E_SG_FCAO("I");
			req.setNQCETB1E_CD_USUA(strCodUser);
			req.setNQCETB1E_NR_SEQU_SIST(strCodSist.isEmpty() ? null : Long.valueOf(strCodSist));
			req.setNQCETB1E_SG_SIST(strSigla);
			req.setNQCETB1E_NM_FCAO_SIST(strNmFuncao);
			req.setNQCETB1E_DS_FCAO_SIST(strDesc);
			req.setNQCETB1E_IN_SIST_ATIV(strAtivo);

			LegadoResult res = NQCETB01Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB01AreaDados> ret = decoder.parseRetorno(res, NQCETB01AreaDados.class, 83, 93);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String alterarSistema(String strCodSist, String strSigla, String strNmFuncao, String strDesc,
			String strAtivo, String strCodUser) throws BusinessException {
		String json = "";		
		try {
			NQCETB01LegadoRequest req = new NQCETB01LegadoRequest();
			req.setNQCETB1E_SG_FCAO("A");
			req.setNQCETB1E_CD_USUA(strCodUser);
			req.setNQCETB1E_NR_SEQU_SIST(strCodSist.isEmpty() ? null : Long.valueOf(strCodSist));
			req.setNQCETB1E_SG_SIST(strSigla);
			req.setNQCETB1E_NM_FCAO_SIST(strNmFuncao);
			req.setNQCETB1E_DS_FCAO_SIST(strDesc);
			req.setNQCETB1E_IN_SIST_ATIV(strAtivo);
			
			LegadoResult res = NQCETB01Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB01AreaDados> ret = decoder.parseRetorno(res, NQCETB01AreaDados.class, 83, 93);
			json =  new ObjectMapper().writeValueAsString(ret);			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String excluirSistema(String strCodSist, String strCodUser) throws BusinessException {
		String json = "";		
		try {
			NQCETB01LegadoRequest req = new NQCETB01LegadoRequest();
			req.setNQCETB1E_SG_FCAO("E");
			req.setNQCETB1E_CD_USUA(strCodUser);
			req.setNQCETB1E_NR_SEQU_SIST(strCodSist.isEmpty() ? null : Long.valueOf(strCodSist));
			
			LegadoResult res = NQCETB01Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB01AreaDados> ret = decoder.parseRetorno(res, NQCETB01AreaDados.class, 83, 93);
			json =  new ObjectMapper().writeValueAsString(ret);			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String inicializarinputArea(String tNQ_NQAT2001_NQCETB01_ENTRADA) {
		return "";
	}

	public String fnAddCaracter(String vlr, String tp, String tam) {
		return "";
	}

}
