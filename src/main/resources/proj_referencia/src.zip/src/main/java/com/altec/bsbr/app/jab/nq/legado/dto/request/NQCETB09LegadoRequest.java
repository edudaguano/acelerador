package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@PsFormat(name = "NQCETB09LegadoRequest")
public class NQCETB09LegadoRequest {
	
/*---------------------------------- CONSTRUTOR -----------------------------*/
	public NQCETB09LegadoRequest() {
		super();
	}

	
/*---------------------------------- Request Area --------------------------*/
	@PsFieldString(name = "NQCETB09_E_NM_PROG", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB09_E_NM_PROG;// 05 NQCETB09-E-NM-PROG PIC X(008).

	@PsFieldString(name = "NQCETB09_E_NM_AREA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB09_E_NM_AREA;// 05 NQCETB09-E-NM-AREA PIC X(008).

	@PsFieldString(name = "NQCETB09_E_SG_FCAO", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB09_E_SG_FCAO;// 05 NQCETB09-E-SG-FCAO PIC X(002).

	@PsFieldNumber(name = "NQCETB09_E_QT_TAMA_AREA", decimal = 0, length = 7, signed = false, defaultValue = "0")
	private Long NQCETB09_E_QT_TAMA_AREA;// 05 NQCETB09-E-QT-TAMA-AREA PIC 9(007).

	@PsFieldString(name = "NQCETB09_E_CD_USUA_ULTI_ALTR", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB09_E_CD_USUA_ULTI_ALTR;// 05 NQCETB09-E-CD-USUA-ULTI-ALTR PIC X(008).

	@PsFieldNumber(name = "NQCETB09_E_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB09_E_NR_SEQU_SIST;// 05 NQCETB09-E-NR-SEQU-SIST PIC 9(004).

	@PsFieldNumber(name = "NQCETB09_E_NR_SEQU_REGR", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB09_E_NR_SEQU_REGR;// 05 NQCETB09-E-NR-SEQU-REGR PIC 9(004).

	@PsFieldString(name = "NQCETB09_E_TP_PERI", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB09_E_TP_PERI;// 05 NQCETB09-E-TP-PERI PIC X(001).

	@PsFieldString(name = "NQCETB09_E_IN_PARE_GERE", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB09_E_IN_PARE_GERE;// 05 NQCETB09-E-IN-PARE-GERE PIC X(001).

	@PsFieldString(name = "NQCETB09_E_IN_PARE_AREA_OPER", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB09_E_IN_PARE_AREA_OPER;// 05 NQCETB09-E-IN-PARE-AREA-OPER PIC X(001).

	@PsFieldString(name = "NQCETB09_E_IN_PARE_UPLD", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB09_E_IN_PARE_UPLD;// 05 NQCETB09-E-IN-PARE-UPLD PIC X(001).

	@PsFieldString(name = "NQCETB09_E_IN_NOTI_UPLD", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB09_E_IN_NOTI_UPLD;// 05 NQCETB09-E-IN-NOTI-UPLD PIC X(001).

	@PsFieldString(name = "NQCETB09_E_DT_OCOR", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB09_E_DT_OCOR;// 05 NQCETB09-E-DT-OCOR PIC X(010).

	@PsFieldString(name = "NQCETB09_E_CD_BANC_CLIE", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB09_E_CD_BANC_CLIE;// 05 NQCETB09-E-CD-BANC-CLIE PIC X(004).

	@PsFieldString(name = "NQCETB09_E_CD_CLIE", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB09_E_CD_CLIE;// 05 NQCETB09-E-CD-CLIE PIC X(008).

/*-----------------------------GETTER/SETTER ------------------------*/
	public String getNQCETB09_E_NM_PROG() {
		return NQCETB09_E_NM_PROG;
	}

	public void setNQCETB09_E_NM_PROG(String nQCETB09_E_NM_PROG) {
		NQCETB09_E_NM_PROG = nQCETB09_E_NM_PROG;
	}

	public String getNQCETB09_E_NM_AREA() {
		return NQCETB09_E_NM_AREA;
	}

	public void setNQCETB09_E_NM_AREA(String nQCETB09_E_NM_AREA) {
		NQCETB09_E_NM_AREA = nQCETB09_E_NM_AREA;
	}

	public String getNQCETB09_E_SG_FCAO() {
		return NQCETB09_E_SG_FCAO;
	}

	public void setNQCETB09_E_SG_FCAO(String nQCETB09_E_SG_FCAO) {
		NQCETB09_E_SG_FCAO = nQCETB09_E_SG_FCAO;
	}

	public Long getNQCETB09_E_QT_TAMA_AREA() {
		return NQCETB09_E_QT_TAMA_AREA;
	}

	public void setNQCETB09_E_QT_TAMA_AREA(Long nQCETB09_E_QT_TAMA_AREA) {
		NQCETB09_E_QT_TAMA_AREA = nQCETB09_E_QT_TAMA_AREA;
	}

	public String getNQCETB09_E_CD_USUA_ULTI_ALTR() {
		return NQCETB09_E_CD_USUA_ULTI_ALTR;
	}

	public void setNQCETB09_E_CD_USUA_ULTI_ALTR(String nQCETB09_E_CD_USUA_ULTI_ALTR) {
		NQCETB09_E_CD_USUA_ULTI_ALTR = nQCETB09_E_CD_USUA_ULTI_ALTR;
	}

	public Long getNQCETB09_E_NR_SEQU_SIST() {
		return NQCETB09_E_NR_SEQU_SIST;
	}

	public void setNQCETB09_E_NR_SEQU_SIST(Long nQCETB09_E_NR_SEQU_SIST) {
		NQCETB09_E_NR_SEQU_SIST = nQCETB09_E_NR_SEQU_SIST;
	}

	public Long getNQCETB09_E_NR_SEQU_REGR() {
		return NQCETB09_E_NR_SEQU_REGR;
	}

	public void setNQCETB09_E_NR_SEQU_REGR(Long nQCETB09_E_NR_SEQU_REGR) {
		NQCETB09_E_NR_SEQU_REGR = nQCETB09_E_NR_SEQU_REGR;
	}

	public String getNQCETB09_E_TP_PERI() {
		return NQCETB09_E_TP_PERI;
	}

	public void setNQCETB09_E_TP_PERI(String nQCETB09_E_TP_PERI) {
		NQCETB09_E_TP_PERI = nQCETB09_E_TP_PERI;
	}

	public String getNQCETB09_E_IN_PARE_GERE() {
		return NQCETB09_E_IN_PARE_GERE;
	}

	public void setNQCETB09_E_IN_PARE_GERE(String nQCETB09_E_IN_PARE_GERE) {
		NQCETB09_E_IN_PARE_GERE = nQCETB09_E_IN_PARE_GERE;
	}

	public String getNQCETB09_E_IN_PARE_AREA_OPER() {
		return NQCETB09_E_IN_PARE_AREA_OPER;
	}

	public void setNQCETB09_E_IN_PARE_AREA_OPER(String nQCETB09_E_IN_PARE_AREA_OPER) {
		NQCETB09_E_IN_PARE_AREA_OPER = nQCETB09_E_IN_PARE_AREA_OPER;
	}

	public String getNQCETB09_E_IN_PARE_UPLD() {
		return NQCETB09_E_IN_PARE_UPLD;
	}

	public void setNQCETB09_E_IN_PARE_UPLD(String nQCETB09_E_IN_PARE_UPLD) {
		NQCETB09_E_IN_PARE_UPLD = nQCETB09_E_IN_PARE_UPLD;
	}

	public String getNQCETB09_E_IN_NOTI_UPLD() {
		return NQCETB09_E_IN_NOTI_UPLD;
	}

	public void setNQCETB09_E_IN_NOTI_UPLD(String nQCETB09_E_IN_NOTI_UPLD) {
		NQCETB09_E_IN_NOTI_UPLD = nQCETB09_E_IN_NOTI_UPLD;
	}

	public String getNQCETB09_E_DT_OCOR() {
		return NQCETB09_E_DT_OCOR;
	}

	public void setNQCETB09_E_DT_OCOR(String nQCETB09_E_DT_OCOR) {
		NQCETB09_E_DT_OCOR = nQCETB09_E_DT_OCOR;
	}

	public String getNQCETB09_E_CD_BANC_CLIE() {
		return NQCETB09_E_CD_BANC_CLIE;
	}

	public void setNQCETB09_E_CD_BANC_CLIE(String nQCETB09_E_CD_BANC_CLIE) {
		NQCETB09_E_CD_BANC_CLIE = nQCETB09_E_CD_BANC_CLIE;
	}

	public String getNQCETB09_E_CD_CLIE() {
		return NQCETB09_E_CD_CLIE;
	}

	public void setNQCETB09_E_CD_CLIE(String nQCETB09_E_CD_CLIE) {
		NQCETB09_E_CD_CLIE = nQCETB09_E_CD_CLIE;
	}

}