package com.altec.bsbr.app.jab.nq.service.impl;

import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.ComUniorgDao;
import com.altec.bsbr.app.jab.nq.service.ComUniorgService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class ComUniorgServiceImpl implements ComUniorgService {
	private final Logger LOGGER = LoggerFactory.getLogger(ComUniorgServiceImpl.class);
	@Autowired
	private ComUniorgDao comuniorg;

	public String versao() throws BusinessException {
		return comuniorg.versao();
	}

	public String consultaUniorg(String strCDUNIOR) throws BusinessException {
		return comuniorg.consultaUniorg(strCDUNIOR);
	}
}
