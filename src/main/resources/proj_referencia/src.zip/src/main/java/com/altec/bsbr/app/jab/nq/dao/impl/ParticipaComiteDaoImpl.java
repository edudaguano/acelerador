package com.altec.bsbr.app.jab.nq.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0100;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0110;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0330;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0100;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0330;
import com.altec.bsbr.app.jab.nq.dao.ParticipaComiteDao;
import com.altec.bsbr.app.jab.nq.dto.RespostaGenerica;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ParticipaComiteDaoImpl implements ParticipaComiteDao {
	private final Logger LOGGER = LoggerFactory.getLogger(ParticipaComiteDaoImpl.class);

	@Autowired
	private AltairService altairService;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String versao() {
		return "";
	}

	public String consultarMatricula(String strNUMATRI) {
		
		NQE0100 request = new NQE0100();
		request.setNUMATRI(strNUMATRI.isEmpty()? null : Long.valueOf(strNUMATRI));
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQB1", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0100.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarParticipante(String strTPUORCM, String strCDUORCM, String strDTCOMIT) {
		
		NQE0330 request = new NQE0330();
		request.setTPUORCM(strTPUORCM);
		request.setCDUORCM(strCDUORCM);
		request.setDTCOMIT(strDTCOMIT);
		
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQC5", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0330.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String inserirParticipante(String strTPUNIOR, String strCDAGENC, String strDTCOMIT, String strNMMATR1,
			String strDSCARG1, String strNMMATR2, String strDSCARG2, String strNMMATR3, String strDSCARG3,
			String strNMMATR4, String strDSCARG4, String strNMMATR5, String strDSCARG5, String strNMMATR6,
			String strDSCARG6, String strNMMATR7, String strDSCARG7, String strNMMATR8, String strDSCARG8,
			String strNMMATR9, String strDSCARG9, String strNMMATR10, String strDSCARG10, String strCDUSRES) {
		
		NQE0110 request = new NQE0110();
		request.setTPUNIOR(strTPUNIOR);
		request.setCDAGENC(strCDAGENC);
		request.setDTCOMIT(strDTCOMIT);
		request.setNMMATR1(strNMMATR1.isEmpty()? null : Long.valueOf(strNMMATR1));
		request.setDSCARG1(strDSCARG1);
		request.setNMMATR2(strNMMATR2.isEmpty()? null : Long.valueOf(strNMMATR2));
		request.setDSCARG2(strDSCARG2);
		request.setNMMATR3(strNMMATR3.isEmpty()? null : Long.valueOf(strNMMATR3));
		request.setDSCARG3(strDSCARG3);
		request.setNMMATR4(strNMMATR4.isEmpty()? null : Long.valueOf(strNMMATR4));
		request.setDSCARG4(strDSCARG4);
		request.setNMMATR5(strNMMATR5.isEmpty()? null : Long.valueOf(strNMMATR5));
		request.setDSCARG5(strDSCARG5);
		request.setNMMATR6(strNMMATR6.isEmpty()? null : Long.valueOf(strNMMATR6));
		request.setDSCARG6(strDSCARG6);
		request.setNMMATR7(strNMMATR7.isEmpty()? null : Long.valueOf(strNMMATR7));
		request.setDSCARG7(strDSCARG7);
		request.setNMMATR8(strNMMATR8.isEmpty()? null : Long.valueOf(strNMMATR8));
		request.setDSCARG8(strDSCARG8);
		request.setNMMATR9(strNMMATR9.isEmpty()? null : Long.valueOf(strNMMATR9));
		request.setDSCARG9(strDSCARG9);
		request.setNMMAT10(strNMMATR10.isEmpty()? null : Long.valueOf(strNMMATR10));
		request.setDSCAR10(strDSCARG10);
		request.setCDUSRES(strCDUSRES);
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQB2", request);
			//TODO: verificar classe de saida 110
			RespostaGenerica respostaGenerica = new RespostaGenerica();
			respostaGenerica.setCodigoRetorno(resp.getObjeto().getCodigoRetorno());
			respostaGenerica.setErros(resp.getObjeto().getListaErros());
			respostaGenerica.setFormatos(resp.getObjeto().getListaFormatos());
			respostaGenerica.setMensagem(resp.getObjeto().getListaMensagem());
			return new ObjectMapper().writeValueAsString(respostaGenerica);
			
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

}
