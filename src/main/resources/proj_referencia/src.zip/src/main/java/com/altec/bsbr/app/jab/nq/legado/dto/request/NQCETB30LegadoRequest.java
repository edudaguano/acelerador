package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB30")
public class NQCETB30LegadoRequest {
	
//  -*-NQCETB30
//                                                                          
//         01     NQCETB30-ENTRADA.                                         
//                                                                          
	@PsFieldString(name= "NQCETB30_E_NM_PROG", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_E_NM_PROG;//           05   NQCETB30-E-NM-PROG            PIC  X(008).                

//        *       NOME DO PROGRAMA CHAMADO                                  
//                                                                          
	@PsFieldString(name= "NQCETB30_E_NM_AREA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_E_NM_AREA;//           05   NQCETB30-E-NM-AREA            PIC  X(008).                

//        *       NOME DA AREA DE TS                                        
//                                                                          
	@PsFieldString(name= "NQCETB30_E_SG_FCAO", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_E_SG_FCAO;//           05   NQCETB30-E-SG-FCAO            PIC  X(002).                

//        *       FUNCAO A SER EXECUTADA                                    
//        *       L = LISTAR                                                
//                                                                          
	@PsFieldNumber(name= "NQCETB30_E_QT_TAMA_AREA", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long NQCETB30_E_QT_TAMA_AREA;//           05   NQCETB30-E-QT-TAMA-AREA       PIC  9(007).                

//        *       TAMANHO DA AREA DE TS                                     
//                                                                          
	@PsFieldString(name= "NQCETB30_E_CD_USUA_ULTI_ALTR", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_E_CD_USUA_ULTI_ALTR;//           05   NQCETB30-E-CD-USUA-ULTI-ALTR  PIC  X(008).                

//        *       CODIGO DO USUARIO                                         
//                                                                          
	@PsFieldNumber(name= "NQCETB30_E_NR_SEQU_SIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB30_E_NR_SEQU_SIST;//           05   NQCETB30-E-NR-SEQU-SIST       PIC  9(004).                

//        *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                          
	@PsFieldString(name= "NQCETB30_E_DT_OCOR", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_E_DT_OCOR;//           05   NQCETB30-E-DT-OCOR            PIC  X(010).                

//        *       DATA DA OCORRENCIA                                                                                               
//         01     NQCETB30-SAIDA.                                           
//                                                                          
//        *       AREA DE MENSAGEM                                          
//                                                                          
	@PsFieldNumber(name= "NQCETB30_S_MENS_LEN", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long NQCETB30_S_MENS_LEN;//          03    NQCETB30-S-MENS-LEN    COMP   PIC  S9(04) VALUE +83.      

//          03    NQCETB30-S-MENS.                                          
	@PsFieldNumber(name= "NQCETB30_S_RETORNO", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB30_S_RETORNO;//           05   NQCETB30-S-RETORNO            PIC  9(003) VALUE ZEROS.    

	@PsFieldString(name= "NQCETB30_S_MENSAGEM", length= 80, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_MENSAGEM;//           05   NQCETB30-S-MENSAGEM           PIC  X(080) VALUE SPACES.   

//                                                                          
//        *       AREA DE DADOS                                             
//                                                                          
	@PsFieldNumber(name= "NQCETB30_S_DATA_LEN", decimal= 0, length= 0, signed= false, defaultValue="0")
	private Long NQCETB30_S_DATA_LEN;//          03    NQCETB30-S-DATA-LEN    COMP   PIC  S9(04) VALUE +96.      

//          03    NQCETB30-S-DATA.                                          
//                                                                          
	@PsFieldNumber(name= "NQCETB30_S_NR_SEQU_SIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB30_S_NR_SEQU_SIST;//           05   NQCETB30-S-NR-SEQU-SIST       PIC  9(004).                

//        *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                          
	@PsFieldString(name= "NQCETB30_S_SG_SIST", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_SG_SIST;//           05   NQCETB30-S-SG-SIST            PIC  X(002).                

//        *       SIGLA DO SISTEMA                                          
//                                                                          
	@PsFieldNumber(name= "NQCETB30_S_NR_SEQU_REGR", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB30_S_NR_SEQU_REGR;//           05   NQCETB30-S-NR-SEQU-REGR       PIC  9(004).                

//        *       NUMERO DE SEQUENCIA DA REGRA                              
//                                                                          
	@PsFieldString(name= "NQCETB30_S_DT_OCOR", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_DT_OCOR;//           05   NQCETB30-S-DT-OCOR            PIC  X(010).                

//        *       DATA DE OCORRENCIA                                        
//                                                                          
	@PsFieldString(name= "NQCETB30_S_TP_PERI", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_TP_PERI;//           05   NQCETB30-S-TP-PERI            PIC  X(001).                

//        *       TIPO DE PERIODO                                           
//                                                                          
	@PsFieldString(name= "NQCETB30_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_CD_PROD_ALTAIR;//           05   NQCETB30-S-CD-PROD-ALTAIR     PIC  X(002).                

//        *       CODIGO DO PRODUTO                                         
//                                                                          
	@PsFieldString(name= "NQCETB30_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_CD_SUBP_ALTAIR;//           05   NQCETB30-S-CD-SUBP-ALTAIR     PIC  X(004).                

//        *       CODIGO DO SUBPRODUTO                                      
//                                                                          
	@PsFieldString(name= "NQCETB30_S_IN_PEP", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_IN_PEP;//           05   NQCETB30-S-IN-PEP             PIC  X(001).                

//        *       INDICADOR DE CLIENTE PEP                                  
//                                                                          
	@PsFieldString(name= "NQCETB30_S_IN_FUNC", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_IN_FUNC;//           05   NQCETB30-S-IN-FUNC            PIC  X(001).                

//        *       INDICADOR DE CLIENTE FUNCIONARIO                          
//                                                                          
	@PsFieldString(name= "NQCETB30_S_TP_TRAN", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_TP_TRAN;//           05   NQCETB30-S-TP-TRAN            PIC  X(001).                

//        *       IDENTIFICACAO DO TIPO DE TRANSACAO                        
//                                                                          
	@PsFieldNumber(name= "NQCETB30_S_QT_TRAN", decimal= 0, length= 9, signed= false, defaultValue="0")
	private Long NQCETB30_S_QT_TRAN;//           05   NQCETB30-S-QT-TRAN            PIC  9(009).                

//        *       QUANTIDADE DE TRANSACOES                                  
//                                                                          
	@PsFieldNumber(name= "NQCETB30_S_VL_PERC_FATU_REND", decimal= 2, length= 5, signed= true, defaultValue="0")
	private Double NQCETB30_S_VL_PERC_FATU_REND;//           05   NQCETB30-S-VL-PERC-FATU-REND  PIC  9(003)V99.             

//        *       VALOR DA PORCENTAGEM SOBRE FATURAMENTO / RENDA            
//                                                                          
	@PsFieldNumber(name= "NQCETB30_S_VL_TRAN", decimal= 2, length= 17, signed= true, defaultValue="0")
	private Double NQCETB30_S_VL_TRAN;//           05   NQCETB30-S-VL-TRAN            PIC  9(015)V99.             

//        *       VALOR DE TRANSACOES                                       
//                                                                          
	@PsFieldString(name= "NQCETB30_S_CD_SITU", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_CD_SITU;//           05   NQCETB30-S-CD-SITU            PIC  X(001).                

//        *       CODIGO DA SITUACAO                                        
//                                                                          
	@PsFieldString(name= "NQCETB30_S_CD_USUA_ULTI_ALTR", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_CD_USUA_ULTI_ALTR;//           05   NQCETB30-S-CD-USUA-ULTI-ALTR  PIC  X(008).                

//        *       CODIGO DA SITUACAO                                        
//                                                                          
	@PsFieldString(name= "NQCETB30_S_DH_ULTI_ALTR", length= 26, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB30_S_DH_ULTI_ALTR;//           05   NQCETB30-S-DH-ULTI-ALTR       PIC  X(026).                

//        *       DATA/HORA ULTIMO PROCESSAMENTO                            
	public NQCETB30LegadoRequest() { }
	public NQCETB30LegadoRequest(String nqcetb30_e_nm_prog, String nqcetb30_e_nm_area, String nqcetb30_e_sg_fcao, Long nqcetb30_e_qt_tama_area, String nqcetb30_e_cd_usua_ulti_altr, Long nqcetb30_e_nr_sequ_sist, String nqcetb30_e_dt_ocor, Long nqcetb30_s_nr_sequ_sist, String nqcetb30_s_sg_sist, Long nqcetb30_s_nr_sequ_regr, String nqcetb30_s_dt_ocor, String nqcetb30_s_tp_peri, String nqcetb30_s_cd_prod_altair, String nqcetb30_s_cd_subp_altair, String nqcetb30_s_in_pep, String nqcetb30_s_in_func, String nqcetb30_s_tp_tran, Long nqcetb30_s_qt_tran, Double nqcetb30_s_vl_perc_fatu_rend, Double nqcetb30_s_vl_tran, String nqcetb30_s_cd_situ, String nqcetb30_s_cd_usua_ulti_altr, String nqcetb30_s_dh_ulti_altr) { 		this.NQCETB30_E_NM_PROG = nqcetb30_e_nm_prog;
		this.NQCETB30_E_NM_AREA = nqcetb30_e_nm_area;
		this.NQCETB30_E_SG_FCAO = nqcetb30_e_sg_fcao;
		this.NQCETB30_E_QT_TAMA_AREA = nqcetb30_e_qt_tama_area;
		this.NQCETB30_E_CD_USUA_ULTI_ALTR = nqcetb30_e_cd_usua_ulti_altr;
		this.NQCETB30_E_NR_SEQU_SIST = nqcetb30_e_nr_sequ_sist;
		this.NQCETB30_E_DT_OCOR = nqcetb30_e_dt_ocor;
		/*this.NQCETB30_S_MENS_LEN = +83;
		this.NQCETB30_S_RETORNO = ZEROS;
		this.NQCETB30_S_MENSAGEM = SPACES;
		this.NQCETB30_S_DATA_LEN = +96;*/
		this.NQCETB30_S_NR_SEQU_SIST = nqcetb30_s_nr_sequ_sist;
		this.NQCETB30_S_SG_SIST = nqcetb30_s_sg_sist;
		this.NQCETB30_S_NR_SEQU_REGR = nqcetb30_s_nr_sequ_regr;
		this.NQCETB30_S_DT_OCOR = nqcetb30_s_dt_ocor;
		this.NQCETB30_S_TP_PERI = nqcetb30_s_tp_peri;
		this.NQCETB30_S_CD_PROD_ALTAIR = nqcetb30_s_cd_prod_altair;
		this.NQCETB30_S_CD_SUBP_ALTAIR = nqcetb30_s_cd_subp_altair;
		this.NQCETB30_S_IN_PEP = nqcetb30_s_in_pep;
		this.NQCETB30_S_IN_FUNC = nqcetb30_s_in_func;
		this.NQCETB30_S_TP_TRAN = nqcetb30_s_tp_tran;
		this.NQCETB30_S_QT_TRAN = nqcetb30_s_qt_tran;
		this.NQCETB30_S_VL_PERC_FATU_REND = nqcetb30_s_vl_perc_fatu_rend;
		this.NQCETB30_S_VL_TRAN = nqcetb30_s_vl_tran;
		this.NQCETB30_S_CD_SITU = nqcetb30_s_cd_situ;
		this.NQCETB30_S_CD_USUA_ULTI_ALTR = nqcetb30_s_cd_usua_ulti_altr;
		this.NQCETB30_S_DH_ULTI_ALTR = nqcetb30_s_dh_ulti_altr; 
	}
	public String getNQCETB30_E_NM_PROG() { return this.NQCETB30_E_NM_PROG; }
	public String getNQCETB30_E_NM_AREA() { return this.NQCETB30_E_NM_AREA; }
	public String getNQCETB30_E_SG_FCAO() { return this.NQCETB30_E_SG_FCAO; }
	public Long getNQCETB30_E_QT_TAMA_AREA() { return this.NQCETB30_E_QT_TAMA_AREA; }
	public String getNQCETB30_E_CD_USUA_ULTI_ALTR() { return this.NQCETB30_E_CD_USUA_ULTI_ALTR; }
	public Long getNQCETB30_E_NR_SEQU_SIST() { return this.NQCETB30_E_NR_SEQU_SIST; }
	public String getNQCETB30_E_DT_OCOR() { return this.NQCETB30_E_DT_OCOR; }
	public Long getNQCETB30_S_MENS_LEN() { return this.NQCETB30_S_MENS_LEN; }
	public Long getNQCETB30_S_RETORNO() { return this.NQCETB30_S_RETORNO; }
	public String getNQCETB30_S_MENSAGEM() { return this.NQCETB30_S_MENSAGEM; }
	public Long getNQCETB30_S_DATA_LEN() { return this.NQCETB30_S_DATA_LEN; }
	public Long getNQCETB30_S_NR_SEQU_SIST() { return this.NQCETB30_S_NR_SEQU_SIST; }
	public String getNQCETB30_S_SG_SIST() { return this.NQCETB30_S_SG_SIST; }
	public Long getNQCETB30_S_NR_SEQU_REGR() { return this.NQCETB30_S_NR_SEQU_REGR; }
	public String getNQCETB30_S_DT_OCOR() { return this.NQCETB30_S_DT_OCOR; }
	public String getNQCETB30_S_TP_PERI() { return this.NQCETB30_S_TP_PERI; }
	public String getNQCETB30_S_CD_PROD_ALTAIR() { return this.NQCETB30_S_CD_PROD_ALTAIR; }
	public String getNQCETB30_S_CD_SUBP_ALTAIR() { return this.NQCETB30_S_CD_SUBP_ALTAIR; }
	public String getNQCETB30_S_IN_PEP() { return this.NQCETB30_S_IN_PEP; }
	public String getNQCETB30_S_IN_FUNC() { return this.NQCETB30_S_IN_FUNC; }
	public String getNQCETB30_S_TP_TRAN() { return this.NQCETB30_S_TP_TRAN; }
	public Long getNQCETB30_S_QT_TRAN() { return this.NQCETB30_S_QT_TRAN; }
	public Double getNQCETB30_S_VL_PERC_FATU_REND() { return this.NQCETB30_S_VL_PERC_FATU_REND; }
	public Double getNQCETB30_S_VL_TRAN() { return this.NQCETB30_S_VL_TRAN; }
	public String getNQCETB30_S_CD_SITU() { return this.NQCETB30_S_CD_SITU; }
	public String getNQCETB30_S_CD_USUA_ULTI_ALTR() { return this.NQCETB30_S_CD_USUA_ULTI_ALTR; }
	public String getNQCETB30_S_DH_ULTI_ALTR() { return this.NQCETB30_S_DH_ULTI_ALTR; }
	public void setNQCETB30_E_NM_PROG(String nqcetb30_e_nm_prog) { this.NQCETB30_E_NM_PROG = nqcetb30_e_nm_prog; }
	public void setNQCETB30_E_NM_AREA(String nqcetb30_e_nm_area) { this.NQCETB30_E_NM_AREA = nqcetb30_e_nm_area; }
	public void setNQCETB30_E_SG_FCAO(String nqcetb30_e_sg_fcao) { this.NQCETB30_E_SG_FCAO = nqcetb30_e_sg_fcao; }
	public void setNQCETB30_E_QT_TAMA_AREA(Long nqcetb30_e_qt_tama_area) { this.NQCETB30_E_QT_TAMA_AREA = nqcetb30_e_qt_tama_area; }
	public void setNQCETB30_E_CD_USUA_ULTI_ALTR(String nqcetb30_e_cd_usua_ulti_altr) { this.NQCETB30_E_CD_USUA_ULTI_ALTR = nqcetb30_e_cd_usua_ulti_altr; }
	public void setNQCETB30_E_NR_SEQU_SIST(Long nqcetb30_e_nr_sequ_sist) { this.NQCETB30_E_NR_SEQU_SIST = nqcetb30_e_nr_sequ_sist; }
	public void setNQCETB30_E_DT_OCOR(String nqcetb30_e_dt_ocor) { this.NQCETB30_E_DT_OCOR = nqcetb30_e_dt_ocor; }
	public void setNQCETB30_S_MENS_LEN(Long nqcetb30_s_mens_len) { this.NQCETB30_S_MENS_LEN = nqcetb30_s_mens_len; }
	public void setNQCETB30_S_RETORNO(Long nqcetb30_s_retorno) { this.NQCETB30_S_RETORNO = nqcetb30_s_retorno; }
	public void setNQCETB30_S_MENSAGEM(String nqcetb30_s_mensagem) { this.NQCETB30_S_MENSAGEM = nqcetb30_s_mensagem; }
	public void setNQCETB30_S_DATA_LEN(Long nqcetb30_s_data_len) { this.NQCETB30_S_DATA_LEN = nqcetb30_s_data_len; }
	public void setNQCETB30_S_NR_SEQU_SIST(Long nqcetb30_s_nr_sequ_sist) { this.NQCETB30_S_NR_SEQU_SIST = nqcetb30_s_nr_sequ_sist; }
	public void setNQCETB30_S_SG_SIST(String nqcetb30_s_sg_sist) { this.NQCETB30_S_SG_SIST = nqcetb30_s_sg_sist; }
	public void setNQCETB30_S_NR_SEQU_REGR(Long nqcetb30_s_nr_sequ_regr) { this.NQCETB30_S_NR_SEQU_REGR = nqcetb30_s_nr_sequ_regr; }
	public void setNQCETB30_S_DT_OCOR(String nqcetb30_s_dt_ocor) { this.NQCETB30_S_DT_OCOR = nqcetb30_s_dt_ocor; }
	public void setNQCETB30_S_TP_PERI(String nqcetb30_s_tp_peri) { this.NQCETB30_S_TP_PERI = nqcetb30_s_tp_peri; }
	public void setNQCETB30_S_CD_PROD_ALTAIR(String nqcetb30_s_cd_prod_altair) { this.NQCETB30_S_CD_PROD_ALTAIR = nqcetb30_s_cd_prod_altair; }
	public void setNQCETB30_S_CD_SUBP_ALTAIR(String nqcetb30_s_cd_subp_altair) { this.NQCETB30_S_CD_SUBP_ALTAIR = nqcetb30_s_cd_subp_altair; }
	public void setNQCETB30_S_IN_PEP(String nqcetb30_s_in_pep) { this.NQCETB30_S_IN_PEP = nqcetb30_s_in_pep; }
	public void setNQCETB30_S_IN_FUNC(String nqcetb30_s_in_func) { this.NQCETB30_S_IN_FUNC = nqcetb30_s_in_func; }
	public void setNQCETB30_S_TP_TRAN(String nqcetb30_s_tp_tran) { this.NQCETB30_S_TP_TRAN = nqcetb30_s_tp_tran; }
	public void setNQCETB30_S_QT_TRAN(Long nqcetb30_s_qt_tran) { this.NQCETB30_S_QT_TRAN = nqcetb30_s_qt_tran; }
	public void setNQCETB30_S_VL_PERC_FATU_REND(Double nqcetb30_s_vl_perc_fatu_rend) { this.NQCETB30_S_VL_PERC_FATU_REND = nqcetb30_s_vl_perc_fatu_rend; }
	public void setNQCETB30_S_VL_TRAN(Double nqcetb30_s_vl_tran) { this.NQCETB30_S_VL_TRAN = nqcetb30_s_vl_tran; }
	public void setNQCETB30_S_CD_SITU(String nqcetb30_s_cd_situ) { this.NQCETB30_S_CD_SITU = nqcetb30_s_cd_situ; }
	public void setNQCETB30_S_CD_USUA_ULTI_ALTR(String nqcetb30_s_cd_usua_ulti_altr) { this.NQCETB30_S_CD_USUA_ULTI_ALTR = nqcetb30_s_cd_usua_ulti_altr; }
	public void setNQCETB30_S_DH_ULTI_ALTR(String nqcetb30_s_dh_ulti_altr) { this.NQCETB30_S_DH_ULTI_ALTR = nqcetb30_s_dh_ulti_altr; }
}