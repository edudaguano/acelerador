package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0120")
public class NQS0120 {
@PsFieldString(name="COALEPA", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALEPA;
@PsFieldString(name="COALERT", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALERT;
@PsFieldString(name="COCLIEN", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COCLIEN;
@PsFieldString(name="NOCLIEN", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOCLIEN;
@PsFieldString(name="TPDOC", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPDOC;
@PsFieldString(name="NUDOC", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUDOC;
@PsFieldString(name="DTCRIAL", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTCRIAL;
@PsFieldString(name="DTQUEST", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTQUEST;
@PsFieldString(name="TPALERT", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPALERT;
@PsFieldNumber(name="CDPAREC", length=2, defaultValue = "0" )
private Integer CDPAREC;
@PsFieldString(name="COALNKM", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALNKM;
@PsFieldString(name="COSITU", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COSITU;

public String getCOALEPA() {
 return COALEPA;
}
public void setCOALEPA(String COALEPA) {
 this.COALEPA = COALEPA;
}

public String getCOALERT() {
 return COALERT;
}
public void setCOALERT(String COALERT) {
 this.COALERT = COALERT;
}

public String getCOCLIEN() {
 return COCLIEN;
}
public void setCOCLIEN(String COCLIEN) {
 this.COCLIEN = COCLIEN;
}

public String getNOCLIEN() {
 return NOCLIEN;
}
public void setNOCLIEN(String NOCLIEN) {
 this.NOCLIEN = NOCLIEN;
}

public String getTPDOC() {
 return TPDOC;
}
public void setTPDOC(String TPDOC) {
 this.TPDOC = TPDOC;
}

public String getNUDOC() {
 return NUDOC;
}
public void setNUDOC(String NUDOC) {
 this.NUDOC = NUDOC;
}

public String getDTCRIAL() {
 return DTCRIAL;
}
public void setDTCRIAL(String DTCRIAL) {
 this.DTCRIAL = DTCRIAL;
}

public String getDTQUEST() {
 return DTQUEST;
}
public void setDTQUEST(String DTQUEST) {
 this.DTQUEST = DTQUEST;
}

public String getTPALERT() {
 return TPALERT;
}
public void setTPALERT(String TPALERT) {
 this.TPALERT = TPALERT;
}
public Integer getCDPAREC() {
 return CDPAREC;
}
public void setCDPAREC(Integer cDPAREC) {
CDPAREC = cDPAREC;
}
public String getCOALNKM() {
 return COALNKM;
}
public void setCOALNKM(String COALNKM) {
 this.COALNKM = COALNKM;
}

public String getCOSITU() {
 return COSITU;
}
public void setCOSITU(String COSITU) {
 this.COSITU = COSITU;
}


}
