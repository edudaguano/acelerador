package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.SistemasDao;
import com.altec.bsbr.app.jab.nq.service.SistemasService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class SistemasServiceImpl implements SistemasService {
	private final Logger LOGGER = LoggerFactory.getLogger(SistemasServiceImpl.class);
	
	@Autowired
	private SistemasDao sistemas;

	public String listarSistema(String strCodUser) throws BusinessException {
		return sistemas.listarSistema(strCodUser);
	}

	public String consultarSistema(String strCodSist, String strCodUser) throws BusinessException {
		return sistemas.consultarSistema(strCodSist, strCodUser);
	}

	public String incluirSistema(String strCodSist, String strSigla, String strNmFuncao, String strDesc,
			String strAtivo, String strCodUser) throws BusinessException {
		return sistemas.incluirSistema(strCodSist, strSigla, strNmFuncao, strDesc, strAtivo, strCodUser);
	}

	public String alterarSistema(String strCodSist, String strSigla, String strNmFuncao, String strDesc,
			String strAtivo, String strCodUser) throws BusinessException {
		return sistemas.alterarSistema(strCodSist, strSigla, strNmFuncao, strDesc, strAtivo, strCodUser);
	}

	public String excluirSistema(String strCodSist, String strCodUser) throws BusinessException {
		return sistemas.excluirSistema(strCodSist, strCodUser);
	}

	public String inicializarinputArea(String tNQ_NQAT2001_NQCETB01_ENTRADA) throws BusinessException{ 
		return sistemas.inicializarinputArea(tNQ_NQAT2001_NQCETB01_ENTRADA);
	}

	public String fnAddCaracter(String vlr,String tp, String tam) throws BusinessException{ 
		return sistemas.fnAddCaracter(vlr, tp, tam);
	}
}
