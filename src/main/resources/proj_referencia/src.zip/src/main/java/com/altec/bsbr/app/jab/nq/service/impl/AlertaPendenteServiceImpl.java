package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.AlertaPendenteDao;
import com.altec.bsbr.app.jab.nq.service.AlertaPendenteService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class AlertaPendenteServiceImpl implements AlertaPendenteService {
	private final Logger LOGGER = LoggerFactory.getLogger(AlertaPendenteServiceImpl.class);
	
	@Autowired
	private AlertaPendenteDao alertapendente;

	public String versao() throws BusinessException {
		return alertapendente.versao();
	}

	public String consultarAlerta(String strCOENTID, String strTPUNIOR, String strCDUNIOR, String strCOALERP,
			String strDTQUEST, String strDTGERPA, String strIDORDPA) throws BusinessException {
		return alertapendente.consultarAlerta(strCOENTID, strTPUNIOR, strCDUNIOR, strCOALERP, strDTQUEST, strDTGERPA,
				strIDORDPA);
	}
}
