package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0290")
public class NQS0290 {
@PsFieldString(name="DSRAZSO", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSRAZSO;
@PsFieldString(name="TPDOCTO", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPDOCTO;
@PsFieldString(name="NUDOCTO", length=15, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUDOCTO;
@PsFieldString(name="DSEGRPR", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSEGRPR;
@PsFieldString(name="DSEGRSE", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSEGRSE;
@PsFieldNumber(name="VLFATUR", length=15, decimal=2, defaultValue = "0" )
private double VLFATUR;
@PsFieldString(name="DTFATUR", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTFATUR;
@PsFieldString(name="DSATIVI", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSATIVI;
@PsFieldString(name="DTULATI", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTULATI;
@PsFieldString(name="ICMARPE", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMARPE;

public String getDSRAZSO() {
 return DSRAZSO;
}
public void setDSRAZSO(String DSRAZSO) {
 this.DSRAZSO = DSRAZSO;
}

public String getTPDOCTO() {
 return TPDOCTO;
}
public void setTPDOCTO(String TPDOCTO) {
 this.TPDOCTO = TPDOCTO;
}

public String getNUDOCTO() {
 return NUDOCTO;
}
public void setNUDOCTO(String NUDOCTO) {
 this.NUDOCTO = NUDOCTO;
}

public String getDSEGRPR() {
 return DSEGRPR;
}
public void setDSEGRPR(String DSEGRPR) {
 this.DSEGRPR = DSEGRPR;
}

public String getDSEGRSE() {
 return DSEGRSE;
}
public void setDSEGRSE(String DSEGRSE) {
 this.DSEGRSE = DSEGRSE;
}
public double getVLFATUR() {
 return VLFATUR;
}
public void setVLFATUR(double vLFATUR) {
VLFATUR = vLFATUR;
}
public String getDTFATUR() {
 return DTFATUR;
}
public void setDTFATUR(String DTFATUR) {
 this.DTFATUR = DTFATUR;
}

public String getDSATIVI() {
 return DSATIVI;
}
public void setDSATIVI(String DSATIVI) {
 this.DSATIVI = DSATIVI;
}

public String getDTULATI() {
 return DTULATI;
}
public void setDTULATI(String DTULATI) {
 this.DTULATI = DTULATI;
}

public String getICMARPE() {
 return ICMARPE;
}
public void setICMARPE(String ICMARPE) {
 this.ICMARPE = ICMARPE;
}


}
