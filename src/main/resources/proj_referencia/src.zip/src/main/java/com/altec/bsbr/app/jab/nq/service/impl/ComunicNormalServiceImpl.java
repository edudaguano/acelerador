package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.ComunicNormalDao;
import com.altec.bsbr.app.jab.nq.service.ComunicNormalService;
import com.altec.bsbr.fw.BusinessException;


@Service
public class ComunicNormalServiceImpl implements ComunicNormalService {
	private final Logger LOGGER = LoggerFactory.getLogger(ComunicNormalServiceImpl.class);
	@Autowired
	private ComunicNormalDao comunicNormal;

	public String versao() throws BusinessException {
		return comunicNormal.versao();
	}

	public String enviaMensagem(String strCDENTID, String strCDAGENC, String strCDALERT, String strCDUNIOR,
			String strTPUNIOR, String strTXPAR01, String strTXPAR02, String strTXPAR03, String strTXPAR04,
			String strTXPAR05, String strTXPAR06, String strTXPAR07, String strTXPAR08, String strTXPAR09,
			String strTXPAR10, String strTPPAREC, String strDTCOMIT, String strCDUSRES, String strNUSEQUE,
			String strTPCHAMA) throws BusinessException {
		return comunicNormal.enviaMensagem(strCDENTID, strCDAGENC, strCDALERT, strCDUNIOR, strTPUNIOR, strTXPAR01,
				strTXPAR02, strTXPAR03, strTXPAR04, strTXPAR05, strTXPAR06, strTXPAR07, strTXPAR08, strTXPAR09,
				strTXPAR10, strTPPAREC, strDTCOMIT, strCDUSRES, strNUSEQUE, strTPCHAMA);
	}
}
