package com.altec.bsbr.app.jab.nq.legado.messageGateway;
import java.util.List;

import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCE6049LegadoRequest;
import com.altec.bsbr.fw.jms.legado.LegadoException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;

public interface NQCE6049MessagingGateway {
	
	LegadoResult sendMessageLegado(NQCE6049LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageMultiLegado(NQCE6049LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageListLegado(List<NQCE6049LegadoRequest> arg0) throws LegadoException;

}