package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0190")
public class NQS0190 {
@PsFieldString(name="COSIGLP", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COSIGLP;
@PsFieldNumber(name="NUSEQSP", length=2, defaultValue = "0" )
private Integer NUSEQSP;
@PsFieldString(name="CODEINP", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODEINP;
@PsFieldString(name="COOPINP", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COOPINP;
@PsFieldString(name="COSIGLA", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COSIGLA;
@PsFieldNumber(name="NUSEQOR", length=2, defaultValue = "0" )
private Integer NUSEQOR;
@PsFieldString(name="CODETIN", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODETIN;
@PsFieldString(name="NOPRODU", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOPRODU;
@PsFieldString(name="COOPINT", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COOPINT;
@PsFieldString(name="DSOPINT", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DSOPINT;
@PsFieldString(name="ICMONIT", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String ICMONIT;
@PsFieldString(name="DTHROPE", length=26, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTHROPE;

public String getCOSIGLP() {
 return COSIGLP;
}
public void setCOSIGLP(String COSIGLP) {
 this.COSIGLP = COSIGLP;
}
public Integer getNUSEQSP() {
 return NUSEQSP;
}
public void setNUSEQSP(Integer nUSEQSP) {
NUSEQSP = nUSEQSP;
}
public String getCODEINP() {
 return CODEINP;
}
public void setCODEINP(String CODEINP) {
 this.CODEINP = CODEINP;
}

public String getCOOPINP() {
 return COOPINP;
}
public void setCOOPINP(String COOPINP) {
 this.COOPINP = COOPINP;
}

public String getCOSIGLA() {
 return COSIGLA;
}
public void setCOSIGLA(String COSIGLA) {
 this.COSIGLA = COSIGLA;
}
public Integer getNUSEQOR() {
 return NUSEQOR;
}
public void setNUSEQOR(Integer nUSEQOR) {
NUSEQOR = nUSEQOR;
}
public String getCODETIN() {
 return CODETIN;
}
public void setCODETIN(String CODETIN) {
 this.CODETIN = CODETIN;
}

public String getNOPRODU() {
 return NOPRODU;
}
public void setNOPRODU(String NOPRODU) {
 this.NOPRODU = NOPRODU;
}

public String getCOOPINT() {
 return COOPINT;
}
public void setCOOPINT(String COOPINT) {
 this.COOPINT = COOPINT;
}

public String getDSOPINT() {
 return DSOPINT;
}
public void setDSOPINT(String DSOPINT) {
 this.DSOPINT = DSOPINT;
}

public String getICMONIT() {
 return ICMONIT;
}
public void setICMONIT(String ICMONIT) {
 this.ICMONIT = ICMONIT;
}

public String getDTHROPE() {
 return DTHROPE;
}
public void setDTHROPE(String DTHROPE) {
 this.DTHROPE = DTHROPE;
}


}
