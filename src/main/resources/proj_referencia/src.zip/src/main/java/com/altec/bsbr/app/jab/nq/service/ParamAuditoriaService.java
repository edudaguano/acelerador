package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface ParamAuditoriaService{ 
	
	public String listarParametro(String strCodSist, String strCodUser) throws BusinessException;

	public String consultarParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodUser) throws BusinessException;

	public String incluirParametro(String strCodSist, String strCodCamp, String strCodDomin, String strCntd1,
			String strCntd2, String strCodList, String strDesc, String strCodUser, String strDtIncAlt, String strAtivo) throws BusinessException;

	public String alterarParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodDomin,
			String strCntd1, String strCntd2, String strCodList, String strDesc, String strCodUser, String strDtIncAlt,
			String strAtivo) throws BusinessException;

	public String excluirParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodUser) throws BusinessException;

	public String inicializarinputArea(String TNQ_NQAT2006_NQCETB06_INPUT_AREA) throws BusinessException;

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws BusinessException;
	
}
