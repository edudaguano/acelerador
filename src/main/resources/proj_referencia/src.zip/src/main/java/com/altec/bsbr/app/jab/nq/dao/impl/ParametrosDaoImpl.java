package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.ParametrosDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCE7035LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCE7035LegadoResponse;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

//BACKEND SEM FONTE
@Repository
public class ParametrosDaoImpl implements ParametrosDao {
	private final Logger LOGGER = LoggerFactory.getLogger(ParametrosDaoImpl.class);

	@Autowired
 	private JSONMapper jsonMapper;

	@Override
	public String confirmarRegras(String acao, String intProduto, String intCodBanco, String intPeriodo,
			String intAgrupa, String lngAtividade, String lngOcupacao, String intSegmento, String dblValor,
			String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String incluirValorOpSensib(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdSelecionada, String dblValor, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String alterarValorOpSensib(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdSelecionada, String dblValor, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarBancoPeriodoProdAplic() {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String consultarValorOpSensivel(String intBanco, String intAplicativo, String intPeriodo,
			String intProduto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarAgencias(String intBanco, String intAgencia, String strFuncao) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarApoio(String intTabela, String number) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarAtvEconomica(String intBanco, String intPeriodicidade) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarRegras(String intBanco, String intProduto, String intPeriodicidade) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String consultarTipoAgrupamento(String intBanco, String intProduto, String intPeriodicidade) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String incluirAgencia(String intCodBancoSelecionado, String intCodAgSelecionada, String TpAgrupaTruncado,
			String strUsuario, String dblValor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String alterarAgencia(String intCodBancoSelecionado, String intCodAgSelecionada, String TpAgrupaTruncado,
			String strUsuario, String dblValor) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String incluirApoio(String intCodTabelaSelecionada, String strCodItem, String strDescricao,
			String strDescResumida, String strStatus, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String alterarApoio(String intCodTabelaSelecionada, String strCodItem, String strDescricao,
			String strDescResumida, String strStatus, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String incluirAtividadeEconomica(String intCodBancoSelecionado, String intCodPeriododSelecionada,
			String intAtvSelecionada, String strUsuario, String strDescricao) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String carregaCombo(String intCodBancoSelecionado) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String incluirCtrlProcessamento(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdutoSelecionada, String auxData, String auxDataAnt,
			String strDescAplicativo, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String alterarCtrlProcessamento(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdutoSelecionada, String auxData, String auxDataAnt,
			String strDescAplicativo, String strUsuario, String strStatus) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String recuperaProduto(String intCodBancoSelecionado) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String alterarFiltroSensib(String codTabela, String strCodItem, String strDescricao, String strDescResumida,
			String strStatus, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String incluirPais(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intPaisSelecionado, String intTipoPaisSelecionado,
			String strUsuario, String strDescPais) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String alterarPais(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intPaisSelecionado, String intTipoPaisSelecionado,
			String strUsuario, String strDescPais) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String recuperaPaisesTipo() {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String incluirReceptores(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodSegmentoSelecionado, String intSequencia, String strNomeRecepItem, String strPrefEmailItem,
			String intCodSufixoSelecionado, String intCodTpEnvioSelecionado, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String alterarReceptores(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodSegmentoSelecionado, String sequencia, String strNomeRecepItem, String strPrefEmailItem,
			String intCodSufixoSelecionado, String intCodTpEnvioSelecionado, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarSegmSufTpEnvio(String intCodBancoSelecionado) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String verificaStatusProduto(String intCodBancoSelecionado) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String recuperaTpHistAtvOcup(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipo1, String intTipo2, String intTipo3) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String recuperaAtvOcup(String intCodBancoSelecionado) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String incluirTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipo, String strUsuario, String strDescAgrupamento) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String recuperarTipoCombo(String banco) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String incluirValorTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipoSelecionado, String dblValor, String strUsuario,
			String strDescricao) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String alterarValorTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipoSelecionado, String dblValor, String strUsuario,
			String strDescricao) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String excluirAgencia(String intCodBancoItem, String intCodAgenciaItem, String strTipoAgrupamento,
			String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarBancoAgencia() {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String excluirApoio(String intTabelaItem, String strCodItem, String strDescTot, String strDescRes,
			String strStatus, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String excluirAtividadeEconomica(String intCodBancoItem, String intCodPeriodoItem, String intCodAtividade,
			String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarBancoPeriodo() {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String consultarBancoPeriodoProduto() {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String recuperaCtrlProcessamento(String banco, String aplicativo, String periodo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarBanco() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarFiltroSensibilizacao(String intCodBancoSelecionado, String dblCodRetorno,
			String strMsgRetorno) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String excluirPais(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem,
			String intCDHISTItem, String intTPHISTItem, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarPaises(String banco, String produto, String periodo) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String excluirReceptores(String intCodBancoItem, String intCodProdItem, String intCodSegmentoItem,
			String intSequencia, String strNomeRecepItem, String strPrefEmailItem, String intCodSufixoEmailItem,
			String strTipoEnvioItem, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarBancoProduto() {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String incluirSensibilizacao(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String alterarSensibilizacao(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarSensibilizacao(String banco, String produto, String periodo) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String incluirTpValorPerfil(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String alterarTpValorPerfil(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarTpValorPerfil(String banco, String produto, String periodo) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	@Override
	public String excluirTipoAgrupamento(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem,
			String intCDHISTItem, String intTPHISTItem, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String excluirValorTpAgrupamento(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem,
			String intTPHISTItem, String strUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String consultarValorTpAgrupamento(String banco, String produto, String periodo) {
		String json = "";
		//TODO: Backend mockado
		try {
			
			NQCE7035LegadoRequest req = new NQCE7035LegadoRequest();
			//TODO: Quais campos serão setados com os valores recebidos nesse metodo? Verificar com Sandro ou gestora da sigla
			//req.set
			
			NQCE7035LegadoResponse res = new NQCE7035LegadoResponse();
			res = (NQCE7035LegadoResponse) jsonMapper.mockLegadoObject(NQCE7035LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			//lst.add(request);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	} 

	
}
