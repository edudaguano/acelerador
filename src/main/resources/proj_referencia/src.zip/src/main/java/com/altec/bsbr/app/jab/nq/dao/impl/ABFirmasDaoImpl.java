package com.altec.bsbr.app.jab.nq.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import com.altec.bsbr.app.jab.nq.dao.ABFirmasDao;

@Repository 
public class ABFirmasDaoImpl implements ABFirmasDao {
	
	private final Logger LOGGER = LoggerFactory.getLogger(ABFirmasDaoImpl.class); 
	
	@Override
	public String rsConsultaProcuradores(String nu_banco, String nu_agencia, String tpConta, String Conta) {
		return "SPOIDJASDJASPDOKASPODJK";
	}

}

