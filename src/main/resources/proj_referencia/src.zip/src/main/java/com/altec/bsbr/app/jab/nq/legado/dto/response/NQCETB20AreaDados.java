package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB20AreaDados")
public class NQCETB20AreaDados {

	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*

	@PsFieldString(name= "NQCETB20_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_CD_BANC_CLIE;//          05   NQCETB20-S-CD-BANC-CLIE       PIC  X(004).                
	
	//*       CODIGO DO BANCO                                           
	//
	@PsFieldString(name= "NQCETB20_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_CD_CLIE;//          05   NQCETB20-S-CD-CLIE            PIC  X(008).                
	
	//*       CODIGO DO CLIENTE                                         
	//
	@PsFieldString(name= "NQCETB20_S_DT_MOVI", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_DT_MOVI;//          05   NQCETB20-S-DT-MOVI            PIC  X(010).                
	
	//*       DATA DO MOVIMENTO                                         
	//
	@PsFieldString(name= "NQCETB20_S_NR_OPER", length= 17, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_NR_OPER;//          05   NQCETB20-S-NR-OPER            PIC  X(017).                
	
	//*       NUMERO DA OPERACAO                                        
	//
	@PsFieldNumber(name= "NQCETB20_S_VL_OPER", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB20_S_VL_OPER;//          05   NQCETB20-S-VL-OPER            PIC S9(015)V99.             
	
	//*       VALOR DA OPERACAO                                         
	//
	@PsFieldString(name= "NQCETB20_S_TP_OPER", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_TP_OPER;//          05   NQCETB20-S-TP-OPER            PIC  X(001).                
	
	//*       TIPO DE OPERACAO                                          
	//
	@PsFieldNumber(name= "NQCETB20_S_TP_NATZ", decimal= 0, length= 5, signed= false, defaultValue="0")
	private Long NQCETB20_S_TP_NATZ;//          05   NQCETB20-S-TP-NATZ            PIC  9(005).                
	
	//*       TIPO DA NATUREZA DA OPERACAO                              
	//
	@PsFieldNumber(name= "NQCETB20_S_TP_FORM_PGTO_1", decimal= 0, length= 2, signed= false, defaultValue="0")
	private Long NQCETB20_S_TP_FORM_PGTO_1;//          05   NQCETB20-S-TP-FORM-PGTO-1     PIC  9(002).                
	
	//*       TIPO DA FORMA DE PAGAMENTO 1                              
	//
	@PsFieldNumber(name= "NQCETB20_S_TP_FORM_PGTO_2", decimal= 0, length= 2, signed= false, defaultValue="0")
	private Long NQCETB20_S_TP_FORM_PGTO_2;//          05   NQCETB20-S-TP-FORM-PGTO-2     PIC  9(002).                
	
	//*       TIPO DA FORMA DE PAGAMENTO 2                              
	//
	@PsFieldString(name= "NQCETB20_S_CD_MOED_ORIG", length= 5, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_CD_MOED_ORIG;//     05   NQCETB20-S-CD-MOED-ORIG       PIC  X(005).                
	
	//*05   NQCETB20-S-CD-MOED-ORIG-N     REDEFINES                   
	//*    NQCETB20-S-CD-MOED-ORIG       PIC  9(005).                
	//*       CODIGO DA MOEDA DA OPERACAO                               
	//
	@PsFieldNumber(name= "NQCETB20_S_VL_ORIG_OPER", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB20_S_VL_ORIG_OPER;//          05   NQCETB20-S-VL-ORIG-OPER       PIC S9(015)V99.             
	
	//*       VALOR ORIGEM DA OPERACAO                                  
	//
	@PsFieldString(name= "NQCETB20_S_CD_GRUP_OPER", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_CD_GRUP_OPER;//          05   NQCETB20-S-CD-GRUP-OPER       PIC  X(004).                
	
	//*       CODIGO DO GRUPO DA OPERACAO                               
	//
	@PsFieldNumber(name= "NQCETB20_S_CD_MOED_MOVI", decimal= 0, length= 5, signed= false, defaultValue="0")
	private Long NQCETB20_S_CD_MOED_MOVI;//          05   NQCETB20-S-CD-MOED-MOVI       PIC  9(005).                
	
	//*       CODIGO DA MOEDA DE MOVIMENTACAO DA OPERACAO               
	//
	@PsFieldNumber(name= "NQCETB20_S_CD_MOED_DEST", decimal= 0, length= 5, signed= false, defaultValue="0")
	private Long NQCETB20_S_CD_MOED_DEST;//          05   NQCETB20-S-CD-MOED-DEST       PIC  9(005).                
	
	//*       CODIGO DA MOEDA DE DESTINO DA OPERACAO                    
	//
	@PsFieldString(name= "NQCETB20_S_CD_PROD", length= 18, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_CD_PROD;//          05   NQCETB20-S-CD-PROD            PIC  X(018).                
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name= "NQCETB20_S_NR_NIO", length= 24, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_NR_NIO;//          05   NQCETB20-S-NR-NIO             PIC  X(024).                
	
	//*       NUMERO NIO DA OPERACAO                                    
	//
	@PsFieldString(name= "NQCETB20_S_CD_AGEN_MOVI", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_CD_AGEN_MOVI;//          05   NQCETB20-S-CD-AGEN-MOVI       PIC  X(004).                
	
	//*       CODIGO DA AGENCIA DE MOVIMENTACAO DA OPERACAO             
	//
	@PsFieldString(name= "NQCETB20_S_CD_BANC_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_CD_BANC_CNTR;//          05   NQCETB20-S-CD-BANC-CNTR       PIC  X(004).                
	
	//*       CODIGO DO BANCO DO CONTRATO                               
	//
	@PsFieldString(name= "NQCETB20_S_CD_AGEN_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_CD_AGEN_CNTR;//          05   NQCETB20-S-CD-AGEN-CNTR       PIC  X(004).                
	
	//*       CODIGO DA AGENCIA DO CONTRATO                             
	//
	@PsFieldString(name= "NQCETB20_S_NR_CNTR_A", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_NR_CNTR_A;//          05   NQCETB20-S-NR-CNTR-A          PIC  X(020).                
	
	//*       NUMERO DO CONTRATO ALTAIR                                 
	//
	@PsFieldString(name= "NQCETB20_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_CD_PROD_ALTAIR;//          05   NQCETB20-S-CD-PROD-ALTAIR     PIC  X(002).                
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name= "NQCETB20_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_CD_SUBP_ALTAIR;//          05   NQCETB20-S-CD-SUBP-ALTAIR     PIC  X(004).                
	
	//*       CODIGO DO SUBPRODUTO                                      
	//
	@PsFieldString(name= "NQCETB20_S_CD_MOED", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_CD_MOED;//          05   NQCETB20-S-CD-MOED            PIC  X(003).                
	
	//*       CODIGO DA MOEDA                                           
	//
	@PsFieldNumber(name= "NQCETB20_S_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB20_S_NR_SEQU_OPER;//          05   NQCETB20-S-NR-SEQU-OPER       PIC  9(003).                
	
	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	@PsFieldString(name= "NQCETB20_S_CD_IDEF_OPER", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_CD_IDEF_OPER;//          05   NQCETB20-S-CD-IDEF-OPER       PIC  X(020).                
	
	//*       CODIGO DA IDENTIFICACAO DA OPERACAO                       
	//
	@PsFieldString(name= "NQCETB20_S_NM_CLIE", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB20_S_NM_CLIE;//     05   NQCETB20-S-NM-CLIE            PIC  X(040). 
	
	//*       NOME DO CLIENTE                                           
	//
	
	public String getNQCETB20_S_CD_BANC_CLIE() {
		return NQCETB20_S_CD_BANC_CLIE;
	}

	public void setNQCETB20_S_CD_BANC_CLIE(String nQCETB20_S_CD_BANC_CLIE) {
		NQCETB20_S_CD_BANC_CLIE = nQCETB20_S_CD_BANC_CLIE;
	}

	public String getNQCETB20_S_CD_CLIE() {
		return NQCETB20_S_CD_CLIE;
	}

	public void setNQCETB20_S_CD_CLIE(String nQCETB20_S_CD_CLIE) {
		NQCETB20_S_CD_CLIE = nQCETB20_S_CD_CLIE;
	}

	public String getNQCETB20_S_DT_MOVI() {
		return NQCETB20_S_DT_MOVI;
	}

	public void setNQCETB20_S_DT_MOVI(String nQCETB20_S_DT_MOVI) {
		NQCETB20_S_DT_MOVI = nQCETB20_S_DT_MOVI;
	}

	public String getNQCETB20_S_NR_OPER() {
		return NQCETB20_S_NR_OPER;
	}

	public void setNQCETB20_S_NR_OPER(String nQCETB20_S_NR_OPER) {
		NQCETB20_S_NR_OPER = nQCETB20_S_NR_OPER;
	}

	public Double getNQCETB20_S_VL_OPER() {
		return NQCETB20_S_VL_OPER;
	}

	public void setNQCETB20_S_VL_OPER(Double nQCETB20_S_VL_OPER) {
		NQCETB20_S_VL_OPER = nQCETB20_S_VL_OPER;
	}

	public String getNQCETB20_S_TP_OPER() {
		return NQCETB20_S_TP_OPER;
	}

	public void setNQCETB20_S_TP_OPER(String nQCETB20_S_TP_OPER) {
		NQCETB20_S_TP_OPER = nQCETB20_S_TP_OPER;
	}

	public Long getNQCETB20_S_TP_NATZ() {
		return NQCETB20_S_TP_NATZ;
	}

	public void setNQCETB20_S_TP_NATZ(Long nQCETB20_S_TP_NATZ) {
		NQCETB20_S_TP_NATZ = nQCETB20_S_TP_NATZ;
	}

	public Long getNQCETB20_S_TP_FORM_PGTO_1() {
		return NQCETB20_S_TP_FORM_PGTO_1;
	}

	public void setNQCETB20_S_TP_FORM_PGTO_1(Long nQCETB20_S_TP_FORM_PGTO_1) {
		NQCETB20_S_TP_FORM_PGTO_1 = nQCETB20_S_TP_FORM_PGTO_1;
	}

	public Long getNQCETB20_S_TP_FORM_PGTO_2() {
		return NQCETB20_S_TP_FORM_PGTO_2;
	}

	public void setNQCETB20_S_TP_FORM_PGTO_2(Long nQCETB20_S_TP_FORM_PGTO_2) {
		NQCETB20_S_TP_FORM_PGTO_2 = nQCETB20_S_TP_FORM_PGTO_2;
	}

	public String getNQCETB20_S_CD_MOED_ORIG() {
		return NQCETB20_S_CD_MOED_ORIG;
	}

	public void setNQCETB20_S_CD_MOED_ORIG(String nQCETB20_S_CD_MOED_ORIG) {
		NQCETB20_S_CD_MOED_ORIG = nQCETB20_S_CD_MOED_ORIG;
	}

	public Double getNQCETB20_S_VL_ORIG_OPER() {
		return NQCETB20_S_VL_ORIG_OPER;
	}

	public void setNQCETB20_S_VL_ORIG_OPER(Double nQCETB20_S_VL_ORIG_OPER) {
		NQCETB20_S_VL_ORIG_OPER = nQCETB20_S_VL_ORIG_OPER;
	}

	public String getNQCETB20_S_CD_GRUP_OPER() {
		return NQCETB20_S_CD_GRUP_OPER;
	}

	public void setNQCETB20_S_CD_GRUP_OPER(String nQCETB20_S_CD_GRUP_OPER) {
		NQCETB20_S_CD_GRUP_OPER = nQCETB20_S_CD_GRUP_OPER;
	}

	public Long getNQCETB20_S_CD_MOED_MOVI() {
		return NQCETB20_S_CD_MOED_MOVI;
	}

	public void setNQCETB20_S_CD_MOED_MOVI(Long nQCETB20_S_CD_MOED_MOVI) {
		NQCETB20_S_CD_MOED_MOVI = nQCETB20_S_CD_MOED_MOVI;
	}

	public Long getNQCETB20_S_CD_MOED_DEST() {
		return NQCETB20_S_CD_MOED_DEST;
	}

	public void setNQCETB20_S_CD_MOED_DEST(Long nQCETB20_S_CD_MOED_DEST) {
		NQCETB20_S_CD_MOED_DEST = nQCETB20_S_CD_MOED_DEST;
	}

	public String getNQCETB20_S_CD_PROD() {
		return NQCETB20_S_CD_PROD;
	}

	public void setNQCETB20_S_CD_PROD(String nQCETB20_S_CD_PROD) {
		NQCETB20_S_CD_PROD = nQCETB20_S_CD_PROD;
	}

	public String getNQCETB20_S_NR_NIO() {
		return NQCETB20_S_NR_NIO;
	}

	public void setNQCETB20_S_NR_NIO(String nQCETB20_S_NR_NIO) {
		NQCETB20_S_NR_NIO = nQCETB20_S_NR_NIO;
	}

	public String getNQCETB20_S_CD_AGEN_MOVI() {
		return NQCETB20_S_CD_AGEN_MOVI;
	}

	public void setNQCETB20_S_CD_AGEN_MOVI(String nQCETB20_S_CD_AGEN_MOVI) {
		NQCETB20_S_CD_AGEN_MOVI = nQCETB20_S_CD_AGEN_MOVI;
	}

	public String getNQCETB20_S_CD_BANC_CNTR() {
		return NQCETB20_S_CD_BANC_CNTR;
	}

	public void setNQCETB20_S_CD_BANC_CNTR(String nQCETB20_S_CD_BANC_CNTR) {
		NQCETB20_S_CD_BANC_CNTR = nQCETB20_S_CD_BANC_CNTR;
	}

	public String getNQCETB20_S_CD_AGEN_CNTR() {
		return NQCETB20_S_CD_AGEN_CNTR;
	}

	public void setNQCETB20_S_CD_AGEN_CNTR(String nQCETB20_S_CD_AGEN_CNTR) {
		NQCETB20_S_CD_AGEN_CNTR = nQCETB20_S_CD_AGEN_CNTR;
	}

	public String getNQCETB20_S_NR_CNTR_A() {
		return NQCETB20_S_NR_CNTR_A;
	}

	public void setNQCETB20_S_NR_CNTR_A(String nQCETB20_S_NR_CNTR_A) {
		NQCETB20_S_NR_CNTR_A = nQCETB20_S_NR_CNTR_A;
	}

	public String getNQCETB20_S_CD_PROD_ALTAIR() {
		return NQCETB20_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB20_S_CD_PROD_ALTAIR(String nQCETB20_S_CD_PROD_ALTAIR) {
		NQCETB20_S_CD_PROD_ALTAIR = nQCETB20_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB20_S_CD_SUBP_ALTAIR() {
		return NQCETB20_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB20_S_CD_SUBP_ALTAIR(String nQCETB20_S_CD_SUBP_ALTAIR) {
		NQCETB20_S_CD_SUBP_ALTAIR = nQCETB20_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB20_S_CD_MOED() {
		return NQCETB20_S_CD_MOED;
	}

	public void setNQCETB20_S_CD_MOED(String nQCETB20_S_CD_MOED) {
		NQCETB20_S_CD_MOED = nQCETB20_S_CD_MOED;
	}

	public Long getNQCETB20_S_NR_SEQU_OPER() {
		return NQCETB20_S_NR_SEQU_OPER;
	}

	public void setNQCETB20_S_NR_SEQU_OPER(Long nQCETB20_S_NR_SEQU_OPER) {
		NQCETB20_S_NR_SEQU_OPER = nQCETB20_S_NR_SEQU_OPER;
	}

	public String getNQCETB20_S_CD_IDEF_OPER() {
		return NQCETB20_S_CD_IDEF_OPER;
	}

	public void setNQCETB20_S_CD_IDEF_OPER(String nQCETB20_S_CD_IDEF_OPER) {
		NQCETB20_S_CD_IDEF_OPER = nQCETB20_S_CD_IDEF_OPER;
	}

	public String getNQCETB20_S_NM_CLIE() {
		return NQCETB20_S_NM_CLIE;
	}

	public void setNQCETB20_S_NM_CLIE(String nQCETB20_S_NM_CLIE) {
		NQCETB20_S_NM_CLIE = nQCETB20_S_NM_CLIE;
	}
	
}