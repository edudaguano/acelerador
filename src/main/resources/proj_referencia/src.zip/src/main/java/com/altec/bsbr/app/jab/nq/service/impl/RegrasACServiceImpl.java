package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.RegrasACDao;
import com.altec.bsbr.app.jab.nq.service.RegrasACService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class RegrasACServiceImpl implements RegrasACService {
	private final Logger LOGGER = LoggerFactory.getLogger(RegrasACServiceImpl.class);

	@Autowired
	private RegrasACDao regrasAC;

	public String consultarRegras(String strCodSist, String strPeriodo, String strSituacao, String strCodUser)
			throws BusinessException {
		return regrasAC.consultarRegras(strCodSist, strPeriodo, strSituacao, strCodUser);
	}

	public String incluirRegras(String strCodSist, String strAtivo, String strCodUser, String strPeriodo,
			String strRegra, String strProduto, String strSubProduto, String StrPEP, String strFunc,
			String strTpTransacao, String strQtdTransacao, String strPercRenda, String strVlTransacao)
			throws BusinessException {
		return regrasAC.incluirRegras(strCodSist, strAtivo, strCodUser, strPeriodo, strRegra, strProduto, strSubProduto, StrPEP, strFunc, strTpTransacao, strQtdTransacao, strPercRenda, strVlTransacao);
	}

	public String alterarRegras(String strCodSist, String strAtivo, String strCodUser, String strPeriodo,
			String strRegra, String strProduto, String strSubProduto, String StrPEP, String strFunc,
			String strTpTransacao, String strQtdTransacao, String strPercRenda, String strVlTransacao)
			throws BusinessException {
		return regrasAC.alterarRegras(strCodSist, strAtivo, strCodUser, strPeriodo, strRegra, strProduto, strSubProduto, StrPEP, strFunc, strTpTransacao, strQtdTransacao, strPercRenda, strVlTransacao);
	}

	public String inicializarinputArea(String tNQ_NQAT2007_NQCETB07_Entrada) throws BusinessException {
		return regrasAC.inicializarinputArea(tNQ_NQAT2007_NQCETB07_Entrada);
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws BusinessException {
		return regrasAC.fnAddCaracter(Vlr, Tp, Tam);
	}

}