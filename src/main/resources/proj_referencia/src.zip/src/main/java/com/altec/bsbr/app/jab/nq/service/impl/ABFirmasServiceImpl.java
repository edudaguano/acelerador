package com.altec.bsbr.app.jab.nq.service.impl;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.altec.bsbr.app.jab.nq.dao.ABFirmasDao;
import com.altec.bsbr.app.jab.nq.service.ABFirmasService;
import com.altec.bsbr.fw.BusinessException;

@Service 
public class ABFirmasServiceImpl implements ABFirmasService{ 
	private final Logger LOGGER = LoggerFactory.getLogger(ABFirmasServiceImpl.class); 
	@Autowired
	private ABFirmasDao abfirmas;
	public String rsConsultaProcuradores(String nu_banco, String nu_agencia, String tpConta, String Conta) throws BusinessException{ 
		return abfirmas.rsConsultaProcuradores( nu_banco,  nu_agencia,  tpConta,  Conta);
	}}

