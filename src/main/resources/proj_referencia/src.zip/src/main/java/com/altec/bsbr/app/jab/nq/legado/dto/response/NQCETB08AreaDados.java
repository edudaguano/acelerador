package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name = "NQCETB08LegadoResponse")
public class NQCETB08AreaDados {
//         03    NQCETB08-S-DATA.                                          
//                                                                         
	@PsFieldString(name = "NQCETB08_S_CD_BANC_CLIE", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_CD_BANC_CLIE;// 05 NQCETB08-S-CD-BANC-CLIE PIC X(004).

//       *       CODIGO DO BANCO                                           
//                                                                         
	@PsFieldString(name = "NQCETB08_S_CD_CLIE", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_CD_CLIE;// 05 NQCETB08-S-CD-CLIE PIC X(008).

//       *       CODIGO DO CLIENTE                                         
//                                                                         
	@PsFieldString(name = "NQCETB08_S_NM_CLIE", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_NM_CLIE;// 05 NQCETB08-S-NM-CLIE PIC X(040).

//       *       NOME DO CLIENTE                                           
//                                                                         
	@PsFieldString(name = "NQCETB08_S_TP_PESS_CLIE", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_TP_PESS_CLIE;// 05 NQCETB08-S-TP-PESS-CLIE PIC X(001).

//       *       TIPO DE PESSOA                                            
//                                                                         
	@PsFieldString(name = "NQCETB08_S_NR_CPF_CNPJ", length = 15, paddingAlign = PsAlign.LEFT, paddingChar = '0')
	private String NQCETB08_S_NR_CPF_CNPJ;// 05 NQCETB08-S-NR-CPF-CNPJ PIC X(015).

//       *       CODIGO DO CPF / CNPJ                                      
//                                                                         
	@PsFieldString(name = "NQCETB08_S_CD_ATVD_OCUP", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_CD_ATVD_OCUP;// 05 NQCETB08-S-CD-ATVD-OCUP PIC X(010).

//       *       CODIGO DA ATIVIDADE / OCUPACAO                            
//                                                                         
	@PsFieldString(name = "NQCETB08_S_DT_NASC_FNDA", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_DT_NASC_FNDA;// 05 NQCETB08-S-DT-NASC-FNDA PIC X(010).

//       *       DATA DE NASCIMENTO / FUNDACAO                             
//                                                                         
	@PsFieldString(name = "NQCETB08_S_NM_CIDA_CLIE", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_NM_CIDA_CLIE;// 05 NQCETB08-S-NM-CIDA-CLIE PIC X(020).

//       *       NOME DA CIDADE                                            
//                                                                         
	@PsFieldString(name = "NQCETB08_S_CD_UF_CLIE", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_CD_UF_CLIE;// 05 NQCETB08-S-CD-UF-CLIE PIC X(002).

//       *       CODIGO DA UF                                              
//                                                                         
	@PsFieldNumber(name = "NQCETB08_S_VL_FATU_REND", decimal = 3, length = 17, signed = false, defaultValue = "0")
	private Double NQCETB08_S_VL_FATU_REND;// 05 NQCETB08-S-VL-FATU-REND PIC 9(015)V99.

//       *       VALOR DA RENDA / FATURAMENTO                              
//                                                                         
	@PsFieldString(name = "NQCETB08_S_DT_FATU_REND", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_DT_FATU_REND;// 05 NQCETB08-S-DT-FATU-REND PIC X(010).

//       *       DATA DA RENDA / FATURAMENTO                               
//                                                                         
	@PsFieldString(name = "NQCETB08_S_NM_GRUP_ECON", length = 25, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_NM_GRUP_ECON;// 05 NQCETB08-S-NM-GRUP-ECON PIC X(025).

//       *       NOME DO GRUPO ECONOMICO                                   
//                                                                         
	@PsFieldString(name = "NQCETB08_S_CD_SEGM", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_CD_SEGM;// 05 NQCETB08-S-CD-SEGM PIC X(004).

//       *       CODIGO DO SEGMENTO                                        
//                                                                         
	@PsFieldString(name = "NQCETB08_S_NR_MATR_GERE_COME", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_NR_MATR_GERE_COME;// 05 NQCETB08-S-NR-MATR-GERE-COME PIC X(008).

//       *       NUMERO DA MATRICULA DO GERENTE                            
//                                                                         
	@PsFieldString(name = "NQCETB08_S_NM_GERENTE", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_NM_GERENTE;// 05 NQCETB08-S-NM-GERENTE PIC X(040).

//       *       NOME DO GERENTE                                           
//                                                                         
	@PsFieldString(name = "NQCETB08_S_CD_RSTR", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_CD_RSTR;// 05 NQCETB08-S-CD-RSTR PIC X(001).

//       *       CODIGO DE RESTRICAO                                       
//                                                                         
	@PsFieldString(name = "NQCETB08_S_DS_RSTR", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB08_S_DS_RSTR;// 05 NQCETB08-S-DS-RSTR PIC X(020).

//       *       DESCRICAO DA RESTRICAO                                    
	public NQCETB08AreaDados() {
	}

	public String getNQCETB08_S_CD_BANC_CLIE() {
		return NQCETB08_S_CD_BANC_CLIE;
	}

	public void setNQCETB08_S_CD_BANC_CLIE(String nQCETB08_S_CD_BANC_CLIE) {
		NQCETB08_S_CD_BANC_CLIE = nQCETB08_S_CD_BANC_CLIE;
	}

	public String getNQCETB08_S_CD_CLIE() {
		return NQCETB08_S_CD_CLIE;
	}

	public void setNQCETB08_S_CD_CLIE(String nQCETB08_S_CD_CLIE) {
		NQCETB08_S_CD_CLIE = nQCETB08_S_CD_CLIE;
	}

	public String getNQCETB08_S_NM_CLIE() {
		return NQCETB08_S_NM_CLIE;
	}

	public void setNQCETB08_S_NM_CLIE(String nQCETB08_S_NM_CLIE) {
		NQCETB08_S_NM_CLIE = nQCETB08_S_NM_CLIE;
	}

	public String getNQCETB08_S_TP_PESS_CLIE() {
		return NQCETB08_S_TP_PESS_CLIE;
	}

	public void setNQCETB08_S_TP_PESS_CLIE(String nQCETB08_S_TP_PESS_CLIE) {
		NQCETB08_S_TP_PESS_CLIE = nQCETB08_S_TP_PESS_CLIE;
	}

	public String getNQCETB08_S_NR_CPF_CNPJ() {
		return NQCETB08_S_NR_CPF_CNPJ;
	}

	public void setNQCETB08_S_NR_CPF_CNPJ(String nQCETB08_S_NR_CPF_CNPJ) {
		NQCETB08_S_NR_CPF_CNPJ = nQCETB08_S_NR_CPF_CNPJ;
	}

	public String getNQCETB08_S_CD_ATVD_OCUP() {
		return NQCETB08_S_CD_ATVD_OCUP;
	}

	public void setNQCETB08_S_CD_ATVD_OCUP(String nQCETB08_S_CD_ATVD_OCUP) {
		NQCETB08_S_CD_ATVD_OCUP = nQCETB08_S_CD_ATVD_OCUP;
	}

	public String getNQCETB08_S_DT_NASC_FNDA() {
		return NQCETB08_S_DT_NASC_FNDA;
	}

	public void setNQCETB08_S_DT_NASC_FNDA(String nQCETB08_S_DT_NASC_FNDA) {
		NQCETB08_S_DT_NASC_FNDA = nQCETB08_S_DT_NASC_FNDA;
	}

	public String getNQCETB08_S_NM_CIDA_CLIE() {
		return NQCETB08_S_NM_CIDA_CLIE;
	}

	public void setNQCETB08_S_NM_CIDA_CLIE(String nQCETB08_S_NM_CIDA_CLIE) {
		NQCETB08_S_NM_CIDA_CLIE = nQCETB08_S_NM_CIDA_CLIE;
	}

	public String getNQCETB08_S_CD_UF_CLIE() {
		return NQCETB08_S_CD_UF_CLIE;
	}

	public void setNQCETB08_S_CD_UF_CLIE(String nQCETB08_S_CD_UF_CLIE) {
		NQCETB08_S_CD_UF_CLIE = nQCETB08_S_CD_UF_CLIE;
	}

	public Double getNQCETB08_S_VL_FATU_REND() {
		return NQCETB08_S_VL_FATU_REND;
	}

	public void setNQCETB08_S_VL_FATU_REND(Double nQCETB08_S_VL_FATU_REND) {
		NQCETB08_S_VL_FATU_REND = nQCETB08_S_VL_FATU_REND;
	}

	public String getNQCETB08_S_DT_FATU_REND() {
		return NQCETB08_S_DT_FATU_REND;
	}

	public void setNQCETB08_S_DT_FATU_REND(String nQCETB08_S_DT_FATU_REND) {
		NQCETB08_S_DT_FATU_REND = nQCETB08_S_DT_FATU_REND;
	}

	public String getNQCETB08_S_NM_GRUP_ECON() {
		return NQCETB08_S_NM_GRUP_ECON;
	}

	public void setNQCETB08_S_NM_GRUP_ECON(String nQCETB08_S_NM_GRUP_ECON) {
		NQCETB08_S_NM_GRUP_ECON = nQCETB08_S_NM_GRUP_ECON;
	}

	public String getNQCETB08_S_CD_SEGM() {
		return NQCETB08_S_CD_SEGM;
	}

	public void setNQCETB08_S_CD_SEGM(String nQCETB08_S_CD_SEGM) {
		NQCETB08_S_CD_SEGM = nQCETB08_S_CD_SEGM;
	}

	public String getNQCETB08_S_NR_MATR_GERE_COME() {
		return NQCETB08_S_NR_MATR_GERE_COME;
	}

	public void setNQCETB08_S_NR_MATR_GERE_COME(String nQCETB08_S_NR_MATR_GERE_COME) {
		NQCETB08_S_NR_MATR_GERE_COME = nQCETB08_S_NR_MATR_GERE_COME;
	}

	public String getNQCETB08_S_NM_GERENTE() {
		return NQCETB08_S_NM_GERENTE;
	}

	public void setNQCETB08_S_NM_GERENTE(String nQCETB08_S_NM_GERENTE) {
		NQCETB08_S_NM_GERENTE = nQCETB08_S_NM_GERENTE;
	}

	public String getNQCETB08_S_CD_RSTR() {
		return NQCETB08_S_CD_RSTR;
	}

	public void setNQCETB08_S_CD_RSTR(String nQCETB08_S_CD_RSTR) {
		NQCETB08_S_CD_RSTR = nQCETB08_S_CD_RSTR;
	}

	public String getNQCETB08_S_DS_RSTR() {
		return NQCETB08_S_DS_RSTR;
	}

	public void setNQCETB08_S_DS_RSTR(String nQCETB08_S_DS_RSTR) {
		NQCETB08_S_DS_RSTR = nQCETB08_S_DS_RSTR;
	}


}