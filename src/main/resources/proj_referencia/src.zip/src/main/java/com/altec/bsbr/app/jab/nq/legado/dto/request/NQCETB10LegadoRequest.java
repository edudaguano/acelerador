package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@PsFormat(name = "NQCETB10LegadoRequest")
public class NQCETB10LegadoRequest {
// -*-
//        01     NQCETB10-ENTRADA.                                         
//                                                                         
	@PsFieldString(name = "NQCETB10_E_NM_PROG", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_E_NM_PROG;// 05 NQCETB10-E-NM-PROG PIC X(008).

//       *       NOME DO PROGRAMA CHAMADO                                  
//                                                                         
	@PsFieldString(name = "NQCETB10_E_NM_AREA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_E_NM_AREA;// 05 NQCETB10-E-NM-AREA PIC X(008).

//       *       NOME DA AREA DE TS                                        
//                                                                         
	@PsFieldString(name = "NQCETB10_E_SG_FCAO", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_E_SG_FCAO;// 05 NQCETB10-E-SG-FCAO PIC X(002).

//       *       FUNCAO A SER EXECUTADA                                    
//       *       C = CONSULTAR                                             
//       *       A = ALTERAR                                               
//                                                                         
	@PsFieldNumber(name = "NQCETB10_E_QT_TAMA_AREA", decimal = 0, length = 7, signed = false, defaultValue = "0")
	private Long NQCETB10_E_QT_TAMA_AREA;// 05 NQCETB10-E-QT-TAMA-AREA PIC 9(007).

//       *       TAMANHO DA AREA DE TS                                     
//                                                                         
	@PsFieldString(name = "NQCETB10_E_CD_USUA_ULTI_ALTR", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_E_CD_USUA_ULTI_ALTR;// 05 NQCETB10-E-CD-USUA-ULTI-ALTR PIC X(008).

//       *       CODIGO DO USUARIO                                         
//                                                                         
	@PsFieldNumber(name = "NQCETB10_E_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB10_E_NR_SEQU_SIST;// 05 NQCETB10-E-NR-SEQU-SIST PIC 9(004).

//       *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                         
	@PsFieldNumber(name = "NQCETB10_E_NR_SEQU_REGR", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB10_E_NR_SEQU_REGR;// 05 NQCETB10-E-NR-SEQU-REGR PIC 9(004).

//       *       NUMERO DE SEQUENCIA DA REGRA                              
//                                                                         
	@PsFieldString(name = "NQCETB10_E_DT_OCOR", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_E_DT_OCOR;// 05 NQCETB10-E-DT-OCOR PIC X(010).

//       *       DATA DA OCORRENCIA                                        
//                                                                         
	@PsFieldString(name = "NQCETB10_E_CD_BANC_CLIE", length = 4, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_E_CD_BANC_CLIE;// 05 NQCETB10-E-CD-BANC-CLIE PIC X(004).

//       *       CODIGO DO BANCO DO CLIENTE                                
//                                                                         
	@PsFieldString(name = "NQCETB10_E_CD_CLIE", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_E_CD_CLIE;// 05 NQCETB10-E-CD-CLIE PIC X(008).

//       *       COGIGO DO CLIENTE                                         
//                                                                         
	@PsFieldString(name = "NQCETB10_E_TP_PERI", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_E_TP_PERI;// 05 NQCETB10-E-TP-PERI PIC X(001).

//       *       TIPO DE PERIODO                                           
//                                                                         
	@PsFieldString(name = "NQCETB10_E_TP_INDC_PARE", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_E_TP_INDC_PARE;// 05 NQCETB10-E-TP-INDC-PARE PIC X(001).

//       *       TIPO DE IDENTIFICACAO DO PARECER                          
//                                                                         
	@PsFieldString(name = "NQCETB10_E_TX_PARE", length = 254, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_E_TX_PARE;// 05 NQCETB10-E-TX-PARE PIC X(254).

//       *       TEXTO DO PARECER                                          
//                                                                         
	@PsFieldString(name = "NQCETB10_E_IN_NOTI_UPLD", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_E_IN_NOTI_UPLD;// 05 NQCETB10-E-IN-NOTI-UPLD PIC X(001).
                                                                      
	public NQCETB10LegadoRequest() {
	}

	public String getNQCETB10_E_NM_PROG() {
		return NQCETB10_E_NM_PROG;
	}

	public void setNQCETB10_E_NM_PROG(String nQCETB10_E_NM_PROG) {
		NQCETB10_E_NM_PROG = nQCETB10_E_NM_PROG;
	}

	public String getNQCETB10_E_NM_AREA() {
		return NQCETB10_E_NM_AREA;
	}

	public void setNQCETB10_E_NM_AREA(String nQCETB10_E_NM_AREA) {
		NQCETB10_E_NM_AREA = nQCETB10_E_NM_AREA;
	}

	public String getNQCETB10_E_SG_FCAO() {
		return NQCETB10_E_SG_FCAO;
	}

	public void setNQCETB10_E_SG_FCAO(String nQCETB10_E_SG_FCAO) {
		NQCETB10_E_SG_FCAO = nQCETB10_E_SG_FCAO;
	}

	public Long getNQCETB10_E_QT_TAMA_AREA() {
		return NQCETB10_E_QT_TAMA_AREA;
	}

	public void setNQCETB10_E_QT_TAMA_AREA(Long nQCETB10_E_QT_TAMA_AREA) {
		NQCETB10_E_QT_TAMA_AREA = nQCETB10_E_QT_TAMA_AREA;
	}

	public String getNQCETB10_E_CD_USUA_ULTI_ALTR() {
		return NQCETB10_E_CD_USUA_ULTI_ALTR;
	}

	public void setNQCETB10_E_CD_USUA_ULTI_ALTR(String nQCETB10_E_CD_USUA_ULTI_ALTR) {
		NQCETB10_E_CD_USUA_ULTI_ALTR = nQCETB10_E_CD_USUA_ULTI_ALTR;
	}

	public Long getNQCETB10_E_NR_SEQU_SIST() {
		return NQCETB10_E_NR_SEQU_SIST;
	}

	public void setNQCETB10_E_NR_SEQU_SIST(Long nQCETB10_E_NR_SEQU_SIST) {
		NQCETB10_E_NR_SEQU_SIST = nQCETB10_E_NR_SEQU_SIST;
	}

	public Long getNQCETB10_E_NR_SEQU_REGR() {
		return NQCETB10_E_NR_SEQU_REGR;
	}

	public void setNQCETB10_E_NR_SEQU_REGR(Long nQCETB10_E_NR_SEQU_REGR) {
		NQCETB10_E_NR_SEQU_REGR = nQCETB10_E_NR_SEQU_REGR;
	}

	public String getNQCETB10_E_DT_OCOR() {
		return NQCETB10_E_DT_OCOR;
	}

	public void setNQCETB10_E_DT_OCOR(String nQCETB10_E_DT_OCOR) {
		NQCETB10_E_DT_OCOR = nQCETB10_E_DT_OCOR;
	}

	public String getNQCETB10_E_CD_BANC_CLIE() {
		return NQCETB10_E_CD_BANC_CLIE;
	}

	public void setNQCETB10_E_CD_BANC_CLIE(String nQCETB10_E_CD_BANC_CLIE) {
		NQCETB10_E_CD_BANC_CLIE = nQCETB10_E_CD_BANC_CLIE;
	}

	public String getNQCETB10_E_CD_CLIE() {
		return NQCETB10_E_CD_CLIE;
	}

	public void setNQCETB10_E_CD_CLIE(String nQCETB10_E_CD_CLIE) {
		NQCETB10_E_CD_CLIE = nQCETB10_E_CD_CLIE;
	}

	public String getNQCETB10_E_TP_PERI() {
		return NQCETB10_E_TP_PERI;
	}

	public void setNQCETB10_E_TP_PERI(String nQCETB10_E_TP_PERI) {
		NQCETB10_E_TP_PERI = nQCETB10_E_TP_PERI;
	}

	public String getNQCETB10_E_TP_INDC_PARE() {
		return NQCETB10_E_TP_INDC_PARE;
	}

	public void setNQCETB10_E_TP_INDC_PARE(String nQCETB10_E_TP_INDC_PARE) {
		NQCETB10_E_TP_INDC_PARE = nQCETB10_E_TP_INDC_PARE;
	}

	public String getNQCETB10_E_TX_PARE() {
		return NQCETB10_E_TX_PARE;
	}

	public void setNQCETB10_E_TX_PARE(String nQCETB10_E_TX_PARE) {
		NQCETB10_E_TX_PARE = nQCETB10_E_TX_PARE;
	}

	public String getNQCETB10_E_IN_NOTI_UPLD() {
		return NQCETB10_E_IN_NOTI_UPLD;
	}

	public void setNQCETB10_E_IN_NOTI_UPLD(String nQCETB10_E_IN_NOTI_UPLD) {
		NQCETB10_E_IN_NOTI_UPLD = nQCETB10_E_IN_NOTI_UPLD;
	}
}