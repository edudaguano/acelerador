package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE7035LegadoResponse {
	
// -*-NQCE7035
//     01          NQCE7035-COMMAREA.                                   
	@FixedLenghtField(position = /*1,*/275, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7035_PROG_CALLED;//         05      NQCE7035-PROG-CALLED        PIC X(08).               

	@FixedLenghtField(position = /*1,*/276, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7035_NOMEDATS;//         05      NQCE7035-NOMEDATS           PIC X(10).               

	@FixedLenghtField(position = /*1,*/277, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_COMMAREA_LEN;//         05      NQCE7035-COMMAREA-LEN       PIC 9(07).               

	@FixedLenghtField(position = /*1,*/278, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7035_FUNCAO;//         05      NQCE7035-FUNCAO             PIC X(01).               

	@FixedLenghtField(position = /*1,*/279, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE1;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/280, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE2;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/281, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE3;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/282, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE4;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/283, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE5;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/284, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE6;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/285, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE7;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/286, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE8;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/287, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE9;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/288, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE10;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/289, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE11;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/290, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE12;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/291, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE13;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/292, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE14;//             10  NQCE7035-CODTABE            PIC 9(03).               

	@FixedLenghtField(position = /*1,*/293, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_CODTABE15;//             10  NQCE7035-CODTABE            PIC 9(03).               

//                                                                         
//     01          NQCE7035-SEND-AREA.                                  
//         05      NQCE7035-TS01.                                       
	@FixedLenghtField(position = /*1,*/294, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_TS01_COD_RETORNO;//             10  NQCE7035-TS01-COD-RETORNO   PIC 9(03).               

	@FixedLenghtField(position = /*1,*/295, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7035_TS01_DES_MENSAGEM;//             10  NQCE7035-TS01-DES-MENSAGEM  PIC X(80).               

//                                                                         
//         05      NQCE7035-TS02.                                       
	@FixedLenghtField(position = /*1,*/296, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_TS02_CODTABE;//             10  NQCE7035-TS02-CODTABE       PIC 9(03).               

	@FixedLenghtField(position = /*1,*/297, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7035_TS02_CODITEM;//             10  NQCE7035-TS02-CODITEM       PIC X(10).               

	@FixedLenghtField(position = /*1,*/298, lenght = 40, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7035_TS02_DESCTOT;//             10  NQCE7035-TS02-DESCTOT       PIC X(40).               

	@FixedLenghtField(position = /*1,*/299, lenght = 15, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7035_TS02_DESCRES;//             10  NQCE7035-TS02-DESCRES       PIC X(15).               

	@FixedLenghtField(position = /*1,*/300, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7035_TS02_STATUS;//             10  NQCE7035-TS02-STATUS        PIC X(01).               

	@FixedLenghtField(position = /*1,*/301, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCE7035_TS02_USERID;//             10  NQCE7035-TS02-USERID        PIC X(10).               

	@FixedLenghtField(position = /*1,*/302, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_TS02_DATAJUST;//             10  NQCE7035-TS02-DATAJUST      PIC 9(08).               

	@FixedLenghtField(position = /*1,*/303, lenght = 6, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCE7035_TS02_HORAJUST;//             10  NQCE7035-TS02-HORAJUST      PIC 9(06).               

	public NQCE7035LegadoResponse() { }
	public NQCE7035LegadoResponse(String nqce7035_prog_called, String nqce7035_nomedats, Long nqce7035_commarea_len, String nqce7035_funcao, Long nqce7035_codtabe1, Long nqce7035_codtabe2, Long nqce7035_codtabe3, Long nqce7035_codtabe4, Long nqce7035_codtabe5, Long nqce7035_codtabe6, Long nqce7035_codtabe7, Long nqce7035_codtabe8, Long nqce7035_codtabe9, Long nqce7035_codtabe10, Long nqce7035_codtabe11, Long nqce7035_codtabe12, Long nqce7035_codtabe13, Long nqce7035_codtabe14, Long nqce7035_codtabe15, Long nqce7035_ts01_cod_retorno, String nqce7035_ts01_des_mensagem, Long nqce7035_ts02_codtabe, String nqce7035_ts02_coditem, String nqce7035_ts02_desctot, String nqce7035_ts02_descres, String nqce7035_ts02_status, String nqce7035_ts02_userid, Long nqce7035_ts02_datajust, Long nqce7035_ts02_horajust) { 		this.NQCE7035_PROG_CALLED = nqce7035_prog_called;
		this.NQCE7035_NOMEDATS = nqce7035_nomedats;
		this.NQCE7035_COMMAREA_LEN = nqce7035_commarea_len;
		this.NQCE7035_FUNCAO = nqce7035_funcao;
		this.NQCE7035_CODTABE1 = nqce7035_codtabe1;
		this.NQCE7035_CODTABE2 = nqce7035_codtabe2;
		this.NQCE7035_CODTABE3 = nqce7035_codtabe3;
		this.NQCE7035_CODTABE4 = nqce7035_codtabe4;
		this.NQCE7035_CODTABE5 = nqce7035_codtabe5;
		this.NQCE7035_CODTABE6 = nqce7035_codtabe6;
		this.NQCE7035_CODTABE7 = nqce7035_codtabe7;
		this.NQCE7035_CODTABE8 = nqce7035_codtabe8;
		this.NQCE7035_CODTABE9 = nqce7035_codtabe9;
		this.NQCE7035_CODTABE10 = nqce7035_codtabe10;
		this.NQCE7035_CODTABE11 = nqce7035_codtabe11;
		this.NQCE7035_CODTABE12 = nqce7035_codtabe12;
		this.NQCE7035_CODTABE13 = nqce7035_codtabe13;
		this.NQCE7035_CODTABE14 = nqce7035_codtabe14;
		this.NQCE7035_CODTABE15 = nqce7035_codtabe15;
		this.NQCE7035_TS01_COD_RETORNO = nqce7035_ts01_cod_retorno;
		this.NQCE7035_TS01_DES_MENSAGEM = nqce7035_ts01_des_mensagem;
		this.NQCE7035_TS02_CODTABE = nqce7035_ts02_codtabe;
		this.NQCE7035_TS02_CODITEM = nqce7035_ts02_coditem;
		this.NQCE7035_TS02_DESCTOT = nqce7035_ts02_desctot;
		this.NQCE7035_TS02_DESCRES = nqce7035_ts02_descres;
		this.NQCE7035_TS02_STATUS = nqce7035_ts02_status;
		this.NQCE7035_TS02_USERID = nqce7035_ts02_userid;
		this.NQCE7035_TS02_DATAJUST = nqce7035_ts02_datajust;
		this.NQCE7035_TS02_HORAJUST = nqce7035_ts02_horajust; 
	}
	public String getNQCE7035_PROG_CALLED() { return this.NQCE7035_PROG_CALLED; }
	public String getNQCE7035_NOMEDATS() { return this.NQCE7035_NOMEDATS; }
	public Long getNQCE7035_COMMAREA_LEN() { return this.NQCE7035_COMMAREA_LEN; }
	public String getNQCE7035_FUNCAO() { return this.NQCE7035_FUNCAO; }
	public Long getNQCE7035_CODTABE1() { return this.NQCE7035_CODTABE1; }
	public Long getNQCE7035_CODTABE2() { return this.NQCE7035_CODTABE2; }
	public Long getNQCE7035_CODTABE3() { return this.NQCE7035_CODTABE3; }
	public Long getNQCE7035_CODTABE4() { return this.NQCE7035_CODTABE4; }
	public Long getNQCE7035_CODTABE5() { return this.NQCE7035_CODTABE5; }
	public Long getNQCE7035_CODTABE6() { return this.NQCE7035_CODTABE6; }
	public Long getNQCE7035_CODTABE7() { return this.NQCE7035_CODTABE7; }
	public Long getNQCE7035_CODTABE8() { return this.NQCE7035_CODTABE8; }
	public Long getNQCE7035_CODTABE9() { return this.NQCE7035_CODTABE9; }
	public Long getNQCE7035_CODTABE10() { return this.NQCE7035_CODTABE10; }
	public Long getNQCE7035_CODTABE11() { return this.NQCE7035_CODTABE11; }
	public Long getNQCE7035_CODTABE12() { return this.NQCE7035_CODTABE12; }
	public Long getNQCE7035_CODTABE13() { return this.NQCE7035_CODTABE13; }
	public Long getNQCE7035_CODTABE14() { return this.NQCE7035_CODTABE14; }
	public Long getNQCE7035_CODTABE15() { return this.NQCE7035_CODTABE15; }
	public Long getNQCE7035_TS01_COD_RETORNO() { return this.NQCE7035_TS01_COD_RETORNO; }
	public String getNQCE7035_TS01_DES_MENSAGEM() { return this.NQCE7035_TS01_DES_MENSAGEM; }
	public Long getNQCE7035_TS02_CODTABE() { return this.NQCE7035_TS02_CODTABE; }
	public String getNQCE7035_TS02_CODITEM() { return this.NQCE7035_TS02_CODITEM; }
	public String getNQCE7035_TS02_DESCTOT() { return this.NQCE7035_TS02_DESCTOT; }
	public String getNQCE7035_TS02_DESCRES() { return this.NQCE7035_TS02_DESCRES; }
	public String getNQCE7035_TS02_STATUS() { return this.NQCE7035_TS02_STATUS; }
	public String getNQCE7035_TS02_USERID() { return this.NQCE7035_TS02_USERID; }
	public Long getNQCE7035_TS02_DATAJUST() { return this.NQCE7035_TS02_DATAJUST; }
	public Long getNQCE7035_TS02_HORAJUST() { return this.NQCE7035_TS02_HORAJUST; }
	public void setNQCE7035_PROG_CALLED(String nqce7035_prog_called) { this.NQCE7035_PROG_CALLED = nqce7035_prog_called; }
	public void setNQCE7035_NOMEDATS(String nqce7035_nomedats) { this.NQCE7035_NOMEDATS = nqce7035_nomedats; }
	public void setNQCE7035_COMMAREA_LEN(Long nqce7035_commarea_len) { this.NQCE7035_COMMAREA_LEN = nqce7035_commarea_len; }
	public void setNQCE7035_FUNCAO(String nqce7035_funcao) { this.NQCE7035_FUNCAO = nqce7035_funcao; }
	public void setNQCE7035_CODTABE1(Long nqce7035_codtabe1) { this.NQCE7035_CODTABE1 = nqce7035_codtabe1; }
	public void setNQCE7035_CODTABE2(Long nqce7035_codtabe2) { this.NQCE7035_CODTABE2 = nqce7035_codtabe2; }
	public void setNQCE7035_CODTABE3(Long nqce7035_codtabe3) { this.NQCE7035_CODTABE3 = nqce7035_codtabe3; }
	public void setNQCE7035_CODTABE4(Long nqce7035_codtabe4) { this.NQCE7035_CODTABE4 = nqce7035_codtabe4; }
	public void setNQCE7035_CODTABE5(Long nqce7035_codtabe5) { this.NQCE7035_CODTABE5 = nqce7035_codtabe5; }
	public void setNQCE7035_CODTABE6(Long nqce7035_codtabe6) { this.NQCE7035_CODTABE6 = nqce7035_codtabe6; }
	public void setNQCE7035_CODTABE7(Long nqce7035_codtabe7) { this.NQCE7035_CODTABE7 = nqce7035_codtabe7; }
	public void setNQCE7035_CODTABE8(Long nqce7035_codtabe8) { this.NQCE7035_CODTABE8 = nqce7035_codtabe8; }
	public void setNQCE7035_CODTABE9(Long nqce7035_codtabe9) { this.NQCE7035_CODTABE9 = nqce7035_codtabe9; }
	public void setNQCE7035_CODTABE10(Long nqce7035_codtabe10) { this.NQCE7035_CODTABE10 = nqce7035_codtabe10; }
	public void setNQCE7035_CODTABE11(Long nqce7035_codtabe11) { this.NQCE7035_CODTABE11 = nqce7035_codtabe11; }
	public void setNQCE7035_CODTABE12(Long nqce7035_codtabe12) { this.NQCE7035_CODTABE12 = nqce7035_codtabe12; }
	public void setNQCE7035_CODTABE13(Long nqce7035_codtabe13) { this.NQCE7035_CODTABE13 = nqce7035_codtabe13; }
	public void setNQCE7035_CODTABE14(Long nqce7035_codtabe14) { this.NQCE7035_CODTABE14 = nqce7035_codtabe14; }
	public void setNQCE7035_CODTABE15(Long nqce7035_codtabe15) { this.NQCE7035_CODTABE15 = nqce7035_codtabe15; }
	public void setNQCE7035_TS01_COD_RETORNO(Long nqce7035_ts01_cod_retorno) { this.NQCE7035_TS01_COD_RETORNO = nqce7035_ts01_cod_retorno; }
	public void setNQCE7035_TS01_DES_MENSAGEM(String nqce7035_ts01_des_mensagem) { this.NQCE7035_TS01_DES_MENSAGEM = nqce7035_ts01_des_mensagem; }
	public void setNQCE7035_TS02_CODTABE(Long nqce7035_ts02_codtabe) { this.NQCE7035_TS02_CODTABE = nqce7035_ts02_codtabe; }
	public void setNQCE7035_TS02_CODITEM(String nqce7035_ts02_coditem) { this.NQCE7035_TS02_CODITEM = nqce7035_ts02_coditem; }
	public void setNQCE7035_TS02_DESCTOT(String nqce7035_ts02_desctot) { this.NQCE7035_TS02_DESCTOT = nqce7035_ts02_desctot; }
	public void setNQCE7035_TS02_DESCRES(String nqce7035_ts02_descres) { this.NQCE7035_TS02_DESCRES = nqce7035_ts02_descres; }
	public void setNQCE7035_TS02_STATUS(String nqce7035_ts02_status) { this.NQCE7035_TS02_STATUS = nqce7035_ts02_status; }
	public void setNQCE7035_TS02_USERID(String nqce7035_ts02_userid) { this.NQCE7035_TS02_USERID = nqce7035_ts02_userid; }
	public void setNQCE7035_TS02_DATAJUST(Long nqce7035_ts02_datajust) { this.NQCE7035_TS02_DATAJUST = nqce7035_ts02_datajust; }
	public void setNQCE7035_TS02_HORAJUST(Long nqce7035_ts02_horajust) { this.NQCE7035_TS02_HORAJUST = nqce7035_ts02_horajust; }
}