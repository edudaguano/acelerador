package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB22AreaDados")
public class NQCETB22AreaDados {

	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*
	//
	//01     NQCETB22-SAIDA.                                           
	
	@PsFieldString(name= "NQCETB22_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_CD_BANC_CLIE;//          05   NQCETB22-S-CD-BANC-CLIE       PIC  X(004).                
	
	//*       CODIGO DO BANCO                                           
	//
	@PsFieldString(name= "NQCETB22_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_CD_CLIE;//          05   NQCETB22-S-CD-CLIE            PIC  X(008).                
	
	//*       CODIGO DO CLIENTE                                         
	//
	@PsFieldString(name= "NQCETB22_S_DT_MOVI", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_DT_MOVI;//          05   NQCETB22-S-DT-MOVI            PIC  X(010).                
	
	//*       DATA DO MOVIMENTO                                         
	//
	@PsFieldString(name= "NQCETB22_S_NR_CNTR", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_NR_CNTR;//          05   NQCETB22-S-NR-CNTR            PIC  X(020).                
	
	//*       NUMERO DO CONTRATO                                        
	//
	@PsFieldNumber(name= "NQCETB22_S_NR_COTA", decimal= 0, length= 9, signed= true, defaultValue="0")
	private Long NQCETB22_S_NR_COTA;//          05   NQCETB22-S-NR-COTA            PIC S9(009).                
	
	//*       NUMERO DE COTAS                                           
	//
	@PsFieldString(name= "NQCETB22_S_DT_FORZ", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_DT_FORZ;//          05   NQCETB22-S-DT-FORZ            PIC  X(010).                
	
	//*       DATA DA FORMALIZACAO                                      
	//
	@PsFieldString(name= "NQCETB22_S_DT_INIC_VIGE", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_DT_INIC_VIGE;//          05   NQCETB22-S-DT-INIC-VIGE       PIC  X(010).                
	
	//*       DATA DE INICIO DA VIGENCIA                                
	//
	@PsFieldString(name= "NQCETB22_S_DT_FIM_VIGE", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_DT_FIM_VIGE;//          05   NQCETB22-S-DT-FIM-VIGE        PIC  X(010).                
	
	//*       DATA DE FIM DA VIGENCIA                                   
	//
	@PsFieldString(name= "NQCETB22_S_CD_COTA", length= 5, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_CD_COTA;//          05   NQCETB22-S-CD-COTA            PIC  X(005).                
	
	//*       CODIGO DA COTA                                            
	//
	@PsFieldNumber(name= "NQCETB22_S_VL_OPER", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB22_S_VL_OPER;//          05   NQCETB22-S-VL-OPER            PIC S9(015)V99.             
	
	//*       VALOR DO CONSORCIO                                        
	//
	@PsFieldNumber(name= "NQCETB22_S_VL_LNCE", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB22_S_VL_LNCE;//          05   NQCETB22-S-VL-LNCE            PIC S9(015)V99.             
	
	//*       VALOR DO LANCE                                            
	//
	@PsFieldString(name= "NQCETB22_S_DT_LNCE", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_DT_LNCE;//          05   NQCETB22-S-DT-LNCE            PIC  X(010).                
	
	//*       DATA DO LANCE                                             
	//
	@PsFieldString(name= "NQCETB22_S_TP_TRAN", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_TP_TRAN;//          05   NQCETB22-S-TP-TRAN            PIC  X(001).                
	
	//*       TIPO DE TRANSACAO                                         
	//
	@PsFieldString(name= "NQCETB22_S_CD_BANC_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_CD_BANC_CNTR;//          05   NQCETB22-S-CD-BANC-CNTR       PIC  X(004).                
	
	//*       CODIGO DO BANCO DO CONTRATO                               
	//
	@PsFieldString(name= "NQCETB22_S_CD_AGEN_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_CD_AGEN_CNTR;//          05   NQCETB22-S-CD-AGEN-CNTR       PIC  X(004).                
	
	//*       CODIGO DA AGENCIA DO CONTRATO                             
	//
	@PsFieldString(name= "NQCETB22_S_NR_CNTR_A", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_NR_CNTR_A;//          05   NQCETB22-S-NR-CNTR-A          PIC  X(020).                
	
	//*       NUMERO DO CONTRATO ALTAIR                                 
	//
	@PsFieldString(name= "NQCETB22_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_CD_PROD_ALTAIR;//          05   NQCETB22-S-CD-PROD-ALTAIR     PIC  X(002).                
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name= "NQCETB22_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_CD_SUBP_ALTAIR;//          05   NQCETB22-S-CD-SUBP-ALTAIR     PIC  X(004).                
	
	//*       CODIGO DO SUBPRODUTO                                      
	//
	@PsFieldString(name= "NQCETB22_S_CD_MOED", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_CD_MOED;//          05   NQCETB22-S-CD-MOED            PIC  X(003).                
	
	//*       CODIGO DA MOEDA                                           
	//
	@PsFieldNumber(name= "NQCETB22_S_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB22_S_NR_SEQU_OPER;//          05   NQCETB22-S-NR-SEQU-OPER       PIC  9(003).                
	
	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	@PsFieldString(name= "NQCETB22_S_CD_IDEF_OPER", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_CD_IDEF_OPER;//          05   NQCETB22-S-CD-IDEF-OPER       PIC  X(020).                
	
	//*       CODIGO DA IDENTIFICACAO DA OPERACAO                       
	//
	@PsFieldString(name= "NQCETB22_S_CD_SEGTO_OPER", length= 5, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_CD_SEGTO_OPER;//          05   NQCETB22-S-CD-SEGTO-OPER      PIC  X(005).                
	
	//*       CODIGO SEGMENTO DA OPERACAO                               
	//
	@PsFieldString(name= "NQCETB22_S_TP_FORM_PGTO_OPER", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_TP_FORM_PGTO_OPER;//           05  NQCETB22-S-TP-FORM-PGTO-OPER  PIC  X(001).                
	
	//*       FORMA DE PAGTO                                            
	//
	@PsFieldString(name= "NQCETB22_S_TP_EMP", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_TP_EMP;//          05   NQCETB22-S-TP-EMP             PIC  X(001).                
	
	//*       TIPO DE EMPRESA DO CONSORCIO                              
	//
	@PsFieldString(name= "NQCETB22_S_TP_LANC", length= 5, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_TP_LANC;//          05   NQCETB22-S-TP-LANC            PIC  X(005).                
	
	//*       TIPO DE LANCE                                             
	//
	@PsFieldString(name= "FILLER0", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String FILLER0;//          05   FILLER                        PIC  X(003).                
	
	//*       LIXO                                                      
	//
	@PsFieldString(name= "NQCETB22_S_NM_CLIE", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB22_S_NM_CLIE;//         05   NQCETB22-S-NM-CLIE            PIC  X(040).                

	public String getNQCETB22_S_CD_BANC_CLIE() {
		return NQCETB22_S_CD_BANC_CLIE;
	}

	public void setNQCETB22_S_CD_BANC_CLIE(String nQCETB22_S_CD_BANC_CLIE) {
		NQCETB22_S_CD_BANC_CLIE = nQCETB22_S_CD_BANC_CLIE;
	}

	public String getNQCETB22_S_CD_CLIE() {
		return NQCETB22_S_CD_CLIE;
	}

	public void setNQCETB22_S_CD_CLIE(String nQCETB22_S_CD_CLIE) {
		NQCETB22_S_CD_CLIE = nQCETB22_S_CD_CLIE;
	}

	public String getNQCETB22_S_DT_MOVI() {
		return NQCETB22_S_DT_MOVI;
	}

	public void setNQCETB22_S_DT_MOVI(String nQCETB22_S_DT_MOVI) {
		NQCETB22_S_DT_MOVI = nQCETB22_S_DT_MOVI;
	}

	public String getNQCETB22_S_NR_CNTR() {
		return NQCETB22_S_NR_CNTR;
	}

	public void setNQCETB22_S_NR_CNTR(String nQCETB22_S_NR_CNTR) {
		NQCETB22_S_NR_CNTR = nQCETB22_S_NR_CNTR;
	}

	public Long getNQCETB22_S_NR_COTA() {
		return NQCETB22_S_NR_COTA;
	}

	public void setNQCETB22_S_NR_COTA(Long nQCETB22_S_NR_COTA) {
		NQCETB22_S_NR_COTA = nQCETB22_S_NR_COTA;
	}

	public String getNQCETB22_S_DT_FORZ() {
		return NQCETB22_S_DT_FORZ;
	}

	public void setNQCETB22_S_DT_FORZ(String nQCETB22_S_DT_FORZ) {
		NQCETB22_S_DT_FORZ = nQCETB22_S_DT_FORZ;
	}

	public String getNQCETB22_S_DT_INIC_VIGE() {
		return NQCETB22_S_DT_INIC_VIGE;
	}

	public void setNQCETB22_S_DT_INIC_VIGE(String nQCETB22_S_DT_INIC_VIGE) {
		NQCETB22_S_DT_INIC_VIGE = nQCETB22_S_DT_INIC_VIGE;
	}

	public String getNQCETB22_S_DT_FIM_VIGE() {
		return NQCETB22_S_DT_FIM_VIGE;
	}

	public void setNQCETB22_S_DT_FIM_VIGE(String nQCETB22_S_DT_FIM_VIGE) {
		NQCETB22_S_DT_FIM_VIGE = nQCETB22_S_DT_FIM_VIGE;
	}

	public String getNQCETB22_S_CD_COTA() {
		return NQCETB22_S_CD_COTA;
	}

	public void setNQCETB22_S_CD_COTA(String nQCETB22_S_CD_COTA) {
		NQCETB22_S_CD_COTA = nQCETB22_S_CD_COTA;
	}

	public Double getNQCETB22_S_VL_OPER() {
		return NQCETB22_S_VL_OPER;
	}

	public void setNQCETB22_S_VL_OPER(Double nQCETB22_S_VL_OPER) {
		NQCETB22_S_VL_OPER = nQCETB22_S_VL_OPER;
	}

	public Double getNQCETB22_S_VL_LNCE() {
		return NQCETB22_S_VL_LNCE;
	}

	public void setNQCETB22_S_VL_LNCE(Double nQCETB22_S_VL_LNCE) {
		NQCETB22_S_VL_LNCE = nQCETB22_S_VL_LNCE;
	}

	public String getNQCETB22_S_DT_LNCE() {
		return NQCETB22_S_DT_LNCE;
	}

	public void setNQCETB22_S_DT_LNCE(String nQCETB22_S_DT_LNCE) {
		NQCETB22_S_DT_LNCE = nQCETB22_S_DT_LNCE;
	}

	public String getNQCETB22_S_TP_TRAN() {
		return NQCETB22_S_TP_TRAN;
	}

	public void setNQCETB22_S_TP_TRAN(String nQCETB22_S_TP_TRAN) {
		NQCETB22_S_TP_TRAN = nQCETB22_S_TP_TRAN;
	}

	public String getNQCETB22_S_CD_BANC_CNTR() {
		return NQCETB22_S_CD_BANC_CNTR;
	}

	public void setNQCETB22_S_CD_BANC_CNTR(String nQCETB22_S_CD_BANC_CNTR) {
		NQCETB22_S_CD_BANC_CNTR = nQCETB22_S_CD_BANC_CNTR;
	}

	public String getNQCETB22_S_CD_AGEN_CNTR() {
		return NQCETB22_S_CD_AGEN_CNTR;
	}

	public void setNQCETB22_S_CD_AGEN_CNTR(String nQCETB22_S_CD_AGEN_CNTR) {
		NQCETB22_S_CD_AGEN_CNTR = nQCETB22_S_CD_AGEN_CNTR;
	}

	public String getNQCETB22_S_NR_CNTR_A() {
		return NQCETB22_S_NR_CNTR_A;
	}

	public void setNQCETB22_S_NR_CNTR_A(String nQCETB22_S_NR_CNTR_A) {
		NQCETB22_S_NR_CNTR_A = nQCETB22_S_NR_CNTR_A;
	}

	public String getNQCETB22_S_CD_PROD_ALTAIR() {
		return NQCETB22_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB22_S_CD_PROD_ALTAIR(String nQCETB22_S_CD_PROD_ALTAIR) {
		NQCETB22_S_CD_PROD_ALTAIR = nQCETB22_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB22_S_CD_SUBP_ALTAIR() {
		return NQCETB22_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB22_S_CD_SUBP_ALTAIR(String nQCETB22_S_CD_SUBP_ALTAIR) {
		NQCETB22_S_CD_SUBP_ALTAIR = nQCETB22_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB22_S_CD_MOED() {
		return NQCETB22_S_CD_MOED;
	}

	public void setNQCETB22_S_CD_MOED(String nQCETB22_S_CD_MOED) {
		NQCETB22_S_CD_MOED = nQCETB22_S_CD_MOED;
	}

	public Long getNQCETB22_S_NR_SEQU_OPER() {
		return NQCETB22_S_NR_SEQU_OPER;
	}

	public void setNQCETB22_S_NR_SEQU_OPER(Long nQCETB22_S_NR_SEQU_OPER) {
		NQCETB22_S_NR_SEQU_OPER = nQCETB22_S_NR_SEQU_OPER;
	}

	public String getNQCETB22_S_CD_IDEF_OPER() {
		return NQCETB22_S_CD_IDEF_OPER;
	}

	public void setNQCETB22_S_CD_IDEF_OPER(String nQCETB22_S_CD_IDEF_OPER) {
		NQCETB22_S_CD_IDEF_OPER = nQCETB22_S_CD_IDEF_OPER;
	}

	public String getNQCETB22_S_CD_SEGTO_OPER() {
		return NQCETB22_S_CD_SEGTO_OPER;
	}

	public void setNQCETB22_S_CD_SEGTO_OPER(String nQCETB22_S_CD_SEGTO_OPER) {
		NQCETB22_S_CD_SEGTO_OPER = nQCETB22_S_CD_SEGTO_OPER;
	}

	public String getNQCETB22_S_TP_FORM_PGTO_OPER() {
		return NQCETB22_S_TP_FORM_PGTO_OPER;
	}

	public void setNQCETB22_S_TP_FORM_PGTO_OPER(String nQCETB22_S_TP_FORM_PGTO_OPER) {
		NQCETB22_S_TP_FORM_PGTO_OPER = nQCETB22_S_TP_FORM_PGTO_OPER;
	}

	public String getNQCETB22_S_TP_EMP() {
		return NQCETB22_S_TP_EMP;
	}

	public void setNQCETB22_S_TP_EMP(String nQCETB22_S_TP_EMP) {
		NQCETB22_S_TP_EMP = nQCETB22_S_TP_EMP;
	}

	public String getNQCETB22_S_TP_LANC() {
		return NQCETB22_S_TP_LANC;
	}

	public void setNQCETB22_S_TP_LANC(String nQCETB22_S_TP_LANC) {
		NQCETB22_S_TP_LANC = nQCETB22_S_TP_LANC;
	}

	public String getFILLER0() {
		return FILLER0;
	}

	public void setFILLER0(String fILLER0) {
		FILLER0 = fILLER0;
	}

	public String getNQCETB22_S_NM_CLIE() {
		return NQCETB22_S_NM_CLIE;
	}

	public void setNQCETB22_S_NM_CLIE(String nQCETB22_S_NM_CLIE) {
		NQCETB22_S_NM_CLIE = nQCETB22_S_NM_CLIE;
	}
}