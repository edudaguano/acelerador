package com.altec.bsbr.app.jab.nq.dao;

import com.altec.bsbr.fw.BusinessException;

public interface ListasDao {
	public String listarLista(String strCodSist, String strCodUser) throws BusinessException;

	public String consultarLista(String strCodSist, String strCodList, String strCodUser) throws BusinessException;

	public String incluirLista(String strCodSist, String strCodCamp, String strDsList, String strListAtiv,
			String strCodUser) throws BusinessException;

	public String alterarLista(String strCodSist, String strCodList, String strCodCamp, String strDsList,
			String strListAtiv, String strCodUser) throws BusinessException;

	public String excluirLista(String strCodSist, String strCodList, String strCodUser) throws BusinessException;

	public String inicializarinputArea(String tNQ_NQAT2003_NQCETB03_ENTRADA);

	public String fnAddCaracter(String Vlr, String Tp, String Tam);
}
