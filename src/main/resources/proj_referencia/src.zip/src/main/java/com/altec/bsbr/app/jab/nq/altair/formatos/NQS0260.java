package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0260")
public class NQS0260 {
@PsFieldString(name="TPDOCPA", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPDOCPA;
@PsFieldString(name="NUDOCPA", length=15, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUDOCPA;
@PsFieldString(name="TPDOCTO", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPDOCTO;
@PsFieldString(name="NUDOCTO", length=15, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUDOCTO;
@PsFieldString(name="NOSOCIO", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOSOCIO;
@PsFieldString(name="NOCARGO", length=30, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOCARGO;

public String getTPDOCPA() {
 return TPDOCPA;
}
public void setTPDOCPA(String TPDOCPA) {
 this.TPDOCPA = TPDOCPA;
}

public String getNUDOCPA() {
 return NUDOCPA;
}
public void setNUDOCPA(String NUDOCPA) {
 this.NUDOCPA = NUDOCPA;
}

public String getTPDOCTO() {
 return TPDOCTO;
}
public void setTPDOCTO(String TPDOCTO) {
 this.TPDOCTO = TPDOCTO;
}

public String getNUDOCTO() {
 return NUDOCTO;
}
public void setNUDOCTO(String NUDOCTO) {
 this.NUDOCTO = NUDOCTO;
}

public String getNOSOCIO() {
 return NOSOCIO;
}
public void setNOSOCIO(String NOSOCIO) {
 this.NOSOCIO = NOSOCIO;
}

public String getNOCARGO() {
 return NOCARGO;
}
public void setNOCARGO(String NOCARGO) {
 this.NOCARGO = NOCARGO;
}


}
