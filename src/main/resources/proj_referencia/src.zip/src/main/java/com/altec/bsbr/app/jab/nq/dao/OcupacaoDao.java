package com.altec.bsbr.app.jab.nq.dao;

public interface OcupacaoDao {
	
	public String consOcupCadastradas(String intBanco, String intPeriodicidade);
	
	public String recuperaDados(String intOcupacao);
	
	public String incluirOcupacao(String intBanco, String intPeriod, String intCodOcup, String strDescOcup, /*CStr(Mid(strDescOcup,1,25))*/ String strUserId); 
	
	public String consultarBancoProdPeriod();
	
	public String exclusaoOcupacao(String intBanco, String intPeriod, String intCodOcup, String strUsuario); 
		   
}
