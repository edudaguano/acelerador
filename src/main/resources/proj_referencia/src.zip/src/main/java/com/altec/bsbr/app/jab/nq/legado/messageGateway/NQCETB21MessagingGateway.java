package com.altec.bsbr.app.jab.nq.legado.messageGateway;

import java.util.List;

import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB21LegadoRequest;
import com.altec.bsbr.fw.jms.legado.LegadoException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;

public interface NQCETB21MessagingGateway {
	
	LegadoResult sendMessageLegado(NQCETB21LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageMultiLegado(NQCETB21LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageListLegado(List<NQCETB21LegadoRequest> arg0) throws LegadoException;

}