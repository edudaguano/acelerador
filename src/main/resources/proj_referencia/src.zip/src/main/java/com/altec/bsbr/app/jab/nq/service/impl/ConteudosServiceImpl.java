package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.ConteudosDao;
import com.altec.bsbr.app.jab.nq.service.ConteudosService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class ConteudosServiceImpl implements ConteudosService {
	private final Logger LOGGER = LoggerFactory.getLogger(ConteudosServiceImpl.class);
	
	@Autowired
	private ConteudosDao conteudos;

	public String listarConteudo(String strCodSist, String strCodList, String strCodUser) throws BusinessException{
		return conteudos.listarConteudo(strCodSist, strCodList, strCodUser);
	}

	public String consultarConteudo(String strCodSist, String strCodList, String strCodCntd, String strCodUser) throws BusinessException{
		return conteudos.consultarConteudo(strCodSist, strCodList, strCodCntd, strCodUser);
	}

	public String incluirConteudo(String strCodSist, String strCodList, String strTxtCntd, String strDescCntd,
			String strDtHr, String strAtivo, String strCodUser) throws BusinessException{
		return conteudos.incluirConteudo(strCodSist, strCodList, strTxtCntd, strDescCntd, strDtHr, strAtivo, strCodUser);
	}

	public String alterarConteudo(String strCodSist, String strCodList, String strCodCntd, String strTxtCntd,
			String strDescCntd, String strDtHr, String strAtivo, String strCodUser) throws BusinessException{
		return conteudos.alterarConteudo(strCodSist, strCodList, strCodCntd, strTxtCntd, strDescCntd, strDtHr, strAtivo, strCodUser);
	}

	public String excluirConteudo(String strCodSist, String strCodList, String strCodCntd, String strCodUser) throws BusinessException{
		return conteudos.excluirConteudo(strCodSist, strCodList, strCodCntd, strCodUser);
	}

	public String inicializarinputArea(String tNQ_NQAT2004_NQCETB04_ENTRADA) throws BusinessException{
		return conteudos.inicializarinputArea(tNQ_NQAT2004_NQCETB04_ENTRADA);
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws BusinessException{
		return conteudos.fnAddCaracter(Vlr, Tp, Tam);
	}
	
}
