package com.altec.bsbr.app.jab.nq.legado.messageGateway;

import java.util.List;

import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB04LegadoRequest;
import com.altec.bsbr.fw.jms.legado.LegadoException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;

public interface NQCETB04MessagingGateway {
	
	LegadoResult sendMessageLegado(NQCETB04LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageMultiLegado(NQCETB04LegadoRequest arg0) throws LegadoException;

	LegadoResult sendMessageListLegado(List<NQCETB04LegadoRequest> arg0) throws LegadoException;

}