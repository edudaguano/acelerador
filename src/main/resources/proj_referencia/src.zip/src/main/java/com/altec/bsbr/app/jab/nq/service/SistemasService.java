package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface SistemasService {
	public String listarSistema(String strCodUser) throws BusinessException;

	public String consultarSistema(String strCodSist, String strCodUser) throws BusinessException;

	public String incluirSistema(String strCodSist, String strSigla, String strNmFuncao, String strDesc,
			String strAtivo, String strCodUser) throws BusinessException;

	public String alterarSistema(String strCodSist, String strSigla, String strNmFuncao, String strDesc,
			String strAtivo, String strCodUser) throws BusinessException;

	public String excluirSistema(String strCodSist, String strCodUser) throws BusinessException;

	public String inicializarinputArea(String tNQ_NQAT2001_NQCETB01_ENTRADA) throws BusinessException;

	public String fnAddCaracter(String vlr, String tp, String tam) throws BusinessException;
}
