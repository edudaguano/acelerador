package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.OperacoesACDao;
import com.altec.bsbr.app.jab.nq.service.OperacoesACService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class OperacoesACServiceImpl implements OperacoesACService {
	private final Logger LOGGER = LoggerFactory.getLogger(OperacoesACServiceImpl.class);
	
	@Autowired
	private OperacoesACDao operacoesACDao;
	
	public String operacoesGC(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException{
		return operacoesACDao.operacoesGC(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumContrato, strNumOper, strTpOperacao, strCodUser);
	}

	public String operacoesMP(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCartaoCred, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException{
		return operacoesACDao.operacoesMP(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumCartaoCred, strNumOper, strTpOperacao, strCodUser);
	}

	public String operacoesUG(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strDtFormaliz, String strNumContrato, String strNumOper, String strTpOperacao,
			String strCodUser) throws BusinessException{
		return operacoesACDao.operacoesUG(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strDtFormaliz, strNumContrato, strNumOper, strTpOperacao, strCodUser);
	}

	public String operacoesLI(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strDtFormaliz, String strNumContrato, String strNumOper, String strCNPJLoji,
			String strTpOperacao, String strCodUser) throws BusinessException{
		return operacoesACDao.operacoesLI(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strDtFormaliz, strNumContrato, strNumOper, strCNPJLoji, strTpOperacao, strCodUser);
	}

	public String operacoesKM(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumTitulo, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException{
		return operacoesACDao.operacoesKM(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumTitulo, strNumOper, strTpOperacao, strCodUser);
	}

	public String operacoesOX(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumProposta, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException{
		return operacoesACDao.operacoesOX(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumProposta, strNumOper, strTpOperacao, strCodUser);
	}

	public String operacoesEZ(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumBoleto, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException{
		return operacoesACDao.operacoesEZ(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumBoleto, strNumOper, strTpOperacao, strCodUser);
	}

	public String operacoesAR(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumOperacao, String strTpOperacao, String strCodUser) throws BusinessException{
		return operacoesACDao.operacoesAR(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumOperacao, strTpOperacao, strCodUser);
	}

	public String operacoesGR(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException{
		return operacoesACDao.operacoesGR(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumContrato, strNumOper, strTpOperacao, strCodUser);
	}

	public String operacoesYZ(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException{
		return operacoesACDao.operacoesYZ(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumContrato, strNumOper, strTpOperacao, strCodUser);
	}

	public String operacoesVC(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCtaDebito, String strNumProposta, String strNumApolice, String strNumOper,
			String strTpOperacao, String strCodUser) throws BusinessException{
		return operacoesACDao.operacoesVC(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumCtaDebito, strNumProposta, strNumApolice, strNumOper, strTpOperacao, strCodUser);
	}

	public String operacoesIY(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCtaDebito, String strNumProposta, String strNumApolice, String strNumOper,
			String strTpOperacao, String strCodUser) throws BusinessException{
		return operacoesACDao.operacoesIY(strCodSist, strBanco, strCodCliente, strDtInicio, strDtFinal, strNumCtaDebito, strNumProposta, strNumApolice, strNumOper, strTpOperacao, strCodUser);
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws BusinessException{
		return operacoesACDao.fnAddCaracter(Vlr, Tp, Tam);
	}

	public String fnAddCaracterCliente(String Vlr, String Tp, String Tam) throws BusinessException{
		return operacoesACDao.fnAddCaracterCliente(Vlr, Tp, Tam);
	}

	public String dataAlta(String dtBaixa) throws BusinessException{
		return operacoesACDao.dataAlta(dtBaixa);
	}

}
