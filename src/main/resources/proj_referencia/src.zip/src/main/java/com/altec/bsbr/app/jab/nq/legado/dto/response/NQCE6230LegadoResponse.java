package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE6230LegadoResponse {
	/*
// -*-NQCE6230
//         01      RECEIVE-COMMAREA.                                        
	@FixedLenghtField(position = 958, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_PGM_CHAMADA;//                 03  COMM-PGM-CHAMADA      PIC  X(008).                   

	@FixedLenghtField(position = 959, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOMEDATS;//                 03  COMM-NOMEDATS         PIC  X(010).                   

	@FixedLenghtField(position = 960, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_TAM_COMM;//                 03  COMM-TAM-COMM         PIC  9(007).                   

	@FixedLenghtField(position = 961, lenght = 9, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_MATRICULA;//                 03  COMM-MATRICULA        PIC  9(009).                   

	@FixedLenghtField(position = 962, lenght = 10, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CCLI;//                 03  COMM-CCLI             PIC  9(010).                   

	@FixedLenghtField(position = 963, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_TIPO;//                 03  COMM-TIPO             PIC  X(001).                   

//         01      SEND-AREA.                                               
	@FixedLenghtField(position = 964, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN;//                 03  TS01-MENS-LEN         PIC S9(004) COMP VALUE +83.    

//                 03  TS01-AREA-MENSAGEM.                                  
	@FixedLenghtField(position = 965, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO;//                     05  TS01-RETORNO      PIC  9(003) VALUE ZEROS.       

	@FixedLenghtField(position = 966, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM;//                     05  TS01-MENSAGEM     PIC  X(080) VALUE SPACES.                                                                      

	@FixedLenghtField(position = 967, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_MENS_LEN;//                 03  TS02-MENS-LEN         PIC S9(004) COMP VALUE +270.   

//                 03  TS02-AREA-NQCE6230.                                  
	@FixedLenghtField(position = 968, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NCLI;//                     05 TS02-NCLI          PIC  X(050).                   

	@FixedLenghtField(position = 969, lenght = 20, paddingAlign = Align.LEFT, paddingChar = '0')
	private String TS02_CPFCNPJ;//                     05 TS02-CPFCNPJ       PIC  X(020).                   

	@FixedLenghtField(position = 970, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_TPPESSOA;//                     05 TS02-TPPESSOA      PIC  X(001).                   

	@FixedLenghtField(position = 971, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_DATA_VIS;//                     05 TS02-DATA-VIS      PIC  9(008).                   

	@FixedLenghtField(position = 972, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_DATA_REF;//                     05 TS02-DATA-REF      PIC  9(008).                   

	@FixedLenghtField(position = 973, lenght = 15, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_VLR_RENFAT;//                     05 TS02-VLR-RENFAT    PIC  X(015).                   

	@FixedLenghtField(position = 974, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_RAMO;//                     05 TS02-RAMO          PIC  X(050).                   

	@FixedLenghtField(position = 975, lenght = 15, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_DESCART;//                     05 TS02-DESCART       PIC  X(015).                   

	@FixedLenghtField(position = 976, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_CINSTIT;//                     05 TS02-CINSTIT       PIC  9(003).                   

	@FixedLenghtField(position = 977, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_CODAGENC;//                     05 TS02-CODAGENC      PIC  9(004).                   

	@FixedLenghtField(position = 978, lenght = 4, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_CPROD;//                     05 TS02-CPROD         PIC  X(004).                   

	@FixedLenghtField(position = 979, lenght = 10, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_NUMCONTA;//                     05 TS02-NUMCONTA      PIC  9(010).                   

	@FixedLenghtField(position = 980, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_DATAMOVI;//                     05 TS02-DATAMOVI      PIC  9(008).                   

	@FixedLenghtField(position = 981, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_CSEQUE;//                     05 TS02-CSEQUE        PIC  9(003).                   

	@FixedLenghtField(position = 982, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_SITMOVIM;//                     05 TS02-SITMOVIM      PIC  X(001).                   

	@FixedLenghtField(position = 983, lenght = 15, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_VALORLAN;//                     05 TS02-VALORLAN      PIC  X(015).                   

	@FixedLenghtField(position = 984, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_QTDELAN;//                     05 TS02-QTDELAN       PIC  9(003).                   

	@FixedLenghtField(position = 985, lenght = 3, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_TIPO;//                     05 TS02-TIPO          PIC  X(003).                   

	@FixedLenghtField(position = 986, lenght = 6, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_ANOMESREF;//                     05 TS02-ANOMESREF     PIC  9(006).                   

	@FixedLenghtField(position = 987, lenght = 15, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_VALORMES;//                     05 TS02-VALORMES      PIC  X(015).                   

	@FixedLenghtField(position = 988, lenght = 5, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_QTDEMES;//                     05 TS02-QTDEMES       PIC  9(005).                   

	@FixedLenghtField(position = 989, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_DTINIC_REL;//                     05 TS02-DTINIC-REL    PIC  9(008).                   

	@FixedLenghtField(position = 990, lenght = 15, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_GERENTE;//                     05 TS02-GERENTE       PIC  X(015).                   

	public NQCE6230LegadoResponse() { }
	public NQCE6230LegadoResponse(String comm_pgm_chamada, String comm_nomedats, Long comm_tam_comm, Long comm_matricula, Long comm_ccli, String comm_tipo, String ts02_ncli, String ts02_cpfcnpj, String ts02_tppessoa, Long ts02_data_vis, Long ts02_data_ref, String ts02_vlr_renfat, String ts02_ramo, String ts02_descart, Long ts02_cinstit, Long ts02_codagenc, String ts02_cprod, Long ts02_numconta, Long ts02_datamovi, Long ts02_cseque, String ts02_sitmovim, String ts02_valorlan, Long ts02_qtdelan, String ts02_tipo, Long ts02_anomesref, String ts02_valormes, Long ts02_qtdemes, Long ts02_dtinic_rel, String ts02_gerente) { 		this.COMM_PGM_CHAMADA = comm_pgm_chamada;
		this.COMM_NOMEDATS = comm_nomedats;
		this.COMM_TAM_COMM = comm_tam_comm;
		this.COMM_MATRICULA = comm_matricula;
		this.COMM_CCLI = comm_ccli;
		this.COMM_TIPO = comm_tipo;
		this.TS01_MENS_LEN = +83;
		this.TS01_RETORNO = ZEROS;
		this.TS01_MENSAGEM = SPACES;
		this.TS02_MENS_LEN = +270;
		this.TS02_NCLI = ts02_ncli;
		this.TS02_CPFCNPJ = ts02_cpfcnpj;
		this.TS02_TPPESSOA = ts02_tppessoa;
		this.TS02_DATA_VIS = ts02_data_vis;
		this.TS02_DATA_REF = ts02_data_ref;
		this.TS02_VLR_RENFAT = ts02_vlr_renfat;
		this.TS02_RAMO = ts02_ramo;
		this.TS02_DESCART = ts02_descart;
		this.TS02_CINSTIT = ts02_cinstit;
		this.TS02_CODAGENC = ts02_codagenc;
		this.TS02_CPROD = ts02_cprod;
		this.TS02_NUMCONTA = ts02_numconta;
		this.TS02_DATAMOVI = ts02_datamovi;
		this.TS02_CSEQUE = ts02_cseque;
		this.TS02_SITMOVIM = ts02_sitmovim;
		this.TS02_VALORLAN = ts02_valorlan;
		this.TS02_QTDELAN = ts02_qtdelan;
		this.TS02_TIPO = ts02_tipo;
		this.TS02_ANOMESREF = ts02_anomesref;
		this.TS02_VALORMES = ts02_valormes;
		this.TS02_QTDEMES = ts02_qtdemes;
		this.TS02_DTINIC_REL = ts02_dtinic_rel;
		this.TS02_GERENTE = ts02_gerente; 
	}
	public String getCOMM_PGM_CHAMADA() { return this.COMM_PGM_CHAMADA; }
	public String getCOMM_NOMEDATS() { return this.COMM_NOMEDATS; }
	public Long getCOMM_TAM_COMM() { return this.COMM_TAM_COMM; }
	public Long getCOMM_MATRICULA() { return this.COMM_MATRICULA; }
	public Long getCOMM_CCLI() { return this.COMM_CCLI; }
	public String getCOMM_TIPO() { return this.COMM_TIPO; }
	public Long getTS01_MENS_LEN() { return this.TS01_MENS_LEN; }
	public Long getTS01_RETORNO() { return this.TS01_RETORNO; }
	public String getTS01_MENSAGEM() { return this.TS01_MENSAGEM; }
	public Long getTS02_MENS_LEN() { return this.TS02_MENS_LEN; }
	public String getTS02_NCLI() { return this.TS02_NCLI; }
	public String getTS02_CPFCNPJ() { return this.TS02_CPFCNPJ; }
	public String getTS02_TPPESSOA() { return this.TS02_TPPESSOA; }
	public Long getTS02_DATA_VIS() { return this.TS02_DATA_VIS; }
	public Long getTS02_DATA_REF() { return this.TS02_DATA_REF; }
	public String getTS02_VLR_RENFAT() { return this.TS02_VLR_RENFAT; }
	public String getTS02_RAMO() { return this.TS02_RAMO; }
	public String getTS02_DESCART() { return this.TS02_DESCART; }
	public Long getTS02_CINSTIT() { return this.TS02_CINSTIT; }
	public Long getTS02_CODAGENC() { return this.TS02_CODAGENC; }
	public String getTS02_CPROD() { return this.TS02_CPROD; }
	public Long getTS02_NUMCONTA() { return this.TS02_NUMCONTA; }
	public Long getTS02_DATAMOVI() { return this.TS02_DATAMOVI; }
	public Long getTS02_CSEQUE() { return this.TS02_CSEQUE; }
	public String getTS02_SITMOVIM() { return this.TS02_SITMOVIM; }
	public String getTS02_VALORLAN() { return this.TS02_VALORLAN; }
	public Long getTS02_QTDELAN() { return this.TS02_QTDELAN; }
	public String getTS02_TIPO() { return this.TS02_TIPO; }
	public Long getTS02_ANOMESREF() { return this.TS02_ANOMESREF; }
	public String getTS02_VALORMES() { return this.TS02_VALORMES; }
	public Long getTS02_QTDEMES() { return this.TS02_QTDEMES; }
	public Long getTS02_DTINIC_REL() { return this.TS02_DTINIC_REL; }
	public String getTS02_GERENTE() { return this.TS02_GERENTE; }
	public void setCOMM_PGM_CHAMADA(String comm_pgm_chamada) { this.COMM_PGM_CHAMADA = comm_pgm_chamada; }
	public void setCOMM_NOMEDATS(String comm_nomedats) { this.COMM_NOMEDATS = comm_nomedats; }
	public void setCOMM_TAM_COMM(Long comm_tam_comm) { this.COMM_TAM_COMM = comm_tam_comm; }
	public void setCOMM_MATRICULA(Long comm_matricula) { this.COMM_MATRICULA = comm_matricula; }
	public void setCOMM_CCLI(Long comm_ccli) { this.COMM_CCLI = comm_ccli; }
	public void setCOMM_TIPO(String comm_tipo) { this.COMM_TIPO = comm_tipo; }
	public void setTS01_MENS_LEN(Long ts01_mens_len) { this.TS01_MENS_LEN = ts01_mens_len; }
	public void setTS01_RETORNO(Long ts01_retorno) { this.TS01_RETORNO = ts01_retorno; }
	public void setTS01_MENSAGEM(String ts01_mensagem) { this.TS01_MENSAGEM = ts01_mensagem; }
	public void setTS02_MENS_LEN(Long ts02_mens_len) { this.TS02_MENS_LEN = ts02_mens_len; }
	public void setTS02_NCLI(String ts02_ncli) { this.TS02_NCLI = ts02_ncli; }
	public void setTS02_CPFCNPJ(String ts02_cpfcnpj) { this.TS02_CPFCNPJ = ts02_cpfcnpj; }
	public void setTS02_TPPESSOA(String ts02_tppessoa) { this.TS02_TPPESSOA = ts02_tppessoa; }
	public void setTS02_DATA_VIS(Long ts02_data_vis) { this.TS02_DATA_VIS = ts02_data_vis; }
	public void setTS02_DATA_REF(Long ts02_data_ref) { this.TS02_DATA_REF = ts02_data_ref; }
	public void setTS02_VLR_RENFAT(String ts02_vlr_renfat) { this.TS02_VLR_RENFAT = ts02_vlr_renfat; }
	public void setTS02_RAMO(String ts02_ramo) { this.TS02_RAMO = ts02_ramo; }
	public void setTS02_DESCART(String ts02_descart) { this.TS02_DESCART = ts02_descart; }
	public void setTS02_CINSTIT(Long ts02_cinstit) { this.TS02_CINSTIT = ts02_cinstit; }
	public void setTS02_CODAGENC(Long ts02_codagenc) { this.TS02_CODAGENC = ts02_codagenc; }
	public void setTS02_CPROD(String ts02_cprod) { this.TS02_CPROD = ts02_cprod; }
	public void setTS02_NUMCONTA(Long ts02_numconta) { this.TS02_NUMCONTA = ts02_numconta; }
	public void setTS02_DATAMOVI(Long ts02_datamovi) { this.TS02_DATAMOVI = ts02_datamovi; }
	public void setTS02_CSEQUE(Long ts02_cseque) { this.TS02_CSEQUE = ts02_cseque; }
	public void setTS02_SITMOVIM(String ts02_sitmovim) { this.TS02_SITMOVIM = ts02_sitmovim; }
	public void setTS02_VALORLAN(String ts02_valorlan) { this.TS02_VALORLAN = ts02_valorlan; }
	public void setTS02_QTDELAN(Long ts02_qtdelan) { this.TS02_QTDELAN = ts02_qtdelan; }
	public void setTS02_TIPO(String ts02_tipo) { this.TS02_TIPO = ts02_tipo; }
	public void setTS02_ANOMESREF(Long ts02_anomesref) { this.TS02_ANOMESREF = ts02_anomesref; }
	public void setTS02_VALORMES(String ts02_valormes) { this.TS02_VALORMES = ts02_valormes; }
	public void setTS02_QTDEMES(Long ts02_qtdemes) { this.TS02_QTDEMES = ts02_qtdemes; }
	public void setTS02_DTINIC_REL(Long ts02_dtinic_rel) { this.TS02_DTINIC_REL = ts02_dtinic_rel; }
	public void setTS02_GERENTE(String ts02_gerente) { this.TS02_GERENTE = ts02_gerente; }
	*/
}