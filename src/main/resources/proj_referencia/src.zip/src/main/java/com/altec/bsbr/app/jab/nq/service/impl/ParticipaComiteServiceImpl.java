package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.ParticipaComiteDao;
import com.altec.bsbr.app.jab.nq.service.ParticipaComiteService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class ParticipaComiteServiceImpl implements ParticipaComiteService {
	private final Logger LOGGER = LoggerFactory.getLogger(ParticipaComiteServiceImpl.class);
	@Autowired
	private ParticipaComiteDao participaComite;

	public String versao() throws BusinessException {
		return participaComite.versao();
	}

	public String consultarMatricula(String strNUMATRI) throws BusinessException {
		return participaComite.consultarMatricula(strNUMATRI);
	}

	public String consultarParticipante(String strTPUORCM, String strCDUORCM, String strDTCOMIT)
			throws BusinessException {
		return participaComite.consultarParticipante(strTPUORCM, strCDUORCM, strDTCOMIT);
	}

	public String inserirParticipante(String strTPUNIOR, String strCDAGENC, String strDTCOMIT, String strNMMATR1,
			String strDSCARG1, String strNMMATR2, String strDSCARG2, String strNMMATR3, String strDSCARG3,
			String strNMMATR4, String strDSCARG4, String strNMMATR5, String strDSCARG5, String strNMMATR6,
			String strDSCARG6, String strNMMATR7, String strDSCARG7, String strNMMATR8, String strDSCARG8,
			String strNMMATR9, String strDSCARG9, String strNMMATR10, String strDSCARG10, String strCDUSRES)
			throws BusinessException {
		return participaComite.inserirParticipante(strTPUNIOR, strCDAGENC, strDTCOMIT, strNMMATR1, strDSCARG1,
				strNMMATR2, strDSCARG2, strNMMATR3, strDSCARG3, strNMMATR4, strDSCARG4, strNMMATR5, strDSCARG5,
				strNMMATR6, strDSCARG6, strNMMATR7, strDSCARG7, strNMMATR8, strDSCARG8, strNMMATR9, strDSCARG9,
				strNMMATR10, strDSCARG10, strCDUSRES);
	}
}
