package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0260")
public class NQE0260 {
@PsFieldString(name="PENUMPE", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String PENUMPE;

public String getPENUMPE() {
 return PENUMPE;
}
public void setPENUMPE(String PENUMPE) {
 this.PENUMPE = PENUMPE;
}


}
