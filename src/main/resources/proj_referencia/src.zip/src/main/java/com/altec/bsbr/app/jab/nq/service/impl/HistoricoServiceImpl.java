package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.HistoricoDao;
import com.altec.bsbr.app.jab.nq.service.HistoricoService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class HistoricoServiceImpl implements HistoricoService {
	private final Logger LOGGER = LoggerFactory.getLogger(HistoricoServiceImpl.class);
	@Autowired
	private HistoricoDao historico;

	@Override
	public String recuperaDadosAlt(String intConceito1, String intConceito2) throws BusinessException {
		return historico.recuperaDadosAlt(intConceito1, intConceito2);
	}

	@Override
	public String recuperaDadosInc(String intHistorico, String intAgrupamento, String intConceito1, String intConceito2)
			throws BusinessException {
		return historico.recuperaDadosInc(intHistorico, intAgrupamento, intConceito1, intConceito2);
	}

	@Override
	public String consultarLista(String intOpcao, String intBanco, String intProduto, String intPeriodicidade)
			throws BusinessException {
		return historico.consultarLista(intOpcao, intBanco, intProduto, intPeriodicidade);
	}

	@Override
	public String consultarBancoProdPeriod() throws BusinessException {
		return historico.consultarBancoProdPeriod();
	}

	@Override
	public String IncluirHistorico(String intOpcao, String intBanco, String intPeriodicidade, String intProduto,
			String intCodHist, String intHistorico, String strUsuario, String strDescricao, String strConceito1,
			String strConceito2) throws BusinessException {
		return historico.IncluirHistorico(intOpcao, intBanco, intPeriodicidade, intProduto, intCodHist, intHistorico, strUsuario, strDescricao, strConceito1, strConceito2);
	}

	@Override
	public String AlterarHistorico(String intOpcao, String intBanco, String intPeriodicidade, String intProduto,
			String intCodHist, String intHistorico, String strUsuario, String strDescricao, String strConceito1,
			String strConceito2) throws BusinessException {
		return historico.AlterarHistorico(intOpcao, intBanco, intPeriodicidade, intProduto, intCodHist, intHistorico, strUsuario, strDescricao, strConceito1, strConceito2);
	}

	@Override
	public String ExclusaoItem(String intOpcao, String intBanco, String intProduto, String intPeriodicidade,
			String intCodHist, String intHistorico, String strUsuario) throws BusinessException {
		return historico.ExclusaoItem(intOpcao, intBanco, intProduto, intPeriodicidade, intCodHist, intHistorico, strUsuario);
	}
}
