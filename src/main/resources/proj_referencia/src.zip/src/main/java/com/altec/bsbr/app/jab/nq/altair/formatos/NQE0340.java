package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0340")
public class NQE0340 {
@PsFieldString(name="COENTID", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COENTID;
@PsFieldString(name="TPDOCTO", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPDOCTO;
@PsFieldString(name="NUDOCTO", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUDOCTO;

public String getCOENTID() {
 return COENTID;
}
public void setCOENTID(String COENTID) {
 this.COENTID = COENTID;
}

public String getTPDOCTO() {
 return TPDOCTO;
}
public void setTPDOCTO(String TPDOCTO) {
 this.TPDOCTO = TPDOCTO;
}

public String getNUDOCTO() {
 return NUDOCTO;
}
public void setNUDOCTO(String NUDOCTO) {
 this.NUDOCTO = NUDOCTO;
}


}
