package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.RegrasACService;
import com.altec.bsbr.app.jab.nq.service.RegrasACWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class RegrasACEndPoint extends SpringBeanAutowiringSupport implements RegrasACWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(RegrasACEndPoint.class);

	@Autowired
	private RegrasACService regrasAC;

	@WebMethod
	public String consultarRegras(String strCodSist, String strPeriodo, String strSituacao, String strCodUser)
			throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = regrasAC.consultarRegras(strCodSist, strPeriodo, strSituacao, strCodUser);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirRegras(String strCodSist, String strAtivo, String strCodUser, String strPeriodo,
			String strRegra, String strProduto, String strSubProduto, String StrPEP, String strFunc,
			String strTpTransacao, String strQtdTransacao, String strPercRenda, String strVlTransacao)
			throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = regrasAC.incluirRegras(strCodSist, strAtivo, strCodUser, strPeriodo, strRegra, strProduto, strSubProduto, StrPEP, strFunc, strTpTransacao, strQtdTransacao, strPercRenda, strVlTransacao);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarRegras(String strCodSist, String strAtivo, String strCodUser, String strPeriodo,
			String strRegra, String strProduto, String strSubProduto, String StrPEP, String strFunc,
			String strTpTransacao, String strQtdTransacao, String strPercRenda, String strVlTransacao)
			throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = regrasAC.alterarRegras(strCodSist, strAtivo, strCodUser, strPeriodo, strRegra, strProduto, strSubProduto, StrPEP, strFunc, strTpTransacao, strQtdTransacao, strPercRenda, strVlTransacao);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String inicializarinputArea(String tNQ_NQAT2007_NQCETB07_Entrada) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = regrasAC.inicializarinputArea(tNQ_NQAT2007_NQCETB07_Entrada);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws WebServiceException{
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = regrasAC.fnAddCaracter(Vlr, Tp, Tam);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	
}
