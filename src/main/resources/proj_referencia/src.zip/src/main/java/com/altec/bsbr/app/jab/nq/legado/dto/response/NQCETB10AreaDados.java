package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name = "NQCETB10AreaDados")
public class NQCETB10AreaDados {

//*       INDICADOR DE NOFICACAO A UPLD                             
//
//*----------------------------------------------------------------*
//*       AREA DE SAIDA                                             
//*----------------------------------------------------------------*

	@PsFieldString(name = "NQCETB10_S_TP_INDC_PARE", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_S_TP_INDC_PARE;// 05 NQCETB10-S-TP-INDC-PARE PIC X(001).

//*       TIPO DE IDENTIFICACAO DO PARECER                          
//
	@PsFieldString(name = "NQCETB10_S_TX_PARE", length = 254, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_S_TX_PARE;// 05 NQCETB10-S-TX-PARE PIC X(254).

//*       TEXTO DO PARECER                                          
//
	@PsFieldString(name = "NQCETB10_S_DT_PARE", length = 10, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_S_DT_PARE;// 05 NQCETB10-S-DT-PARE PIC X(010).

//*       DATA DO PARECER                                           
//
	@PsFieldString(name = "NQCETB10_S_CD_USUA_ULTI_ALTR", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_S_CD_USUA_ULTI_ALTR;// 05 NQCETB10-S-CD-USUA-ULTI-ALTR PIC X(008).

//*       CODIGO DO USUARIO DA ULTIMA ALTERACAO                     
//
	@PsFieldString(name = "NQCETB10_S_DH_ULTI_ALTR", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_S_DH_ULTI_ALTR;// 05 NQCETB10-S-DH-ULTI-ALTR PIC X(026).

//*       DATA/HORA ULTIMA ALTERACAO                                
//
	@PsFieldString(name = "NQCETB10_S_IN_NOTI_UPLD", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB10_S_IN_NOTI_UPLD;// 05 NQCETB10-S-IN-NOTI-UPLD PIC X(001).

//*       INDICADOR DE NOFICACAO A UPLD                             
	
}