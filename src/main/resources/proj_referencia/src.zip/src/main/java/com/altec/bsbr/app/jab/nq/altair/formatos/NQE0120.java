package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0120")
public class NQE0120 {
@PsFieldString(name="COENTID", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COENTID;
@PsFieldString(name="COALERT", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALERT;
@PsFieldString(name="COAGENC", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COAGENC;
@PsFieldNumber(name="COUNIOR", length=7, defaultValue = "0" )
private Integer COUNIOR;
@PsFieldString(name="TPDOC", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPDOC;
@PsFieldString(name="NUDOC", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUDOC;
@PsFieldString(name="DTINICI", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTINICI;
@PsFieldString(name="DTFIM", length=10, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String DTFIM;
@PsFieldString(name="COSITUA", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COSITUA;
@PsFieldString(name="IDORDPA", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String IDORDPA;
@PsFieldNumber(name="TPCHM", length=1, defaultValue = "0" )
private Integer TPCHM;
@PsFieldString(name="COALNKM", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALNKM;

public String getCOENTID() {
 return COENTID;
}
public void setCOENTID(String COENTID) {
 this.COENTID = COENTID;
}

public String getCOALERT() {
 return COALERT;
}
public void setCOALERT(String COALERT) {
 this.COALERT = COALERT;
}

public String getCOAGENC() {
 return COAGENC;
}
public void setCOAGENC(String COAGENC) {
 this.COAGENC = COAGENC;
}
public Integer getCOUNIOR() {
 return COUNIOR;
}
public void setCOUNIOR(Integer cOUNIOR) {
COUNIOR = cOUNIOR;
}
public String getTPDOC() {
 return TPDOC;
}
public void setTPDOC(String TPDOC) {
 this.TPDOC = TPDOC;
}

public String getNUDOC() {
 return NUDOC;
}
public void setNUDOC(String NUDOC) {
 this.NUDOC = NUDOC;
}

public String getDTINICI() {
 return DTINICI;
}
public void setDTINICI(String DTINICI) {
 this.DTINICI = DTINICI;
}

public String getDTFIM() {
 return DTFIM;
}
public void setDTFIM(String DTFIM) {
 this.DTFIM = DTFIM;
}

public String getCOSITUA() {
 return COSITUA;
}
public void setCOSITUA(String COSITUA) {
 this.COSITUA = COSITUA;
}

public String getIDORDPA() {
 return IDORDPA;
}
public void setIDORDPA(String IDORDPA) {
 this.IDORDPA = IDORDPA;
}
public Integer getTPCHM() {
 return TPCHM;
}
public void setTPCHM(Integer tPCHM) {
TPCHM = tPCHM;
}
public String getCOALNKM() {
 return COALNKM;
}
public void setCOALNKM(String COALNKM) {
 this.COALNKM = COALNKM;
}


}
