package com.altec.bsbr.app.jab.nq.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0150;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0160;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0360;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0150;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0160;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0360;
import com.altec.bsbr.app.jab.nq.dao.ParamProdutoDao;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ParamProdutoDaoImpl implements ParamProdutoDao {
	private final Logger LOGGER = LoggerFactory.getLogger(ParamProdutoDaoImpl.class);

	@Autowired
	private AltairService altairService;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String versao() {
		return "";
	}

	public String listaProduto(String strSIGLA, String strNUSEQ, String strDETINTE, String strNOMEPRO,
			String strIDORDPA) {
		
		NQE0150 request = new NQE0150();
		request.setSIGLA(strSIGLA);
		request.setNUSEQ(strNUSEQ.isEmpty()? null : Integer.valueOf(strNUSEQ));
		request.setDETINTE(strDETINTE);
		request.setNOMEPRO(strNOMEPRO);
		request.setIDORDPA(strIDORDPA);

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQB5", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0150.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String alteraProduto(String strSGSISOR, String strSQSISOR, String strCDDETIN, String strDHFILTR,
			String strTPOPER, String strICMONIT, String strVLMINPR, String strCDUSRES) {
		
		NQE0160 request = new NQE0160();
		request.setSGSISOR(strSGSISOR);
		request.setSQSISOR(strSQSISOR.isEmpty()? null : Integer.valueOf(strSQSISOR));
		request.setCDDETIN(strCDDETIN);
		request.setDHFILTR(strDHFILTR);
		request.setTPOPER(strTPOPER);
		request.setICMONIT(strICMONIT);
		request.setVLMINPR(Integer.valueOf(strVLMINPR));
		request.setCDUSRES(strCDUSRES);
		
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQB6", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0160.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String listaAlteracaoParametro(String strCOSIGLA, String strNUSEQSI, String strCODETIN, String strCOOPINT,
			String strIDORDPG) {

		NQE0360 request = new NQE0360();
		request.setCOSIGLA(strCOSIGLA);
		request.setNUSEQSI(strNUSEQSI.isEmpty()? null : Integer.valueOf(strNUSEQSI));
		request.setCODETIN(strCODETIN);
		request.setCOOPINT(strCOOPINT);
		request.setIDORDPG(strIDORDPG);
		
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQC8", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0360.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

}
