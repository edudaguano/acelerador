package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.util.Date;

@PsFormat(name= "NQCETB14AreaDados")
public class NQCETB14AreaDados {

	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	//*----------------------------------------------------------------*
	//*       AREA DE SAIDA                                             
	//*----------------------------------------------------------------*
	//
	//01     NQCETB14-SAIDA.                                           

	@PsFieldString(name= "NQCETB14_S_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_CD_BANC_CLIE;//          05   NQCETB14-S-CD-BANC-CLIE       PIC  X(004).                
	
	//*       CODIGO DO BANCO                                           
	//
	@PsFieldString(name= "NQCETB14_S_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_CD_CLIE;//          05   NQCETB14-S-CD-CLIE            PIC  X(008).                
	
	//*       CODIGO DO CLIENTE                                         
	//
	@PsFieldString(name= "NQCETB14_S_DT_MOVI", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_DT_MOVI;//          05   NQCETB14-S-DT-MOVI            PIC  X(010).                
	
	//*       DATA DO MOVIMENTO                                         
	//
	@PsFieldNumber(name= "NQCETB14_S_NR_CRTO_CRED", decimal= 0, length= 16, signed= false, defaultValue="0")
	private Long NQCETB14_S_NR_CRTO_CRED;//     05   NQCETB14-S-NR-CRTO-CRED       PIC  9(016).                
	
	//*       NUMERO DO CARTAO DE CREDITO                               
	//
	@PsFieldString(name= "NQCETB14_S_CD_CNTR_ALTAIR", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_CD_CNTR_ALTAIR;//          05   NQCETB14-S-CD-CNTR-ALTAIR     PIC  X(020).                
	
	//*       CODIGO DO CONTRATO ALTAIR                                 
	//
	@PsFieldString(name= "NQCETB14_S_NM_CIDA_UTIZ", length= 26, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_NM_CIDA_UTIZ;//          05   NQCETB14-S-NM-CIDA-UTIZ       PIC  X(026).                
	
	//*       NOME DA CIDADE ONDE O CARTAO FOI UTILIZADO                
	//
	@PsFieldString(name= "NQCETB14_S_CD_PAIS_UTIZ", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_CD_PAIS_UTIZ;//          05   NQCETB14-S-CD-PAIS-UTIZ       PIC  X(003).                
	
	//*       CODIGO DO PAIS ONDE O CARTAO FOI UTILIZADO                
	//
	@PsFieldString(name= "NQCETB14_S_NM_ESTB_UTIZ", length= 27, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_NM_ESTB_UTIZ;//          05   NQCETB14-S-NM-ESTB-UTIZ       PIC  X(027).                
	
	//*       NOME DO ESTABELECIMENTO ONDE O CARTAO FOI UTILIZADO       
	//
	@PsFieldString(name= "NQCETB14_S_TP_TRAN", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_TP_TRAN;//          05   NQCETB14-S-TP-TRAN            PIC  X(001).                
	
	//*       TIPO DE TRANSACAO                                         
	//
	@PsFieldString(name= "NQCETB14_S_TP_FATU", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_TP_FATU;//          05   NQCETB14-S-TP-FATU            PIC  X(004).                
	
	//*       TIPO DE FATURAMENTO                                       
	//
	@PsFieldNumber(name= "NQCETB14_S_VL_OPER", decimal= 3, length= 18, signed= true, defaultValue="0")
	private Double NQCETB14_S_VL_OPER;//          05   NQCETB14-S-VL-OPER            PIC S9(015)V99.             
	
	//*       VALOR DA OPERACAO                                         
	//
	@PsFieldString(name= "NQCETB14_S_TP_FORM_PGTO", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_TP_FORM_PGTO;//          05   NQCETB14-S-TP-FORM-PGTO       PIC  X(001).                
	
	//*       TIPO DA FORMA DE PAGAMENTO                                
	//
	@PsFieldString(name= "NQCETB14_S_TP_FORM_FATU", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_TP_FORM_FATU;//          05   NQCETB14-S-TP-FORM-FATU       PIC  X(001).                
	
	//*       TIPO DA FORMA DE FATURAMENTO                              
	//
	@PsFieldString(name= "NQCETB14_S_CD_RAMO_ATVD", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_CD_RAMO_ATVD;//          05   NQCETB14-S-CD-RAMO-ATVD       PIC  X(004).                
	
	//*       CODIGO DO RAMO DE ATIVIDADE                               
	//
	@PsFieldString(name= "NQCETB14_S_CD_BANC_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_CD_BANC_CNTR;//          05   NQCETB14-S-CD-BANC-CNTR       PIC  X(004).                
	
	//*       CODIGO DO BANCO DO CONTRATO                               
	//
	@PsFieldString(name= "NQCETB14_S_CD_AGEN_CNTR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_CD_AGEN_CNTR;//          05   NQCETB14-S-CD-AGEN-CNTR       PIC  X(004).                
	
	//*       CODIGO DA AGENCIA DO CONTRATO                             
	//
	@PsFieldString(name= "NQCETB14_S_NR_CNTR_A", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_NR_CNTR_A;//          05   NQCETB14-S-NR-CNTR-A          PIC  X(020).                
	
	//*       NUMERO DO CONTRATO ALTAIR                                 
	//
	@PsFieldString(name= "NQCETB14_S_CD_PROD_ALTAIR", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_CD_PROD_ALTAIR;//          05   NQCETB14-S-CD-PROD-ALTAIR     PIC  X(002).                
	
	//*       CODIGO DO PRODUTO                                         
	//
	@PsFieldString(name= "NQCETB14_S_CD_SUBP_ALTAIR", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_CD_SUBP_ALTAIR;//          05   NQCETB14-S-CD-SUBP-ALTAIR     PIC  X(004).                
	
	//*       CODIGO DO SUBPRODUTO                                      
	//
	@PsFieldString(name= "NQCETB14_S_CD_MOED", length= 3, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_CD_MOED;//          05   NQCETB14-S-CD-MOED            PIC  X(003).                
	
	//*       CODIGO DA MOEDA                                           
	//
	@PsFieldNumber(name= "NQCETB14_S_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB14_S_NR_SEQU_OPER;//          05   NQCETB14-S-NR-SEQU-OPER       PIC  9(003).                
	
	//*       NUMERO SEQUENCIAL DA OPERACAO                             
	//
	@PsFieldString(name= "NQCETB14_S_CD_IDEF_OPER", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_CD_IDEF_OPER;//          05   NQCETB14-S-CD-IDEF-OPER       PIC  X(020).                
	
	//*       CODIGO DA IDENTIFICACAO DA OPERACAO                       
	//
	@PsFieldString(name= "NQCETB14_S_NM_CLIE", length= 40, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB14_S_NM_CLIE;//     05   NQCETB14-S-NM-CLIE            PIC  X(040).                

	
	public String getNQCETB14_S_CD_BANC_CLIE() {
		return NQCETB14_S_CD_BANC_CLIE;
	}

	public void setNQCETB14_S_CD_BANC_CLIE(String nQCETB14_S_CD_BANC_CLIE) {
		NQCETB14_S_CD_BANC_CLIE = nQCETB14_S_CD_BANC_CLIE;
	}

	public String getNQCETB14_S_CD_CLIE() {
		return NQCETB14_S_CD_CLIE;
	}

	public void setNQCETB14_S_CD_CLIE(String nQCETB14_S_CD_CLIE) {
		NQCETB14_S_CD_CLIE = nQCETB14_S_CD_CLIE;
	}

	public String getNQCETB14_S_DT_MOVI() {
		return NQCETB14_S_DT_MOVI;
	}

	public void setNQCETB14_S_DT_MOVI(String nQCETB14_S_DT_MOVI) {
		NQCETB14_S_DT_MOVI = nQCETB14_S_DT_MOVI;
	}

	public Long getNQCETB14_S_NR_CRTO_CRED() {
		return NQCETB14_S_NR_CRTO_CRED;
	}

	public void setNQCETB14_S_NR_CRTO_CRED(Long nQCETB14_S_NR_CRTO_CRED) {
		NQCETB14_S_NR_CRTO_CRED = nQCETB14_S_NR_CRTO_CRED;
	}

	public String getNQCETB14_S_CD_CNTR_ALTAIR() {
		return NQCETB14_S_CD_CNTR_ALTAIR;
	}

	public void setNQCETB14_S_CD_CNTR_ALTAIR(String nQCETB14_S_CD_CNTR_ALTAIR) {
		NQCETB14_S_CD_CNTR_ALTAIR = nQCETB14_S_CD_CNTR_ALTAIR;
	}

	public String getNQCETB14_S_NM_CIDA_UTIZ() {
		return NQCETB14_S_NM_CIDA_UTIZ;
	}

	public void setNQCETB14_S_NM_CIDA_UTIZ(String nQCETB14_S_NM_CIDA_UTIZ) {
		NQCETB14_S_NM_CIDA_UTIZ = nQCETB14_S_NM_CIDA_UTIZ;
	}

	public String getNQCETB14_S_CD_PAIS_UTIZ() {
		return NQCETB14_S_CD_PAIS_UTIZ;
	}

	public void setNQCETB14_S_CD_PAIS_UTIZ(String nQCETB14_S_CD_PAIS_UTIZ) {
		NQCETB14_S_CD_PAIS_UTIZ = nQCETB14_S_CD_PAIS_UTIZ;
	}

	public String getNQCETB14_S_NM_ESTB_UTIZ() {
		return NQCETB14_S_NM_ESTB_UTIZ;
	}

	public void setNQCETB14_S_NM_ESTB_UTIZ(String nQCETB14_S_NM_ESTB_UTIZ) {
		NQCETB14_S_NM_ESTB_UTIZ = nQCETB14_S_NM_ESTB_UTIZ;
	}

	public String getNQCETB14_S_TP_TRAN() {
		return NQCETB14_S_TP_TRAN;
	}

	public void setNQCETB14_S_TP_TRAN(String nQCETB14_S_TP_TRAN) {
		NQCETB14_S_TP_TRAN = nQCETB14_S_TP_TRAN;
	}

	public String getNQCETB14_S_TP_FATU() {
		return NQCETB14_S_TP_FATU;
	}

	public void setNQCETB14_S_TP_FATU(String nQCETB14_S_TP_FATU) {
		NQCETB14_S_TP_FATU = nQCETB14_S_TP_FATU;
	}

	public Double getNQCETB14_S_VL_OPER() {
		return NQCETB14_S_VL_OPER;
	}

	public void setNQCETB14_S_VL_OPER(Double nQCETB14_S_VL_OPER) {
		NQCETB14_S_VL_OPER = nQCETB14_S_VL_OPER;
	}

	public String getNQCETB14_S_TP_FORM_PGTO() {
		return NQCETB14_S_TP_FORM_PGTO;
	}

	public void setNQCETB14_S_TP_FORM_PGTO(String nQCETB14_S_TP_FORM_PGTO) {
		NQCETB14_S_TP_FORM_PGTO = nQCETB14_S_TP_FORM_PGTO;
	}

	public String getNQCETB14_S_TP_FORM_FATU() {
		return NQCETB14_S_TP_FORM_FATU;
	}

	public void setNQCETB14_S_TP_FORM_FATU(String nQCETB14_S_TP_FORM_FATU) {
		NQCETB14_S_TP_FORM_FATU = nQCETB14_S_TP_FORM_FATU;
	}

	public String getNQCETB14_S_CD_RAMO_ATVD() {
		return NQCETB14_S_CD_RAMO_ATVD;
	}

	public void setNQCETB14_S_CD_RAMO_ATVD(String nQCETB14_S_CD_RAMO_ATVD) {
		NQCETB14_S_CD_RAMO_ATVD = nQCETB14_S_CD_RAMO_ATVD;
	}

	public String getNQCETB14_S_CD_BANC_CNTR() {
		return NQCETB14_S_CD_BANC_CNTR;
	}

	public void setNQCETB14_S_CD_BANC_CNTR(String nQCETB14_S_CD_BANC_CNTR) {
		NQCETB14_S_CD_BANC_CNTR = nQCETB14_S_CD_BANC_CNTR;
	}

	public String getNQCETB14_S_CD_AGEN_CNTR() {
		return NQCETB14_S_CD_AGEN_CNTR;
	}

	public void setNQCETB14_S_CD_AGEN_CNTR(String nQCETB14_S_CD_AGEN_CNTR) {
		NQCETB14_S_CD_AGEN_CNTR = nQCETB14_S_CD_AGEN_CNTR;
	}

	public String getNQCETB14_S_NR_CNTR_A() {
		return NQCETB14_S_NR_CNTR_A;
	}

	public void setNQCETB14_S_NR_CNTR_A(String nQCETB14_S_NR_CNTR_A) {
		NQCETB14_S_NR_CNTR_A = nQCETB14_S_NR_CNTR_A;
	}

	public String getNQCETB14_S_CD_PROD_ALTAIR() {
		return NQCETB14_S_CD_PROD_ALTAIR;
	}

	public void setNQCETB14_S_CD_PROD_ALTAIR(String nQCETB14_S_CD_PROD_ALTAIR) {
		NQCETB14_S_CD_PROD_ALTAIR = nQCETB14_S_CD_PROD_ALTAIR;
	}

	public String getNQCETB14_S_CD_SUBP_ALTAIR() {
		return NQCETB14_S_CD_SUBP_ALTAIR;
	}

	public void setNQCETB14_S_CD_SUBP_ALTAIR(String nQCETB14_S_CD_SUBP_ALTAIR) {
		NQCETB14_S_CD_SUBP_ALTAIR = nQCETB14_S_CD_SUBP_ALTAIR;
	}

	public String getNQCETB14_S_CD_MOED() {
		return NQCETB14_S_CD_MOED;
	}

	public void setNQCETB14_S_CD_MOED(String nQCETB14_S_CD_MOED) {
		NQCETB14_S_CD_MOED = nQCETB14_S_CD_MOED;
	}

	public Long getNQCETB14_S_NR_SEQU_OPER() {
		return NQCETB14_S_NR_SEQU_OPER;
	}

	public void setNQCETB14_S_NR_SEQU_OPER(Long nQCETB14_S_NR_SEQU_OPER) {
		NQCETB14_S_NR_SEQU_OPER = nQCETB14_S_NR_SEQU_OPER;
	}

	public String getNQCETB14_S_CD_IDEF_OPER() {
		return NQCETB14_S_CD_IDEF_OPER;
	}

	public void setNQCETB14_S_CD_IDEF_OPER(String nQCETB14_S_CD_IDEF_OPER) {
		NQCETB14_S_CD_IDEF_OPER = nQCETB14_S_CD_IDEF_OPER;
	}

	public String getNQCETB14_S_NM_CLIE() {
		return NQCETB14_S_NM_CLIE;
	}

	public void setNQCETB14_S_NM_CLIE(String nQCETB14_S_NM_CLIE) {
		NQCETB14_S_NM_CLIE = nQCETB14_S_NM_CLIE;
	}
	
	//*       NOME DO CLIENTE                                           
	//
	
	
	
}