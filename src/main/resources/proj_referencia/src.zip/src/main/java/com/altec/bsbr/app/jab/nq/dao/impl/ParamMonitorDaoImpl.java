package com.altec.bsbr.app.jab.nq.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0190;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0200;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0370;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0190;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0200;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0370;
import com.altec.bsbr.app.jab.nq.dao.ParamMonitorDao;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ParamMonitorDaoImpl implements ParamMonitorDao {
	private final Logger LOGGER = LoggerFactory.getLogger(ParamMonitorDaoImpl.class);

	@Autowired
	private AltairService altairService;
	
	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String versao() {
		return "";
	}

	public String listaTipoMovimentoMonitorado(String strCOSIGLA, String strNUSEQSI, String strCODETIN,
			String strCOOPINT, String strNOOPEIN, String strIDORDPA) {
		NQE0190 request = new NQE0190();
		request.setCOSIGLA(strCOSIGLA);
		request.setNUSEQSI(strNUSEQSI.isEmpty()? null : Integer.valueOf(strNUSEQSI));
		request.setCODETIN(strCODETIN);
		request.setCOOPINT(strCOOPINT);
		request.setNOOPEIN(strNOOPEIN);
		request.setIDORDPA(strIDORDPA);
		
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQB7", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0190.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String incluirTipoMovimentoMonitorado(String strCOSIGLA, String strNUSEQSI, String strCODETIN,
			String strCOOPINT, String strNOOPEIN, String strICMONIT, String strTPOPERA, String strDTHROPE,
			String strCDUSRES, String strTPMANUT) {
		NQE0200 request = new NQE0200();
		request.setCOSIGLA(strCOSIGLA);
		request.setNUSEQSI(strNUSEQSI.isEmpty()? null : Integer.valueOf(strNUSEQSI));
		request.setCODETIN(strCODETIN);
		request.setCOOPINT(strCOOPINT);
		request.setNOOPEIN(strNOOPEIN);
		request.setICMONIT(strICMONIT);
		request.setTPOPERA(strTPOPERA);
		request.setDTHROPE(strDTHROPE);
		request.setCDUSRES(strCDUSRES);
		request.setTPMANUT(strTPMANUT);
		
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQB8", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0200.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String montarComboProduto(String strCOPRSPR) {
		NQE0370 request = new NQE0370();
		request.setCOPRSPR(strCOPRSPR);
	
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQC9", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0370.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

}
