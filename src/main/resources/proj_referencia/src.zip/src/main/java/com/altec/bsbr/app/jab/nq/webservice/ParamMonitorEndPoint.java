package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.ParamMonitorService;
import com.altec.bsbr.app.jab.nq.service.ParamMonitorWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class ParamMonitorEndPoint extends SpringBeanAutowiringSupport implements ParamMonitorWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(ParamMonitorEndPoint.class);
	@Autowired
	private ParamMonitorService paramMonitor;

	@WebMethod
	public String versao() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramMonitor.versao();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String listaTipoMovimentoMonitorado(String strCOSIGLA, String strNUSEQSI, String strCODETIN,
			String strCOOPINT, String strNOOPEIN, String strIDORDPA) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramMonitor.listaTipoMovimentoMonitorado(strCOSIGLA, strNUSEQSI, strCODETIN, strCOOPINT,
					strNOOPEIN, strIDORDPA);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirTipoMovimentoMonitorado(String strCOSIGLA, String strNUSEQSI, String strCODETIN,
			String strCOOPINT, String strNOOPEIN, String strICMONIT, String strTPOPERA, String strDTHROPE,
			String strCDUSRES, String strTPMANUT) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramMonitor.incluirTipoMovimentoMonitorado(strCOSIGLA, strNUSEQSI, strCODETIN, strCOOPINT,
					strNOOPEIN, strICMONIT, strTPOPERA, strDTHROPE, strCDUSRES, strTPMANUT);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String montarComboProduto(String strCOPRSPR) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = paramMonitor.montarComboProduto(strCOPRSPR);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}
}
