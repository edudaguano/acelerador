package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@PsFormat(name= "NQCETB01AreaDados")
public class NQCETB01AreaDados {

//  
//*       AREA DE DADOS                                             

	@PsFieldNumber(name = "NQCETB1S_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB1S_NR_SEQU_SIST;// 05 NQCETB1S-NR-SEQU-SIST PIC 9(004).

//*       NUMERO DE SEQUENCIA DO SISTEMA                            
//  
	@PsFieldString(name = "NQCETB1S_SG_SIST", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1S_SG_SIST;// 05 NQCETB1S-SG-SIST PIC X(002).

//*       SIGLA DO SISTEMA                                          
//  
	@PsFieldString(name = "NQCETB1S_NM_FCAO_SIST", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1S_NM_FCAO_SIST;// 05 NQCETB1S-NM-FCAO-SIST PIC X(020).

//*       NOME DA FUNCAO DO SISTEMA                                 
//  
	@PsFieldString(name = "NQCETB1S_DS_FCAO_SIST", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1S_DS_FCAO_SIST;// 05 NQCETB1S-DS-FCAO-SIST PIC X(040).

//*       DESCRICAO DA FUNCAO DO SISTEMA                            
//  
	@PsFieldString(name = "NQCETB1S_DH_ULTI_PROC_SIST", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1S_DH_ULTI_PROC_SIST;// 05 NQCETB1S-DH-ULTI-PROC-SIST PIC X(026).

//*       DATA/HORA ULTIMO PROCESSAMENTO INTERFACE SISTEMA          
//  
	@PsFieldString(name = "NQCETB1S_IN_SIST_ATIV", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1S_IN_SIST_ATIV;// 05 NQCETB1S-IN-SIST-ATIV PIC X(001).

	public Long getNQCETB1S_NR_SEQU_SIST() {
		return NQCETB1S_NR_SEQU_SIST;
	}

	public void setNQCETB1S_NR_SEQU_SIST(Long nQCETB1S_NR_SEQU_SIST) {
		NQCETB1S_NR_SEQU_SIST = nQCETB1S_NR_SEQU_SIST;
	}

	public String getNQCETB1S_SG_SIST() {
		return NQCETB1S_SG_SIST;
	}

	public void setNQCETB1S_SG_SIST(String nQCETB1S_SG_SIST) {
		NQCETB1S_SG_SIST = nQCETB1S_SG_SIST;
	}

	public String getNQCETB1S_NM_FCAO_SIST() {
		return NQCETB1S_NM_FCAO_SIST;
	}

	public void setNQCETB1S_NM_FCAO_SIST(String nQCETB1S_NM_FCAO_SIST) {
		NQCETB1S_NM_FCAO_SIST = nQCETB1S_NM_FCAO_SIST;
	}

	public String getNQCETB1S_DS_FCAO_SIST() {
		return NQCETB1S_DS_FCAO_SIST;
	}

	public void setNQCETB1S_DS_FCAO_SIST(String nQCETB1S_DS_FCAO_SIST) {
		NQCETB1S_DS_FCAO_SIST = nQCETB1S_DS_FCAO_SIST;
	}

	public String getNQCETB1S_DH_ULTI_PROC_SIST() {
		return NQCETB1S_DH_ULTI_PROC_SIST;
	}

	public void setNQCETB1S_DH_ULTI_PROC_SIST(String nQCETB1S_DH_ULTI_PROC_SIST) {
		NQCETB1S_DH_ULTI_PROC_SIST = nQCETB1S_DH_ULTI_PROC_SIST;
	}

	public String getNQCETB1S_IN_SIST_ATIV() {
		return NQCETB1S_IN_SIST_ATIV;
	}

	public void setNQCETB1S_IN_SIST_ATIV(String nQCETB1S_IN_SIST_ATIV) {
		NQCETB1S_IN_SIST_ATIV = nQCETB1S_IN_SIST_ATIV;
	}

//*       INDICADOR DE SISTEMA ATIVO                     
	
	

}