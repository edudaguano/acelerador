package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0360")
public class NQE0360 {
@PsFieldString(name="COSIGLA", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COSIGLA;
@PsFieldNumber(name="NUSEQSI", length=2, defaultValue = "0" )
private Integer NUSEQSI;
@PsFieldString(name="CODETIN", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODETIN;
@PsFieldString(name="COOPINT", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COOPINT;
@PsFieldString(name="IDORDPG", length=1, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String IDORDPG;

public String getCOSIGLA() {
 return COSIGLA;
}
public void setCOSIGLA(String COSIGLA) {
 this.COSIGLA = COSIGLA;
}
public Integer getNUSEQSI() {
 return NUSEQSI;
}
public void setNUSEQSI(Integer nUSEQSI) {
NUSEQSI = nUSEQSI;
}
public String getCODETIN() {
 return CODETIN;
}
public void setCODETIN(String CODETIN) {
 this.CODETIN = CODETIN;
}

public String getCOOPINT() {
 return COOPINT;
}
public void setCOOPINT(String COOPINT) {
 this.COOPINT = COOPINT;
}

public String getIDORDPG() {
 return IDORDPG;
}
public void setIDORDPG(String IDORDPG) {
 this.IDORDPG = IDORDPG;
}


}
