package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE6074LegadoResponse {
	/*
// -*-NQCE6074
//         01      RECEIVE-COMMAREA.                                        
	@FixedLenghtField(position = 461, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_PGM_CHAMADA;//                 03  COMM-PGM-CHAMADA    PIC  X(008).                     

	@FixedLenghtField(position = 462, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOMEDATS;//                 03  COMM-NOMEDATS       PIC  X(010).                     

	@FixedLenghtField(position = 463, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_TAM_COMM;//                 03  COMM-TAM-COMM       PIC  9(007).                     

	@FixedLenghtField(position = 464, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOME_TS;//                 03  COMM-NOME-TS        PIC  X(008).                     

	@FixedLenghtField(position = 465, lenght = 9, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_MATRICULA;//                 03  COMM-MATRICULA      PIC  9(009).                     

	@FixedLenghtField(position = 466, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CINSTIT;//                 03  COMM-CINSTIT        PIC  9(003).                     

	@FixedLenghtField(position = 467, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_DATA;//                 03  COMM-DATA           PIC  9(008).                     

	@FixedLenghtField(position = 468, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_TP_TOT;//                 03  COMM-TP-TOT         PIC  X(001).                     

//         01      SEND-AREA.                                               
	@FixedLenghtField(position = 469, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN;//                 03  TS01-MENS-LEN       PIC S9(004) COMP VALUE +83.      

//                 03  TS01-AREA-MENSAGEM.                                  
	@FixedLenghtField(position = 470, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO;//                     05  TS01-RETORNO    PIC  9(003) VALUE ZEROS.         

	@FixedLenghtField(position = 471, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM;//                     05  TS01-MENSAGEM   PIC  X(080) VALUE SPACES.                                                                        

	@FixedLenghtField(position = 472, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_MENS_LEN;//                 03  TS02-MENS-LEN       PIC S9(004) COMP VALUE +90.      

//                 03  TS02-AREA-DETALHE.                                   
	@FixedLenghtField(position = 473, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_CODAGENC;//                     05 TS02-CODAGENC    PIC  9(004).                     

	@FixedLenghtField(position = 474, lenght = 30, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NOMAGENC;//                     05 TS02-NOMAGENC    PIC  X(030).                     

	@FixedLenghtField(position = 475, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_CADASTRADAS;//                     05 TS02-CADASTRADAS PIC  9(008).                     

	@FixedLenghtField(position = 476, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_VISITADAS;//                     05 TS02-VISITADAS   PIC  9(008).                     

	@FixedLenghtField(position = 477, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_RECUSADAS;//                     05 TS02-RECUSADAS   PIC  9(008).                     

	@FixedLenghtField(position = 478, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_APROVADAS;//                     05 TS02-APROVADAS   PIC  9(008).                     

	@FixedLenghtField(position = 479, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_AVISITAR;//                     05 TS02-AVISITAR    PIC  9(008).                     

	@FixedLenghtField(position = 480, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_AAPROVAR;//                     05 TS02-AAPROVAR    PIC  9(008).                     

	@FixedLenghtField(position = 481, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_ATRASADAS;//                     05 TS02-ATRASADAS   PIC  9(008).                     

	public NQCE6074LegadoResponse() { }
	public NQCE6074LegadoResponse(String comm_pgm_chamada, String comm_nomedats, Long comm_tam_comm, String comm_nome_ts, Long comm_matricula, Long comm_cinstit, Long comm_data, String comm_tp_tot, Long ts02_codagenc, String ts02_nomagenc, Long ts02_cadastradas, Long ts02_visitadas, Long ts02_recusadas, Long ts02_aprovadas, Long ts02_avisitar, Long ts02_aaprovar, Long ts02_atrasadas) { 		this.COMM_PGM_CHAMADA = comm_pgm_chamada;
		this.COMM_NOMEDATS = comm_nomedats;
		this.COMM_TAM_COMM = comm_tam_comm;
		this.COMM_NOME_TS = comm_nome_ts;
		this.COMM_MATRICULA = comm_matricula;
		this.COMM_CINSTIT = comm_cinstit;
		this.COMM_DATA = comm_data;
		this.COMM_TP_TOT = comm_tp_tot;
		this.TS01_MENS_LEN = +83;
		this.TS01_RETORNO = ZEROS;
		this.TS01_MENSAGEM = SPACES;
		this.TS02_MENS_LEN = +90;
		this.TS02_CODAGENC = ts02_codagenc;
		this.TS02_NOMAGENC = ts02_nomagenc;
		this.TS02_CADASTRADAS = ts02_cadastradas;
		this.TS02_VISITADAS = ts02_visitadas;
		this.TS02_RECUSADAS = ts02_recusadas;
		this.TS02_APROVADAS = ts02_aprovadas;
		this.TS02_AVISITAR = ts02_avisitar;
		this.TS02_AAPROVAR = ts02_aaprovar;
		this.TS02_ATRASADAS = ts02_atrasadas; 
	}
	public String getCOMM_PGM_CHAMADA() { return this.COMM_PGM_CHAMADA; }
	public String getCOMM_NOMEDATS() { return this.COMM_NOMEDATS; }
	public Long getCOMM_TAM_COMM() { return this.COMM_TAM_COMM; }
	public String getCOMM_NOME_TS() { return this.COMM_NOME_TS; }
	public Long getCOMM_MATRICULA() { return this.COMM_MATRICULA; }
	public Long getCOMM_CINSTIT() { return this.COMM_CINSTIT; }
	public Long getCOMM_DATA() { return this.COMM_DATA; }
	public String getCOMM_TP_TOT() { return this.COMM_TP_TOT; }
	public Long getTS01_MENS_LEN() { return this.TS01_MENS_LEN; }
	public Long getTS01_RETORNO() { return this.TS01_RETORNO; }
	public String getTS01_MENSAGEM() { return this.TS01_MENSAGEM; }
	public Long getTS02_MENS_LEN() { return this.TS02_MENS_LEN; }
	public Long getTS02_CODAGENC() { return this.TS02_CODAGENC; }
	public String getTS02_NOMAGENC() { return this.TS02_NOMAGENC; }
	public Long getTS02_CADASTRADAS() { return this.TS02_CADASTRADAS; }
	public Long getTS02_VISITADAS() { return this.TS02_VISITADAS; }
	public Long getTS02_RECUSADAS() { return this.TS02_RECUSADAS; }
	public Long getTS02_APROVADAS() { return this.TS02_APROVADAS; }
	public Long getTS02_AVISITAR() { return this.TS02_AVISITAR; }
	public Long getTS02_AAPROVAR() { return this.TS02_AAPROVAR; }
	public Long getTS02_ATRASADAS() { return this.TS02_ATRASADAS; }
	public void setCOMM_PGM_CHAMADA(String comm_pgm_chamada) { this.COMM_PGM_CHAMADA = comm_pgm_chamada; }
	public void setCOMM_NOMEDATS(String comm_nomedats) { this.COMM_NOMEDATS = comm_nomedats; }
	public void setCOMM_TAM_COMM(Long comm_tam_comm) { this.COMM_TAM_COMM = comm_tam_comm; }
	public void setCOMM_NOME_TS(String comm_nome_ts) { this.COMM_NOME_TS = comm_nome_ts; }
	public void setCOMM_MATRICULA(Long comm_matricula) { this.COMM_MATRICULA = comm_matricula; }
	public void setCOMM_CINSTIT(Long comm_cinstit) { this.COMM_CINSTIT = comm_cinstit; }
	public void setCOMM_DATA(Long comm_data) { this.COMM_DATA = comm_data; }
	public void setCOMM_TP_TOT(String comm_tp_tot) { this.COMM_TP_TOT = comm_tp_tot; }
	public void setTS01_MENS_LEN(Long ts01_mens_len) { this.TS01_MENS_LEN = ts01_mens_len; }
	public void setTS01_RETORNO(Long ts01_retorno) { this.TS01_RETORNO = ts01_retorno; }
	public void setTS01_MENSAGEM(String ts01_mensagem) { this.TS01_MENSAGEM = ts01_mensagem; }
	public void setTS02_MENS_LEN(Long ts02_mens_len) { this.TS02_MENS_LEN = ts02_mens_len; }
	public void setTS02_CODAGENC(Long ts02_codagenc) { this.TS02_CODAGENC = ts02_codagenc; }
	public void setTS02_NOMAGENC(String ts02_nomagenc) { this.TS02_NOMAGENC = ts02_nomagenc; }
	public void setTS02_CADASTRADAS(Long ts02_cadastradas) { this.TS02_CADASTRADAS = ts02_cadastradas; }
	public void setTS02_VISITADAS(Long ts02_visitadas) { this.TS02_VISITADAS = ts02_visitadas; }
	public void setTS02_RECUSADAS(Long ts02_recusadas) { this.TS02_RECUSADAS = ts02_recusadas; }
	public void setTS02_APROVADAS(Long ts02_aprovadas) { this.TS02_APROVADAS = ts02_aprovadas; }
	public void setTS02_AVISITAR(Long ts02_avisitar) { this.TS02_AVISITAR = ts02_avisitar; }
	public void setTS02_AAPROVAR(Long ts02_aaprovar) { this.TS02_AAPROVAR = ts02_aaprovar; }
	public void setTS02_ATRASADAS(Long ts02_atrasadas) { this.TS02_ATRASADAS = ts02_atrasadas; }
	*/
}