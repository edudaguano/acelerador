package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface ComOpSusInfCliService {

	public String versao() throws BusinessException;

	public String consultarAgencia(String strNUENTID, String strNUAGENC, String strNUCONTA, String strCOCLIEN)
			throws BusinessException;

	public String consultarSocio(String strPENUMPE) throws BusinessException;

	public String consultarClientePJ(String strCODENT, String strTPDOCTO, String strNUDOCTO, String strCDALERT)
			throws BusinessException;

	public String consultarClientePF(String strTPDOCTO, String strNUDOCTO, String strCDENTID, String strCDALERT)
			throws BusinessException;

	public String consultarClientePE(String strCOENTID, String strTPDOCTO, String strNUDOCTO) throws BusinessException;

	public String log(String strTexto) throws BusinessException;
}
