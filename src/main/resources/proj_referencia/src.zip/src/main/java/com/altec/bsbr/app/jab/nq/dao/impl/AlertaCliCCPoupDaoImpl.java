package com.altec.bsbr.app.jab.nq.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0020;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0240;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0250;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0270;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0290;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0020;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0240;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0250;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0270;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0290;
import com.altec.bsbr.app.jab.nq.dao.AlertaCliCCPoupDao;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class AlertaCliCCPoupDaoImpl implements AlertaCliCCPoupDao {
	private final Logger LOGGER = LoggerFactory.getLogger(AlertaCliCCPoupDaoImpl.class);

	@Autowired
	private AltairService altairService;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String versao() {
		return "";
	}

	public String consultarCenario(String strCODENTI, String strCODALER, String strCODCENA) {
		NQE0240 request = new NQE0240();
		request.setCODENTI(strCODENTI);
		request.setCODALER(strCODALER);
		request.setCODCENA(strCODCENA);

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQBB", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0240.class));
			
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarDadoProduto(String strCDENTI, String strCDALER, String strCDCENA, String strCDDTINT,
			String strCDPROD, String strNUCNTR) {
		NQE0270 request = new NQE0270();
		request.setCDENTI(strCDENTI);
		request.setCDALER(strCDALER);
		request.setCDCENA(strCDCENA);
		request.setCDDTINT(strCDDTINT);
		request.setCDPROD(strCDPROD);
		request.setNUCNTR(strNUCNTR);

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQC3", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0270.class));
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarClientePJ(String strCOENTID, String strCOALER) {
		NQE0290 request = new NQE0290();
		request.setCOENTID(strCOENTID);
		request.setCOALERT(strCOALER);

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQA4", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0290.class));
			
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarClientePF(String strCOENTID, String strCOALER) {
		NQE0020 request = new NQE0020();
		request.setCODENT(strCOENTID);
		request.setCOALER(strCOALER);
		
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQA2", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0020.class));
			
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarOperacao(String strCDENTID, String strCDALERT, String strCDCENAR, String strCDDETIN,
			String strCDDOCOP, String strNUCNTR) {
		NQE0250 request = new NQE0250();
		request.setCDENTID(strCDENTID);
		request.setCDALERT(strCDALERT);
		request.setCDCENAR(strCDCENAR);
		request.setCDDETIN(strCDDETIN);
		request.setCDDOCOP(strCDDOCOP);
		request.setNUCNTR(strNUCNTR);

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQC1", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0250.class));
			
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

}
