package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface AlertaGeradoService {
	public String versao() throws BusinessException;

	public String montarComboSituacao(String strCDSITU) throws BusinessException;

	public String consultaFiltroAlerta(String strCOENTID, String strCOALERT, String strCOAGENC, String strCOUNIOR,
			String strTPDOC, String strNUDOC, String strDTINICI, String strDTFIM, String strCOSITUA, String strIDORDPA,
			String strTPCHM, String strCOALNKM) throws BusinessException;
}
