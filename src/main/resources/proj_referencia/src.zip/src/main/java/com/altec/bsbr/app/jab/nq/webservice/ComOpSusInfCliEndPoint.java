package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.ComOpSusInfCliService;
import com.altec.bsbr.app.jab.nq.service.ComOpSusInfCliWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class ComOpSusInfCliEndPoint extends SpringBeanAutowiringSupport implements ComOpSusInfCliWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(ComOpSusInfCliEndPoint.class);

	@Autowired
	private ComOpSusInfCliService comOpSusInfCli;
	
	@WebMethod
	public String versao() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = comOpSusInfCli.versao();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarAgencia(String strNUENTID, String strNUAGENC, String strNUCONTA, String strCOCLIEN)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = comOpSusInfCli.consultarAgencia(strNUENTID, strNUAGENC, strNUCONTA, strCOCLIEN);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarSocio(String strPENUMPE) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = comOpSusInfCli.consultarSocio(strPENUMPE);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarClientePJ(String strCODENT, String strTPDOCTO, String strNUDOCTO, String strCDALERT)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = comOpSusInfCli.consultarClientePJ(strCODENT, strTPDOCTO, strNUDOCTO, strCDALERT);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarClientePF(String strTPDOCTO, String strNUDOCTO, String strCDENTID, String strCDALERT)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = comOpSusInfCli.consultarClientePF(strTPDOCTO, strNUDOCTO, strCDENTID, strCDALERT);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarClientePE(String strCOENTID, String strTPDOCTO, String strNUDOCTO)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = comOpSusInfCli.consultarClientePE(strCOENTID, strTPDOCTO, strNUDOCTO);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String log(String strTexto) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = comOpSusInfCli.log(strTexto);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

}
