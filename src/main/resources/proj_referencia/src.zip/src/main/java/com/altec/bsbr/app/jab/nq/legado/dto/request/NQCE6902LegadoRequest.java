package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE6902LegadoRequest {
	/*
// -*-NQCE6902
//         01      RECEIVE-COMMAREA.                                        
	@FixedLenghtField(position = 1,070, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_PGM_CHAMADA;//                 03  COMM-PGM-CHAMADA      PIC  X(008).                   

	@FixedLenghtField(position = 1,071, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOMEDATS;//                 03  COMM-NOMEDATS         PIC  X(010).                   

	@FixedLenghtField(position = 1,072, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_TAM_COMM;//                 03  COMM-TAM-COMM         PIC  9(007).                   

	@FixedLenghtField(position = 1,073, lenght = 9, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_MATRICULA;//                 03  COMM-MATRICULA        PIC  9(009).                   

	@FixedLenghtField(position = 1,074, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_DATAINI;//                 03  COMM-DATAINI          PIC  9(008).                   

	@FixedLenghtField(position = 1,075, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_DATAFIM;//                 03  COMM-DATAFIM          PIC  9(008).                   

	@FixedLenghtField(position = 1,076, lenght = 1, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_OPCAO;//                 03  COMM-OPCAO            PIC  9(001).                   

//         01      SEND-AREA.                                               
	@FixedLenghtField(position = 1,077, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN;//                 03  TS01-MENS-LEN         PIC S9(004) COMP VALUE +83.    

//                 03  TS01-AREA-MENSAGEM.                                  
	@FixedLenghtField(position = 1,078, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO;//                     05  TS01-RETORNO      PIC  9(003) VALUE ZEROS.       

	@FixedLenghtField(position = 1,079, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM;//                     05  TS01-MENSAGEM     PIC  X(080) VALUE SPACES.                                                                      

	@FixedLenghtField(position = 1,080, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN_X;//                 03  TS01-MENS-LEN-X       PIC S9(004) COMP VALUE +83.    

//                 03  TS01-AREA-NQCE6902.                                  
	@FixedLenghtField(position = 1,081, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO_X;//                     05  TS01-RETORNO-X    PIC  9(003) VALUE ZEROS.       

	@FixedLenghtField(position = 1,082, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM_X;//                     05  TS01-MENSAGEM-X   PIC  X(080) VALUE SPACES.      

	public NQCE6902LegadoRequest() { }
	public NQCE6902LegadoRequest(String comm_pgm_chamada, String comm_nomedats, Long comm_tam_comm, Long comm_matricula, Long comm_dataini, Long comm_datafim, Long comm_opcao) { 		this.COMM_PGM_CHAMADA = comm_pgm_chamada;
		this.COMM_NOMEDATS = comm_nomedats;
		this.COMM_TAM_COMM = comm_tam_comm;
		this.COMM_MATRICULA = comm_matricula;
		this.COMM_DATAINI = comm_dataini;
		this.COMM_DATAFIM = comm_datafim;
		this.COMM_OPCAO = comm_opcao;
		this.TS01_MENS_LEN = +83;
		this.TS01_RETORNO = ZEROS;
		this.TS01_MENSAGEM = SPACES;
		this.TS01_MENS_LEN_X = +83;
		this.TS01_RETORNO_X = ZEROS;
		this.TS01_MENSAGEM_X = SPACES; 
	}
	public String getCOMM_PGM_CHAMADA() { return this.COMM_PGM_CHAMADA; }
	public String getCOMM_NOMEDATS() { return this.COMM_NOMEDATS; }
	public Long getCOMM_TAM_COMM() { return this.COMM_TAM_COMM; }
	public Long getCOMM_MATRICULA() { return this.COMM_MATRICULA; }
	public Long getCOMM_DATAINI() { return this.COMM_DATAINI; }
	public Long getCOMM_DATAFIM() { return this.COMM_DATAFIM; }
	public Long getCOMM_OPCAO() { return this.COMM_OPCAO; }
	public Long getTS01_MENS_LEN() { return this.TS01_MENS_LEN; }
	public Long getTS01_RETORNO() { return this.TS01_RETORNO; }
	public String getTS01_MENSAGEM() { return this.TS01_MENSAGEM; }
	public Long getTS01_MENS_LEN_X() { return this.TS01_MENS_LEN_X; }
	public Long getTS01_RETORNO_X() { return this.TS01_RETORNO_X; }
	public String getTS01_MENSAGEM_X() { return this.TS01_MENSAGEM_X; }
	public void setCOMM_PGM_CHAMADA(String comm_pgm_chamada) { this.COMM_PGM_CHAMADA = comm_pgm_chamada; }
	public void setCOMM_NOMEDATS(String comm_nomedats) { this.COMM_NOMEDATS = comm_nomedats; }
	public void setCOMM_TAM_COMM(Long comm_tam_comm) { this.COMM_TAM_COMM = comm_tam_comm; }
	public void setCOMM_MATRICULA(Long comm_matricula) { this.COMM_MATRICULA = comm_matricula; }
	public void setCOMM_DATAINI(Long comm_dataini) { this.COMM_DATAINI = comm_dataini; }
	public void setCOMM_DATAFIM(Long comm_datafim) { this.COMM_DATAFIM = comm_datafim; }
	public void setCOMM_OPCAO(Long comm_opcao) { this.COMM_OPCAO = comm_opcao; }
	public void setTS01_MENS_LEN(Long ts01_mens_len) { this.TS01_MENS_LEN = ts01_mens_len; }
	public void setTS01_RETORNO(Long ts01_retorno) { this.TS01_RETORNO = ts01_retorno; }
	public void setTS01_MENSAGEM(String ts01_mensagem) { this.TS01_MENSAGEM = ts01_mensagem; }
	public void setTS01_MENS_LEN_X(Long ts01_mens_len_x) { this.TS01_MENS_LEN_X = ts01_mens_len_x; }
	public void setTS01_RETORNO_X(Long ts01_retorno_x) { this.TS01_RETORNO_X = ts01_retorno_x; }
	public void setTS01_MENSAGEM_X(String ts01_mensagem_x) { this.TS01_MENSAGEM_X = ts01_mensagem_x; }
	*/
}