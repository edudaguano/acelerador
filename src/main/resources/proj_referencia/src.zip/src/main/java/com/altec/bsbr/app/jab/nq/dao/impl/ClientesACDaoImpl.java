package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.ClientesACDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB08LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB12LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB08AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB12AreaDados;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB08MessagingGateway;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB12MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ClientesACDaoImpl implements ClientesACDao {

	private final Logger LOGGER = LoggerFactory.getLogger(ClientesACDaoImpl.class);

	@Autowired
	private JSONMapper jsonMapper;

	@Autowired
	private NQCETB08MessagingGateway NQCETB08Service;
	
	@Autowired
	private NQCETB12MessagingGateway NQCETB12Service;
	
	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String consultarClientes(String strBanco, String strCliente, String StrUsuario) throws BusinessException {
		String json = "";
		try {
			NQCETB08LegadoRequest req = new NQCETB08LegadoRequest();
			
			req.setNQCETB08_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB08_E_CD_CLIE(strCliente);
			req.setNQCETB08_E_CD_USUA(StrUsuario);
			req.setNQCETB08_E_NM_AREA("NQAT2008");
			req.setNQCETB08_E_NM_PROG("NQAT2008");
			req.setNQCETB08_E_QT_TAMA_AREA(Long.valueOf("45"));
			req.setNQCETB08_E_SG_FCAO("C");
			LegadoResult res = NQCETB08Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB08AreaDados> ret = decoder.parseRetorno(res, NQCETB08AreaDados.class, 83, 235);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String listarClientes(String strBanco, String strCliente, String StrUsuario) throws BusinessException {
		String json = "";
		try {
			NQCETB12LegadoRequest req = new NQCETB12LegadoRequest();

			req.setNQCETB12_E_NM_AREA("NQAT2012");
			req.setNQCETB12_E_NM_PROG("NQAT2012");
			req.setNQCETB12_E_QT_TAMA_AREA(Long.valueOf("45"));
			req.setNQCETB12_E_SG_FCAO("L");			
			
			LegadoResult res = NQCETB12Service.sendMessageMultiLegado(req);
			PsFormatDecoder decoder = new PsFormatDecoder();
			List<NQCETB12AreaDados> ret = decoder.parseRetorno(res, NQCETB12AreaDados.class, 83, 60);
			json =  new ObjectMapper().writeValueAsString(ret);			
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) {
		String json = "";
		return json;
	}
}
