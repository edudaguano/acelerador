package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.ParametrosService;
import com.altec.bsbr.app.jab.nq.service.ParametrosWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class ParametrosEndPoint extends SpringBeanAutowiringSupport implements ParametrosWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(ParametrosEndPoint.class);
	@Autowired
	private ParametrosService parametros;

	@WebMethod
	public String confirmarRegras(String acao, String intProduto, String intCodBanco, String intPeriodo,
			String intAgrupa, String lngAtividade, String lngOcupacao, String intSegmento, String dblValor,
			String strUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.confirmarRegras(acao, intProduto, intCodBanco, intPeriodo, intAgrupa, lngAtividade, lngOcupacao, intSegmento, dblValor, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirValorOpSensib(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdSelecionada, String dblValor, String strUsuario)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.incluirValorOpSensib(intCodBancoSelecionado, intCodAplicSelecionada, intCodPeriododSelecionada, intCodProdSelecionada, dblValor, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarValorOpSensib(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdSelecionada, String dblValor, String strUsuario)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.alterarValorOpSensib(intCodBancoSelecionado, intCodAplicSelecionada, intCodPeriododSelecionada, intCodProdSelecionada, dblValor, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarBancoPeriodoProdAplic() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarBancoPeriodoProdAplic();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarValorOpSensivel(String intBanco, String intAplicativo, String intPeriodo, String intProduto)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarValorOpSensivel(intBanco, intAplicativo, intPeriodo, intProduto);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarAgencias(String intBanco, String intAgencia, String strFuncao) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarAgencias(intBanco, intAgencia, strFuncao);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarApoio(String intTabela, String number) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarApoio(intTabela, number);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarAtvEconomica(String intBanco, String intPeriodicidade) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarAtvEconomica(intBanco, intPeriodicidade);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarRegras(String intBanco, String intProduto, String intPeriodicidade)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarRegras(intBanco, intProduto, intPeriodicidade);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarTipoAgrupamento(String intBanco, String intProduto, String intPeriodicidade)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarTipoAgrupamento(intBanco, intProduto, intPeriodicidade);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirAgencia(String intCodBancoSelecionado, String intCodAgSelecionada, String TpAgrupaTruncado,
			String strUsuario, String dblValor) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.incluirAgencia(intCodBancoSelecionado, intCodAgSelecionada, TpAgrupaTruncado, strUsuario, dblValor);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarAgencia(String intCodBancoSelecionado, String intCodAgSelecionada, String TpAgrupaTruncado,
			String strUsuario, String dblValor) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.alterarAgencia(intCodBancoSelecionado, intCodAgSelecionada, TpAgrupaTruncado, strUsuario, dblValor);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirApoio(String intCodTabelaSelecionada, String strCodItem, String strDescricao,
			String strDescResumida, String strStatus, String strUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.incluirApoio(intCodTabelaSelecionada, strCodItem, strDescricao, strDescResumida, strStatus, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarApoio(String intCodTabelaSelecionada, String strCodItem, String strDescricao,
			String strDescResumida, String strStatus, String strUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.alterarApoio(intCodTabelaSelecionada, strCodItem, strDescricao, strDescResumida, strStatus, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirAtividadeEconomica(String intCodBancoSelecionado, String intCodPeriododSelecionada,
			String intAtvSelecionada, String strUsuario, String strDescricao) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.incluirAtividadeEconomica(intCodBancoSelecionado, intCodPeriododSelecionada, intAtvSelecionada, strUsuario, strDescricao);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String carregaCombo(String intCodBancoSelecionado) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.carregaCombo(intCodBancoSelecionado);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirCtrlProcessamento(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdutoSelecionada, String auxData, String auxDataAnt,
			String strDescAplicativo, String strUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.incluirCtrlProcessamento(intCodBancoSelecionado, intCodAplicSelecionada, intCodPeriododSelecionada, intCodProdutoSelecionada, auxData, auxDataAnt, strDescAplicativo, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarCtrlProcessamento(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdutoSelecionada, String auxData, String auxDataAnt,
			String strDescAplicativo, String strUsuario, String strStatus) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.alterarCtrlProcessamento(intCodBancoSelecionado, intCodAplicSelecionada, intCodPeriododSelecionada, intCodProdutoSelecionada, auxData, auxDataAnt, strDescAplicativo, strUsuario, strStatus);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String recuperaProduto(String intCodBancoSelecionado) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.recuperaProduto(intCodBancoSelecionado);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarFiltroSensib(String codTabela, String strCodItem, String strDescricao, String strDescResumida,
			String strStatus, String strUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.alterarFiltroSensib(codTabela, strCodItem, strDescricao, strDescResumida, strStatus, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirPais(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intPaisSelecionado, String intTipoPaisSelecionado,
			String strUsuario, String strDescPais) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.incluirPais(intCodBancoSelecionado, intCodProdSelecionada, intCodPeriododSelecionada, intPaisSelecionado, intTipoPaisSelecionado, strUsuario, strDescPais);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarPais(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intPaisSelecionado, String intTipoPaisSelecionado,
			String strUsuario, String strDescPais) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.alterarPais(intCodBancoSelecionado, intCodProdSelecionada, intCodPeriododSelecionada, intPaisSelecionado, intTipoPaisSelecionado, strUsuario, strDescPais);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String recuperaPaisesTipo() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.recuperaPaisesTipo();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirReceptores(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodSegmentoSelecionado, String intSequencia, String strNomeRecepItem, String strPrefEmailItem,
			String intCodSufixoSelecionado, String intCodTpEnvioSelecionado, String strUsuario)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.incluirReceptores(intCodBancoSelecionado, intCodProdSelecionada, intCodSegmentoSelecionado, intSequencia, strNomeRecepItem, strPrefEmailItem, intCodSufixoSelecionado, intCodTpEnvioSelecionado, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarReceptores(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodSegmentoSelecionado, String sequencia, String strNomeRecepItem, String strPrefEmailItem,
			String intCodSufixoSelecionado, String intCodTpEnvioSelecionado, String strUsuario)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.alterarReceptores(intCodBancoSelecionado, intCodProdSelecionada, intCodSegmentoSelecionado, sequencia, strNomeRecepItem, strPrefEmailItem, intCodSufixoSelecionado, intCodTpEnvioSelecionado, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarSegmSufTpEnvio(String intCodBancoSelecionado) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarSegmSufTpEnvio(intCodBancoSelecionado);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String verificaStatusProduto(String intCodBancoSelecionado) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.verificaStatusProduto(intCodBancoSelecionado);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String recuperaTpHistAtvOcup(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipo1, String intTipo2, String intTipo3)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.recuperaTpHistAtvOcup(intCodBancoSelecionado, intCodProdSelecionada, intCodPeriododSelecionada, intTipo1, intTipo2, intTipo3);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String recuperaAtvOcup(String intCodBancoSelecionado) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.recuperaAtvOcup(intCodBancoSelecionado);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipo, String strUsuario, String strDescAgrupamento)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.incluirTpAgrupamento(intCodBancoSelecionado, intCodProdSelecionada, intCodPeriododSelecionada, intTipo, strUsuario, strDescAgrupamento);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String recuperarTipoCombo(String banco) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.recuperarTipoCombo(banco);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirValorTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipoSelecionado, String dblValor, String strUsuario,
			String strDescricao) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.incluirValorTpAgrupamento(intCodBancoSelecionado, intCodProdSelecionada, intCodPeriododSelecionada, intTipoSelecionado, dblValor, strUsuario, strDescricao);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarValorTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipoSelecionado, String dblValor, String strUsuario,
			String strDescricao) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.incluirValorTpAgrupamento(intCodBancoSelecionado, intCodProdSelecionada, intCodPeriododSelecionada, intTipoSelecionado, dblValor, strUsuario, strDescricao);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String excluirAgencia(String intCodBancoItem, String intCodAgenciaItem, String strTipoAgrupamento,
			String strUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.excluirAgencia(intCodBancoItem, intCodAgenciaItem, strTipoAgrupamento, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarBancoAgencia() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarBancoAgencia();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String excluirApoio(String intTabelaItem, String strCodItem, String strDescTot, String strDescRes,
			String strStatus, String strUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.excluirApoio(intTabelaItem, strCodItem, strDescTot, strDescRes, strStatus, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String excluirAtividadeEconomica(String intCodBancoItem, String intCodPeriodoItem, String intCodAtividade,
			String strUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.excluirAtividadeEconomica(intCodBancoItem, intCodPeriodoItem, intCodAtividade, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarBancoPeriodo() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarBancoPeriodo();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarBancoPeriodoProduto() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarBancoPeriodoProduto();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String recuperaCtrlProcessamento(String banco, String aplicativo, String periodo)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.recuperaCtrlProcessamento(banco, aplicativo, periodo);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarBanco() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarBanco();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarFiltroSensibilizacao(String intCodBancoSelecionado, String dblCodRetorno,
			String strMsgRetorno) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarFiltroSensibilizacao(intCodBancoSelecionado, dblCodRetorno, strMsgRetorno);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String excluirPais(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem,
			String intCDHISTItem, String intTPHISTItem, String strUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.excluirPais(intCodBancoItem, intCodProdItem, intCodPeriodoItem, intCDHISTItem, intTPHISTItem, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarPaises(String banco, String produto, String periodo) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarPaises(banco, produto, periodo);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String excluirReceptores(String intCodBancoItem, String intCodProdItem, String intCodSegmentoItem,
			String intSequencia, String strNomeRecepItem, String strPrefEmailItem, String intCodSufixoEmailItem,
			String strTipoEnvioItem, String strUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.excluirReceptores(intCodBancoItem, intCodProdItem, intCodSegmentoItem, intSequencia, strNomeRecepItem, strPrefEmailItem, intCodSufixoEmailItem, strTipoEnvioItem, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarBancoProduto() throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarBancoProduto();
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirSensibilizacao(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.incluirSensibilizacao(intCodBancoSelecionado, intCodProdSelecionada, intCodPeriododSelecionada, intCodMesSelecionado, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarSensibilizacao(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.alterarSensibilizacao(intCodBancoSelecionado, intCodProdSelecionada, intCodPeriododSelecionada, intCodMesSelecionado, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarSensibilizacao(String banco, String produto, String periodo) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarSensibilizacao(banco, produto, periodo);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String incluirTpValorPerfil(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.incluirTpValorPerfil(intCodBancoSelecionado, intCodProdSelecionada, intCodPeriododSelecionada, intCodMesSelecionado, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String alterarTpValorPerfil(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario)
			throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.alterarTpValorPerfil(intCodBancoSelecionado, intCodProdSelecionada, intCodPeriododSelecionada, intCodMesSelecionado, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarTpValorPerfil(String banco, String produto, String periodo) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarTpValorPerfil(banco, produto, periodo);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String excluirTipoAgrupamento(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem,
			String intCDHISTItem, String intTPHISTItem, String strUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.excluirTipoAgrupamento(intCodBancoItem, intCodProdItem, intCodPeriodoItem, intCDHISTItem, intTPHISTItem, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String excluirValorTpAgrupamento(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem,
			String intTPHISTItem, String strUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.excluirValorTpAgrupamento(intCodBancoItem, intCodProdItem, intCodPeriodoItem, intTPHISTItem, strUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

	@WebMethod
	public String consultarValorTpAgrupamento(String banco, String produto, String periodo) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = parametros.consultarValorTpAgrupamento(banco, produto, periodo);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	}

}
