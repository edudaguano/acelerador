package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQS0040")
public class NQS0040 {
@PsFieldString(name="COENTID", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COENTID;
@PsFieldString(name="NOBANCO", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOBANCO;
@PsFieldString(name="TPDOCTO", length=2, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPDOCTO;
@PsFieldString(name="NUDOCTO", length=15, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUDOCTO;
@PsFieldString(name="NOCLIEN", length=40, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOCLIEN;
@PsFieldString(name="NUAGENC", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUAGENC;
@PsFieldString(name="NOAGENC", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NOAGENC;
@PsFieldString(name="NUCONTA", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUCONTA;

public String getCOENTID() {
 return COENTID;
}
public void setCOENTID(String COENTID) {
 this.COENTID = COENTID;
}

public String getNOBANCO() {
 return NOBANCO;
}
public void setNOBANCO(String NOBANCO) {
 this.NOBANCO = NOBANCO;
}

public String getTPDOCTO() {
 return TPDOCTO;
}
public void setTPDOCTO(String TPDOCTO) {
 this.TPDOCTO = TPDOCTO;
}

public String getNUDOCTO() {
 return NUDOCTO;
}
public void setNUDOCTO(String NUDOCTO) {
 this.NUDOCTO = NUDOCTO;
}

public String getNOCLIEN() {
 return NOCLIEN;
}
public void setNOCLIEN(String NOCLIEN) {
 this.NOCLIEN = NOCLIEN;
}

public String getNUAGENC() {
 return NUAGENC;
}
public void setNUAGENC(String NUAGENC) {
 this.NUAGENC = NUAGENC;
}

public String getNOAGENC() {
 return NOAGENC;
}
public void setNOAGENC(String NOAGENC) {
 this.NOAGENC = NOAGENC;
}

public String getNUCONTA() {
 return NUCONTA;
}
public void setNUCONTA(String NUCONTA) {
 this.NUCONTA = NUCONTA;
}


}
