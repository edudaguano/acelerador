package com.altec.bsbr.app.jab.nq.dao;

public interface AlertaCliAnRespDao{ 
public String versao(); 
public String recuperarPergunta(String strCOENTID,String strCOALERT); 
public String consultarHistorico(String strCOENTID,String strCOALERT,String strDTCOMIT,String strNUSEQUE); 
public String consultarJustificativa(String strCOENTI,String strCOALER); 
public String consultarEnquadramento(String strCOENTID,String strCOALERT,String strCOORGEN,String strCOENQSI); 
public String consultaOrgaoEnquadramento(String strCORGENQ); 
}

