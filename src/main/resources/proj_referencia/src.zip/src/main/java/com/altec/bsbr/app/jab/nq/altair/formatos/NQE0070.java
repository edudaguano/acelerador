package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0070")
public class NQE0070 {
@PsFieldNumber(name="CDENTID", length=4, defaultValue = "0" )
private Integer CDENTID;
@PsFieldString(name="CDALERT", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDALERT;
@PsFieldNumber(name="CDOREN1", length=2, defaultValue = "0" )
private Integer CDOREN1;
@PsFieldString(name="CDENQ01", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDENQ01;
@PsFieldString(name="CDUSRES", length=8, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDUSRES;
public Integer getCDENTID() {
 return CDENTID;
}
public void setCDENTID(Integer cDENTID) {
CDENTID = cDENTID;
}
public String getCDALERT() {
 return CDALERT;
}
public void setCDALERT(String CDALERT) {
 this.CDALERT = CDALERT;
}
public Integer getCDOREN1() {
 return CDOREN1;
}
public void setCDOREN1(Integer cDOREN1) {
CDOREN1 = cDOREN1;
}
public String getCDENQ01() {
 return CDENQ01;
}
public void setCDENQ01(String CDENQ01) {
 this.CDENQ01 = CDENQ01;
}

public String getCDUSRES() {
 return CDUSRES;
}
public void setCDUSRES(String CDUSRES) {
 this.CDUSRES = CDUSRES;
}


}
