package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCETB05LegadoResponse {
	
// -*-NQCETB05
//                                                                          
//         01     NQCETB05-ENTRADA.                                         
//                                                                          
	@FixedLenghtField(position = 2195, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5E_NM_PROG;//           05   NQCETB5E-NM-PROG              PIC  X(008).                

//        *       NOME DO PROGRAMA CHAMADO                                  
//                                                                          
	@FixedLenghtField(position = 2196, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5E_NM_AREA;//           05   NQCETB5E-NM-AREA              PIC  X(008).                

//        *       NOME DA AREA DE TS                                        
//                                                                          
	@FixedLenghtField(position = 2197, lenght = 2, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5E_SG_FCAO;//           05   NQCETB5E-SG-FCAO              PIC  X(002).                

//        *       FUNCAO A SER EXECUTADA                                    
//        *       C = CONSULTAR                                             
//        *       L = LISTAR                                                
//        *       I = INCLUIR                                               
//        *       A = ALTERAR                                               
//        *       E = EXCLUIR                                               
//                                                                          
	@FixedLenghtField(position = 2198, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB5E_QT_TAMA_AREA;//           05   NQCETB5E-QT-TAMA-AREA         PIC  9(007).                

//        *       TAMANHO DA AREA DE TS                                     
//                                                                          
	@FixedLenghtField(position = 2199, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5E_CD_USUA;//           05   NQCETB5E-CD-USUA              PIC  X(008).                

//        *       CODIGO DO USUARIO                                         
//                                                                          
	@FixedLenghtField(position = 2200, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB5E_NR_SEQU_DOMI_OPER;//           05   NQCETB5E-NR-SEQU-DOMI-OPER    PIC  9(004).                

//        *       NUMERO DE SEQUENCIA DO DOMINIO                            
//                                                                          
	@FixedLenghtField(position = 2201, lenght = 20, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5E_VL_PARM_DOMI_OPER;//           05   NQCETB5E-VL-PARM-DOMI-OPER    PIC  X(020).                

//        *       VALOR DO DOMINIO                                          
//                                                                          
	@FixedLenghtField(position = 2202, lenght = 40, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5E_DS_PARM_DOMI_OPER;//           05   NQCETB5E-DS-PARM-DOMI-OPER    PIC  X(040).                

//        *       DESCRICAO DO DOMINIO                                      
//                                                                          
	@FixedLenghtField(position = 2203, lenght = 2, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5E_TP_USO_DOMI_OPER;//           05   NQCETB5E-TP-USO-DOMI-OPER     PIC  X(002).                

//        *       TIPO DE USO DO DOMINIO                                    
//                                                                          
	@FixedLenghtField(position = 2204, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5E_IN_DOMI_OPER_ATIV;//           05   NQCETB5E-IN-DOMI-OPER-ATIV    PIC  X(001).                

//        *       INDICADOR DE DOMINIO ATIVO                                
//                                                                          
//         01     NQCETB05-SAIDA.                                           
//                                                                          
//        *       AREA DE MENSAGEM                                          
//                                                                          
	@FixedLenghtField(position = 2205, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB5S_MENS_LEN;//          03    NQCETB5S-MENS-LEN      COMP   PIC  S9(04) VALUE +83.      

//          03    NQCETB5S-MENS.                                            
	@FixedLenghtField(position = 2206, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB5S_RETORNO;//           05   NQCETB5S-RETORNO              PIC  9(003) VALUE ZEROS.    

	@FixedLenghtField(position = 2207, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5S_MENSAGEM;//           05   NQCETB5S-MENSAGEM             PIC  X(080) VALUE SPACES.   

//                                                                          
//        *       AREA DE DADOS                                             
//                                                                          
	@FixedLenghtField(position = 2208, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB5S_DATA_LEN;//          03    NQCETB5S-DATA-LEN      COMP   PIC  S9(04) VALUE +107.     

//          03    NQCETB5S-DATA.                                            
	@FixedLenghtField(position = 2209, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB5S_NR_SEQU_DOMI_OPER;//           05   NQCETB5S-NR-SEQU-DOMI-OPER    PIC  9(004).                

//        *       NUMERO DE SEQUENCIA DO DOMINIO                            
//                                                                          
	@FixedLenghtField(position = 2210, lenght = 20, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5S_VL_PARM_DOMI_OPER;//           05   NQCETB5S-VL-PARM-DOMI-OPER    PIC  X(020).                

//        *       VALOR DO DOMINIO                                          
//                                                                          
	@FixedLenghtField(position = 2211, lenght = 40, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5S_DS_PARM_DOMI_OPER;//           05   NQCETB5S-DS-PARM-DOMI-OPER    PIC  X(040).                

//        *       DESCRICAO DO DOMINIO                                      
//                                                                          
	@FixedLenghtField(position = 2212, lenght = 2, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5S_TP_USO_DOMI_OPER;//           05   NQCETB5S-TP-USO-DOMI-OPER     PIC  X(002).                

//        *       TIPO DE USO DO DOMINIO                                    
//                                                                          
	@FixedLenghtField(position = 2213, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5S_IN_DOMI_OPER_ATIV;//           05   NQCETB5S-IN-DOMI-OPER-ATIV    PIC  X(001).                

//        *       INDICADOR DE DOMINIO ATIVO                                
//                                                                          
	@FixedLenghtField(position = 2214, lenght = 40, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB5S_DS_CNTD;//           05   NQCETB5S-DS-CNTD              PIC  X(040).                

//        *       DESCRICAO DO CONTEUDO                                     
	public NQCETB05LegadoResponse() { }
	public NQCETB05LegadoResponse(String nqcetb5e_nm_prog, String nqcetb5e_nm_area, String nqcetb5e_sg_fcao, Long nqcetb5e_qt_tama_area, String nqcetb5e_cd_usua, Long nqcetb5e_nr_sequ_domi_oper, String nqcetb5e_vl_parm_domi_oper, String nqcetb5e_ds_parm_domi_oper, String nqcetb5e_tp_uso_domi_oper, String nqcetb5e_in_domi_oper_ativ, Long nqcetb5s_nr_sequ_domi_oper, String nqcetb5s_vl_parm_domi_oper, String nqcetb5s_ds_parm_domi_oper, String nqcetb5s_tp_uso_domi_oper, String nqcetb5s_in_domi_oper_ativ, String nqcetb5s_ds_cntd) { 		this.NQCETB5E_NM_PROG = nqcetb5e_nm_prog;
		this.NQCETB5E_NM_AREA = nqcetb5e_nm_area;
		this.NQCETB5E_SG_FCAO = nqcetb5e_sg_fcao;
		this.NQCETB5E_QT_TAMA_AREA = nqcetb5e_qt_tama_area;
		this.NQCETB5E_CD_USUA = nqcetb5e_cd_usua;
		this.NQCETB5E_NR_SEQU_DOMI_OPER = nqcetb5e_nr_sequ_domi_oper;
		this.NQCETB5E_VL_PARM_DOMI_OPER = nqcetb5e_vl_parm_domi_oper;
		this.NQCETB5E_DS_PARM_DOMI_OPER = nqcetb5e_ds_parm_domi_oper;
		this.NQCETB5E_TP_USO_DOMI_OPER = nqcetb5e_tp_uso_domi_oper;
		this.NQCETB5E_IN_DOMI_OPER_ATIV = nqcetb5e_in_domi_oper_ativ;
		/*this.NQCETB5S_MENS_LEN = +83;
		this.NQCETB5S_RETORNO = ZEROS;
		this.NQCETB5S_MENSAGEM = SPACES;
		this.NQCETB5S_DATA_LEN = +107;*/
		this.NQCETB5S_NR_SEQU_DOMI_OPER = nqcetb5s_nr_sequ_domi_oper;
		this.NQCETB5S_VL_PARM_DOMI_OPER = nqcetb5s_vl_parm_domi_oper;
		this.NQCETB5S_DS_PARM_DOMI_OPER = nqcetb5s_ds_parm_domi_oper;
		this.NQCETB5S_TP_USO_DOMI_OPER = nqcetb5s_tp_uso_domi_oper;
		this.NQCETB5S_IN_DOMI_OPER_ATIV = nqcetb5s_in_domi_oper_ativ;
		this.NQCETB5S_DS_CNTD = nqcetb5s_ds_cntd; 
	}
	public String getNQCETB5E_NM_PROG() { return this.NQCETB5E_NM_PROG; }
	public String getNQCETB5E_NM_AREA() { return this.NQCETB5E_NM_AREA; }
	public String getNQCETB5E_SG_FCAO() { return this.NQCETB5E_SG_FCAO; }
	public Long getNQCETB5E_QT_TAMA_AREA() { return this.NQCETB5E_QT_TAMA_AREA; }
	public String getNQCETB5E_CD_USUA() { return this.NQCETB5E_CD_USUA; }
	public Long getNQCETB5E_NR_SEQU_DOMI_OPER() { return this.NQCETB5E_NR_SEQU_DOMI_OPER; }
	public String getNQCETB5E_VL_PARM_DOMI_OPER() { return this.NQCETB5E_VL_PARM_DOMI_OPER; }
	public String getNQCETB5E_DS_PARM_DOMI_OPER() { return this.NQCETB5E_DS_PARM_DOMI_OPER; }
	public String getNQCETB5E_TP_USO_DOMI_OPER() { return this.NQCETB5E_TP_USO_DOMI_OPER; }
	public String getNQCETB5E_IN_DOMI_OPER_ATIV() { return this.NQCETB5E_IN_DOMI_OPER_ATIV; }
	public Long getNQCETB5S_MENS_LEN() { return this.NQCETB5S_MENS_LEN; }
	public Long getNQCETB5S_RETORNO() { return this.NQCETB5S_RETORNO; }
	public String getNQCETB5S_MENSAGEM() { return this.NQCETB5S_MENSAGEM; }
	public Long getNQCETB5S_DATA_LEN() { return this.NQCETB5S_DATA_LEN; }
	public Long getNQCETB5S_NR_SEQU_DOMI_OPER() { return this.NQCETB5S_NR_SEQU_DOMI_OPER; }
	public String getNQCETB5S_VL_PARM_DOMI_OPER() { return this.NQCETB5S_VL_PARM_DOMI_OPER; }
	public String getNQCETB5S_DS_PARM_DOMI_OPER() { return this.NQCETB5S_DS_PARM_DOMI_OPER; }
	public String getNQCETB5S_TP_USO_DOMI_OPER() { return this.NQCETB5S_TP_USO_DOMI_OPER; }
	public String getNQCETB5S_IN_DOMI_OPER_ATIV() { return this.NQCETB5S_IN_DOMI_OPER_ATIV; }
	public String getNQCETB5S_DS_CNTD() { return this.NQCETB5S_DS_CNTD; }
	public void setNQCETB5E_NM_PROG(String nqcetb5e_nm_prog) { this.NQCETB5E_NM_PROG = nqcetb5e_nm_prog; }
	public void setNQCETB5E_NM_AREA(String nqcetb5e_nm_area) { this.NQCETB5E_NM_AREA = nqcetb5e_nm_area; }
	public void setNQCETB5E_SG_FCAO(String nqcetb5e_sg_fcao) { this.NQCETB5E_SG_FCAO = nqcetb5e_sg_fcao; }
	public void setNQCETB5E_QT_TAMA_AREA(Long nqcetb5e_qt_tama_area) { this.NQCETB5E_QT_TAMA_AREA = nqcetb5e_qt_tama_area; }
	public void setNQCETB5E_CD_USUA(String nqcetb5e_cd_usua) { this.NQCETB5E_CD_USUA = nqcetb5e_cd_usua; }
	public void setNQCETB5E_NR_SEQU_DOMI_OPER(Long nqcetb5e_nr_sequ_domi_oper) { this.NQCETB5E_NR_SEQU_DOMI_OPER = nqcetb5e_nr_sequ_domi_oper; }
	public void setNQCETB5E_VL_PARM_DOMI_OPER(String nqcetb5e_vl_parm_domi_oper) { this.NQCETB5E_VL_PARM_DOMI_OPER = nqcetb5e_vl_parm_domi_oper; }
	public void setNQCETB5E_DS_PARM_DOMI_OPER(String nqcetb5e_ds_parm_domi_oper) { this.NQCETB5E_DS_PARM_DOMI_OPER = nqcetb5e_ds_parm_domi_oper; }
	public void setNQCETB5E_TP_USO_DOMI_OPER(String nqcetb5e_tp_uso_domi_oper) { this.NQCETB5E_TP_USO_DOMI_OPER = nqcetb5e_tp_uso_domi_oper; }
	public void setNQCETB5E_IN_DOMI_OPER_ATIV(String nqcetb5e_in_domi_oper_ativ) { this.NQCETB5E_IN_DOMI_OPER_ATIV = nqcetb5e_in_domi_oper_ativ; }
	public void setNQCETB5S_MENS_LEN(Long nqcetb5s_mens_len) { this.NQCETB5S_MENS_LEN = nqcetb5s_mens_len; }
	public void setNQCETB5S_RETORNO(Long nqcetb5s_retorno) { this.NQCETB5S_RETORNO = nqcetb5s_retorno; }
	public void setNQCETB5S_MENSAGEM(String nqcetb5s_mensagem) { this.NQCETB5S_MENSAGEM = nqcetb5s_mensagem; }
	public void setNQCETB5S_DATA_LEN(Long nqcetb5s_data_len) { this.NQCETB5S_DATA_LEN = nqcetb5s_data_len; }
	public void setNQCETB5S_NR_SEQU_DOMI_OPER(Long nqcetb5s_nr_sequ_domi_oper) { this.NQCETB5S_NR_SEQU_DOMI_OPER = nqcetb5s_nr_sequ_domi_oper; }
	public void setNQCETB5S_VL_PARM_DOMI_OPER(String nqcetb5s_vl_parm_domi_oper) { this.NQCETB5S_VL_PARM_DOMI_OPER = nqcetb5s_vl_parm_domi_oper; }
	public void setNQCETB5S_DS_PARM_DOMI_OPER(String nqcetb5s_ds_parm_domi_oper) { this.NQCETB5S_DS_PARM_DOMI_OPER = nqcetb5s_ds_parm_domi_oper; }
	public void setNQCETB5S_TP_USO_DOMI_OPER(String nqcetb5s_tp_uso_domi_oper) { this.NQCETB5S_TP_USO_DOMI_OPER = nqcetb5s_tp_uso_domi_oper; }
	public void setNQCETB5S_IN_DOMI_OPER_ATIV(String nqcetb5s_in_domi_oper_ativ) { this.NQCETB5S_IN_DOMI_OPER_ATIV = nqcetb5s_in_domi_oper_ativ; }
	public void setNQCETB5S_DS_CNTD(String nqcetb5s_ds_cntd) { this.NQCETB5S_DS_CNTD = nqcetb5s_ds_cntd; }
	
}