package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface OperacoesACService { 

	public String operacoesGC(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException;

	public String operacoesMP(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCartaoCred, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException;

	public String operacoesUG(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strDtFormaliz, String strNumContrato, String strNumOper, String strTpOperacao,
			String strCodUser) throws BusinessException;

	public String operacoesLI(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strDtFormaliz, String strNumContrato, String strNumOper, String strCNPJLoji,
			String strTpOperacao, String strCodUser) throws BusinessException;

	public String operacoesKM(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumTitulo, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException;

	public String operacoesOX(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumProposta, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException;

	public String operacoesEZ(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumBoleto, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException;

	public String operacoesAR(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumOperacao, String strTpOperacao, String strCodUser) throws BusinessException;

	public String operacoesGR(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException;

	public String operacoesYZ(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws BusinessException;

	public String operacoesVC(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCtaDebito, String strNumProposta, String strNumApolice, String strNumOper,
			String strTpOperacao, String strCodUser) throws BusinessException;

	public String operacoesIY(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCtaDebito, String strNumProposta, String strNumApolice, String strNumOper,
			String strTpOperacao, String strCodUser) throws BusinessException;

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws BusinessException;

	public String fnAddCaracterCliente(String Vlr, String Tp, String Tam) throws BusinessException;

	public String dataAlta(String dtBaixa) throws BusinessException;
	 
}
