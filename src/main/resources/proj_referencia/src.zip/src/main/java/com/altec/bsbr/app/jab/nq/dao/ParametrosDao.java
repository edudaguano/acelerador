package com.altec.bsbr.app.jab.nq.dao;

public interface ParametrosDao {
	
	public String confirmarRegras(String acao, String intProduto, String intCodBanco, String intPeriodo, String intAgrupa, String lngAtividade, String lngOcupacao, 
	String intSegmento, String dblValor, String strUsuario);
	
	public String incluirValorOpSensib(String intCodBancoSelecionado, String intCodAplicSelecionada, String intCodPeriododSelecionada, String intCodProdSelecionada, String dblValor,
	String strUsuario);
	
	public String alterarValorOpSensib(String intCodBancoSelecionado, String intCodAplicSelecionada, String intCodPeriododSelecionada, String intCodProdSelecionada, 
	String dblValor, String strUsuario);
	
	public String consultarBancoPeriodoProdAplic();
	
	public String consultarValorOpSensivel(String intBanco, String intAplicativo, String intPeriodo, String intProduto);
	
	public String consultarAgencias(String intBanco, String intAgencia, String strFuncao);
	
	public String consultarApoio(String intTabela, String number);
	
	public String consultarAtvEconomica(String intBanco,String intPeriodicidade);
	
	public String consultarRegras(String intBanco, String intProduto, String intPeriodicidade);
	
	public String consultarTipoAgrupamento(String intBanco, String intProduto, String intPeriodicidade);
	
	public String incluirAgencia(String intCodBancoSelecionado, String intCodAgSelecionada, String TpAgrupaTruncado, String strUsuario, String dblValor);
	
	public String alterarAgencia(String intCodBancoSelecionado, String intCodAgSelecionada, String TpAgrupaTruncado, String strUsuario, String dblValor);
    
    public String incluirApoio(String intCodTabelaSelecionada, String strCodItem, String strDescricao, String strDescResumida, String strStatus, String strUsuario);

    public String alterarApoio(String intCodTabelaSelecionada, String strCodItem, String strDescricao, String strDescResumida, String strStatus, String strUsuario);
    
    public String incluirAtividadeEconomica(String intCodBancoSelecionado, String intCodPeriododSelecionada, String intAtvSelecionada, String strUsuario, String strDescricao);
	
    public String carregaCombo(String intCodBancoSelecionado);
	
    public String incluirCtrlProcessamento(String intCodBancoSelecionado, String intCodAplicSelecionada, String intCodPeriododSelecionada, String intCodProdutoSelecionada, String auxData,
    String auxDataAnt, String strDescAplicativo, String strUsuario);
	 
	public String alterarCtrlProcessamento(String intCodBancoSelecionado, String intCodAplicSelecionada, String intCodPeriododSelecionada, String intCodProdutoSelecionada, String auxData,
	String auxDataAnt, String strDescAplicativo, String strUsuario, String strStatus);
		
	public String recuperaProduto(String intCodBancoSelecionado);
		
	public String alterarFiltroSensib(String codTabela, String strCodItem, String strDescricao, String strDescResumida, String strStatus, String strUsuario);
		
	public String incluirPais(String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada, String intPaisSelecionado, /*right("0000000000" & intPaisSelecionado,10), _*/
	String intTipoPaisSelecionado, /*right("000" & intTipoPaisSelecionado,3), _*/
	String strUsuario, String strDescPais);
        
    public String alterarPais(String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada, String intPaisSelecionado,/*right("0000000000" & intPaisSelecionado,10),*/
	String intTipoPaisSelecionado, /*right("000" & intTipoPaisSelecionado,3),*/
	String strUsuario, String strDescPais);
    
    public String recuperaPaisesTipo();
    
    public String incluirReceptores(String intCodBancoSelecionado, String intCodProdSelecionada, String intCodSegmentoSelecionado,/*right(intCodSegmentoSelecionado,3), */
    String intSequencia, String strNomeRecepItem, String strPrefEmailItem, String intCodSufixoSelecionado, String intCodTpEnvioSelecionado, String strUsuario);
	
	public String alterarReceptores(String intCodBancoSelecionado, String intCodProdSelecionada, String intCodSegmentoSelecionado, String sequencia, String strNomeRecepItem, String strPrefEmailItem, 
	String intCodSufixoSelecionado, String intCodTpEnvioSelecionado, String strUsuario);
	
	public String consultarSegmSufTpEnvio(String intCodBancoSelecionado);
	
	public String verificaStatusProduto(String intCodBancoSelecionado);
	
	public String recuperaTpHistAtvOcup(String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada, String intTipo1, String intTipo2, String intTipo3);
		
	public String recuperaAtvOcup(String intCodBancoSelecionado);
		
	public String incluirTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada, String intTipo, String strUsuario, String strDescAgrupamento);
		
	public String recuperarTipoCombo(String banco);
		
	public String incluirValorTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada, String intTipoSelecionado, String dblValor, String strUsuario,
	String strDescricao);
	
	public String alterarValorTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada, String intTipoSelecionado, String dblValor, String strUsuario,
	String strDescricao);
	
	public String excluirAgencia(String intCodBancoItem, String intCodAgenciaItem, String strTipoAgrupamento, String strUsuario);
	 
	public String consultarBancoAgencia();
	 
	public String excluirApoio(String intTabelaItem, String strCodItem, String strDescTot, String strDescRes, String strStatus, String strUsuario);
	 
	public String excluirAtividadeEconomica(String intCodBancoItem, String intCodPeriodoItem, String intCodAtividade, String strUsuario);
     
    public String consultarBancoPeriodo();
	
    public String consultarBancoPeriodoProduto();

    public String recuperaCtrlProcessamento(String banco,String aplicativo, String periodo);
     
    public String consultarBanco();
     
    public String consultarFiltroSensibilizacao(String intCodBancoSelecionado, String dblCodRetorno, String strMsgRetorno);
         
	public String excluirPais(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem, String intCDHISTItem, String intTPHISTItem, String strUsuario);
			  
	public String consultarPaises(String banco, String produto, String periodo);
	  
	public String excluirReceptores(String intCodBancoItem, String intCodProdItem, String intCodSegmentoItem, String intSequencia, String strNomeRecepItem, String strPrefEmailItem, String intCodSufixoEmailItem,
	String strTipoEnvioItem, String strUsuario);
	 
	public String consultarBancoProduto();
	    
	public String incluirSensibilizacao(String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario);
			  
	public String alterarSensibilizacao(String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario);
		
	public String consultarSensibilizacao(String banco, String produto, String periodo);

	public String incluirTpValorPerfil(String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario);
	
	public String alterarTpValorPerfil(String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario);

	public String consultarTpValorPerfil(String banco, String produto, String periodo);
	
	public String excluirTipoAgrupamento(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem, String intCDHISTItem, String intTPHISTItem, String strUsuario);
		  
	public String excluirValorTpAgrupamento(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem, String intTPHISTItem, String strUsuario); /*Left(Trim(strUsuario),8),*/
		 
	public String consultarValorTpAgrupamento(String banco, String produto, String periodo);			 
				
}
