package com.altec.bsbr.app.jab.nq.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.altec.bsbr.app.jab.nq.dao.ParamAuditoriaDao;
import com.altec.bsbr.app.jab.nq.service.ParamAuditoriaService;
import com.altec.bsbr.fw.BusinessException;

@Service
public class ParamAuditoriaServiceImpl implements ParamAuditoriaService {
	private final Logger LOGGER = LoggerFactory.getLogger(ParamAuditoriaServiceImpl.class);

	@Autowired
	private ParamAuditoriaDao paramAuditoria;

	public String listarParametro(String strCodSist, String strCodUser) throws BusinessException{
		return paramAuditoria.listarParametro(strCodSist, strCodUser);
	}

	public String consultarParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodUser) throws BusinessException{
		return paramAuditoria.consultarParametro(strCodSist, strCodCamp, strCodParam, strCodUser);
	}

	public String incluirParametro(String strCodSist, String strCodCamp, String strCodDomin, String strCntd1,
			String strCntd2, String strCodList, String strDesc, String strCodUser, String strDtIncAlt, String strAtivo) throws BusinessException{
		return paramAuditoria.incluirParametro(strCodSist, strCodCamp, strCodDomin, strCntd1, strCntd2, strCodList, strDesc, strCodUser, strDtIncAlt, strAtivo);
	}

	public String alterarParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodDomin,
			String strCntd1, String strCntd2, String strCodList, String strDesc, String strCodUser, String strDtIncAlt,
			String strAtivo) throws BusinessException {
		return paramAuditoria.alterarParametro(strCodSist, strCodCamp, strCodParam, strCodDomin, strCntd1, strCntd2, strCodList, strDesc, strCodUser, strDtIncAlt, strAtivo);
	}

	public String excluirParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodUser) throws BusinessException{
		return paramAuditoria.excluirParametro(strCodSist, strCodCamp, strCodParam, strCodUser);
	}

	public String inicializarinputArea(String TNQ_NQAT2006_NQCETB06_INPUT_AREA) throws BusinessException{
		return paramAuditoria.inicializarinputArea(TNQ_NQAT2006_NQCETB06_INPUT_AREA);
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws BusinessException{
		return paramAuditoria.fnAddCaracter(Vlr, Tp, Tam);
	}
}
