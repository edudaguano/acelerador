package com.altec.bsbr.app.jab.nq.dao;

public interface AlertaCliDdsCtpDao {
	public String versao();

	public String consultarContraparte(String strCOENTID, String strCOALERT, String strCDCENAR, String strCDDETIN,
			String strCDOCOPE, String strNUCNTR);
}
