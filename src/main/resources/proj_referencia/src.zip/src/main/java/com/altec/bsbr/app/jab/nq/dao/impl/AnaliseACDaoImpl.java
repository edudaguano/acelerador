package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.AnaliseACDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB09LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB09AreaDados;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB09LegadoResponse;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB09MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class AnaliseACDaoImpl implements AnaliseACDao {
	
	private final Logger LOGGER = LoggerFactory.getLogger(AnaliseACDaoImpl.class);
	
	@Autowired
 	private JSONMapper jsonMapper;

	@Autowired
	private NQCETB09MessagingGateway NQCETB09service;
	
	
	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String consultarAnalises(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr, String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra, String strPeriodo, String strCodUser, String strFuncao) {
		String json = "";

		try {
			NQCETB09LegadoRequest req = new NQCETB09LegadoRequest();
			/* Exemplo de Retorno
			 * req.setNQCETB09_E_NM_AREA("NQAT2009");
			 * req.setNQCETB09_E_NM_PROG("NQAT2009");
			 * req.setNQCETB09_E_QT_TAMA_AREA(Long.valueOf(68));
			 * 
			 * req.setNQCETB09_E_NR_SEQU_SIST(Long.valueOf("0001")); //strCodSist
			 * req.setNQCETB09_E_CD_BANC_CLIE("0033");				 //strBanco
			 * req.setNQCETB09_E_CD_CLIE("00000010");				 //strCodCliente
			 * req.setNQCETB09_E_DT_OCOR("07.01.2009");				 //strDtOcorr
			 * req.setNQCETB09_E_IN_NOTI_UPLD("Não");				 //strNotUPLD
			 * req.setNQCETB09_E_IN_PARE_AREA_OPER("Não");			 //strNotUPLD
			 * req.setNQCETB09_E_IN_PARE_GERE("Não");				 //strParGer
			 * req.setNQCETB09_E_IN_PARE_UPLD("Não");				 //strParUPLD
			 * req.setNQCETB09_E_NR_SEQU_REGR(Long.valueOf("0001")); //strRegra
			 * req.setNQCETB09_E_TP_PERI("T");
			 * req.setNQCETB09_E_SG_FCAO("L2");                      //strFuncao   
			 * req.setNQCETB09_E_CD_USUA_ULTI_ALTR("X217323 ");      //strCodUser
			*/
			
			/*FIXO*/
			req.setNQCETB09_E_NM_AREA("NQAT2009");
			req.setNQCETB09_E_NM_PROG("NQAT2009");
			req.setNQCETB09_E_QT_TAMA_AREA(Long.valueOf(68));
			
			
			/*VARIAVEL*/
			req.setNQCETB09_E_NR_SEQU_SIST(Long.valueOf(strCodSist));
			req.setNQCETB09_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB09_E_CD_CLIE(strCodCliente);
			req.setNQCETB09_E_DT_OCOR(strDtOcorr);
			req.setNQCETB09_E_IN_NOTI_UPLD(strNotUPLD);
			req.setNQCETB09_E_IN_PARE_AREA_OPER(strParOper);
			req.setNQCETB09_E_IN_PARE_GERE(strParGer);
			req.setNQCETB09_E_IN_PARE_UPLD(strParUPLD);
			req.setNQCETB09_E_NR_SEQU_REGR(Long.valueOf(strRegra));
			req.setNQCETB09_E_TP_PERI(strPeriodo);
			req.setNQCETB09_E_SG_FCAO(strFuncao);
			req.setNQCETB09_E_CD_USUA_ULTI_ALTR(strCodUser);
			
			PsFormatDecoder decoder = new PsFormatDecoder();
			LegadoResult res = NQCETB09service.sendMessageLegado(req);
			List<NQCETB09AreaDados> ret = decoder.parseRetorno(res,NQCETB09AreaDados.class, 83, 151);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	public String listarPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser) {
		String json = "";

		try {
			NQCETB09LegadoRequest req = new NQCETB09LegadoRequest();
			req.setNQCETB09_E_NM_AREA("NQAT2009");
			req.setNQCETB09_E_NM_PROG("NQAT2009");
			req.setNQCETB09_E_QT_TAMA_AREA(Long.valueOf(68));
			req.setNQCETB09_E_SG_FCAO("L2");
			req.setNQCETB09_E_CD_USUA_ULTI_ALTR(strCodUser);
			req.setNQCETB09_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB09_E_CD_CLIE(strCodCliente);
			req.setNQCETB09_E_DT_OCOR(strDtOcorr);
			req.setNQCETB09_E_IN_NOTI_UPLD(strNotUPLD);
			req.setNQCETB09_E_IN_PARE_AREA_OPER(strParOper);
			req.setNQCETB09_E_IN_PARE_GERE(strParGer);
			req.setNQCETB09_E_IN_PARE_UPLD(strParUPLD);
			req.setNQCETB09_E_NR_SEQU_REGR(strRegra.isEmpty()? null : Long.valueOf(strRegra));
			req.setNQCETB09_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB09_E_TP_PERI(strPeriodo);
			
			NQCETB09LegadoResponse res = new NQCETB09LegadoResponse();
 			res = (NQCETB09LegadoResponse) jsonMapper.mockLegadoObject(NQCETB09LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			lst.add(req);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
 			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	public String listarClientes(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser) {
		String json = "";
		
		try {
			NQCETB09LegadoRequest req = new NQCETB09LegadoRequest();
			req.setNQCETB09_E_NM_AREA("NQAT2009");
			req.setNQCETB09_E_NM_PROG("NQAT2009");
			req.setNQCETB09_E_QT_TAMA_AREA(Long.valueOf(68));
			req.setNQCETB09_E_SG_FCAO("L2");
			req.setNQCETB09_E_CD_USUA_ULTI_ALTR(strCodUser);
			req.setNQCETB09_E_CD_BANC_CLIE(strBanco);
			req.setNQCETB09_E_CD_CLIE(strCodCliente);
			req.setNQCETB09_E_DT_OCOR(strDtOcorr);
			req.setNQCETB09_E_IN_NOTI_UPLD(strNotUPLD);
			req.setNQCETB09_E_IN_PARE_AREA_OPER(strParOper);
			req.setNQCETB09_E_IN_PARE_GERE(strParGer);
			req.setNQCETB09_E_IN_PARE_UPLD(strParUPLD);
			req.setNQCETB09_E_NR_SEQU_REGR(strRegra.isEmpty()? null : Long.valueOf(strRegra));
			req.setNQCETB09_E_NR_SEQU_SIST(strCodSist.isEmpty()? null : Long.valueOf(strCodSist));
			req.setNQCETB09_E_TP_PERI(strPeriodo);
			
			NQCETB09LegadoResponse res = new NQCETB09LegadoResponse();
 			res = (NQCETB09LegadoResponse) jsonMapper.mockLegadoObject(NQCETB09LegadoResponse.class, res);
			
 			LegadoResult response = new LegadoResult();
 			List<Object> lst = new ArrayList<Object>();
 			lst.add(req);
 			lst.add(res);
 			response.setList(lst);
 			
 			json = new ObjectMapper().writeValueAsString(jsonMapper.legadoToJSON(response.getList()));
 			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

	public String fnAddCaracter(String vlr, String tp, String tam) {
		return "";
	}

	public String dataAlta(String dtBaixa) {
		return "";
	}

}
