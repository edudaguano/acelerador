package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.ClientesACService;
import com.altec.bsbr.app.jab.nq.service.ClientesACWebService;
import com.altec.bsbr.fw.webservice.WebServiceException;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public class ClientesACEndPoint extends SpringBeanAutowiringSupport implements ClientesACWebService {
	private final Logger LOGGER = LoggerFactory.getLogger(ClientesACEndPoint.class);
	
	@Autowired
	private ClientesACService clientesAC;

	@WebMethod
	public String consultarClientes(String strBanco, String strCliente, String StrUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = clientesAC.consultarClientes(strBanco, strCliente, StrUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	};

	@WebMethod
	public String listarClientes(String strBanco, String strCliente, String StrUsuario) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = clientesAC.listarClientes(strBanco, strCliente, StrUsuario);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	};

	@WebMethod
	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws WebServiceException {
		String retorno = "";
		try {
			LOGGER.info("Executar Teste Unitario");
			retorno = clientesAC.fnAddCaracter(Vlr, Tp, Tam);
		} catch (Exception e) {
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1);
		}
		return retorno;
	};

}
