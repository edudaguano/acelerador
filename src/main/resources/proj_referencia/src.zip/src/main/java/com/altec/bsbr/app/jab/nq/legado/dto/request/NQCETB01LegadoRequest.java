package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name= "NQCETB01LegadoRequest")
public class NQCETB01LegadoRequest {
//  
//01     NQCETB01-ENTRADA.                                         
//  
	@PsFieldString(name = "NQCETB1E_NM_PROG", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1E_NM_PROG;// 05 NQCETB1E-NM-PROG PIC X(008).

//*       NOME DO PROGRAMA CHAMADO                                  
//  
	@PsFieldString(name = "NQCETB1E_NM_AREA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1E_NM_AREA;// 05 NQCETB1E-NM-AREA PIC X(008).

//*       NOME DA AREA DE TS                                        
//  
	@PsFieldString(name = "NQCETB1E_SG_FCAO", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1E_SG_FCAO;// 05 NQCETB1E-SG-FCAO PIC X(002).

//*       FUNCAO A SER EXECUTADA                                    
//*       C = CONSULTAR                                             
//*       L = LISTAR                                                
//*       I = INCLUIR                                               
//*       A = ALTERAR                                               
//*       E = EXCLUIR                                               
//  
	@PsFieldNumber(name = "NQCETB1E_QT_TAMA_AREA", length = 7, signed = false, defaultValue = "0")
	private Long NQCETB1E_QT_TAMA_AREA;// 05 NQCETB1E-QT-TAMA-AREA PIC 9(007).

//*       TAMANHO DA AREA DE TS                                     
//  
	@PsFieldString(name = "NQCETB1E_CD_USUA", length = 8, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1E_CD_USUA;// 05 NQCETB1E-CD-USUA PIC X(008).

//*       CODIGO DO USUARIO                                         
//  
	@PsFieldNumber(name = "NQCETB1E_NR_SEQU_SIST", decimal = 0, length = 4, signed = false, defaultValue = "0")
	private Long NQCETB1E_NR_SEQU_SIST;// 05 NQCETB1E-NR-SEQU-SIST PIC 9(004).

//*       NUMERO DE SEQUENCIA DO SISTEMA                            
//  
	@PsFieldString(name = "NQCETB1E_SG_SIST", length = 2, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1E_SG_SIST;// 05 NQCETB1E-SG-SIST PIC X(002).

//*       SIGLA DO SISTEMA                                          
//  
	@PsFieldString(name = "NQCETB1E_NM_FCAO_SIST", length = 20, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1E_NM_FCAO_SIST;// 05 NQCETB1E-NM-FCAO-SIST PIC X(020).

//*       NOME DA FUNCAO DO SISTEMA                                 
//  
	@PsFieldString(name = "NQCETB1E_DS_FCAO_SIST", length = 40, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1E_DS_FCAO_SIST;// 05 NQCETB1E-DS-FCAO-SIST PIC X(040).

//*       DESCRICAO DA FUNCAO DO SISTEMA                            
//  
	@PsFieldString(name = "NQCETB1E_DH_ULTI_PROC_SIST", length = 26, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1E_DH_ULTI_PROC_SIST;// 05 NQCETB1E-DH-ULTI-PROC-SIST PIC X(026).

//*       DATA/HORA ULTIMO PROCESSAMENTO INTERFACE SISTEMA          
//  
	@PsFieldString(name = "NQCETB1E_IN_SIST_ATIV", length = 1, paddingAlign = PsAlign.LEFT, paddingChar = ' ')
	private String NQCETB1E_IN_SIST_ATIV;// 05 NQCETB1E-IN-SIST-ATIV PIC X(001).

	public String getNQCETB1E_NM_PROG() {
		return NQCETB1E_NM_PROG;
	}

	public void setNQCETB1E_NM_PROG(String nQCETB1E_NM_PROG) {
		NQCETB1E_NM_PROG = nQCETB1E_NM_PROG;
	}

	public String getNQCETB1E_NM_AREA() {
		return NQCETB1E_NM_AREA;
	}

	public void setNQCETB1E_NM_AREA(String nQCETB1E_NM_AREA) {
		NQCETB1E_NM_AREA = nQCETB1E_NM_AREA;
	}

	public String getNQCETB1E_SG_FCAO() {
		return NQCETB1E_SG_FCAO;
	}

	public void setNQCETB1E_SG_FCAO(String nQCETB1E_SG_FCAO) {
		NQCETB1E_SG_FCAO = nQCETB1E_SG_FCAO;
	}

	public Long getNQCETB1E_QT_TAMA_AREA() {
		return NQCETB1E_QT_TAMA_AREA;
	}

	public void setNQCETB1E_QT_TAMA_AREA(Long nQCETB1E_QT_TAMA_AREA) {
		NQCETB1E_QT_TAMA_AREA = nQCETB1E_QT_TAMA_AREA;
	}

	public String getNQCETB1E_CD_USUA() {
		return NQCETB1E_CD_USUA;
	}

	public void setNQCETB1E_CD_USUA(String nQCETB1E_CD_USUA) {
		NQCETB1E_CD_USUA = nQCETB1E_CD_USUA;
	}

	public Long getNQCETB1E_NR_SEQU_SIST() {
		return NQCETB1E_NR_SEQU_SIST;
	}

	public void setNQCETB1E_NR_SEQU_SIST(Long nQCETB1E_NR_SEQU_SIST) {
		NQCETB1E_NR_SEQU_SIST = nQCETB1E_NR_SEQU_SIST;
	}

	public String getNQCETB1E_SG_SIST() {
		return NQCETB1E_SG_SIST;
	}

	public void setNQCETB1E_SG_SIST(String nQCETB1E_SG_SIST) {
		NQCETB1E_SG_SIST = nQCETB1E_SG_SIST;
	}

	public String getNQCETB1E_NM_FCAO_SIST() {
		return NQCETB1E_NM_FCAO_SIST;
	}

	public void setNQCETB1E_NM_FCAO_SIST(String nQCETB1E_NM_FCAO_SIST) {
		NQCETB1E_NM_FCAO_SIST = nQCETB1E_NM_FCAO_SIST;
	}

	public String getNQCETB1E_DS_FCAO_SIST() {
		return NQCETB1E_DS_FCAO_SIST;
	}

	public void setNQCETB1E_DS_FCAO_SIST(String nQCETB1E_DS_FCAO_SIST) {
		NQCETB1E_DS_FCAO_SIST = nQCETB1E_DS_FCAO_SIST;
	}

	public String getNQCETB1E_DH_ULTI_PROC_SIST() {
		return NQCETB1E_DH_ULTI_PROC_SIST;
	}

	public void setNQCETB1E_DH_ULTI_PROC_SIST(String nQCETB1E_DH_ULTI_PROC_SIST) {
		NQCETB1E_DH_ULTI_PROC_SIST = nQCETB1E_DH_ULTI_PROC_SIST;
	}

	public String getNQCETB1E_IN_SIST_ATIV() {
		return NQCETB1E_IN_SIST_ATIV;
	}

	public void setNQCETB1E_IN_SIST_ATIV(String nQCETB1E_IN_SIST_ATIV) {
		NQCETB1E_IN_SIST_ATIV = nQCETB1E_IN_SIST_ATIV;
	}	
}