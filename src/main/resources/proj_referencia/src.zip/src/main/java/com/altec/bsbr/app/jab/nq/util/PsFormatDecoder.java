package com.altec.bsbr.app.jab.nq.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import com.altec.bsbr.app.jab.nq.legado.dto.response.AreaMensagem;
import com.altec.bsbr.app.jab.nq.legado.dto.response.FullAreaResponse;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.altec.bsbr.fw.ps.annotations.PsFieldByte;
import com.altec.bsbr.fw.ps.annotations.PsFieldDate;
import com.altec.bsbr.fw.ps.annotations.PsFieldList;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.enums.PsContextEnum;
import com.altec.bsbr.fw.ps.enums.PsFieldEnum;
import com.altec.bsbr.fw.ps.exception.PsFormatException;
import com.altec.bsbr.fw.ps.types.IpsField;

public class PsFormatDecoder {
	
	public <T> List<T> parseRetorno(LegadoResult res, Class<T> klassDados, int tamanhoMensagem, int tamanhoDados) throws PsFormatException, Exception {
		String json;
		AreaMensagem areaMsg = new AreaMensagem();
		List<T> areaDados = new ArrayList<T>();
					
		PsFormatDecoder decoder = new PsFormatDecoder();			
		for(int i = 0; i < res.getList().size(); i++) 
			if (res.getList().get(i).getClass().equals(FullAreaResponse.class)) {
				FullAreaResponse cur = (FullAreaResponse) res.getList().get(i);
				String msg = cur.getRetorno();
				if (msg.length() == tamanhoMensagem)  areaMsg =  decoder.decodeLegado(msg, AreaMensagem.class); 
				else if(msg.length() == tamanhoDados) areaDados.add(decoder.decodeLegado(msg, klassDados));									
			}
				
		if (!areaMsg.getMENSAGEM().trim().equals(""))
			throw new Exception(areaMsg.getRETORNO().toString()+" - "+areaMsg.getMENSAGEM());
		
		return areaDados;
	}

	public <T> List<T> decodeLegado(LegadoResult respostaCruaLegado, Class<T> klass) throws PsFormatException {
		List<T> ret = new ArrayList<T>();
		for (int i = 0; i < respostaCruaLegado.getList().size(); i++)
			if (respostaCruaLegado.getList().get(i).getClass().equals(FullAreaResponse.class)) {
				FullAreaResponse r = (FullAreaResponse) respostaCruaLegado.getList().get(i);
				try {
					T parsed = null;
					parsed = klass.newInstance();
					parsed = (T) this.decode(r.getRetorno().getBytes("Cp1047"), klass, false);
					ret.add(parsed);
				} catch (Exception e) {
					throw new PsFormatException("GenericDecoder: " + e.getClass().getSimpleName(),
							e.fillInStackTrace());
				}
			}

		return ret;
	}

	public <T> T decodeLegado(String msg, Class<T> klass) throws PsFormatException {
		T parsed;
		try {
			parsed = klass.newInstance();
			parsed = (T) this.decode(msg.getBytes("Cp1047"), klass, false);
		} catch (Exception e) {
			throw new PsFormatException("GenericDecoder: " + e.getClass().getSimpleName(), e.fillInStackTrace());
		}
		return parsed;
	}

	private Object decode(byte[] msg, Class k, boolean isSg) throws PsFormatException {
		Object result = null;
		try {
			result = k.newInstance();
		} catch (IllegalAccessException | InstantiationException e) {
			throw new PsFormatException("Parser Decode : NewInstance : " + e.getClass().getSimpleName(),
					e.fillInStackTrace());
		}

		Field[] fields = result.getClass().getDeclaredFields();
		int pos = 0;

		for (Field field : fields) {
			Annotation[] annotations = field.getAnnotations();

			for (Annotation annotation : annotations) {
				if ((annotation instanceof PsFieldByte) || (annotation instanceof PsFieldDate)
						|| (annotation instanceof PsFieldList) || (annotation instanceof PsFieldNumber)
						|| (annotation instanceof PsFieldString)) {
					PsFieldEnum fieldEnum = PsFieldEnum.valueOf(annotation.annotationType().getSimpleName());
					IpsField atributo = null;

					try {
						atributo = (IpsField) fieldEnum.fieldClass().newInstance();
						atributo.setAnnotation(annotation);
						atributo.setField(field);
						atributo.setContext(PsContextEnum.ALTAIR);
						if (!fieldEnum.equals(PsFieldEnum.PsFieldList)) {
							if (isSg)
								pos += 1;

							byte[] value;
							if (msg.length < atributo.length())
								value = getArray(msg, pos, msg.length);
							else
								value = getArray(msg, pos, atributo.length());

							Object objeto = atributo.toFormatClass(value);
							setValue(result, field, objeto);
						}
						pos += atributo.length();
					} catch (InstantiationException | IllegalAccessException e) {
						throw new PsFormatException("Parser Decode : " + e.getClass().getSimpleName(),
								e.fillInStackTrace());
					}
				}
			}
		}

		return result;
	}

	private byte[] getArray(byte[] value, int start, int length) throws ArrayIndexOutOfBoundsException {
		byte[] result = new byte[length];
		System.arraycopy(value, start, result, 0, length);
		return result;
	}

	private void setValue(Object object, Field field, Object value) throws PsFormatException {
		if (value != null) {
			String methodName = "set" + String.valueOf(field.getName().charAt(0)).toUpperCase()
					+ field.getName().substring(1);
			Class<?>[] parameterTypes = new Class[] { field.getType() };
			Method method = null;

			try {
				method = object.getClass().getMethod(methodName, parameterTypes);
				method.invoke(object, value);
			} catch (SecurityException | IllegalArgumentException | IllegalAccessException | InvocationTargetException
					| NoSuchMethodException e) {
				throw new PsFormatException("Parser SetValue : " + e.getClass().getSimpleName(), e.fillInStackTrace());
			}
		}
	}
}
