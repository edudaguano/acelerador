package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE6048LegadoRequest {
	/*
// -*-NQCE6048
//         01      RECEIVE-COMMAREA.                                                                                                       
	@FixedLenghtField(position = 166, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_PGM_CHAMADA;//                03  COMM-PGM-CHAMADA      PIC  X(008).                   

	@FixedLenghtField(position = 167, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOMEDATS;//                03  COMM-NOMEDATS         PIC  X(010).                   

	@FixedLenghtField(position = 168, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_TAM_COMM;//                03  COMM-TAM-COMM         PIC  9(007).                   

	@FixedLenghtField(position = 169, lenght = 9, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_MATRICULA;//                03  COMM-MATRICULA        PIC  9(009).                   

	@FixedLenghtField(position = 170, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CINSTIT;//                03  COMM-CINSTIT          PIC  9(003).                   

	@FixedLenghtField(position = 171, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CODAGENC;//                03  COMM-CODAGENC         PIC  9(004).                   

	@FixedLenghtField(position = 172, lenght = 4, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_CPROD;//                03  COMM-CPROD            PIC  X(004).                   

	@FixedLenghtField(position = 173, lenght = 10, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_NUMCONTA;//                03  COMM-NUMCONTA         PIC  9(010).                   

	@FixedLenghtField(position = 174, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_DATAMOVI;//                03  COMM-DATAMOVI         PIC  9(008).                   

	@FixedLenghtField(position = 175, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CSEQUE;//                03  COMM-CSEQUE           PIC  9(003).                   

	@FixedLenghtField(position = 176, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 03;// PJ0004         03  COMM-CCLI             PIC  9(010).                                                                                

//        01      SEND-AREA.                                                                                                             
	@FixedLenghtField(position = 177, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN;//                03  TS01-MENS-LEN         PIC S9(004) COMP VALUE +83.    

//                03  TS01-AREA-MENSAGEM.                                  
	@FixedLenghtField(position = 178, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO;//                    05  TS01-RETORNO      PIC  9(003) VALUE ZEROS.       

	@FixedLenghtField(position = 179, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM;//                    05  TS01-MENSAGEM     PIC  X(080) VALUE SPACES.                                                                    

	@FixedLenghtField(position = 180, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 03;// PJ0004         03  TS02-MENS-LEN         PIC S9(004) COMP VALUE +331.   

//                03  TS02-AREA-NQCE6048.                                  
	@FixedLenghtField(position = 181, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NOME_AGENCIA;//                    05 TS02-NOME-AGENCIA  PIC  X(050).                   

	@FixedLenghtField(position = 182, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_NOME_EMPRESA;//                    05 TS02-NOME-EMPRESA  PIC  X(050).                   

	@FixedLenghtField(position = 183, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_DTABER_CC;//                    05 TS02-DTABER-CC     PIC  9(008).                   

	@FixedLenghtField(position = 184, lenght = 50, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_RAMO_ATIV;//                    05 TS02-RAMO-ATIV     PIC  X(050).                   

	@FixedLenghtField(position = 185, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_TPPESSOA;//                    05 TS02-TPPESSOA      PIC  X(001).                   

	@FixedLenghtField(position = 186, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_DATA_VIS;//                    05 TS02-DATA-VIS      PIC  9(008).                   

	@FixedLenghtField(position = 187, lenght = 8, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS02_DATA_REF;//                    05 TS02-DATA-REF      PIC  9(008).                   

	@FixedLenghtField(position = 188, lenght = 15, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_VLR_RENFAT;//                    05 TS02-VLR-RENFAT    PIC  X(015).                   

	@FixedLenghtField(position = 189, lenght = 3, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_TPHIST;//                    05 TS02-TPHIST        PIC  X(003).                   

	@FixedLenghtField(position = 190, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_INDESP;//                    05 TS02-INDESP        PIC  X(001).                   

	@FixedLenghtField(position = 191, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS02_TIPOLAN;//                    05 TS02-TIPOLAN       PIC  X(001).                   

	@FixedLenghtField(position = 192, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 05;// PJ0004             05 TS02-CARTEIRA      PIC  X(015).                   

	@FixedLenghtField(position = 193, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 05;// PJ0004             05 TS02-GERCOMER      PIC  X(015).                   

// PJ0004             05 TS02-LISTA-OPER.                                  
	@FixedLenghtField(position = 194, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 07;// PJ0004                07 TS02-DATAINIP   PIC  9(008).                   

	@FixedLenghtField(position = 195, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 07;// PJ0004                07 TS02-DATAFIMP   PIC  9(008).                   

	@FixedLenghtField(position = 196, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 07;// PJ0004                07 TS02-NOME-PROD  PIC  X(015).                   

	@FixedLenghtField(position = 197, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 07;// PJ0004                07 TS02-NOME-HIST  PIC  X(015).                   

	@FixedLenghtField(position = 198, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 07;// PJ0004                07 TS02-CONTA      PIC  9(010).                   

	@FixedLenghtField(position = 199, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 07;// PJ0004                07 TS02-VLR-OPER   PIC  X(015).                   

	@FixedLenghtField(position = 200, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 07;// PJ0004                07 TS02-QTD-OPER   PIC  9(005).                   

	@FixedLenghtField(position = 201, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 07;// PJ0004                07 TS02-STATUS     PIC  X(001).                   

	@FixedLenghtField(position = 202, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 07;// PJ0004                07 TS02-PERFIL     PIC  9(002).                   

	@FixedLenghtField(position = 203, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 07;// PJ0004                07 TS02-DESCSTATUS PIC  X(015).                   

	@FixedLenghtField(position = 204, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 07;// PJ0004                07 TS02-DATA-ANAL  PIC  9(008).                   

	@FixedLenghtField(position = 205, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long 07;// PJ0004                07 TS02-HORA-ANAL  PIC  9(004).                   

	public NQCE6048LegadoRequest() { }
	public NQCE6048LegadoRequest(String comm_pgm_chamada, String comm_nomedats, Long comm_tam_comm, Long comm_matricula, Long comm_cinstit, Long comm_codagenc, String comm_cprod, Long comm_numconta, Long comm_datamovi, Long comm_cseque, Long 03, String ts02_nome_agencia, String ts02_nome_empresa, Long ts02_dtaber_cc, String ts02_ramo_ativ, String ts02_tppessoa, Long ts02_data_vis, Long ts02_data_ref, String ts02_vlr_renfat, String ts02_tphist, String ts02_indesp, String ts02_tipolan, String 05, String 05, Long 07, Long 07, String 07, String 07, Long 07, String 07, Long 07, String 07, Long 07, String 07, Long 07, Long 07) { 		this.COMM_PGM_CHAMADA = comm_pgm_chamada;
		this.COMM_NOMEDATS = comm_nomedats;
		this.COMM_TAM_COMM = comm_tam_comm;
		this.COMM_MATRICULA = comm_matricula;
		this.COMM_CINSTIT = comm_cinstit;
		this.COMM_CODAGENC = comm_codagenc;
		this.COMM_CPROD = comm_cprod;
		this.COMM_NUMCONTA = comm_numconta;
		this.COMM_DATAMOVI = comm_datamovi;
		this.COMM_CSEQUE = comm_cseque;
		this.03 = 03;
		this.TS01_MENS_LEN = +83;
		this.TS01_RETORNO = ZEROS;
		this.TS01_MENSAGEM = SPACES;
		this.03 = +331;
		this.TS02_NOME_AGENCIA = ts02_nome_agencia;
		this.TS02_NOME_EMPRESA = ts02_nome_empresa;
		this.TS02_DTABER_CC = ts02_dtaber_cc;
		this.TS02_RAMO_ATIV = ts02_ramo_ativ;
		this.TS02_TPPESSOA = ts02_tppessoa;
		this.TS02_DATA_VIS = ts02_data_vis;
		this.TS02_DATA_REF = ts02_data_ref;
		this.TS02_VLR_RENFAT = ts02_vlr_renfat;
		this.TS02_TPHIST = ts02_tphist;
		this.TS02_INDESP = ts02_indesp;
		this.TS02_TIPOLAN = ts02_tipolan;
		this.05 = 05;
		this.05 = 05;
		this.07 = 07;
		this.07 = 07;
		this.07 = 07;
		this.07 = 07;
		this.07 = 07;
		this.07 = 07;
		this.07 = 07;
		this.07 = 07;
		this.07 = 07;
		this.07 = 07;
		this.07 = 07;
		this.07 = 07; 
	}
	public String getCOMM_PGM_CHAMADA() { return this.COMM_PGM_CHAMADA; }
	public String getCOMM_NOMEDATS() { return this.COMM_NOMEDATS; }
	public Long getCOMM_TAM_COMM() { return this.COMM_TAM_COMM; }
	public Long getCOMM_MATRICULA() { return this.COMM_MATRICULA; }
	public Long getCOMM_CINSTIT() { return this.COMM_CINSTIT; }
	public Long getCOMM_CODAGENC() { return this.COMM_CODAGENC; }
	public String getCOMM_CPROD() { return this.COMM_CPROD; }
	public Long getCOMM_NUMCONTA() { return this.COMM_NUMCONTA; }
	public Long getCOMM_DATAMOVI() { return this.COMM_DATAMOVI; }
	public Long getCOMM_CSEQUE() { return this.COMM_CSEQUE; }
	public Long get03() { return this.03; }
	public Long getTS01_MENS_LEN() { return this.TS01_MENS_LEN; }
	public Long getTS01_RETORNO() { return this.TS01_RETORNO; }
	public String getTS01_MENSAGEM() { return this.TS01_MENSAGEM; }
	public Long get03() { return this.03; }
	public String getTS02_NOME_AGENCIA() { return this.TS02_NOME_AGENCIA; }
	public String getTS02_NOME_EMPRESA() { return this.TS02_NOME_EMPRESA; }
	public Long getTS02_DTABER_CC() { return this.TS02_DTABER_CC; }
	public String getTS02_RAMO_ATIV() { return this.TS02_RAMO_ATIV; }
	public String getTS02_TPPESSOA() { return this.TS02_TPPESSOA; }
	public Long getTS02_DATA_VIS() { return this.TS02_DATA_VIS; }
	public Long getTS02_DATA_REF() { return this.TS02_DATA_REF; }
	public String getTS02_VLR_RENFAT() { return this.TS02_VLR_RENFAT; }
	public String getTS02_TPHIST() { return this.TS02_TPHIST; }
	public String getTS02_INDESP() { return this.TS02_INDESP; }
	public String getTS02_TIPOLAN() { return this.TS02_TIPOLAN; }
	public String get05() { return this.05; }
	public String get05() { return this.05; }
	public Long get07() { return this.07; }
	public Long get07() { return this.07; }
	public String get07() { return this.07; }
	public String get07() { return this.07; }
	public Long get07() { return this.07; }
	public String get07() { return this.07; }
	public Long get07() { return this.07; }
	public String get07() { return this.07; }
	public Long get07() { return this.07; }
	public String get07() { return this.07; }
	public Long get07() { return this.07; }
	public Long get07() { return this.07; }
	public void setCOMM_PGM_CHAMADA(String comm_pgm_chamada) { this.COMM_PGM_CHAMADA = comm_pgm_chamada; }
	public void setCOMM_NOMEDATS(String comm_nomedats) { this.COMM_NOMEDATS = comm_nomedats; }
	public void setCOMM_TAM_COMM(Long comm_tam_comm) { this.COMM_TAM_COMM = comm_tam_comm; }
	public void setCOMM_MATRICULA(Long comm_matricula) { this.COMM_MATRICULA = comm_matricula; }
	public void setCOMM_CINSTIT(Long comm_cinstit) { this.COMM_CINSTIT = comm_cinstit; }
	public void setCOMM_CODAGENC(Long comm_codagenc) { this.COMM_CODAGENC = comm_codagenc; }
	public void setCOMM_CPROD(String comm_cprod) { this.COMM_CPROD = comm_cprod; }
	public void setCOMM_NUMCONTA(Long comm_numconta) { this.COMM_NUMCONTA = comm_numconta; }
	public void setCOMM_DATAMOVI(Long comm_datamovi) { this.COMM_DATAMOVI = comm_datamovi; }
	public void setCOMM_CSEQUE(Long comm_cseque) { this.COMM_CSEQUE = comm_cseque; }
	public void set03(Long 03) { this.03 = 03; }
	public void setTS01_MENS_LEN(Long ts01_mens_len) { this.TS01_MENS_LEN = ts01_mens_len; }
	public void setTS01_RETORNO(Long ts01_retorno) { this.TS01_RETORNO = ts01_retorno; }
	public void setTS01_MENSAGEM(String ts01_mensagem) { this.TS01_MENSAGEM = ts01_mensagem; }
	public void set03(Long 03) { this.03 = 03; }
	public void setTS02_NOME_AGENCIA(String ts02_nome_agencia) { this.TS02_NOME_AGENCIA = ts02_nome_agencia; }
	public void setTS02_NOME_EMPRESA(String ts02_nome_empresa) { this.TS02_NOME_EMPRESA = ts02_nome_empresa; }
	public void setTS02_DTABER_CC(Long ts02_dtaber_cc) { this.TS02_DTABER_CC = ts02_dtaber_cc; }
	public void setTS02_RAMO_ATIV(String ts02_ramo_ativ) { this.TS02_RAMO_ATIV = ts02_ramo_ativ; }
	public void setTS02_TPPESSOA(String ts02_tppessoa) { this.TS02_TPPESSOA = ts02_tppessoa; }
	public void setTS02_DATA_VIS(Long ts02_data_vis) { this.TS02_DATA_VIS = ts02_data_vis; }
	public void setTS02_DATA_REF(Long ts02_data_ref) { this.TS02_DATA_REF = ts02_data_ref; }
	public void setTS02_VLR_RENFAT(String ts02_vlr_renfat) { this.TS02_VLR_RENFAT = ts02_vlr_renfat; }
	public void setTS02_TPHIST(String ts02_tphist) { this.TS02_TPHIST = ts02_tphist; }
	public void setTS02_INDESP(String ts02_indesp) { this.TS02_INDESP = ts02_indesp; }
	public void setTS02_TIPOLAN(String ts02_tipolan) { this.TS02_TIPOLAN = ts02_tipolan; }
	public void set05(String 05) { this.05 = 05; }
	public void set05(String 05) { this.05 = 05; }
	public void set07(Long 07) { this.07 = 07; }
	public void set07(Long 07) { this.07 = 07; }
	public void set07(String 07) { this.07 = 07; }
	public void set07(String 07) { this.07 = 07; }
	public void set07(Long 07) { this.07 = 07; }
	public void set07(String 07) { this.07 = 07; }
	public void set07(Long 07) { this.07 = 07; }
	public void set07(String 07) { this.07 = 07; }
	public void set07(Long 07) { this.07 = 07; }
	public void set07(String 07) { this.07 = 07; }
	public void set07(Long 07) { this.07 = 07; }
	public void set07(Long 07) { this.07 = 07; }
	*/
}