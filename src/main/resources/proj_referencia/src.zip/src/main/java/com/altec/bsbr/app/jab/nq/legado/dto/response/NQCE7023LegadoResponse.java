package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;

@PsFormat(name= "NQCE7023LegadoResponse")
public class NQCE7023LegadoResponse {
// -*-
//        01          NQCE7023-COMMAREA.                                   
	@PsFieldString(name= "NQCE7023_PROG_CALLED", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_PROG_CALLED;//            05      NQCE7023-PROG-CALLED        PIC X(08).               

	@PsFieldString(name= "NQCE7023_NOMEDATS", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_NOMEDATS;//            05      NQCE7023-NOMEDATS           PIC X(10).               

	@PsFieldNumber(name= "NQCE7023_COMMAREA_LEN", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long NQCE7023_COMMAREA_LEN;//            05      NQCE7023-COMMAREA-LEN       PIC 9(07).               

	@PsFieldString(name= "NQCE7023_FUNCAO", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_FUNCAO;//            05      NQCE7023-FUNCAO             PIC X(01).               

	@PsFieldNumber(name= "NQCE7023_CINSTIT", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCE7023_CINSTIT;//            05      NQCE7023-CINSTIT            PIC 9(03).               

	@PsFieldString(name= "NQCE7023_CODPROD", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_CODPROD;//            05      NQCE7023-CODPROD            PIC X(10).               

//                                                                         
//        01      SEND-AREA.                                               
//                                                                         
	@PsFieldNumber(name= "NQCE7023_TS01_MENS_LEN", length= 4, binary= true, signed= true, decimal= 0)
	private Long NQCE7023_TS01_MENS_LEN;//            05  NQCE7023-TS01-MENS-LEN         PIC S9(04) COMP VALUE +83.

//            05  NQCE7023-TS01.                                           
	@PsFieldNumber(name= "NQCE7023_TS01_COD_RETORNO", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCE7023_TS01_COD_RETORNO;//                10  NQCE7023-TS01-COD-RETORNO   PIC 9(03).               

	@PsFieldString(name= "NQCE7023_TS01_DES_MENSAGEM", length= 80, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS01_DES_MENSAGEM;//                10  NQCE7023-TS01-DES-MENSAGEM  PIC X(80).               

	@PsFieldNumber(name= "NQCE7023_TS02_MENS_LENG", length= 4, binary= true, signed= true, decimal= 0)
	private Long NQCE7023_TS02_MENS_LENG;//            05  NQCE7023-TS02-MENS-LENG       PIC S9(04) COMP VALUE +290.

//            05  NQCE7023-TS02-AREA-ENVIO.                                
	@PsFieldNumber(name= "NQCE7023_TS02_CINSTIT", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCE7023_TS02_CINSTIT;//                10  NQCE7023-TS02-CINSTIT       PIC 9(03).               

	@PsFieldString(name= "NQCE7023_TS02_CPROD", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_CPROD;//                10  NQCE7023-TS02-CPROD         PIC X(10).               

	@PsFieldString(name= "NQCE7023_TS02_DESCPROD", length= 15, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_DESCPROD;//                10  NQCE7023-TS02-DESCPROD      PIC X(15).               

	@PsFieldNumber(name= "NQCE7023_TS02_CSEGM", decimal= 0, length= 5, signed= false, defaultValue="0")
	private Long NQCE7023_TS02_CSEGM;//                10  NQCE7023-TS02-CSEGM         PIC 9(05).               

	@PsFieldNumber(name= "NQCE7023_TS02_NRSEQUE", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCE7023_TS02_NRSEQUE;//                10  NQCE7023-TS02-NRSEQUE       PIC 9(03).               

	@PsFieldString(name= "NQCE7023_TS02_DESCSEGM", length= 50, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_DESCSEGM;//                10  NQCE7023-TS02-DESCSEGM      PIC X(50).               

	@PsFieldString(name= "NQCE7023_TS02_NOMRECE", length= 50, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_NOMRECE;//                10  NQCE7023-TS02-NOMRECE       PIC X(50).               

	@PsFieldString(name= "NQCE7023_TS02_PRERECE", length= 50, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_PRERECE;//                10  NQCE7023-TS02-PRERECE       PIC X(50).               

	@PsFieldNumber(name= "NQCE7023_TS02_CODSUFI", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCE7023_TS02_CODSUFI;//                10  NQCE7023-TS02-CODSUFI       PIC 9(03).               

	@PsFieldString(name= "NQCE7023_TS02_DESCSUF", length= 50, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_DESCSUF;//                10  NQCE7023-TS02-DESCSUF       PIC X(50).               

	@PsFieldString(name= "NQCE7023_TS02_TPENVIO", length= 1, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_TPENVIO;//                10  NQCE7023-TS02-TPENVIO       PIC X(01).               

	@PsFieldString(name= "NQCE7023_TS02_DESCENV", length= 50, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCE7023_TS02_DESCENV;//                10  NQCE7023-TS02-DESCENV       PIC X(50).               

	public NQCE7023LegadoResponse() { }
	public NQCE7023LegadoResponse(String nqce7023_prog_called, String nqce7023_nomedats, Long nqce7023_commarea_len, String nqce7023_funcao, Long nqce7023_cinstit, String nqce7023_codprod, Long nqce7023_ts01_cod_retorno, String nqce7023_ts01_des_mensagem, Long nqce7023_ts02_cinstit, String nqce7023_ts02_cprod, String nqce7023_ts02_descprod, Long nqce7023_ts02_csegm, Long nqce7023_ts02_nrseque, String nqce7023_ts02_descsegm, String nqce7023_ts02_nomrece, String nqce7023_ts02_prerece, Long nqce7023_ts02_codsufi, String nqce7023_ts02_descsuf, String nqce7023_ts02_tpenvio, String nqce7023_ts02_descenv) { 		this.NQCE7023_PROG_CALLED = nqce7023_prog_called;
		this.NQCE7023_NOMEDATS = nqce7023_nomedats;
		this.NQCE7023_COMMAREA_LEN = nqce7023_commarea_len;
		this.NQCE7023_FUNCAO = nqce7023_funcao;
		this.NQCE7023_CINSTIT = nqce7023_cinstit;
		this.NQCE7023_CODPROD = nqce7023_codprod;
		/*this.NQCE7023_TS01_MENS_LEN = +83;*/
		this.NQCE7023_TS01_COD_RETORNO = nqce7023_ts01_cod_retorno;
		this.NQCE7023_TS01_DES_MENSAGEM = nqce7023_ts01_des_mensagem;
		/*this.NQCE7023_TS02_MENS_LENG = +290;*/
		this.NQCE7023_TS02_CINSTIT = nqce7023_ts02_cinstit;
		this.NQCE7023_TS02_CPROD = nqce7023_ts02_cprod;
		this.NQCE7023_TS02_DESCPROD = nqce7023_ts02_descprod;
		this.NQCE7023_TS02_CSEGM = nqce7023_ts02_csegm;
		this.NQCE7023_TS02_NRSEQUE = nqce7023_ts02_nrseque;
		this.NQCE7023_TS02_DESCSEGM = nqce7023_ts02_descsegm;
		this.NQCE7023_TS02_NOMRECE = nqce7023_ts02_nomrece;
		this.NQCE7023_TS02_PRERECE = nqce7023_ts02_prerece;
		this.NQCE7023_TS02_CODSUFI = nqce7023_ts02_codsufi;
		this.NQCE7023_TS02_DESCSUF = nqce7023_ts02_descsuf;
		this.NQCE7023_TS02_TPENVIO = nqce7023_ts02_tpenvio;
		this.NQCE7023_TS02_DESCENV = nqce7023_ts02_descenv; 
	}
	public String getNQCE7023_PROG_CALLED() { return this.NQCE7023_PROG_CALLED; }
	public String getNQCE7023_NOMEDATS() { return this.NQCE7023_NOMEDATS; }
	public Long getNQCE7023_COMMAREA_LEN() { return this.NQCE7023_COMMAREA_LEN; }
	public String getNQCE7023_FUNCAO() { return this.NQCE7023_FUNCAO; }
	public Long getNQCE7023_CINSTIT() { return this.NQCE7023_CINSTIT; }
	public String getNQCE7023_CODPROD() { return this.NQCE7023_CODPROD; }
	public Long getNQCE7023_TS01_MENS_LEN() { return this.NQCE7023_TS01_MENS_LEN; }
	public Long getNQCE7023_TS01_COD_RETORNO() { return this.NQCE7023_TS01_COD_RETORNO; }
	public String getNQCE7023_TS01_DES_MENSAGEM() { return this.NQCE7023_TS01_DES_MENSAGEM; }
	public Long getNQCE7023_TS02_MENS_LENG() { return this.NQCE7023_TS02_MENS_LENG; }
	public Long getNQCE7023_TS02_CINSTIT() { return this.NQCE7023_TS02_CINSTIT; }
	public String getNQCE7023_TS02_CPROD() { return this.NQCE7023_TS02_CPROD; }
	public String getNQCE7023_TS02_DESCPROD() { return this.NQCE7023_TS02_DESCPROD; }
	public Long getNQCE7023_TS02_CSEGM() { return this.NQCE7023_TS02_CSEGM; }
	public Long getNQCE7023_TS02_NRSEQUE() { return this.NQCE7023_TS02_NRSEQUE; }
	public String getNQCE7023_TS02_DESCSEGM() { return this.NQCE7023_TS02_DESCSEGM; }
	public String getNQCE7023_TS02_NOMRECE() { return this.NQCE7023_TS02_NOMRECE; }
	public String getNQCE7023_TS02_PRERECE() { return this.NQCE7023_TS02_PRERECE; }
	public Long getNQCE7023_TS02_CODSUFI() { return this.NQCE7023_TS02_CODSUFI; }
	public String getNQCE7023_TS02_DESCSUF() { return this.NQCE7023_TS02_DESCSUF; }
	public String getNQCE7023_TS02_TPENVIO() { return this.NQCE7023_TS02_TPENVIO; }
	public String getNQCE7023_TS02_DESCENV() { return this.NQCE7023_TS02_DESCENV; }
	public void setNQCE7023_PROG_CALLED(String nqce7023_prog_called) { this.NQCE7023_PROG_CALLED = nqce7023_prog_called; }
	public void setNQCE7023_NOMEDATS(String nqce7023_nomedats) { this.NQCE7023_NOMEDATS = nqce7023_nomedats; }
	public void setNQCE7023_COMMAREA_LEN(Long nqce7023_commarea_len) { this.NQCE7023_COMMAREA_LEN = nqce7023_commarea_len; }
	public void setNQCE7023_FUNCAO(String nqce7023_funcao) { this.NQCE7023_FUNCAO = nqce7023_funcao; }
	public void setNQCE7023_CINSTIT(Long nqce7023_cinstit) { this.NQCE7023_CINSTIT = nqce7023_cinstit; }
	public void setNQCE7023_CODPROD(String nqce7023_codprod) { this.NQCE7023_CODPROD = nqce7023_codprod; }
	public void setNQCE7023_TS01_MENS_LEN(Long nqce7023_ts01_mens_len) { this.NQCE7023_TS01_MENS_LEN = nqce7023_ts01_mens_len; }
	public void setNQCE7023_TS01_COD_RETORNO(Long nqce7023_ts01_cod_retorno) { this.NQCE7023_TS01_COD_RETORNO = nqce7023_ts01_cod_retorno; }
	public void setNQCE7023_TS01_DES_MENSAGEM(String nqce7023_ts01_des_mensagem) { this.NQCE7023_TS01_DES_MENSAGEM = nqce7023_ts01_des_mensagem; }
	public void setNQCE7023_TS02_MENS_LENG(Long nqce7023_ts02_mens_leng) { this.NQCE7023_TS02_MENS_LENG = nqce7023_ts02_mens_leng; }
	public void setNQCE7023_TS02_CINSTIT(Long nqce7023_ts02_cinstit) { this.NQCE7023_TS02_CINSTIT = nqce7023_ts02_cinstit; }
	public void setNQCE7023_TS02_CPROD(String nqce7023_ts02_cprod) { this.NQCE7023_TS02_CPROD = nqce7023_ts02_cprod; }
	public void setNQCE7023_TS02_DESCPROD(String nqce7023_ts02_descprod) { this.NQCE7023_TS02_DESCPROD = nqce7023_ts02_descprod; }
	public void setNQCE7023_TS02_CSEGM(Long nqce7023_ts02_csegm) { this.NQCE7023_TS02_CSEGM = nqce7023_ts02_csegm; }
	public void setNQCE7023_TS02_NRSEQUE(Long nqce7023_ts02_nrseque) { this.NQCE7023_TS02_NRSEQUE = nqce7023_ts02_nrseque; }
	public void setNQCE7023_TS02_DESCSEGM(String nqce7023_ts02_descsegm) { this.NQCE7023_TS02_DESCSEGM = nqce7023_ts02_descsegm; }
	public void setNQCE7023_TS02_NOMRECE(String nqce7023_ts02_nomrece) { this.NQCE7023_TS02_NOMRECE = nqce7023_ts02_nomrece; }
	public void setNQCE7023_TS02_PRERECE(String nqce7023_ts02_prerece) { this.NQCE7023_TS02_PRERECE = nqce7023_ts02_prerece; }
	public void setNQCE7023_TS02_CODSUFI(Long nqce7023_ts02_codsufi) { this.NQCE7023_TS02_CODSUFI = nqce7023_ts02_codsufi; }
	public void setNQCE7023_TS02_DESCSUF(String nqce7023_ts02_descsuf) { this.NQCE7023_TS02_DESCSUF = nqce7023_ts02_descsuf; }
	public void setNQCE7023_TS02_TPENVIO(String nqce7023_ts02_tpenvio) { this.NQCE7023_TS02_TPENVIO = nqce7023_ts02_tpenvio; }
	public void setNQCE7023_TS02_DESCENV(String nqce7023_ts02_descenv) { this.NQCE7023_TS02_DESCENV = nqce7023_ts02_descenv; }
}
