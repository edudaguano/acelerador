package com.altec.bsbr.app.jab.nq.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0350;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0350;
import com.altec.bsbr.app.jab.nq.dao.ComOpSuspComuDao;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class ComOpSuspComuDaoImpl implements ComOpSuspComuDao {
	private final Logger LOGGER = LoggerFactory.getLogger(ComOpSuspComuDaoImpl.class);

	@Autowired
	private AltairService altairService;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String versao() {
		return "";
	}

	public String salvaComunicacao(String strCOENTID, String strCODAGEN, String strTPUNIOR, String strNUNIORG,
			String strNUCONTA, String strNUPENUM, String strTPDOCTO, String strNUDOCTO, String strNOPESSO,
			String strCOSEGPR, String strCOSEGSE, String strCOAREAT, String strTCOPROF, String strVLRENDA,
			String strDTRENDA, String strCOTPREN, String strVLPATRI, String strDTPATRI, String strICCEP,
			String strNOEMPRE, String strCOATIVI, String strCOATCNA, String strCOTPCOR, String strVLFATAN,
			String strDTFATAN, String strTXPARA1, String strTXPARA2, String strTXPARA3, String strTXPARA4,
			String strTXPARA5, String strTXPARA6, String strTXPARA7, String strTXPARA8, String strTXPARA9,
			String strTXPAR10, String strNOCONJU, String strICORREN, String strCDUSRES, String strICIMPED) {
		
		NQE0350 request = new NQE0350();
		request.setCOENTID(strCOENTID);
		request.setCODAGEN(strCODAGEN);
		request.setTPUNIOR(strTPUNIOR.isEmpty()? null : Integer.valueOf(strTPUNIOR));
		request.setNUNIORG(strNUNIORG.isEmpty()? null : Integer.valueOf(strNUNIORG));
		request.setNUCONTA(strNUCONTA);
		request.setNUPENUM(strNUPENUM);
		request.setTPDOCTO(strTPDOCTO);
		request.setNUDOCTO(strNUDOCTO);
		request.setNOPESSO(strNOPESSO);
		request.setCOSEGPR(strCOSEGPR);
		request.setCOSEGSE(strCOSEGSE);
		request.setCOAREAT(strCOAREAT);
		request.setCOPROF(strTCOPROF);
		request.setVLRENDA(strVLRENDA.isEmpty()? null : Integer.valueOf(strVLRENDA));//13
		request.setDTRENDA(strDTRENDA);
		request.setCOTPREN(strCOTPREN);
		request.setVLPATRI(strVLPATRI.isEmpty()? null : Integer.valueOf(strVLPATRI));//16
		request.setDTPATRI(strDTPATRI);
		request.setICCEP(strICCEP);
		request.setNOEMPRE(strNOEMPRE);
		request.setCOATIVI(strCOATIVI);
		request.setCOATCNA(strCOATCNA);
		request.setCOTPCOR(strCOTPCOR);
		request.setVLFATAN(strVLFATAN.isEmpty()? null : Integer.valueOf(strVLFATAN));//23
		request.setDTFATAN(strDTFATAN);
		request.setTXPARA1(strTXPARA1);
		request.setTXPARA2(strTXPARA2);
		request.setTXPARA3(strTXPARA3);
		request.setTXPARA4(strTXPARA4);
		request.setTXPARA5(strTXPARA5);
		request.setTXPARA6(strTXPARA6);
		request.setTXPARA7(strTXPARA7);
		request.setTXPARA8(strTXPARA8);
		request.setTXPARA9(strTXPARA9);
		request.setTXPAR10(strTXPAR10);
		request.setNOCONJU(strNOCONJU);
		request.setICORREN(strICORREN);
		request.setCDUSRES(strCDUSRES);
		request.setICIMPED(strICIMPED);

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQC7", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0350.class));

		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}

	}

}
