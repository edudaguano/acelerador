package com.altec.bsbr.app.jab.nq.legado.dto.response;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCETB09LegadoResponse {
	
// -*-NQCETB09
//         01     NQCETB09-ENTRADA.                                         
//                                                                          
	@FixedLenghtField(position = /*2,*/761, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_E_NM_PROG;//           05   NQCETB09-E-NM-PROG            PIC  X(008).                

//        *       NOME DO PROGRAMA CHAMADO                                  
//                                                                          
	@FixedLenghtField(position = /*2,*/762, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_E_NM_AREA;//           05   NQCETB09-E-NM-AREA            PIC  X(008).                

//        *       NOME DA AREA DE TS                                        
//                                                                          
	@FixedLenghtField(position = /*2,*/763, lenght = 2, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_E_SG_FCAO;//           05   NQCETB09-E-SG-FCAO            PIC  X(002).                

//        *       FUNCAO A SER EXECUTADA                                    
//        *       L = LISTAR                                                
//                                                                          
	@FixedLenghtField(position = /*2,*/764, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB09_E_QT_TAMA_AREA;//           05   NQCETB09-E-QT-TAMA-AREA       PIC  9(007).                

//        *       TAMANHO DA AREA DE TS                                     
//                                                                          
	@FixedLenghtField(position = /*2,*/765, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_E_CD_USUA_ULTI_ALTR;//           05   NQCETB09-E-CD-USUA-ULTI-ALTR  PIC  X(008).                

//        *       CODIGO DO USUARIO                                         
//                                                                          
	@FixedLenghtField(position = /*2,*/766, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB09_E_NR_SEQU_SIST;//           05   NQCETB09-E-NR-SEQU-SIST       PIC  9(004).                

//        *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                          
	@FixedLenghtField(position = /*2,*/767, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB09_E_NR_SEQU_REGR;//           05   NQCETB09-E-NR-SEQU-REGR       PIC  9(004).                

//        *       NUMERO DE SEQUENCIA DA REGRA                              
//                                                                          
	@FixedLenghtField(position = /*2,*/768, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_E_TP_PERI;//           05   NQCETB09-E-TP-PERI            PIC  X(001).                

//        *       TIPO DE PERIODO                                           
//                                                                          
	@FixedLenghtField(position = /*2,*/769, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_E_IN_PARE_GERE;//           05   NQCETB09-E-IN-PARE-GERE       PIC  X(001).                

//        *       INDICADOR DE PARECER DO GERENTE                           
//                                                                          
	@FixedLenghtField(position = /*2,*/770, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_E_IN_PARE_AREA_OPER;//           05   NQCETB09-E-IN-PARE-AREA-OPER  PIC  X(001).                

//        *       INDICADOR DE PARECER DA AREA OPERACIONAL                  
//                                                                          
	@FixedLenghtField(position = /*2,*/771, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_E_IN_PARE_UPLD;//           05   NQCETB09-E-IN-PARE-UPLD       PIC  X(001).                

//        *       INDICADOR DE PARECER DA UPLD                              
//                                                                          
	@FixedLenghtField(position = /*2,*/772, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_E_IN_NOTI_UPLD;//           05   NQCETB09-E-IN-NOTI-UPLD       PIC  X(001).                

//        *       INDICADOR DE NOTIFICACAO A UPLD                           
//                                                                          
	@FixedLenghtField(position = /*2,*/773, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_E_DT_OCOR;//           05   NQCETB09-E-DT-OCOR            PIC  X(010).                

//        *       DATA DA OCORRENCIA                                        
//                                                                          
	@FixedLenghtField(position = /*2,*/774, lenght = 4, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_E_CD_BANC_CLIE;//           05   NQCETB09-E-CD-BANC-CLIE       PIC  X(004).                

//        *       CODIGO DO BANCO DO CLIENTE                                
//                                                                          
	@FixedLenghtField(position = /*2,*/775, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_E_CD_CLIE;//           05   NQCETB09-E-CD-CLIE            PIC  X(008).                

//        *       CODIGO DO CLIENTE                                         
//                                                                          
//         01     NQCETB09-SAIDA.                                           
//                                                                          
//        *       AREA DE MENSAGEM                                          
//                                                                          
	@FixedLenghtField(position = /*2,*/776, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB09_S_MENS_LEN;//          03    NQCETB09-S-MENS-LEN    COMP   PIC  S9(04) VALUE +83.      

//          03    NQCETB09-S-MENS.                                          
	@FixedLenghtField(position = /*2,*/777, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB09_S_RETORNO;//           05   NQCETB09-S-RETORNO            PIC  9(003) VALUE ZEROS.    

	@FixedLenghtField(position = /*2,*/778, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_MENSAGEM;//           05   NQCETB09-S-MENSAGEM           PIC  X(080) VALUE SPACES.   

//                                                                          
//        *       AREA DE DADOS                                             
//                                                                          
	@FixedLenghtField(position = /*2,*/779, lenght = 0, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB09_S_DATA_LEN;//          03    NQCETB09-S-DATA-LEN    COMP   PIC  S9(04) VALUE +151.     

//          03    NQCETB09-S-DATA.                                          
//                                                                          
	@FixedLenghtField(position = /*2,*/780, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB09_S_NR_SEQU_SIST;//           05   NQCETB09-S-NR-SEQU-SIST       PIC  9(004).                

//        *       NUMERO DE SEQUENCIA DO SISTEMA                            
//                                                                          
	@FixedLenghtField(position = /*2,*/781, lenght = 2, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_SG_SIST;//           05   NQCETB09-S-SG-SIST            PIC  X(002).                

//        *       SIGLA DO SISTEMA                                          
//                                                                          
	@FixedLenghtField(position = /*2,*/782, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long NQCETB09_S_NR_SEQU_REGR;//           05   NQCETB09-S-NR-SEQU-REGR       PIC  9(004).                

//        *       NUMERO DE SEQUENCIA DA REGRA                              
//                                                                          
	@FixedLenghtField(position = /*2,*/783, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_TP_PERI;//           05   NQCETB09-S-TP-PERI            PIC  X(001).                

//        *       TIPO DE PERIODO                                           
//                                                                          
	@FixedLenghtField(position = /*2,*/784, lenght = 4, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_CD_BANC_CLIE;//           05   NQCETB09-S-CD-BANC-CLIE       PIC  X(004).                

//        *       CODIGO DO BANCO DO CLIENTE                                
//                                                                          
	@FixedLenghtField(position = /*2,*/785, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_CD_CLIE;//           05   NQCETB09-S-CD-CLIE            PIC  X(008).                

//        *       CODIGO DO CLIENTE                                         
//                                                                          
	@FixedLenghtField(position = /*2,*/786, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_DT_OCOR;//           05   NQCETB09-S-DT-OCOR            PIC  X(010).                

//        *       DATA DA OCORRENCIA                                        
//                                                                          
	@FixedLenghtField(position = /*2,*/787, lenght = 40, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_NM_CLIE;//           05   NQCETB09-S-NM-CLIE            PIC  X(040).                

//        *       NOME DO CLIENTE                                           
//                                                                          
	@FixedLenghtField(position = /*2,*/788, lenght = 40, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_NM_GERENTE;//           05   NQCETB09-S-NM-GERENTE         PIC  X(040).                

//        *       NOME DO GERENTE                                           
//                                                                          
	@FixedLenghtField(position = /*2,*/789, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_IN_PARE_GERE;//           05   NQCETB09-S-IN-PARE-GERE       PIC  X(001).                

//        *       INDICADOR DE PARECER DO GERENTE                           
//                                                                          
	@FixedLenghtField(position = /*2,*/790, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_IN_PARE_AREA_OPER;//           05   NQCETB09-S-IN-PARE-AREA-OPER  PIC  X(001).                

//        *       INDICADOR DE PARECER DA AREA OPERACIONAL                  
//                                                                          
	@FixedLenghtField(position = /*2,*/791, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_IN_PARE_UPLD;//           05   NQCETB09-S-IN-PARE-UPLD       PIC  X(001).                

//        *       INDICADOR DE PARECER DA UPLD                              
//                                                                          
	@FixedLenghtField(position = /*2,*/792, lenght = 1, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_IN_NOTI_UPLD;//           05   NQCETB09-S-IN-NOTI-UPLD       PIC  X(001).                

//        *       INDICADOR DE NOTIFICACAO A UPLD                           
//                                                                          
	@FixedLenghtField(position = /*2,*/793, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_CD_USUA_ULTI_ALTR;//           05   NQCETB09-S-CD-USUA-ULTI-ALTR  PIC  X(008).                

//        *       CODIGO DO USUARIO DA ULTIMA ALTERACAO                     
//                                                                          
	@FixedLenghtField(position = /*2,*/794, lenght = 26, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String NQCETB09_S_DH_ULTI_ALTR;//           05   NQCETB09-S-DH-ULTI-ALTR       PIC  X(026).                

//        *       DATA/HORA ULTIMA ALTERACAO                                
	public NQCETB09LegadoResponse() { }
	public NQCETB09LegadoResponse(String nqcetb09_e_nm_prog, String nqcetb09_e_nm_area, String nqcetb09_e_sg_fcao, Long nqcetb09_e_qt_tama_area, String nqcetb09_e_cd_usua_ulti_altr, Long nqcetb09_e_nr_sequ_sist, Long nqcetb09_e_nr_sequ_regr, String nqcetb09_e_tp_peri, String nqcetb09_e_in_pare_gere, String nqcetb09_e_in_pare_area_oper, String nqcetb09_e_in_pare_upld, String nqcetb09_e_in_noti_upld, String nqcetb09_e_dt_ocor, String nqcetb09_e_cd_banc_clie, String nqcetb09_e_cd_clie, Long nqcetb09_s_nr_sequ_sist, String nqcetb09_s_sg_sist, Long nqcetb09_s_nr_sequ_regr, String nqcetb09_s_tp_peri, String nqcetb09_s_cd_banc_clie, String nqcetb09_s_cd_clie, String nqcetb09_s_dt_ocor, String nqcetb09_s_nm_clie, String nqcetb09_s_nm_gerente, String nqcetb09_s_in_pare_gere, String nqcetb09_s_in_pare_area_oper, String nqcetb09_s_in_pare_upld, String nqcetb09_s_in_noti_upld, String nqcetb09_s_cd_usua_ulti_altr, String nqcetb09_s_dh_ulti_altr) { 		this.NQCETB09_E_NM_PROG = nqcetb09_e_nm_prog;
		this.NQCETB09_E_NM_AREA = nqcetb09_e_nm_area;
		this.NQCETB09_E_SG_FCAO = nqcetb09_e_sg_fcao;
		this.NQCETB09_E_QT_TAMA_AREA = nqcetb09_e_qt_tama_area;
		this.NQCETB09_E_CD_USUA_ULTI_ALTR = nqcetb09_e_cd_usua_ulti_altr;
		this.NQCETB09_E_NR_SEQU_SIST = nqcetb09_e_nr_sequ_sist;
		this.NQCETB09_E_NR_SEQU_REGR = nqcetb09_e_nr_sequ_regr;
		this.NQCETB09_E_TP_PERI = nqcetb09_e_tp_peri;
		this.NQCETB09_E_IN_PARE_GERE = nqcetb09_e_in_pare_gere;
		this.NQCETB09_E_IN_PARE_AREA_OPER = nqcetb09_e_in_pare_area_oper;
		this.NQCETB09_E_IN_PARE_UPLD = nqcetb09_e_in_pare_upld;
		this.NQCETB09_E_IN_NOTI_UPLD = nqcetb09_e_in_noti_upld;
		this.NQCETB09_E_DT_OCOR = nqcetb09_e_dt_ocor;
		this.NQCETB09_E_CD_BANC_CLIE = nqcetb09_e_cd_banc_clie;
		this.NQCETB09_E_CD_CLIE = nqcetb09_e_cd_clie;
		/*this.NQCETB09_S_MENS_LEN = +83;
		this.NQCETB09_S_RETORNO = ZEROS;
		this.NQCETB09_S_MENSAGEM = SPACES;
		this.NQCETB09_S_DATA_LEN = +151;*/
		this.NQCETB09_S_NR_SEQU_SIST = nqcetb09_s_nr_sequ_sist;
		this.NQCETB09_S_SG_SIST = nqcetb09_s_sg_sist;
		this.NQCETB09_S_NR_SEQU_REGR = nqcetb09_s_nr_sequ_regr;
		this.NQCETB09_S_TP_PERI = nqcetb09_s_tp_peri;
		this.NQCETB09_S_CD_BANC_CLIE = nqcetb09_s_cd_banc_clie;
		this.NQCETB09_S_CD_CLIE = nqcetb09_s_cd_clie;
		this.NQCETB09_S_DT_OCOR = nqcetb09_s_dt_ocor;
		this.NQCETB09_S_NM_CLIE = nqcetb09_s_nm_clie;
		this.NQCETB09_S_NM_GERENTE = nqcetb09_s_nm_gerente;
		this.NQCETB09_S_IN_PARE_GERE = nqcetb09_s_in_pare_gere;
		this.NQCETB09_S_IN_PARE_AREA_OPER = nqcetb09_s_in_pare_area_oper;
		this.NQCETB09_S_IN_PARE_UPLD = nqcetb09_s_in_pare_upld;
		this.NQCETB09_S_IN_NOTI_UPLD = nqcetb09_s_in_noti_upld;
		this.NQCETB09_S_CD_USUA_ULTI_ALTR = nqcetb09_s_cd_usua_ulti_altr;
		this.NQCETB09_S_DH_ULTI_ALTR = nqcetb09_s_dh_ulti_altr; 
	}
	public String getNQCETB09_E_NM_PROG() { return this.NQCETB09_E_NM_PROG; }
	public String getNQCETB09_E_NM_AREA() { return this.NQCETB09_E_NM_AREA; }
	public String getNQCETB09_E_SG_FCAO() { return this.NQCETB09_E_SG_FCAO; }
	public Long getNQCETB09_E_QT_TAMA_AREA() { return this.NQCETB09_E_QT_TAMA_AREA; }
	public String getNQCETB09_E_CD_USUA_ULTI_ALTR() { return this.NQCETB09_E_CD_USUA_ULTI_ALTR; }
	public Long getNQCETB09_E_NR_SEQU_SIST() { return this.NQCETB09_E_NR_SEQU_SIST; }
	public Long getNQCETB09_E_NR_SEQU_REGR() { return this.NQCETB09_E_NR_SEQU_REGR; }
	public String getNQCETB09_E_TP_PERI() { return this.NQCETB09_E_TP_PERI; }
	public String getNQCETB09_E_IN_PARE_GERE() { return this.NQCETB09_E_IN_PARE_GERE; }
	public String getNQCETB09_E_IN_PARE_AREA_OPER() { return this.NQCETB09_E_IN_PARE_AREA_OPER; }
	public String getNQCETB09_E_IN_PARE_UPLD() { return this.NQCETB09_E_IN_PARE_UPLD; }
	public String getNQCETB09_E_IN_NOTI_UPLD() { return this.NQCETB09_E_IN_NOTI_UPLD; }
	public String getNQCETB09_E_DT_OCOR() { return this.NQCETB09_E_DT_OCOR; }
	public String getNQCETB09_E_CD_BANC_CLIE() { return this.NQCETB09_E_CD_BANC_CLIE; }
	public String getNQCETB09_E_CD_CLIE() { return this.NQCETB09_E_CD_CLIE; }
	public Long getNQCETB09_S_MENS_LEN() { return this.NQCETB09_S_MENS_LEN; }
	public Long getNQCETB09_S_RETORNO() { return this.NQCETB09_S_RETORNO; }
	public String getNQCETB09_S_MENSAGEM() { return this.NQCETB09_S_MENSAGEM; }
	public Long getNQCETB09_S_DATA_LEN() { return this.NQCETB09_S_DATA_LEN; }
	public Long getNQCETB09_S_NR_SEQU_SIST() { return this.NQCETB09_S_NR_SEQU_SIST; }
	public String getNQCETB09_S_SG_SIST() { return this.NQCETB09_S_SG_SIST; }
	public Long getNQCETB09_S_NR_SEQU_REGR() { return this.NQCETB09_S_NR_SEQU_REGR; }
	public String getNQCETB09_S_TP_PERI() { return this.NQCETB09_S_TP_PERI; }
	public String getNQCETB09_S_CD_BANC_CLIE() { return this.NQCETB09_S_CD_BANC_CLIE; }
	public String getNQCETB09_S_CD_CLIE() { return this.NQCETB09_S_CD_CLIE; }
	public String getNQCETB09_S_DT_OCOR() { return this.NQCETB09_S_DT_OCOR; }
	public String getNQCETB09_S_NM_CLIE() { return this.NQCETB09_S_NM_CLIE; }
	public String getNQCETB09_S_NM_GERENTE() { return this.NQCETB09_S_NM_GERENTE; }
	public String getNQCETB09_S_IN_PARE_GERE() { return this.NQCETB09_S_IN_PARE_GERE; }
	public String getNQCETB09_S_IN_PARE_AREA_OPER() { return this.NQCETB09_S_IN_PARE_AREA_OPER; }
	public String getNQCETB09_S_IN_PARE_UPLD() { return this.NQCETB09_S_IN_PARE_UPLD; }
	public String getNQCETB09_S_IN_NOTI_UPLD() { return this.NQCETB09_S_IN_NOTI_UPLD; }
	public String getNQCETB09_S_CD_USUA_ULTI_ALTR() { return this.NQCETB09_S_CD_USUA_ULTI_ALTR; }
	public String getNQCETB09_S_DH_ULTI_ALTR() { return this.NQCETB09_S_DH_ULTI_ALTR; }
	public void setNQCETB09_E_NM_PROG(String nqcetb09_e_nm_prog) { this.NQCETB09_E_NM_PROG = nqcetb09_e_nm_prog; }
	public void setNQCETB09_E_NM_AREA(String nqcetb09_e_nm_area) { this.NQCETB09_E_NM_AREA = nqcetb09_e_nm_area; }
	public void setNQCETB09_E_SG_FCAO(String nqcetb09_e_sg_fcao) { this.NQCETB09_E_SG_FCAO = nqcetb09_e_sg_fcao; }
	public void setNQCETB09_E_QT_TAMA_AREA(Long nqcetb09_e_qt_tama_area) { this.NQCETB09_E_QT_TAMA_AREA = nqcetb09_e_qt_tama_area; }
	public void setNQCETB09_E_CD_USUA_ULTI_ALTR(String nqcetb09_e_cd_usua_ulti_altr) { this.NQCETB09_E_CD_USUA_ULTI_ALTR = nqcetb09_e_cd_usua_ulti_altr; }
	public void setNQCETB09_E_NR_SEQU_SIST(Long nqcetb09_e_nr_sequ_sist) { this.NQCETB09_E_NR_SEQU_SIST = nqcetb09_e_nr_sequ_sist; }
	public void setNQCETB09_E_NR_SEQU_REGR(Long nqcetb09_e_nr_sequ_regr) { this.NQCETB09_E_NR_SEQU_REGR = nqcetb09_e_nr_sequ_regr; }
	public void setNQCETB09_E_TP_PERI(String nqcetb09_e_tp_peri) { this.NQCETB09_E_TP_PERI = nqcetb09_e_tp_peri; }
	public void setNQCETB09_E_IN_PARE_GERE(String nqcetb09_e_in_pare_gere) { this.NQCETB09_E_IN_PARE_GERE = nqcetb09_e_in_pare_gere; }
	public void setNQCETB09_E_IN_PARE_AREA_OPER(String nqcetb09_e_in_pare_area_oper) { this.NQCETB09_E_IN_PARE_AREA_OPER = nqcetb09_e_in_pare_area_oper; }
	public void setNQCETB09_E_IN_PARE_UPLD(String nqcetb09_e_in_pare_upld) { this.NQCETB09_E_IN_PARE_UPLD = nqcetb09_e_in_pare_upld; }
	public void setNQCETB09_E_IN_NOTI_UPLD(String nqcetb09_e_in_noti_upld) { this.NQCETB09_E_IN_NOTI_UPLD = nqcetb09_e_in_noti_upld; }
	public void setNQCETB09_E_DT_OCOR(String nqcetb09_e_dt_ocor) { this.NQCETB09_E_DT_OCOR = nqcetb09_e_dt_ocor; }
	public void setNQCETB09_E_CD_BANC_CLIE(String nqcetb09_e_cd_banc_clie) { this.NQCETB09_E_CD_BANC_CLIE = nqcetb09_e_cd_banc_clie; }
	public void setNQCETB09_E_CD_CLIE(String nqcetb09_e_cd_clie) { this.NQCETB09_E_CD_CLIE = nqcetb09_e_cd_clie; }
	public void setNQCETB09_S_MENS_LEN(Long nqcetb09_s_mens_len) { this.NQCETB09_S_MENS_LEN = nqcetb09_s_mens_len; }
	public void setNQCETB09_S_RETORNO(Long nqcetb09_s_retorno) { this.NQCETB09_S_RETORNO = nqcetb09_s_retorno; }
	public void setNQCETB09_S_MENSAGEM(String nqcetb09_s_mensagem) { this.NQCETB09_S_MENSAGEM = nqcetb09_s_mensagem; }
	public void setNQCETB09_S_DATA_LEN(Long nqcetb09_s_data_len) { this.NQCETB09_S_DATA_LEN = nqcetb09_s_data_len; }
	public void setNQCETB09_S_NR_SEQU_SIST(Long nqcetb09_s_nr_sequ_sist) { this.NQCETB09_S_NR_SEQU_SIST = nqcetb09_s_nr_sequ_sist; }
	public void setNQCETB09_S_SG_SIST(String nqcetb09_s_sg_sist) { this.NQCETB09_S_SG_SIST = nqcetb09_s_sg_sist; }
	public void setNQCETB09_S_NR_SEQU_REGR(Long nqcetb09_s_nr_sequ_regr) { this.NQCETB09_S_NR_SEQU_REGR = nqcetb09_s_nr_sequ_regr; }
	public void setNQCETB09_S_TP_PERI(String nqcetb09_s_tp_peri) { this.NQCETB09_S_TP_PERI = nqcetb09_s_tp_peri; }
	public void setNQCETB09_S_CD_BANC_CLIE(String nqcetb09_s_cd_banc_clie) { this.NQCETB09_S_CD_BANC_CLIE = nqcetb09_s_cd_banc_clie; }
	public void setNQCETB09_S_CD_CLIE(String nqcetb09_s_cd_clie) { this.NQCETB09_S_CD_CLIE = nqcetb09_s_cd_clie; }
	public void setNQCETB09_S_DT_OCOR(String nqcetb09_s_dt_ocor) { this.NQCETB09_S_DT_OCOR = nqcetb09_s_dt_ocor; }
	public void setNQCETB09_S_NM_CLIE(String nqcetb09_s_nm_clie) { this.NQCETB09_S_NM_CLIE = nqcetb09_s_nm_clie; }
	public void setNQCETB09_S_NM_GERENTE(String nqcetb09_s_nm_gerente) { this.NQCETB09_S_NM_GERENTE = nqcetb09_s_nm_gerente; }
	public void setNQCETB09_S_IN_PARE_GERE(String nqcetb09_s_in_pare_gere) { this.NQCETB09_S_IN_PARE_GERE = nqcetb09_s_in_pare_gere; }
	public void setNQCETB09_S_IN_PARE_AREA_OPER(String nqcetb09_s_in_pare_area_oper) { this.NQCETB09_S_IN_PARE_AREA_OPER = nqcetb09_s_in_pare_area_oper; }
	public void setNQCETB09_S_IN_PARE_UPLD(String nqcetb09_s_in_pare_upld) { this.NQCETB09_S_IN_PARE_UPLD = nqcetb09_s_in_pare_upld; }
	public void setNQCETB09_S_IN_NOTI_UPLD(String nqcetb09_s_in_noti_upld) { this.NQCETB09_S_IN_NOTI_UPLD = nqcetb09_s_in_noti_upld; }
	public void setNQCETB09_S_CD_USUA_ULTI_ALTR(String nqcetb09_s_cd_usua_ulti_altr) { this.NQCETB09_S_CD_USUA_ULTI_ALTR = nqcetb09_s_cd_usua_ulti_altr; }
	public void setNQCETB09_S_DH_ULTI_ALTR(String nqcetb09_s_dh_ulti_altr) { this.NQCETB09_S_DH_ULTI_ALTR = nqcetb09_s_dh_ulti_altr; }
}