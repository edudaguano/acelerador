package com.altec.bsbr.app.jab.nq.dao.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.dao.DominiosDao;
import com.altec.bsbr.app.jab.nq.legado.dto.request.NQCETB05LegadoRequest;
import com.altec.bsbr.app.jab.nq.legado.dto.response.NQCETB05AreaDados;
import com.altec.bsbr.app.jab.nq.legado.messageGateway.NQCETB05MessagingGateway;
import com.altec.bsbr.app.jab.nq.util.JSONMapper;
import com.altec.bsbr.app.jab.nq.util.PsFormatDecoder;
import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.fw.jms.legado.LegadoResult;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class DominiosDaoImpl implements DominiosDao {
	
	private final Logger LOGGER = LoggerFactory.getLogger(DominiosDaoImpl.class);

	@Autowired
	private JSONMapper jsonMapper;
	
	@Autowired
	private NQCETB05MessagingGateway NQCETB05service;
	
	public String listarDominio(String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB05LegadoRequest req = new NQCETB05LegadoRequest();
			req.setNQCETB5E_NM_PROG("NQAT2005");
			req.setNQCETB5E_NM_AREA("NQAT2005");
			req.setNQCETB5E_QT_TAMA_AREA(Long.valueOf("0000100"));
			req.setNQCETB5E_NR_SEQU_DOMI_OPER(Long.valueOf("0000"));
			req.setNQCETB5E_SG_FCAO("L");
			
			/*-----------------------------------------------------------------*/	
			req.setNQCETB5E_CD_USUA(strCodUser);
			/*-----------------------------------------------------------------*/	
			PsFormatDecoder decoder = new PsFormatDecoder();
			LegadoResult res = NQCETB05service.sendMessageLegado(req);
			List<NQCETB05AreaDados> ret = decoder.parseRetorno(res, NQCETB05AreaDados.class, 83, 107);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		
		return json;
	}

	public String consultarDominio(String strCodDom, String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB05LegadoRequest req = new NQCETB05LegadoRequest();
			req.setNQCETB5E_NM_PROG("NQAT2005");
			req.setNQCETB5E_NM_AREA("NQAT2005");
			req.setNQCETB5E_QT_TAMA_AREA(Long.valueOf("0000100"));
			req.setNQCETB5E_NR_SEQU_DOMI_OPER(Long.valueOf("0000"));
			req.setNQCETB5E_SG_FCAO("C");
			
			/*-----------------------------------------------------------------*/	
			req.setNQCETB5E_NR_SEQU_DOMI_OPER(Long.valueOf(strCodDom));
			req.setNQCETB5E_CD_USUA(strCodUser);
			/*-----------------------------------------------------------------*/	
			PsFormatDecoder decoder = new PsFormatDecoder();
			LegadoResult res = NQCETB05service.sendMessageLegado(req);
			List<NQCETB05AreaDados> ret = decoder.parseRetorno(res, NQCETB05AreaDados.class, 83, 107);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		
		return json;
	}

	public String incluirDominio(String strVlrDom, String strDesDom, String strTpUsuDom, String strIndDomAtv, String strCodUser) throws BusinessException {
		String json = "";
		try {
			NQCETB05LegadoRequest req = new NQCETB05LegadoRequest();
			req.setNQCETB5E_NM_PROG("NQAT2005");
			req.setNQCETB5E_NM_AREA("NQAT2005");
			req.setNQCETB5E_QT_TAMA_AREA(Long.valueOf("0000100"));
			req.setNQCETB5E_NR_SEQU_DOMI_OPER(Long.valueOf("0000"));
			req.setNQCETB5E_SG_FCAO("I");
			
			/*-----------------------------------------------------------------*/	
			req.setNQCETB5E_VL_PARM_DOMI_OPER(strVlrDom);
			req.setNQCETB5E_DS_PARM_DOMI_OPER(strDesDom);
			req.setNQCETB5E_TP_USO_DOMI_OPER(strTpUsuDom);
			req.setNQCETB5E_IN_DOMI_OPER_ATIV(strIndDomAtv);
			req.setNQCETB5E_CD_USUA(strCodUser);
			/*-----------------------------------------------------------------*/	
			PsFormatDecoder decoder = new PsFormatDecoder();
			LegadoResult res = NQCETB05service.sendMessageLegado(req);
			List<NQCETB05AreaDados> ret = decoder.parseRetorno(res, NQCETB05AreaDados.class, 83, 107);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		return json;
	}

	public String alterarDominio(String strCodDom, String strVlrDom, String strDesDom, String strTpUsuDom, String strIndDomAtv, String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB05LegadoRequest req = new NQCETB05LegadoRequest();
			req.setNQCETB5E_NM_PROG("NQAT2005");
			req.setNQCETB5E_NM_AREA("NQAT2005");
			req.setNQCETB5E_QT_TAMA_AREA(Long.valueOf("0000100"));
			req.setNQCETB5E_NR_SEQU_DOMI_OPER(Long.valueOf("0000"));
			req.setNQCETB5E_SG_FCAO("A");
			
			/*-----------------------------------------------------------------*/			
			req.setNQCETB5E_NR_SEQU_DOMI_OPER(Long.valueOf(strCodDom));
			req.setNQCETB5E_VL_PARM_DOMI_OPER(strVlrDom);
			req.setNQCETB5E_DS_PARM_DOMI_OPER(strDesDom);
			req.setNQCETB5E_TP_USO_DOMI_OPER(strTpUsuDom);
			req.setNQCETB5E_IN_DOMI_OPER_ATIV(strIndDomAtv);
			req.setNQCETB5E_CD_USUA(strCodUser);
			/*-----------------------------------------------------------------*/
			PsFormatDecoder decoder = new PsFormatDecoder();
			LegadoResult res = NQCETB05service.sendMessageLegado(req);
			List<NQCETB05AreaDados> ret = decoder.parseRetorno(res, NQCETB05AreaDados.class, 83, 107);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		
		return json;
	}

	public String excluirDominio(String strCodDom, String strCodUser) throws BusinessException {
		String json = "";
		
		try {
			NQCETB05LegadoRequest req = new NQCETB05LegadoRequest();
			req.setNQCETB5E_NM_PROG("NQAT2005");
			req.setNQCETB5E_NM_AREA("NQAT2005");
			req.setNQCETB5E_QT_TAMA_AREA(Long.valueOf("0000100"));
			req.setNQCETB5E_NR_SEQU_DOMI_OPER(Long.valueOf("0000"));
			req.setNQCETB5E_SG_FCAO("E");
			
			/*-----------------------------------------------------------------*/
			req.setNQCETB5E_CD_USUA(strCodUser);
			req.setNQCETB5E_NR_SEQU_DOMI_OPER(Long.valueOf(strCodDom));
			/*-----------------------------------------------------------------*/
			
			PsFormatDecoder decoder = new PsFormatDecoder();
			LegadoResult res = NQCETB05service.sendMessageLegado(req);
			List<NQCETB05AreaDados> ret = decoder.parseRetorno(res, NQCETB05AreaDados.class, 83, 107);
			json =  new ObjectMapper().writeValueAsString(ret);
		} catch (Exception e) {
			throw new BusinessException(e.getMessage(), e.fillInStackTrace());
		}
		
		return json;
	}	

	public String inicializarinputArea(String tNQ_NQAT2005_NQCETB05_ENTRADA) {
		String json = "";
		return json;
	}

	public String fnAddCaracter(String Vlr, String Tp, String Tam) {
		String json = "";
		return json;
	}

}
