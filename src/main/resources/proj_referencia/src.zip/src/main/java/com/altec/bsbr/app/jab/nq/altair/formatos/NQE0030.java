package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0030")
public class NQE0030 {
@PsFieldString(name="TPDOCTO", length=3, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String TPDOCTO;
@PsFieldString(name="NUDOCTO", length=20, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUDOCTO;
@PsFieldString(name="CDENTID", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDENTID;
@PsFieldString(name="CDALERT", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDALERT;

public String getTPDOCTO() {
 return TPDOCTO;
}
public void setTPDOCTO(String TPDOCTO) {
 this.TPDOCTO = TPDOCTO;
}

public String getNUDOCTO() {
 return NUDOCTO;
}
public void setNUDOCTO(String NUDOCTO) {
 this.NUDOCTO = NUDOCTO;
}

public String getCDENTID() {
 return CDENTID;
}
public void setCDENTID(String CDENTID) {
 this.CDENTID = CDENTID;
}

public String getCDALERT() {
 return CDALERT;
}
public void setCDALERT(String CDALERT) {
 this.CDALERT = CDALERT;
}


}
