package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0020")
public class NQE0020 {
@PsFieldString(name="CODENT", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CODENT;
@PsFieldString(name="COALER", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String COALER;

public String getCODENT() {
 return CODENT;
}
public void setCODENT(String CODENT) {
 this.CODENT = CODENT;
}

public String getCOALER() {
 return COALER;
}
public void setCOALER(String COALER) {
 this.COALER = COALER;
}


}
