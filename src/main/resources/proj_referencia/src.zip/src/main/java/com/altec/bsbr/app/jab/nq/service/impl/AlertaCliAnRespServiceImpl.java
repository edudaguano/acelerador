package com.altec.bsbr.app.jab.nq.service.impl;

import java.util.ArrayList;
import java.util.List;
 

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;import com.altec.bsbr.fw.BusinessException;
import com.altec.bsbr.app.jab.nq.dao.AlertaCliAnRespDao;
import com.altec.bsbr.app.jab.nq.service.AlertaCliAnRespService;

@Service 
 public class AlertaCliAnRespServiceImpl implements AlertaCliAnRespService{ 
private final Logger LOGGER = LoggerFactory.getLogger(AlertaCliAnRespServiceImpl.class); 
@Autowired
private AlertaCliAnRespDao alertaclianresp;
 public String versao() throws BusinessException{ 
return alertaclianresp.versao();
}
 public String recuperarPergunta(String strCOENTID,String strCOALERT) throws BusinessException{ 
return alertaclianresp.recuperarPergunta(strCOENTID, strCOALERT);
}
 public String consultarHistorico(String strCOENTID,String strCOALERT,String strDTCOMIT,String strNUSEQUE) throws BusinessException{ 
return alertaclianresp.consultarHistorico(strCOENTID, strCOALERT, strDTCOMIT, strNUSEQUE);
}
 public String consultarJustificativa(String strCOENTI,String strCOALER) throws BusinessException{ 
return alertaclianresp.consultarJustificativa(strCOENTI, strCOALER);
}
 public String consultarEnquadramento(String strCOENTID,String strCOALERT,String strCOORGEN,String strCOENQSI) throws BusinessException{ 
return alertaclianresp.consultarEnquadramento(strCOENTID, strCOALERT, strCOORGEN, strCOENQSI);
}
 public String consultaOrgaoEnquadramento(String strCORGENQ) throws BusinessException{ 
return alertaclianresp.consultaOrgaoEnquadramento(strCORGENQ);
}}

