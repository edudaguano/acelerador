package com.altec.bsbr.app.jab.nq.dao.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0060;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQE0070;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0060;
import com.altec.bsbr.app.jab.nq.altair.formatos.NQS0070;
import com.altec.bsbr.app.jab.nq.dao.EnqSuspeitaDao;
import com.altec.bsbr.app.jab.nq.util.Utils;
import com.altec.bsbr.fw.altair.dto.ResponseDto;
import com.altec.bsbr.fw.altair.service.AltairService;
import com.altec.bsbr.fw.dao.jdbc.GenericJdbcDao;
import com.altec.bsbr.fw.ps.enums.PsFormatEnum;
import com.fasterxml.jackson.databind.ObjectMapper;

@Repository
public class EnqSuspeitaDaoImpl implements EnqSuspeitaDao {

	private final Logger LOGGER = LoggerFactory.getLogger(EnqSuspeitaDaoImpl.class);

	@Autowired
	private AltairService altairService;

	public void EscreveLog(String sTexto) {
		LOGGER.info(sTexto);
	}

	public String versao() {
		return "";
	}

	public String inserirEnquadramento(String strCDENTID, String strCDALERT, String strCDOREN1, String strCDENQ01,
			String strCDUSRES) {
		NQE0070 request = new NQE0070();
		request.setCDENTID(strCDENTID.isEmpty() ? null : Integer.valueOf(strCDENTID));
		request.setCDALERT(strCDALERT);
		request.setCDOREN1(strCDOREN1.isEmpty() ? null : Integer.valueOf(strCDOREN1));
		request.setCDENQ01(strCDENQ01);
		request.setCDUSRES(strCDUSRES);

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQA9", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0070.class));
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String listarOrgaoEnquadramento(String strCORGPAG) {
		NQE0060 request = new NQE0060();
		request.setCORGPAG(strCORGPAG.isEmpty() ? null : Integer.valueOf(strCORGPAG));

		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQA8", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0060.class));
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

	public String consultarEnquadramento(String strCORGENQ, String strCOENPAG) {
		NQE0060 request = new NQE0060();
		request.setCOENPAG(strCORGENQ);
		request.setCORGPAG(strCOENPAG.isEmpty() ? null : Integer.valueOf(strCOENPAG));
		
		try {
			ResponseDto resp = altairService.executar(PsFormatEnum.PS7, "NQA8", request);
			return new ObjectMapper().writeValueAsString(Utils.gerarRespostaGenericaAltair(resp.getObjeto(), NQS0060.class));
		} catch (Exception e) {
			e.printStackTrace();
			return e.getMessage().toString();
		}
	}

}
