package com.altec.bsbr.app.jab.nq.webservice;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.altec.bsbr.app.jab.nq.service.ComaService;
import com.altec.bsbr.app.jab.nq.service.ComaWebService;
import com.altec.bsbr.fw.webservice.WebServiceException; 

@WebService 
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL) 
public class ComaEndPoint extends SpringBeanAutowiringSupport implements ComaWebService {

	private final Logger LOGGER = LoggerFactory.getLogger(ComaEndPoint.class); 
	@Autowired
	private ComaService coma; 

	@WebMethod 
	public String fgNQAT7023(String programa,String segundoProg,String tamanho,String posicao,String banco,String codProd,String codigoErro,String  mensagemErro) throws WebServiceException{ 
		String retorno = ""; 
		try{ 
			LOGGER.info("Executar Teste Unitario");
			retorno = coma.fgNQAT7023(programa, segundoProg, tamanho, posicao, banco, codProd, codigoErro,  mensagemErro);
		}
		catch(Exception e){
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1); 
		} 
		return retorno; 
	}@WebMethod 
	public String fgNQAT6203(String programa,String segundoProg,String tamanho,String nuMatric,String nuBanco,String nuAgencia,String conta,String cliente,String pvs,String texto6,String tpUorg,String codigoErro,String  mensagemErro) throws WebServiceException{ 
		String retorno = ""; 
		try{ 
			LOGGER.info("Executar Teste Unitario");
			retorno = coma.fgNQAT6203(programa, segundoProg, tamanho, nuMatric, nuBanco, nuAgencia, conta, cliente, pvs, texto6, tpUorg, codigoErro,  mensagemErro);
		}
		catch(Exception e){
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1); 
		} 
		return retorno; 
	}@WebMethod 
	public String fgNQAT6200(String programa,String segundoProg,String tamanho,String nuMatric,String nuBanco,String nuAgencia,String cliente,String conta,String codigoErro,String  mensagemErro) throws WebServiceException{ 
		String retorno = ""; 
		try{ 
			LOGGER.info("Executar Teste Unitario");
			retorno = coma.fgNQAT6200(programa, segundoProg, tamanho, nuMatric, nuBanco, nuAgencia, cliente, conta, codigoErro,  mensagemErro);
		}
		catch(Exception e){
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1); 
		} 
		return retorno; 
	}@WebMethod 
	public String fgNQAT6202(String programa,String segundoProg,String tamanho,String nuMatric,String nuBanco,String nuAgencia,String cliente,String codigoErro,String  mensagemErro) throws WebServiceException{ 
		String retorno = ""; 
		try{ 
			LOGGER.info("Executar Teste Unitario");
			retorno = coma.fgNQAT6202(programa, segundoProg, tamanho, nuMatric, nuBanco, nuAgencia, cliente, codigoErro,  mensagemErro);
		}
		catch(Exception e){
			LOGGER.error(e.getMessage());
			throw new WebServiceException(e.getMessage(), -1); 
		} 
		return retorno; 
	}}

