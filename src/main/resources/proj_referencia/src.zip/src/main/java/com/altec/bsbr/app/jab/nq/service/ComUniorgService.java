package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.BusinessException;

public interface ComUniorgService {
	
	public String versao() throws BusinessException;

	public String consultaUniorg(String strCDUNIOR) throws BusinessException;
}
