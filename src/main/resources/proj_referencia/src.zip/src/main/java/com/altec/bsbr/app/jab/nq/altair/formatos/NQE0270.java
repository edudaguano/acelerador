package com.altec.bsbr.app.jab.nq.altair.formatos;
import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;
import java.math.BigInteger;

@PsFormat(name="NQE0270")
public class NQE0270 {
@PsFieldString(name="CDENTI", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDENTI;
@PsFieldString(name="CDALER", length=12, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDALER;
@PsFieldString(name="CDCENA", length=22, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDCENA;
@PsFieldString(name="CDDTINT", length=4, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDDTINT;
@PsFieldString(name="CDPROD", length=6, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String CDPROD;
@PsFieldString(name="NUCNTR", length=32, paddingAlign=PsAlign.LEFT, paddingChar=' ')
private String NUCNTR;

public String getCDENTI() {
 return CDENTI;
}
public void setCDENTI(String CDENTI) {
 this.CDENTI = CDENTI;
}

public String getCDALER() {
 return CDALER;
}
public void setCDALER(String CDALER) {
 this.CDALER = CDALER;
}

public String getCDCENA() {
 return CDCENA;
}
public void setCDCENA(String CDCENA) {
 this.CDCENA = CDCENA;
}

public String getCDDTINT() {
 return CDDTINT;
}
public void setCDDTINT(String CDDTINT) {
 this.CDDTINT = CDDTINT;
}

public String getCDPROD() {
 return CDPROD;
}
public void setCDPROD(String CDPROD) {
 this.CDPROD = CDPROD;
}

public String getNUCNTR() {
 return NUCNTR;
}
public void setNUCNTR(String NUCNTR) {
 this.NUCNTR = NUCNTR;
}


}
