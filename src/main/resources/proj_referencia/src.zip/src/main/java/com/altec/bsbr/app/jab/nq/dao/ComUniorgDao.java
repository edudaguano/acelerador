package com.altec.bsbr.app.jab.nq.dao;

import java.util.List;
import com.altec.bsbr.fw.ps.parser.object.PsScreen;

public interface ComUniorgDao {
	public String versao();

	public String consultaUniorg(String strCDUNIOR);
}
