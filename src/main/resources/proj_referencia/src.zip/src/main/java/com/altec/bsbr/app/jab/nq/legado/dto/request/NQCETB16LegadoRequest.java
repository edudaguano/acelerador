package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.ps.annotations.PsFormat;
import com.altec.bsbr.fw.ps.enums.PsAlign;


@PsFormat(name= "NQCETB16LegadoRequest")
public class NQCETB16LegadoRequest {
// -*-
//                                                                         
//        01     NQCETB16-ENTRADA.                                         
//                                                                         
	@PsFieldString(name= "NQCETB16_E_NM_PROG", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_E_NM_PROG;//          05   NQCETB16-E-NM-PROG            PIC  X(008).                

//       *       NOME DO PROGRAMA CHAMADO                                  
//                                                                         
	@PsFieldString(name= "NQCETB16_E_NM_AREA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_E_NM_AREA;//          05   NQCETB16-E-NM-AREA            PIC  X(008).                

//       *       NOME DA AREA DE TS                                        
//                                                                         
	@PsFieldString(name= "NQCETB16_E_SG_FCAO", length= 2, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_E_SG_FCAO;//          05   NQCETB16-E-SG-FCAO            PIC  X(002).                

//       *       FUNCAO A SER EXECUTADA                                    
//       *       L = LISTAR                                                
//       *       C = CONSULTA                                              
//                                                                         
	@PsFieldNumber(name= "NQCETB16_E_QT_TAMA_AREA", decimal= 0, length= 7, signed= false, defaultValue="0")
	private Long NQCETB16_E_QT_TAMA_AREA;//          05   NQCETB16-E-QT-TAMA-AREA       PIC  9(007).                

//       *       TAMANHO DA AREA DE TS                                     
//                                                                         
	@PsFieldString(name= "NQCETB16_E_CD_USUA", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_E_CD_USUA;//          05   NQCETB16-E-CD-USUA            PIC  X(008).                

//       *       CODIGO DO USUARIO                                         
//                                                                         
	@PsFieldNumber(name= "NQCETB16_E_NR_SEQU_SIST", decimal= 0, length= 4, signed= false, defaultValue="0")
	private Long NQCETB16_E_NR_SEQU_SIST;//          05   NQCETB16-E-NR-SEQU-SIST       PIC  9(004).                

//       *       NUMERO SEQUENCIAL DO SISTEMA                              
//                                                                         
	@PsFieldString(name= "NQCETB16_E_CD_BANC_CLIE", length= 4, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_E_CD_BANC_CLIE;//          05   NQCETB16-E-CD-BANC-CLIE       PIC  X(004).                

//       *       CODIGO DO BANCO                                           
//                                                                         
	@PsFieldString(name= "NQCETB16_E_CD_CLIE", length= 8, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_E_CD_CLIE;//          05   NQCETB16-E-CD-CLIE            PIC  X(008).                

//       *       CODIGO DO CLIENTE                                         
//                                                                         
	@PsFieldString(name= "NQCETB16_E_DT_INICIO", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_E_DT_INICIO;//          05   NQCETB16-E-DT-INICIO          PIC  X(010).                

//       *       DATA INICIO DO PERIODO                                    
//                                                                         
	@PsFieldString(name= "NQCETB16_E_DT_FIM", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_E_DT_FIM;//          05   NQCETB16-E-DT-FIM             PIC  X(010).                

//       *       DATA FIM DO PERIODO                                       
//                                                                         
	@PsFieldString(name= "NQCETB16_E_NR_CNTR", length= 20, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_E_NR_CNTR;//          05   NQCETB16-E-NR-CNTR            PIC  X(020).                

//       *       NUMERO DO CONTRATO                                        
//                                                                         
	@PsFieldString(name= "NQCETB16_E_DT_FORZ", length= 10, paddingAlign= PsAlign.LEFT, paddingChar= ' ')
	private String NQCETB16_E_DT_FORZ;//          05   NQCETB16-E-DT-FORZ            PIC  X(010).                

//       *       DATA DE FORMALIZACAO                                      
//                                                                         
	@PsFieldString(name= "NQCETB16_E_NR_CNPJ_LOJI", length= 15, paddingAlign= PsAlign.LEFT, paddingChar= '0')
	private String NQCETB16_E_NR_CNPJ_LOJI;//          05   NQCETB16-E-NR-CNPJ-LOJI       PIC  9(015).                

//       *       NUMERO DO CNPJ DO LOJISTA                                 
//                                                                         
	@PsFieldNumber(name= "NQCETB16_E_NR_SEQU_OPER", decimal= 0, length= 3, signed= false, defaultValue="0")
	private Long NQCETB16_E_NR_SEQU_OPER;//          05   NQCETB16-E-NR-SEQU-OPER       PIC  9(003).                
                                                                      
	public NQCETB16LegadoRequest() { }

	public String getNQCETB16_E_NM_PROG() {
		return NQCETB16_E_NM_PROG;
	}

	public void setNQCETB16_E_NM_PROG(String nQCETB16_E_NM_PROG) {
		NQCETB16_E_NM_PROG = nQCETB16_E_NM_PROG;
	}

	public String getNQCETB16_E_NM_AREA() {
		return NQCETB16_E_NM_AREA;
	}

	public void setNQCETB16_E_NM_AREA(String nQCETB16_E_NM_AREA) {
		NQCETB16_E_NM_AREA = nQCETB16_E_NM_AREA;
	}

	public String getNQCETB16_E_SG_FCAO() {
		return NQCETB16_E_SG_FCAO;
	}

	public void setNQCETB16_E_SG_FCAO(String nQCETB16_E_SG_FCAO) {
		NQCETB16_E_SG_FCAO = nQCETB16_E_SG_FCAO;
	}

	public Long getNQCETB16_E_QT_TAMA_AREA() {
		return NQCETB16_E_QT_TAMA_AREA;
	}

	public void setNQCETB16_E_QT_TAMA_AREA(Long nQCETB16_E_QT_TAMA_AREA) {
		NQCETB16_E_QT_TAMA_AREA = nQCETB16_E_QT_TAMA_AREA;
	}

	public String getNQCETB16_E_CD_USUA() {
		return NQCETB16_E_CD_USUA;
	}

	public void setNQCETB16_E_CD_USUA(String nQCETB16_E_CD_USUA) {
		NQCETB16_E_CD_USUA = nQCETB16_E_CD_USUA;
	}

	public Long getNQCETB16_E_NR_SEQU_SIST() {
		return NQCETB16_E_NR_SEQU_SIST;
	}

	public void setNQCETB16_E_NR_SEQU_SIST(Long nQCETB16_E_NR_SEQU_SIST) {
		NQCETB16_E_NR_SEQU_SIST = nQCETB16_E_NR_SEQU_SIST;
	}

	public String getNQCETB16_E_CD_BANC_CLIE() {
		return NQCETB16_E_CD_BANC_CLIE;
	}

	public void setNQCETB16_E_CD_BANC_CLIE(String nQCETB16_E_CD_BANC_CLIE) {
		NQCETB16_E_CD_BANC_CLIE = nQCETB16_E_CD_BANC_CLIE;
	}

	public String getNQCETB16_E_CD_CLIE() {
		return NQCETB16_E_CD_CLIE;
	}

	public void setNQCETB16_E_CD_CLIE(String nQCETB16_E_CD_CLIE) {
		NQCETB16_E_CD_CLIE = nQCETB16_E_CD_CLIE;
	}

	public String getNQCETB16_E_DT_INICIO() {
		return NQCETB16_E_DT_INICIO;
	}

	public void setNQCETB16_E_DT_INICIO(String nQCETB16_E_DT_INICIO) {
		NQCETB16_E_DT_INICIO = nQCETB16_E_DT_INICIO;
	}

	public String getNQCETB16_E_DT_FIM() {
		return NQCETB16_E_DT_FIM;
	}

	public void setNQCETB16_E_DT_FIM(String nQCETB16_E_DT_FIM) {
		NQCETB16_E_DT_FIM = nQCETB16_E_DT_FIM;
	}

	public String getNQCETB16_E_NR_CNTR() {
		return NQCETB16_E_NR_CNTR;
	}

	public void setNQCETB16_E_NR_CNTR(String nQCETB16_E_NR_CNTR) {
		NQCETB16_E_NR_CNTR = nQCETB16_E_NR_CNTR;
	}

	public String getNQCETB16_E_DT_FORZ() {
		return NQCETB16_E_DT_FORZ;
	}

	public void setNQCETB16_E_DT_FORZ(String nQCETB16_E_DT_FORZ) {
		NQCETB16_E_DT_FORZ = nQCETB16_E_DT_FORZ;
	}

	public String getNQCETB16_E_NR_CNPJ_LOJI() {
		return NQCETB16_E_NR_CNPJ_LOJI;
	}

	public void setNQCETB16_E_NR_CNPJ_LOJI(String nQCETB16_E_NR_CNPJ_LOJI) {
		NQCETB16_E_NR_CNPJ_LOJI = nQCETB16_E_NR_CNPJ_LOJI;
	}

	public Long getNQCETB16_E_NR_SEQU_OPER() {
		return NQCETB16_E_NR_SEQU_OPER;
	}

	public void setNQCETB16_E_NR_SEQU_OPER(Long nQCETB16_E_NR_SEQU_OPER) {
		NQCETB16_E_NR_SEQU_OPER = nQCETB16_E_NR_SEQU_OPER;
	}	
}