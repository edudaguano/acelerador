package com.altec.bsbr.app.jab.nq.dao;

import java.util.List;

import com.altec.bsbr.fw.ps.parser.object.PsScreen;

public interface AlertaGeradoDao {
	
	public String versao();

	public String montarComboSituacao(String strCDSITU);

	public String consultaFiltroAlerta(String strCOENTID, String strCOALERT, String strCOAGENC, String strCOUNIOR,
			String strTPDOC, String strNUDOC, String strDTINICI, String strDTFIM, String strCOSITUA, String strIDORDPA,
			String strTPCHM, String strCOALNKM);
}