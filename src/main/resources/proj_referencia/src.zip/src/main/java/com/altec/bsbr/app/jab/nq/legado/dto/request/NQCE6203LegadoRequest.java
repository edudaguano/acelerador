package com.altec.bsbr.app.jab.nq.legado.dto.request;

import com.altec.bsbr.fw.record.adapters.flatfile.Align;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtFieldFile;

@FixedLenghtFieldFile
public class NQCE6203LegadoRequest {
	/*
//  -*-NQCE6203                                                               
//         01      RECEIVE-COMMAREA.                                        
	@FixedLenghtField(position = 781, lenght = 8, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_PGM_CHAMADA;//                 03  COMM-PGM-CHAMADA      PIC  X(008).                   

	@FixedLenghtField(position = 782, lenght = 10, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_NOMEDATS;//                 03  COMM-NOMEDATS         PIC  X(010).                   

	@FixedLenghtField(position = 783, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_TAM_COMM;//                 03  COMM-TAM-COMM         PIC  9(007).                   

	@FixedLenghtField(position = 784, lenght = 9, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_MATRICULA;//                 03  COMM-MATRICULA        PIC  9(009).                   

	@FixedLenghtField(position = 785, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CINSTIT;//                 03  COMM-CINSTIT          PIC  9(003).                   

	@FixedLenghtField(position = 786, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_CODAGENC;//                 03  COMM-CODAGENC         PIC  9(004).                   

	@FixedLenghtField(position = 787, lenght = 10, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_NUMCONTA;//                 03  COMM-NUMCONTA         PIC  9(010).                   

//  ISBAN1*        03  COMM-CCLI             PIC  9(010).                   
	@FixedLenghtField(position = 788, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 03;//  ISBAN1         03  COMM-CCLI             PIC  X(008).                   

	@FixedLenghtField(position = 789, lenght = 0, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String 03;//  ISBAN1         03  COMM-FILLER           PIC  X(002).                   

	@FixedLenghtField(position = 790, lenght = 7, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_IDENT_PVS;//                 03  COMM-IDENT-PVS        PIC  9(007).                   

	@FixedLenghtField(position = 791, lenght = 474, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String COMM_TEXTO_6;//                 03  COMM-TEXTO-6          PIC  X(474).                   

	@FixedLenghtField(position = 792, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long COMM_TP_UOR;//                 03  COMM-TP-UOR           PIC  9(003).                   

//         01      SEND-AREA.                                               
	@FixedLenghtField(position = 793, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN;//                 03  TS01-MENS-LEN         PIC S9(004) COMP VALUE +83.    

//                 03  TS01-AREA-MENSAGEM.                                  
	@FixedLenghtField(position = 794, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO;//                     05  TS01-RETORNO      PIC  9(003) VALUE ZEROS.       

	@FixedLenghtField(position = 795, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM;//                     05  TS01-MENSAGEM     PIC  X(080) VALUE SPACES.                                                                     

	@FixedLenghtField(position = 796, lenght = 4, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_MENS_LEN_X;//                 03  TS01-MENS-LEN-X       PIC S9(004) COMP VALUE +83.    

//                 03  TS01-AREA-NQCE6203.                                  
	@FixedLenghtField(position = 797, lenght = 3, paddingAlign = Align.LEFT, paddingChar = '0')
	private Long TS01_RETORNO_X;//                     05  TS01-RETORNO-X    PIC  9(003) VALUE ZEROS.       

	@FixedLenghtField(position = 798, lenght = 80, paddingAlign = Align.LEFT, paddingChar = ' ')
	private String TS01_MENSAGEM_X;//                     05  TS01-MENSAGEM-X   PIC  X(080) VALUE SPACES.      

	public NQCE6203LegadoRequest() { }
	public NQCE6203LegadoRequest(String comm_pgm_chamada, String comm_nomedats, Long comm_tam_comm, Long comm_matricula, Long comm_cinstit, Long comm_codagenc, Long comm_numconta, String 03, String 03, Long comm_ident_pvs, String comm_texto_6, Long comm_tp_uor) { 		this.COMM_PGM_CHAMADA = comm_pgm_chamada;
		this.COMM_NOMEDATS = comm_nomedats;
		this.COMM_TAM_COMM = comm_tam_comm;
		this.COMM_MATRICULA = comm_matricula;
		this.COMM_CINSTIT = comm_cinstit;
		this.COMM_CODAGENC = comm_codagenc;
		this.COMM_NUMCONTA = comm_numconta;
		this.03 = 03;
		this.03 = 03;
		this.COMM_IDENT_PVS = comm_ident_pvs;
		this.COMM_TEXTO_6 = comm_texto_6;
		this.COMM_TP_UOR = comm_tp_uor;
		this.TS01_MENS_LEN = +83;
		this.TS01_RETORNO = ZEROS;
		this.TS01_MENSAGEM = SPACES;
		this.TS01_MENS_LEN_X = +83;
		this.TS01_RETORNO_X = ZEROS;
		this.TS01_MENSAGEM_X = SPACES; 
	}
	public String getCOMM_PGM_CHAMADA() { return this.COMM_PGM_CHAMADA; }
	public String getCOMM_NOMEDATS() { return this.COMM_NOMEDATS; }
	public Long getCOMM_TAM_COMM() { return this.COMM_TAM_COMM; }
	public Long getCOMM_MATRICULA() { return this.COMM_MATRICULA; }
	public Long getCOMM_CINSTIT() { return this.COMM_CINSTIT; }
	public Long getCOMM_CODAGENC() { return this.COMM_CODAGENC; }
	public Long getCOMM_NUMCONTA() { return this.COMM_NUMCONTA; }
	public String get03() { return this.03; }
	public String get03() { return this.03; }
	public Long getCOMM_IDENT_PVS() { return this.COMM_IDENT_PVS; }
	public String getCOMM_TEXTO_6() { return this.COMM_TEXTO_6; }
	public Long getCOMM_TP_UOR() { return this.COMM_TP_UOR; }
	public Long getTS01_MENS_LEN() { return this.TS01_MENS_LEN; }
	public Long getTS01_RETORNO() { return this.TS01_RETORNO; }
	public String getTS01_MENSAGEM() { return this.TS01_MENSAGEM; }
	public Long getTS01_MENS_LEN_X() { return this.TS01_MENS_LEN_X; }
	public Long getTS01_RETORNO_X() { return this.TS01_RETORNO_X; }
	public String getTS01_MENSAGEM_X() { return this.TS01_MENSAGEM_X; }
	public void setCOMM_PGM_CHAMADA(String comm_pgm_chamada) { this.COMM_PGM_CHAMADA = comm_pgm_chamada; }
	public void setCOMM_NOMEDATS(String comm_nomedats) { this.COMM_NOMEDATS = comm_nomedats; }
	public void setCOMM_TAM_COMM(Long comm_tam_comm) { this.COMM_TAM_COMM = comm_tam_comm; }
	public void setCOMM_MATRICULA(Long comm_matricula) { this.COMM_MATRICULA = comm_matricula; }
	public void setCOMM_CINSTIT(Long comm_cinstit) { this.COMM_CINSTIT = comm_cinstit; }
	public void setCOMM_CODAGENC(Long comm_codagenc) { this.COMM_CODAGENC = comm_codagenc; }
	public void setCOMM_NUMCONTA(Long comm_numconta) { this.COMM_NUMCONTA = comm_numconta; }
	public void set03(String 03) { this.03 = 03; }
	public void set03(String 03) { this.03 = 03; }
	public void setCOMM_IDENT_PVS(Long comm_ident_pvs) { this.COMM_IDENT_PVS = comm_ident_pvs; }
	public void setCOMM_TEXTO_6(String comm_texto_6) { this.COMM_TEXTO_6 = comm_texto_6; }
	public void setCOMM_TP_UOR(Long comm_tp_uor) { this.COMM_TP_UOR = comm_tp_uor; }
	public void setTS01_MENS_LEN(Long ts01_mens_len) { this.TS01_MENS_LEN = ts01_mens_len; }
	public void setTS01_RETORNO(Long ts01_retorno) { this.TS01_RETORNO = ts01_retorno; }
	public void setTS01_MENSAGEM(String ts01_mensagem) { this.TS01_MENSAGEM = ts01_mensagem; }
	public void setTS01_MENS_LEN_X(Long ts01_mens_len_x) { this.TS01_MENS_LEN_X = ts01_mens_len_x; }
	public void setTS01_RETORNO_X(Long ts01_retorno_x) { this.TS01_RETORNO_X = ts01_retorno_x; }
	public void setTS01_MENSAGEM_X(String ts01_mensagem_x) { this.TS01_MENSAGEM_X = ts01_mensagem_x; }
	*/
}