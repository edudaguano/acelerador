package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface ParametrosWebService {
	
	public String confirmarRegras(String acao, String intProduto, String intCodBanco, String intPeriodo,
			String intAgrupa, String lngAtividade, String lngOcupacao, String intSegmento, String dblValor,
			String strUsuario) throws WebServiceException;

	public String incluirValorOpSensib(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdSelecionada, String dblValor, String strUsuario) throws WebServiceException;

	public String alterarValorOpSensib(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdSelecionada, String dblValor, String strUsuario) throws WebServiceException;

	public String consultarBancoPeriodoProdAplic() throws WebServiceException;

	public String consultarValorOpSensivel(String intBanco, String intAplicativo, String intPeriodo, String intProduto) throws WebServiceException;

	public String consultarAgencias(String intBanco, String intAgencia, String strFuncao) throws WebServiceException;

	public String consultarApoio(String intTabela, String number) throws WebServiceException;

	public String consultarAtvEconomica(String intBanco, String intPeriodicidade) throws WebServiceException;

	public String consultarRegras(String intBanco, String intProduto, String intPeriodicidade) throws WebServiceException;

	public String consultarTipoAgrupamento(String intBanco, String intProduto, String intPeriodicidade) throws WebServiceException;

	public String incluirAgencia(String intCodBancoSelecionado, String intCodAgSelecionada, String TpAgrupaTruncado,
			String strUsuario, String dblValor) throws WebServiceException;

	public String alterarAgencia(String intCodBancoSelecionado, String intCodAgSelecionada, String TpAgrupaTruncado,
			String strUsuario, String dblValor) throws WebServiceException;

	public String incluirApoio(String intCodTabelaSelecionada, String strCodItem, String strDescricao,
			String strDescResumida, String strStatus, String strUsuario) throws WebServiceException;

	public String alterarApoio(String intCodTabelaSelecionada, String strCodItem, String strDescricao,
			String strDescResumida, String strStatus, String strUsuario) throws WebServiceException;

	public String incluirAtividadeEconomica(String intCodBancoSelecionado, String intCodPeriododSelecionada,
			String intAtvSelecionada, String strUsuario, String strDescricao) throws WebServiceException;

	public String carregaCombo(String intCodBancoSelecionado) throws WebServiceException;

	public String incluirCtrlProcessamento(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdutoSelecionada, String auxData, String auxDataAnt,
			String strDescAplicativo, String strUsuario) throws WebServiceException;

	public String alterarCtrlProcessamento(String intCodBancoSelecionado, String intCodAplicSelecionada,
			String intCodPeriododSelecionada, String intCodProdutoSelecionada, String auxData, String auxDataAnt,
			String strDescAplicativo, String strUsuario, String strStatus) throws WebServiceException;

	public String recuperaProduto(String intCodBancoSelecionado) throws WebServiceException;

	public String alterarFiltroSensib(String codTabela, String strCodItem, String strDescricao, String strDescResumida,
			String strStatus, String strUsuario) throws WebServiceException;

	public String incluirPais(
			String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada,
			String intPaisSelecionado, /* right("0000000000" & intPaisSelecionado,10), _ */
			String intTipoPaisSelecionado, /* right("000" & intTipoPaisSelecionado,3), _ */
			String strUsuario, String strDescPais) throws WebServiceException;

	public String alterarPais(
			String intCodBancoSelecionado, String intCodProdSelecionada, String intCodPeriododSelecionada,
			String intPaisSelecionado, /* right("0000000000" & intPaisSelecionado,10), */
			String intTipoPaisSelecionado, /* right("000" & intTipoPaisSelecionado,3), */
			String strUsuario, String strDescPais) throws WebServiceException;

	public String recuperaPaisesTipo() throws WebServiceException;

	public String incluirReceptores(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodSegmentoSelecionado, /* right(intCodSegmentoSelecionado,3), */
			String intSequencia, String strNomeRecepItem, String strPrefEmailItem, String intCodSufixoSelecionado,
			String intCodTpEnvioSelecionado, String strUsuario) throws WebServiceException;

	public String alterarReceptores(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodSegmentoSelecionado, String sequencia, String strNomeRecepItem, String strPrefEmailItem,
			String intCodSufixoSelecionado, String intCodTpEnvioSelecionado, String strUsuario) throws WebServiceException;

	public String consultarSegmSufTpEnvio(String intCodBancoSelecionado) throws WebServiceException;

	public String verificaStatusProduto(String intCodBancoSelecionado) throws WebServiceException;

	public String recuperaTpHistAtvOcup(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipo1, String intTipo2, String intTipo3) throws WebServiceException;

	public String recuperaAtvOcup(String intCodBancoSelecionado) throws WebServiceException;

	public String incluirTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipo, String strUsuario, String strDescAgrupamento) throws WebServiceException;

	public String recuperarTipoCombo(String banco) throws WebServiceException;

	public String incluirValorTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipoSelecionado, String dblValor, String strUsuario,
			String strDescricao) throws WebServiceException;

	public String alterarValorTpAgrupamento(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intTipoSelecionado, String dblValor, String strUsuario,
			String strDescricao) throws WebServiceException;

	public String excluirAgencia(String intCodBancoItem, String intCodAgenciaItem, String strTipoAgrupamento,
			String strUsuario) throws WebServiceException;

	public String consultarBancoAgencia() throws WebServiceException;

	public String excluirApoio(String intTabelaItem, String strCodItem, String strDescTot, String strDescRes,
			String strStatus, String strUsuario) throws WebServiceException;

	public String excluirAtividadeEconomica(String intCodBancoItem, String intCodPeriodoItem, String intCodAtividade,
			String strUsuario) throws WebServiceException;

	public String consultarBancoPeriodo() throws WebServiceException;

	public String consultarBancoPeriodoProduto() throws WebServiceException;

	public String recuperaCtrlProcessamento(String banco, String aplicativo, String periodo) throws WebServiceException;

	public String consultarBanco() throws WebServiceException;

	public String consultarFiltroSensibilizacao(String intCodBancoSelecionado, String dblCodRetorno,
			String strMsgRetorno) throws WebServiceException;

	public String excluirPais(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem,
			String intCDHISTItem, String intTPHISTItem, String strUsuario) throws WebServiceException;

	public String consultarPaises(String banco, String produto, String periodo) throws WebServiceException;

	public String excluirReceptores(String intCodBancoItem, String intCodProdItem, String intCodSegmentoItem,
			String intSequencia, String strNomeRecepItem, String strPrefEmailItem, String intCodSufixoEmailItem,
			String strTipoEnvioItem, String strUsuario) throws WebServiceException;

	public String consultarBancoProduto() throws WebServiceException;

	public String incluirSensibilizacao(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario) throws WebServiceException;

	public String alterarSensibilizacao(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario) throws WebServiceException;

	public String consultarSensibilizacao(String banco, String produto, String periodo) throws WebServiceException;

	public String incluirTpValorPerfil(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario) throws WebServiceException;

	public String alterarTpValorPerfil(String intCodBancoSelecionado, String intCodProdSelecionada,
			String intCodPeriododSelecionada, String intCodMesSelecionado, String strUsuario) throws WebServiceException;

	public String consultarTpValorPerfil(String banco, String produto, String periodo) throws WebServiceException;

	public String excluirTipoAgrupamento(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem,
			String intCDHISTItem, String intTPHISTItem, String strUsuario) throws WebServiceException;

	public String excluirValorTpAgrupamento(String intCodBancoItem, String intCodProdItem, String intCodPeriodoItem,
			String intTPHISTItem, String strUsuario) throws WebServiceException; /* Left(Trim(strUsuario),8), */

	public String consultarValorTpAgrupamento(String banco, String produto, String periodo) throws WebServiceException;
}
