package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException; 

public interface ComaWebService {
	
	public String fgNQAT7023(String programa,String segundoProg,String tamanho,String posicao,String banco,String codProd,String codigoErro,String  mensagemErro) throws WebServiceException; 
	public String fgNQAT6203(String programa,String segundoProg,String tamanho,String nuMatric,String nuBanco,String nuAgencia,String conta,String cliente,String pvs,String texto6,String tpUorg,String codigoErro,String  mensagemErro) throws WebServiceException; 
	public String fgNQAT6200(String programa,String segundoProg,String tamanho,String nuMatric,String nuBanco,String nuAgencia,String cliente,String conta,String codigoErro,String  mensagemErro) throws WebServiceException; 
	public String fgNQAT6202(String programa,String segundoProg,String tamanho,String nuMatric,String nuBanco,String nuAgencia,String cliente,String codigoErro,String  mensagemErro) throws WebServiceException;
	
}

