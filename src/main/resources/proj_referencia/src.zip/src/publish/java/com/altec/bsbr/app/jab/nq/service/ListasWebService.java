package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface ListasWebService {
	public String listarLista(String strCodSist, String strCodUser) throws WebServiceException;

	public String consultarLista(String strCodSist, String strCodList, String strCodUser) throws WebServiceException;

	public String incluirLista(String strCodSist, String strCodCamp, String strDsList, String strListAtiv,
			String strCodUser) throws WebServiceException;

	public String alterarLista(String strCodSist, String strCodList, String strCodCamp, String strDsList,
			String strListAtiv, String strCodUser) throws WebServiceException;

	public String excluirLista(String strCodSist, String strCodList, String strCodUser) throws WebServiceException;

	public String inicializarinputArea(String tNQ_NQAT2003_NQCETB03_ENTRADA) throws WebServiceException;

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws WebServiceException;
}
