package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface ComOpSuspComuWebService {
	public String versao() throws WebServiceException;

	public String salvaComunicacao(String strCOENTID, String strCODAGEN, String strTPUNIOR, String strNUNIORG,
			String strNUCONTA, String strNUPENUM, String strTPDOCTO, String strNUDOCTO, String strNOPESSO,
			String strCOSEGPR, String strCOSEGSE, String strCOAREAT, String strTCOPROF, String strVLRENDA,
			String strDTRENDA, String strCOTPREN, String strVLPATRI, String strDTPATRI, String strICCEP,
			String strNOEMPRE, String strCOATIVI, String strCOATCNA, String strCOTPCOR, String strVLFATAN,
			String strDTFATAN, String strTXPARA1, String strTXPARA2, String strTXPARA3, String strTXPARA4,
			String strTXPARA5, String strTXPARA6, String strTXPARA7, String strTXPARA8, String strTXPARA9,
			String strTXPAR10, String strNOCONJU, String strICORREN, String strCDUSRES, String strICIMPED)
			throws WebServiceException;
}
