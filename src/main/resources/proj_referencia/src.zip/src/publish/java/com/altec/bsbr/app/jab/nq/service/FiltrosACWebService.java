package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface FiltrosACWebService {
	public String consultarFiltros2(String strCodSist, String strDtOcorr, String strCodUser)
			throws WebServiceException;

	public String consultarFiltros(String strCodSist, String strDtOcorr, String strCodUser)
			throws WebServiceException;

	public String fnAddCaracter(String vlr, String tp, String tam) throws WebServiceException;

	public String dataAlta(String dtBaixa) throws WebServiceException;
}
