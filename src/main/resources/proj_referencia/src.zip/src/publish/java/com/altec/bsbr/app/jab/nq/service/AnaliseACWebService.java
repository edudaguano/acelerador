package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface AnaliseACWebService {
	public String consultarAnalises(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser, String strFuncao) throws WebServiceException;

	public String listarPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser) throws WebServiceException;

	public String listarClientes(String strCodSist, String strBanco, String strCodCliente, String strDtOcorr,
			String strNotUPLD, String strParOper, String strParGer, String strParUPLD, String strRegra,
			String strPeriodo, String strCodUser) throws WebServiceException;

	public String fnAddCaracter(String vlr, String tp, String tam) throws WebServiceException;

	public String dataAlta(String dtBaixa) throws WebServiceException;
}
