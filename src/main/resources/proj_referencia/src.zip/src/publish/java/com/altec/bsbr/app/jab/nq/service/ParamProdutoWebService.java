package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface ParamProdutoWebService {
	public String versao() throws WebServiceException;

	public String listaProduto(String strSIGLA, String strNUSEQ, String strDETINTE, String strNOMEPRO,
			String strIDORDPA) throws WebServiceException;

	public String alteraProduto(String strSGSISOR, String strSQSISOR, String strCDDETIN, String strDHFILTR,
			String strTPOPER, String strICMONIT, String strVLMINPR, String strCDUSRES) throws WebServiceException;

	public String listaAlteracaoParametro(String strCOSIGLA, String strNUSEQSI, String strCODETIN, String strCOOPINT,
			String strIDORDPG) throws WebServiceException;
}
