package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface HistoricoWebService {
	
	public String recuperaDadosAlt(String intConceito1, String intConceito2) throws WebServiceException;

	public String recuperaDadosInc(String intHistorico, String intAgrupamento, String intConceito1, String intConceito2) throws WebServiceException;

	public String consultarLista(String intOpcao, String intBanco, String intProduto, String intPeriodicidade) throws WebServiceException;

	public String consultarBancoProdPeriod() throws WebServiceException;

	public String IncluirHistorico(String intOpcao, String intBanco, String intPeriodicidade, String intProduto,
			String intCodHist, String intHistorico, String strUsuario, String strDescricao, String strConceito1,
			String strConceito2) throws WebServiceException;

	public String AlterarHistorico(String intOpcao, String intBanco, String intPeriodicidade, String intProduto,
			String intCodHist, String intHistorico, String strUsuario, String strDescricao, String strConceito1, String strConceito2) throws WebServiceException;

	public String ExclusaoItem(String intOpcao, String intBanco, String intProduto, String intPeriodicidade,
			String intCodHist, String intHistorico, String strUsuario) throws WebServiceException;
}
