package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface ClientesACWebService {
	public String consultarClientes(String strBanco, String strCliente, String StrUsuario) throws WebServiceException;

	public String listarClientes(String strBanco, String strCliente, String StrUsuario) throws WebServiceException;

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws WebServiceException;
}
