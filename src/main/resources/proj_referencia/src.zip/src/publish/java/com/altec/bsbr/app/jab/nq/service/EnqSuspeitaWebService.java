package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface EnqSuspeitaWebService {
	public String versao() throws WebServiceException;

	public String inserirEnquadramento(String strCDENTID, String strCDALERT, String strCDOREN1, String strCDENQ01,
			String strCDUSRES) throws WebServiceException;

	public String listarOrgaoEnquadramento(String strCORGPAG) throws WebServiceException;

	public String consultarEnquadramento(String strCORGENQ, String strCOENPAG) throws WebServiceException;
}
