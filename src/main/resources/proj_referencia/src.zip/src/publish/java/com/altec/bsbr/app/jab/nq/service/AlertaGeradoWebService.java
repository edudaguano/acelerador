package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface AlertaGeradoWebService {
	public String versao() throws WebServiceException;

	public String montarComboSituacao(String strCDSITU) throws WebServiceException;

	public String consultaFiltroAlerta(String strCOENTID, String strCOALERT, String strCOAGENC, String strCOUNIOR,
			String strTPDOC, String strNUDOC, String strDTINICI, String strDTFIM, String strCOSITUA, String strIDORDPA,
			String strTPCHM, String strCOALNKM) throws WebServiceException;
}
