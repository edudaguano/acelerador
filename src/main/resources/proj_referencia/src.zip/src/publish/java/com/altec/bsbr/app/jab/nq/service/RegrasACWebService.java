package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface RegrasACWebService {
	public String consultarRegras(String strCodSist, String strPeriodo, String strSituacao, String strCodUser)
			throws WebServiceException;

	public String incluirRegras(String strCodSist, String strAtivo, String strCodUser, String strPeriodo,
			String strRegra, String strProduto, String strSubProduto, String StrPEP, String strFunc,
			String strTpTransacao, String strQtdTransacao, String strPercRenda, String strVlTransacao)
			throws WebServiceException;

	public String alterarRegras(String strCodSist, String strAtivo, String strCodUser, String strPeriodo,
			String strRegra, String strProduto, String strSubProduto, String StrPEP, String strFunc,
			String strTpTransacao, String strQtdTransacao, String strPercRenda, String strVlTransacao)
			throws WebServiceException;

	public String inicializarinputArea(String tNQ_NQAT2007_NQCETB07_Entrada) throws WebServiceException;

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws WebServiceException;
}
