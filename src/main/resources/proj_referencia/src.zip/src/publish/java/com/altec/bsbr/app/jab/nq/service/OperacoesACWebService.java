package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface OperacoesACWebService{ 

	public String operacoesGC(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException;

	public String operacoesMP(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCartaoCred, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException;

	public String operacoesUG(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strDtFormaliz, String strNumContrato, String strNumOper, String strTpOperacao,
			String strCodUser) throws WebServiceException;

	public String operacoesLI(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strDtFormaliz, String strNumContrato, String strNumOper, String strCNPJLoji,
			String strTpOperacao, String strCodUser) throws WebServiceException;

	public String operacoesKM(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumTitulo, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException;

	public String operacoesOX(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumProposta, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException;

	public String operacoesEZ(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumBoleto, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException;

	public String operacoesAR(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumOperacao, String strTpOperacao, String strCodUser) throws WebServiceException;

	public String operacoesGR(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException;

	public String operacoesYZ(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumContrato, String strNumOper, String strTpOperacao, String strCodUser) throws WebServiceException;

	public String operacoesVC(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCtaDebito, String strNumProposta, String strNumApolice, String strNumOper,
			String strTpOperacao, String strCodUser) throws WebServiceException;

	public String operacoesIY(String strCodSist, String strBanco, String strCodCliente, String strDtInicio,
			String strDtFinal, String strNumCtaDebito, String strNumProposta, String strNumApolice, String strNumOper,
			String strTpOperacao, String strCodUser) throws WebServiceException;

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws WebServiceException;

	public String fnAddCaracterCliente(String Vlr, String Tp, String Tam) throws WebServiceException;

	public String dataAlta(String dtBaixa) throws WebServiceException; 
}
