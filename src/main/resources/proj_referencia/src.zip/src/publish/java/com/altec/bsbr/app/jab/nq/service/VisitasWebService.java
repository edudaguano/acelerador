package com.altec.bsbr.app.jab.nq.service;

import java.util.Date;

import com.altec.bsbr.fw.webservice.WebServiceException; 

public interface VisitasWebService{ 

	public String grid6070(String NQAT6070p, String NQAT6070s, 
			String campoNumerico, String campoAlfanumerico, long lngMatricula, 
			String banco, String agencia, String status, 
			String pessoa, long cnpjCpf, int codigo, String mensagem) throws WebServiceException; 
	
	public String especifica6071(String NQAT6071p, String NQAT6071s,
			String campoNumerico, String campoAlfanumerico, long lngMatricula, 
			String chave1, String chave2, String chave3, String chave4,  
			String chave5, String chave6, String texto1, int codigo, String mensagem) throws WebServiceException;
	
	public String parecer6072(String NQAT6072p, String NQAT6072s, 
			 String numericoUm,  String campoAlfanumerico,  long lngMatricula, 
			 String cboBanco,  String txtAgencia,  String tpPessoa, String cpfCnpj, 
			 String texto1, String texto2, String texto3, String texto4, String texto5, 
			 String motivo, long longMatricula, Date data, String tpPerfil, String acao, 
			 int codigo, String mensagem) throws WebServiceException; 
	
	public String incExc6073(String NQAT6073p, String NQAT6073s, 
			String campoNumerico, String campoAlfanumerico, long matricula, 
			String banco, String agencia, String pessoa, String documento, 
			String conta, String acao, int codigo, String mensagem) throws WebServiceException; 
	
	public String gridTotal6074(String NQAT6074p,  String NQAT6074s, 
			String campoNumerico, String campoAlfanumerico,  long matricula, 
			String banco,  Date data,  String texto1, int codigo, String parm) throws WebServiceException; 

}

