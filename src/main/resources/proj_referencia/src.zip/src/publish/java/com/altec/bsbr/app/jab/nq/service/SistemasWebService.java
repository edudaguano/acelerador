package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface SistemasWebService {
	public String listarSistema(String strCodUser) throws WebServiceException;

	public String consultarSistema(String strCodSist, String strCodUser) throws WebServiceException;

	public String incluirSistema(String strCodSist, String strSigla, String strNmFuncao, String strDesc,
			String strAtivo, String strCodUser) throws WebServiceException;

	public String alterarSistema(String strCodSist, String strSigla, String strNmFuncao, String strDesc,
			String strAtivo, String strCodUser) throws WebServiceException;

	public String excluirSistema(String strCodSist, String strCodUser) throws WebServiceException;

	public String inicializarinputArea(String tNQ_NQAT2001_NQCETB01_ENTRADA) throws WebServiceException;

	public String fnAddCaracter(String vlr, String tp, String tam) throws WebServiceException;
}
