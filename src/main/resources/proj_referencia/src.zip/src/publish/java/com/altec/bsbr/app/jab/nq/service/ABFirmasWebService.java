package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException; 

 public interface ABFirmasWebService{ 
public String rsConsultaProcuradores(String nu_banco, String nu_agencia, String tpConta, String Conta) throws WebServiceException; 
}

