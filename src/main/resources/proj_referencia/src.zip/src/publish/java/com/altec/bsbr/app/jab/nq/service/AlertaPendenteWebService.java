package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface AlertaPendenteWebService {
	public String versao() throws WebServiceException;

	public String consultarAlerta(String strCOENTID, String strTPUNIOR, String strCDUNIOR, String strCOALERP,
			String strDTQUEST, String strDTGERPA, String strIDORDPA) throws WebServiceException;
}
