package com.altec.bsbr.app.jab.nq.util;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

import com.altec.bsbr.fw.ps.annotations.PsFieldNumber;
import com.altec.bsbr.fw.ps.annotations.PsFieldString;
import com.altec.bsbr.fw.record.adapters.flatfile.annotation.FixedLenghtField;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

@Service
public class JSONMapper {
	
	public <T> T jsonToObject(String json, Class<T> mapClass) throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper m = new ObjectMapper();
		m.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		return m.readValue(json, mapClass);
	}
	
	public <T> List<T> jsonToObjectList(String json, Class<T> mapClass) throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper m = new ObjectMapper();
		m.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		return m.readValue(json, m.getTypeFactory().constructCollectionType(List.class, mapClass));
	}
	
//	public Map<String, Object> legadoToJSON(List<Object> legado) {
//		Map<String, Object> mapResponses = new HashMap<String, Object>();
//		for(Object elem : legado)
//			if(mapResponses.containsKey(elem.getClass().getSimpleName())) {
//				if(!(mapResponses.get(elem.getClass().getSimpleName()) instanceof List)) {
//					List<Object> resps = new ArrayList<Object>();
//					resps.add(mapResponses.get(elem.getClass().getSimpleName()));
//					mapResponses.replace(elem.getClass().getSimpleName(), resps);
//				}
//				((List<Object>) mapResponses.get(elem.getClass().getSimpleName())).add(elem);				
//			} else
//				mapResponses.put(elem.getClass().getSimpleName(), elem);
//		
//		return mapResponses;
// 	}
	
	public Map<String, List<Object>> legadoToJSON(List<Object> legado) {
		Map<String, List<Object>> mapResponses = new HashMap<String, List<Object>>();
		ObjectMapper om = new ObjectMapper();
		om.enable(SerializationFeature.INDENT_OUTPUT);
		for(Object elem : legado) 
			if (mapResponses.containsKey(elem.getClass().getSimpleName())) {
				List<Object> lst = mapResponses.get(elem.getClass().getSimpleName());
				lst.add(elem);
				mapResponses.replace(elem.getClass().getSimpleName(), lst);
			} else {
				List<Object> lst = new ArrayList<Object>();
				lst.add(elem);
				mapResponses.put(elem.getClass().getSimpleName(), lst);
			}
		
			
		return mapResponses;
 	}

 	public String mockLegadoVarString(Integer len, String varName) {
 		String[] blocks = varName.toLowerCase().split(Pattern.quote("_"));
// 		System.out.println("arrays copy "+Arrays.toString(Arrays.copyOfRange(blocks, 1, blocks.length)));
// 		System.out.println("arrays join "+String.join(" ", Arrays.copyOfRange(blocks, 1, blocks.length)));
 		return String.join(" ", Arrays.copyOfRange(blocks, 1, blocks.length));
 	}
 	
 	public Double mockLegadoVarDouble(Integer len) {
 		return (Math.random()); 
 	}
 	
 	public Integer mockLegadoVarInteger(Integer len) {
 		return (int) (Math.random()); 
 	}
 	
 	public Long mockLegadoVarLong(Integer len) {
 		return (long) (Math.random()); 
 	}
 	
 	public Object mockLegadoObject(Class clazz, Object o) {
		try {	 			
			for(Field f : clazz.getDeclaredFields()) {
				f.setAccessible(true);
				Class fType = f.getType();
				switch(fType.getSimpleName()) {
					case "String":
						try {
							f.set(o, mockLegadoVarString(f.getAnnotation(FixedLenghtField.class).lenght(), f.getName()));							
						} catch (Exception e) {
							f.set(o, mockLegadoVarString(f.getAnnotation(PsFieldString.class).length(), f.getName()));
						}
						break;
					case "Long":
						try {
							f.set(o, mockLegadoVarLong(f.getAnnotation(FixedLenghtField.class).lenght()));
						} catch (Exception e) {
							f.set(o, mockLegadoVarLong(f.getAnnotation(PsFieldNumber.class).length()));
						}
						break;
					case "Integer":
						try {
							f.set(o, mockLegadoVarInteger(f.getAnnotation(FixedLenghtField.class).lenght()));
						} catch (Exception e) {
							f.set(o, mockLegadoVarLong(f.getAnnotation(PsFieldNumber.class).length()));
						}
						break;
					case "Double":
						try {
							f.set(o, mockLegadoVarDouble(f.getAnnotation(FixedLenghtField.class).lenght()));							
						} catch (Exception e) {
							f.set(o, mockLegadoVarLong(f.getAnnotation(PsFieldNumber.class).length()));
						}
						break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return o;
 	}
	
}
