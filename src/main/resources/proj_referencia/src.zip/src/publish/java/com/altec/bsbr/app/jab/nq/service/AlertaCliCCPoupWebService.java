package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface AlertaCliCCPoupWebService {
	public String versao() throws WebServiceException;

	public String consultarCenario(String strCODENTI, String strCODALER, String strCODCENA) throws WebServiceException;

	public String consultarDadoProduto(String strCDENTI, String strCDALER, String strCDCENA, String strCDDTINT,
			String strCDPROD, String strNUCNTR) throws WebServiceException;

	public String consultarClientePJ(String strCOENTID, String strCOALER) throws WebServiceException;

	public String consultarClientePF(String strCOENTID, String strCOALER) throws WebServiceException;

	public String consultarOperacao(String strCDENTID, String strCDALERT, String strCDCENAR, String strCDDETIN,
			String strCDDOCOP, String strNUCNTR) throws WebServiceException;
}
