package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface ComUniorgWebService {
	
	public String versao() throws WebServiceException;

	public String consultaUniorg(String strCDUNIOR) throws WebServiceException;
}
