package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface ComOpSusInfCliWebService {

	public String versao() throws WebServiceException;

	public String consultarAgencia(String strNUENTID, String strNUAGENC, String strNUCONTA, String strCOCLIEN)
			throws WebServiceException;

	public String consultarSocio(String strPENUMPE) throws WebServiceException;

	public String consultarClientePJ(String strCODENT, String strTPDOCTO, String strNUDOCTO, String strCDALERT)
			throws WebServiceException;

	public String consultarClientePF(String strTPDOCTO, String strNUDOCTO, String strCDENTID, String strCDALERT)
			throws WebServiceException;

	public String consultarClientePE(String strCOENTID, String strTPDOCTO, String strNUDOCTO)
			throws WebServiceException;

	public String log(String strTexto) throws WebServiceException;
}
