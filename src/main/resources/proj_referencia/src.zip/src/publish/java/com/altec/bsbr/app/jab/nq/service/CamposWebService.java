package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException; 

 public interface CamposWebService{ 
	public String listarCampos(String strCodSist, String strCodUser) throws WebServiceException;

		public String consultarCampos(String strCodSist, String strCodCampo, String strCodUser) throws WebServiceException;

		public String incluirCampos(String strCodSist, String strTpCampo, String strDescCampo, String strTamCampo,
				String strPosIni, String strAtivo, String strCodUser) throws WebServiceException;

		public String alterarCampos(String strCodSist, String strCodCampo, String strTpCampo, String strDescCampo,
				String strTamCampo, String strPosIni, String strAtivo, String strCodUser) throws WebServiceException;

		public String excluirCampos(String strCodSist, String strCodCampo, String strCodUser) throws WebServiceException;

		public String inicializarinputArea(String tNQ_NQAT2002_NQCETB02_ENTRADA) throws WebServiceException;

		public String fnAddCaracter(String Vlr, String Tp, String Tam) throws WebServiceException;
	}
 
 

