package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface ParamMonitorWebService {
	public String versao() throws WebServiceException;

	public String listaTipoMovimentoMonitorado(String strCOSIGLA, String strNUSEQSI, String strCODETIN,
			String strCOOPINT, String strNOOPEIN, String strIDORDPA) throws WebServiceException;

	public String incluirTipoMovimentoMonitorado(String strCOSIGLA, String strNUSEQSI, String strCODETIN,
			String strCOOPINT, String strNOOPEIN, String strICMONIT, String strTPOPERA, String strDTHROPE,
			String strCDUSRES, String strTPMANUT) throws WebServiceException;

	public String montarComboProduto(String strCOPRSPR) throws WebServiceException;
}
