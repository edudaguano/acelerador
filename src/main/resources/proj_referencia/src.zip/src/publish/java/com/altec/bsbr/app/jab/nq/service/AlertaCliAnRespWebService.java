package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface AlertaCliAnRespWebService{ 
public String versao() throws WebServiceException; 
public String recuperarPergunta(String strCOENTID,String strCOALERT) throws WebServiceException; 
public String consultarHistorico(String strCOENTID,String strCOALERT,String strDTCOMIT,String strNUSEQUE) throws WebServiceException; 
public String consultarJustificativa(String strCOENTI,String strCOALER) throws WebServiceException; 
public String consultarEnquadramento(String strCOENTID,String strCOALERT,String strCOORGEN,String strCOENQSI) throws WebServiceException; 
public String consultaOrgaoEnquadramento(String strCORGENQ) throws WebServiceException; 
}

