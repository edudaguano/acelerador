package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface PareceresACWebService {
	
	public String consultarRegistros(String strCodSist, String strBanco, String strCodCliente, String strDtOcorrenca,
			String strNotUPLD, String strRegra, String strIndParecer, String strPeriodo, String strCodUser) throws WebServiceException;

	public String incluirPareceres(String strCodSist, String strBanco, String strCodCliente, String strDtOcorrenca,
			String strNotUPLD, String strRegra, String strIndParecer, String strPeriodo, String strTxtParecer,
			String strCodUser) throws WebServiceException;

	public String alterarPareceres(String strCodSist,String strBanco,String strCodCliente,String strDtOcorrenca,String strNotUPLD,String strRegra,String strIndParecer,String strPeriodo,String strTxtParecer,String strCodUser) throws WebServiceException;

	public String inicializarinputArea(String tNQ_NQAT2010_NQCETB10_Entrada) throws WebServiceException;

	public String fnAddCaracter(String vlr,String tp,String tam) throws WebServiceException;

	public String dataAlta(String dtBaixa) throws WebServiceException; 
}
