package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface ParticipaComiteWebService {
	public String versao() throws WebServiceException;

	public String consultarMatricula(String strNUMATRI) throws WebServiceException;

	public String consultarParticipante(String strTPUORCM, String strCDUORCM, String strDTCOMIT)
			throws WebServiceException;

	public String inserirParticipante(String strTPUNIOR, String strCDAGENC, String strDTCOMIT, String strNMMATR1,
			String strDSCARG1, String strNMMATR2, String strDSCARG2, String strNMMATR3, String strDSCARG3,
			String strNMMATR4, String strDSCARG4, String strNMMATR5, String strDSCARG5, String strNMMATR6,
			String strDSCARG6, String strNMMATR7, String strDSCARG7, String strNMMATR8, String strDSCARG8,
			String strNMMATR9, String strDSCARG9, String strNMMATR10, String strDSCARG10, String strCDUSRES)
			throws WebServiceException;
}
