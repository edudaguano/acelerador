package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface ParamAuditoriaWebService{ 
	public String listarParametro(String strCodSist, String strCodUser) throws WebServiceException;

	public String consultarParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodUser) throws WebServiceException;

	public String incluirParametro(String strCodSist, String strCodCamp, String strCodDomin, String strCntd1,
			String strCntd2, String strCodList, String strDesc, String strCodUser, String strDtIncAlt, String strAtivo) throws WebServiceException;

	public String alterarParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodDomin,
			String strCntd1, String strCntd2, String strCodList, String strDesc, String strCodUser, String strDtIncAlt,
			String strAtivo) throws WebServiceException;

	public String excluirParametro(String strCodSist, String strCodCamp, String strCodParam, String strCodUser) throws WebServiceException;

	public String inicializarinputArea(String TNQ_NQAT2006_NQCETB06_INPUT_AREA) throws WebServiceException;

	public String fnAddCaracter(String Vlr, String Tp, String Tam) throws WebServiceException;
 
}
