package com.altec.bsbr.app.jab.nq.service;

import com.altec.bsbr.fw.webservice.WebServiceException;

public interface OcupacaoWebService {

	public String consOcupCadastradas(String intBanco, String intPeriodicidade) throws WebServiceException;

	public String recuperaDados(String intOcupacao) throws WebServiceException;

	public String incluirOcupacao(String intBanco, String intPeriod, String intCodOcup, String strDescOcup,
			String strUserId) throws WebServiceException;

	public String consultarBancoProdPeriod() throws WebServiceException;

	public String exclusaoOcupacao(String intBanco, String intPeriod, String intCodOcup, String strUsuario) throws WebServiceException;

}
