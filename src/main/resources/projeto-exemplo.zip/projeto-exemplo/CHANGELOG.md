# Changelog

## 1.0.0 (14-01-2020)

## Novidades

- Implementação dos módulos `afe/@http-interceptors` e `afe/@encryption`
- Equalização das dependências do projeto no `package.json`

## 0.1.2 (19-11-2019)

### Novidades
- Criação da tag 0.1.2
- Atualização do package.json para versões das libs exatas