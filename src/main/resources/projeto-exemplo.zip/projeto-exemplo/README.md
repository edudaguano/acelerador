A aplicação de referência foi desenvolvida com o intuito de disponibilizar aos desenvolvedores uma aplicação funcional com a implementação básica das peças de arquitetura.

Ela pode ser acessada atráves [deste link](https://afe.paas.santanderbr.pre.corp/aplicacao-referencia/).

## Peças da arquitetura integradas na aplicação

- [Http Interceptors](https://confluence.santanderbr.corp/display/AFE/Http+Interceptors)
- [Encryption](https://confluence.santanderbr.corp/display/AFE/Encryption)

## Pré-requisitos

Ter o ambiente de trabalho configurado, como apontado no link: [Configuração da Área de Trabalho](https://confluence.santanderbr.corp/pages/viewpage.action?pageId=138975409).

## Como executar a aplicação

1) Clone o repositório da aplicação de referência em uma pasta de sua preferência:

```
git clone https://gitlab.santanderbr.corp/afe/OUTROS/aplicacao-referencia.git
```

2) Entre na pasta criada ao clonar o repositório:

```
git clone cd aplicacao-referencia
```

3) Execute o comando abaixo para instalar as dependências do projeto:

```
npm install
```

4) Por fim, rode a aplicação:

```
npm start
```

Após o deploy, a aplicação de referência ficará disponível em http://localhost:4200/