export class MBSGroups {
    groups: Groups;
}

export class Groups {
    group: Array<Group>;
}

export class Group {
    code: string;
    name: string;
}
