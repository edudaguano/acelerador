export interface User {
    id: number;
    name: string;
    address: string;
}