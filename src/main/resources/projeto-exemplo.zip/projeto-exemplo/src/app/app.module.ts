import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HubConnectorInterceptorModule, RootConfig, Storages } from '@afe/http-interceptors/hub-connector';
import { SSOInterceptorModule, SSOnterceptorConfig } from '@afe/http-interceptors/sso';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { $componentImport$} from './pages/$foldername$/$componentname$'

import { EncryptionModule, RootConfig as RootConfigEncryption } from '@afe/encryption';
import { urlConfig } from './config/url.config';

export const hubConnectorConfig: RootConfig = {
  urlsToIntercept: [
    '/hub-url'
  ],
  urlsToIgnore: [],
  storage: {
      keys: {
          jwt: 'jwt',
          xUid: 'x-uid',
      },
      type: Storages.LocalStorage,
  },
};

export const ssoConfig: SSOnterceptorConfig = {
  urlsSSO: [
    urlConfig.sso
  ]
}


@export const configEncryption: RootConfigEncryption = {
  url: '/hub-url/cryptographic-security/v1/key/public/js?gw-app-key=fd6cbf70165f013503fc0050569009ca',
  systemCode: 'SPA',
};

@NgModule({
  declarations: [
      AppComponent,
  ],
  imports: [
      BrowserModule,
      FormsModule,
      AppRoutingModule,
      HttpClientModule,
      HubConnectorInterceptorModule.forRoot(hubConnectorConfig),
      EncryptionModule.forRoot(configEncryption),
      SSOInterceptorModule.forRoot(ssoConfig)
  ],
  bootstrap: [AppComponent],
  providers : [
    HttpClientModule
  ]
})
export class AppModule { }
