export const urlConfig = Object.freeze({
    sso: '/hub-sso-url/sso/authenticate/internal-front?gw-app-key=fd6cbf70165f013503fc0050569009ca',
    changeKeys: '/hub-url/cryptographic-security/v1/key/public/js?gw-app-key=fd6cbf70165f013503fc0050569009ca',
});
