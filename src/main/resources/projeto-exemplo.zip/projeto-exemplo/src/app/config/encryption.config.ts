import { RootConfig } from '@afe/encryption';
import { urlConfig } from './url.config';

export const encryptionConfig: RootConfig = {
    url: urlConfig.changeKeys,
    systemCode: 'SPA',
};

