import { RootConfig, Storages } from '@afe/http-interceptors/hub-connector';

export const hubConnectorConfig: RootConfig = {
    urlsToIntercept: [
        'hub-url',
        'cryptographic-security/v1/key/public/js'
    ],
    storage: {
        keys: {
            jwt: 'jwt',
            xUid: 'x-uid',
        },
        type: Storages.LocalStorage,
    },
};
