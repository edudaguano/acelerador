import { TestBed, ComponentFixture } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { EncryptionService} from '@afe/encryption';
import { FormsModule } from '@angular/forms';

describe('AppComponent', () => {
  let app: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  
  let mockEncryptionService;
  
  beforeEach((() => {    

    mockEncryptionService = jasmine.createSpyObj([
      'isInitialized', 
      'changeKeys',
      'encrypt',
      'decrypt',
      'encryptHashPassword',
      'encryptToDLB',
      'encryptToMF',
      'sign',
      'getPublicServerKey',
      'getTicket'
    ]);

    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule,
        HttpClientTestingModule,
      ],
      declarations: [
        AppComponent
      ],
      providers: [
        { provide : EncryptionService, useValue: mockEncryptionService }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);

    mockEncryptionService = TestBed.get( EncryptionService );
  }));
  
  it(`should create the app `, () => {
    app = fixture.debugElement.componentInstance;

    expect(app).toBeTruthy();
  }); 

  it(`should have as title 'Aplicacao de Referencia'`, () => {
    app = fixture.debugElement.componentInstance;

    expect(app.title).toEqual('Aplicacao de Referencia');
  });

  it('should render title in a h1 tag', () => {
    let dom = fixture.debugElement.nativeElement;

    expect(dom.querySelector('h1').textContent).toContain('Bem-vindo ao Scaffold Santander!');
  });

  it('should call isInitialized', () => {
    fixture.componentInstance.isInitialized();
    
    expect(mockEncryptionService.isInitialized).toHaveBeenCalledTimes(1);
  });

  it('should call encrypt', () => {
    fixture.componentInstance.encrypt();
    
    expect(mockEncryptionService.encrypt).toHaveBeenCalledTimes(1);
  });

  it('should call encryptHashPassword', () => {
    fixture.componentInstance.encryptHashPassword();
    
    expect(mockEncryptionService.encryptHashPassword).toHaveBeenCalledTimes(1);
  });

  it('should call encryptToDLB', () => {
    fixture.componentInstance.encryptToDLB();
    
    expect(mockEncryptionService.encryptToDLB).toHaveBeenCalledTimes(1);
  });

  it('should call encryptToMF', () => {
    fixture.componentInstance.encryptToMF();
    
    expect(mockEncryptionService.encryptToMF).toHaveBeenCalledTimes(1);
  });

  it('should call sign', () => {
    fixture.componentInstance.sign();
    
    expect(mockEncryptionService.sign).toHaveBeenCalledTimes(1);
  });

  it('should call getPublicServerKey', () => {
    fixture.componentInstance.getPublicServerKey();
    
    expect(mockEncryptionService.getPublicServerKey).toHaveBeenCalledTimes(1);
  });

  it('should call getTicket', () => {
    fixture.componentInstance.getTicket();
    
    expect(mockEncryptionService.getTicket).toHaveBeenCalledTimes(1);
  });
});