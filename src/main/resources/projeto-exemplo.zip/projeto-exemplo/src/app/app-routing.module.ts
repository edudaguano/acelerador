import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { $componentImport$} from './pages/$foldername$/$componentname$'


const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
